/**
 * PayrollPro — app.js
 * Sidebar, dropdowns, notifications, modals, flash, dark mode, themes
 */
'use strict';

/* ══════════════════════════════════════════════════════════
   THEME PALETTE — defined immediately so applyTheme() works
══════════════════════════════════════════════════════════ */
var THEMES = {
  default: {
    label:'Default', iconColor:'#6366f1',
    vars:{'--theme-primary':'#6366f1','--theme-secondary':'#8b5cf6','--theme-accent':'#a855f7','--theme-sidebar-from':'#0f172a','--theme-sidebar-to':'#1e293b','--theme-active-bg':'rgba(99,102,241,.18)','--theme-active-border':'#6366f1','--theme-active-icon':'#a5b4fc','--theme-brand-icon-from':'#6366f1','--theme-brand-icon-to':'#8b5cf6'}
  },
  neon: {
    label:'Neon', iconColor:'#00e676',
    vars:{'--theme-primary':'#00e676','--theme-secondary':'#ff00ff','--theme-accent':'#00bcd4','--theme-sidebar-from':'#050510','--theme-sidebar-to':'#0a0a1a','--theme-active-bg':'rgba(0,230,118,.15)','--theme-active-border':'#00e676','--theme-active-icon':'#00ff88','--theme-brand-icon-from':'#00e676','--theme-brand-icon-to':'#ff00ff'}
  },
  sunset: {
    label:'Sunset', iconColor:'#f97316',
    vars:{'--theme-primary':'#f97316','--theme-secondary':'#ec4899','--theme-accent':'#f43f5e','--theme-sidebar-from':'#1c0a00','--theme-sidebar-to':'#2d1200','--theme-active-bg':'rgba(249,115,22,.18)','--theme-active-border':'#f97316','--theme-active-icon':'#fdba74','--theme-brand-icon-from':'#f97316','--theme-brand-icon-to':'#ec4899'}
  },
  ocean: {
    label:'Ocean', iconColor:'#0ea5e9',
    vars:{'--theme-primary':'#0ea5e9','--theme-secondary':'#06b6d4','--theme-accent':'#0284c7','--theme-sidebar-from':'#0c1a2e','--theme-sidebar-to':'#0f2744','--theme-active-bg':'rgba(14,165,233,.18)','--theme-active-border':'#0ea5e9','--theme-active-icon':'#7dd3fc','--theme-brand-icon-from':'#0ea5e9','--theme-brand-icon-to':'#06b6d4'}
  },
  forest: {
    label:'Forest', iconColor:'#16a34a',
    vars:{'--theme-primary':'#16a34a','--theme-secondary':'#15803d','--theme-accent':'#14532d','--theme-sidebar-from':'#052e16','--theme-sidebar-to':'#14532d','--theme-active-bg':'rgba(22,163,74,.18)','--theme-active-border':'#16a34a','--theme-active-icon':'#86efac','--theme-brand-icon-from':'#16a34a','--theme-brand-icon-to':'#15803d'}
  },
  rose: {
    label:'Rose', iconColor:'#f43f5e',
    vars:{'--theme-primary':'#f43f5e','--theme-secondary':'#e11d48','--theme-accent':'#be123c','--theme-sidebar-from':'#1a0010','--theme-sidebar-to':'#2d0020','--theme-active-bg':'rgba(244,63,94,.18)','--theme-active-border':'#f43f5e','--theme-active-icon':'#fda4af','--theme-brand-icon-from':'#f43f5e','--theme-brand-icon-to':'#e11d48'}
  },
  flower: {
    label:'Flower', iconColor:'#d946ef',
    vars:{'--theme-primary':'#d946ef','--theme-secondary':'#a21caf','--theme-accent':'#86198f','--theme-sidebar-from':'#1a0020','--theme-sidebar-to':'#2d0040','--theme-active-bg':'rgba(217,70,239,.18)','--theme-active-border':'#d946ef','--theme-active-icon':'#f0abfc','--theme-brand-icon-from':'#d946ef','--theme-brand-icon-to':'#a21caf'}
  },
  midnight: {
    label:'Midnight', iconColor:'#818cf8',
    vars:{'--theme-primary':'#818cf8','--theme-secondary':'#6366f1','--theme-accent':'#4f46e5','--theme-sidebar-from':'#05050f','--theme-sidebar-to':'#0f0f23','--theme-active-bg':'rgba(129,140,248,.18)','--theme-active-border':'#818cf8','--theme-active-icon':'#c7d2fe','--theme-brand-icon-from':'#818cf8','--theme-brand-icon-to':'#312e81'}
  },
  amber: {
    label:'Amber', iconColor:'#f59e0b',
    vars:{'--theme-primary':'#f59e0b','--theme-secondary':'#d97706','--theme-accent':'#b45309','--theme-sidebar-from':'#1c1000','--theme-sidebar-to':'#2d1a00','--theme-active-bg':'rgba(245,158,11,.18)','--theme-active-border':'#f59e0b','--theme-active-icon':'#fcd34d','--theme-brand-icon-from':'#f59e0b','--theme-brand-icon-to':'#d97706'}
  },
  slate: {
    label:'Slate', iconColor:'#64748b',
    vars:{'--theme-primary':'#475569','--theme-secondary':'#334155','--theme-accent':'#1e293b','--theme-sidebar-from':'#0f172a','--theme-sidebar-to':'#1e293b','--theme-active-bg':'rgba(71,85,105,.25)','--theme-active-border':'#64748b','--theme-active-icon':'#94a3b8','--theme-brand-icon-from':'#475569','--theme-brand-icon-to':'#1e293b'}
  }
};

window.applyTheme = function(name, swatchEl) {
  var theme = THEMES[name];
  if (!theme) return;
  var root = document.documentElement;
  Object.keys(theme.vars).forEach(function(k) { root.style.setProperty(k, theme.vars[k]); });
  var icon = document.getElementById('themePickerIcon');
  if (icon) icon.style.color = theme.iconColor;
  document.querySelectorAll('.theme-swatch').forEach(function(s) { s.classList.remove('active'); });
  if (swatchEl) swatchEl.classList.add('active');
  localStorage.setItem('payrollTheme', name);
  if (typeof showToast === 'function') showToast(theme.label + ' theme applied!', 'success');
};

/* Restore saved theme immediately (before DOM ready) */
(function() {
  var saved = localStorage.getItem('payrollTheme') || 'default';
  var theme = THEMES[saved];
  if (!theme) return;
  var root = document.documentElement;
  Object.keys(theme.vars).forEach(function(k) { root.style.setProperty(k, theme.vars[k]); });
}());

/* ══════════════════════════════════════════════════════════
   DARK MODE — defined immediately (not inside DOMContentLoaded)
   so the inline onclick="toggleDarkMode()" always works
══════════════════════════════════════════════════════════ */
window.toggleDarkMode = function () {
  var html   = document.documentElement;
  var isDark = html.getAttribute('data-theme') === 'dark';

  if (isDark) {
    html.removeAttribute('data-theme');
    localStorage.setItem('darkMode', 'false');
  } else {
    html.setAttribute('data-theme', 'dark');
    localStorage.setItem('darkMode', 'true');
  }

  _syncDarkModeIcon();
  _syncDarkModeTopbar();
};

function _syncDarkModeIcon() {
  var icon   = document.getElementById('darkModeIcon');
  var btn    = document.getElementById('darkModeToggle');
  if (!icon) return;

  var isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  icon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';

  if (btn) {
    btn.title = isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode';
    btn.style.color = isDark ? '#fbbf24' : '';
  }
}

/* Sync topbar background — the topbar has an inline-style-like class
   that needs to respond to dark mode */
function _syncDarkModeTopbar() {
  var topbar = document.querySelector('.topbar');
  if (!topbar) return;
  var isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  topbar.style.background    = isDark ? 'rgba(15,23,42,0.97)' : '';
  topbar.style.borderColor   = isDark ? '#334155' : '';
  topbar.style.boxShadow     = isDark ? '0 1px 3px rgba(0,0,0,.3)' : '';
}

/* Run on every page load to sync state */
(function _initDarkMode() {
  _syncDarkModeIcon();
  _syncDarkModeTopbar();
}());

document.addEventListener('DOMContentLoaded', function () {
  _syncDarkModeIcon();
  _syncDarkModeTopbar();

  /* ── Sidebar toggle ── */
  var sidebar        = document.getElementById('sidebar');
  var mainWrapper    = document.getElementById('mainWrapper');
  var sidebarOverlay = document.getElementById('sidebarOverlay');
  var topbarMenuBtn  = document.getElementById('topbarMenuBtn');
  var sidebarToggle  = document.getElementById('sidebarToggle');

  function openSidebar() {
    if (!sidebar) return;
    sidebar.classList.add('open');
    if (sidebarOverlay) sidebarOverlay.style.display = 'block';
  }

  window.closeSidebar = function () {
    if (!sidebar) return;
    sidebar.classList.remove('open');
    if (sidebarOverlay) sidebarOverlay.style.display = 'none';
  };

  function toggleSidebar() {
    if (window.innerWidth <= 1024) {
      sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    } else {
      // Desktop collapse
      sidebar && sidebar.classList.toggle('collapsed');
      if (mainWrapper) {
        mainWrapper.style.marginLeft = sidebar.classList.contains('collapsed') ? '72px' : '260px';
      }
    }
  }

  topbarMenuBtn && topbarMenuBtn.addEventListener('click', toggleSidebar);
  sidebarToggle && sidebarToggle.addEventListener('click', toggleSidebar);

  /* ── Notification dropdown ── */
  var notifBtn      = document.getElementById('notifBtn');
  var notifDropdown = document.getElementById('notifDropdown');
  var profileBtn    = document.getElementById('profileBtn');
  var profileDrop   = document.getElementById('profileDropdown');

  function closeAllDropdowns() {
    notifDropdown && notifDropdown.classList.remove('open');
    profileDrop   && profileDrop.classList.remove('open');
  }

  notifBtn && notifBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    var isOpen = notifDropdown.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) {
      notifDropdown.classList.add('open');
      loadNotifications();
    }
  });

  profileBtn && profileBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    var isOpen = profileDrop.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) profileDrop.classList.add('open');
  });

  document.addEventListener('click', closeAllDropdowns);

  /* ── Mark all read ── */
  var markAllBtn = document.getElementById('markAllRead');
  markAllBtn && markAllBtn.addEventListener('click', function () {
    ajax('POST', 'notifications/read-all', {}, function () {
      var badge = document.getElementById('notifBadge');
      if (badge) badge.style.display = 'none';
      document.querySelectorAll('.notif-item.unread').forEach(function (el) {
        el.classList.remove('unread');
      });
    });
  });

  /* ── Auto-dismiss flash ── */
  var flash = document.getElementById('flashMsg');
  if (flash) setTimeout(function () {
    flash.style.transition = 'opacity .4s';
    flash.style.opacity = '0';
    setTimeout(function () { flash.remove(); }, 400);
  }, 5000);

  /* ── Modal helpers ── */
  window.openModal = function (id) {
    var m = document.getElementById(id);
    if (m) { m.style.display = 'flex'; document.body.style.overflow = 'hidden'; }
  };
  window.closeModal = function (id) {
    var m = document.getElementById(id);
    if (m) { m.style.display = 'none'; document.body.style.overflow = ''; }
  };

  document.querySelectorAll('.modal-overlay').forEach(function (overlay) {
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closeModal(overlay.id);
    });
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay[style*="flex"]').forEach(function (m) {
        m.style.display = 'none';
        document.body.style.overflow = '';
      });
    }
  });

  /* ── Avatar preview ── */
  document.querySelectorAll('.avatar-upload-input, input[type="file"][accept*="image"]').forEach(function (input) {
    input.addEventListener('change', function () {
      var preview = document.querySelector('.avatar-preview, #avatarPreview');
      if (preview && this.files[0]) {
        preview.src = URL.createObjectURL(this.files[0]);
      }
    });
  });

  /* ── Live clock ── */
  var clockEl = document.getElementById('liveClock');
  if (clockEl) {
    var tick = function () {
      clockEl.textContent = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      });
    };
    tick();
    setInterval(tick, 1000);
  }

  /* ── Confirm delete ── */
  document.querySelectorAll('[data-confirm]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      if (!confirm(btn.dataset.confirm || 'Are you sure?')) e.preventDefault();
    });
  });

  /* ── Clickable table rows ── */
  document.querySelectorAll('tr[data-href]').forEach(function (row) {
    row.style.cursor = 'pointer';
    row.addEventListener('click', function () { window.location = row.dataset.href; });
  });

  /* ── Load notifications on page load ── */
  loadNotifications();

  /* ── Theme picker dropdown toggle ── */
  var themeBtn  = document.getElementById('themePickerBtn');
  var themeDrop = document.getElementById('themePickerDropdown');

  if (themeBtn && themeDrop) {
    themeBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      var isOpen = themeDrop.classList.contains('open');
      // Close all other dropdowns first
      closeAllDropdowns();
      if (!isOpen) {
        themeDrop.classList.add('open');
      }
    });
  }

  /* Extend closeAllDropdowns to also close theme picker */
  var _origClose = closeAllDropdowns;
  closeAllDropdowns = function() {
    _origClose();
    if (themeDrop) themeDrop.classList.remove('open');
  };

  /* Sync active swatch from saved theme */
  var savedTheme = localStorage.getItem('payrollTheme') || 'default';
  var activeSwatch = document.querySelector('[data-theme-name="' + savedTheme + '"]');
  if (activeSwatch) {
    document.querySelectorAll('.theme-swatch').forEach(function(s) { s.classList.remove('active'); });
    activeSwatch.classList.add('active');
  }
  var themeIcon = document.getElementById('themePickerIcon');
  if (themeIcon && THEMES[savedTheme]) {
    themeIcon.style.color = THEMES[savedTheme].iconColor;
  }

  /* ── Ripple keyframe (inject once) ── */
  if (!document.getElementById('rippleStyle')) {
    var s = document.createElement('style');
    s.id = 'rippleStyle';
    s.textContent = '@keyframes ripple{0%{transform:scale(0);opacity:.6}100%{transform:scale(2.5);opacity:0}}';
    document.head.appendChild(s);
  }

  /* ── Button ripple effect ── */
  document.addEventListener('click', function(e) {
    var btn = e.target.closest('.btn');
    if (!btn || btn.disabled) return;

    var rect   = btn.getBoundingClientRect();
    var size   = Math.max(rect.width, rect.height) * 1.4;
    var x      = e.clientX - rect.left - size / 2;
    var y      = e.clientY - rect.top  - size / 2;

    var ripple = document.createElement('span');
    ripple.style.cssText = [
      'position:absolute',
      'border-radius:50%',
      'background:rgba(255,255,255,0.3)',
      'width:'  + size + 'px',
      'height:' + size + 'px',
      'left:'   + x    + 'px',
      'top:'    + y    + 'px',
      'transform:scale(0)',
      'animation:ripple 0.55s linear',
      'pointer-events:none'
    ].join(';');

    // Outline buttons get a colored ripple
    if (btn.classList.contains('btn-outline')) {
      ripple.style.background = 'rgba(99,102,241,0.15)';
    }

    btn.appendChild(ripple);
    setTimeout(function() { ripple.remove(); }, 600);
  });
});

/* ── Load Notifications ── */
function loadNotifications() {
  ajax('GET', 'notifications', {}, function (data) {
    var badge = document.getElementById('notifBadge');
    var list  = document.getElementById('notifList');
    if (!list) return;

    var count = data.unread_count || 0;
    if (badge) {
      badge.textContent = count > 9 ? '9+' : count;
      badge.style.display = count > 0 ? 'flex' : 'none';
    }

    if (!data.notifications || !data.notifications.length) {
      list.innerHTML = '<div class="notif-empty"><i class="fas fa-check-circle"></i><span>All caught up!</span></div>';
      return;
    }

    var iconMap = {
      payroll: 'fa-money-bill-wave notif-icon-payroll',
      success: 'fa-check-circle notif-icon-success',
      warning: 'fa-exclamation-triangle notif-icon-warning',
      info:    'fa-info-circle notif-icon-info',
      leave:   'fa-calendar-check notif-icon-info',
      danger:  'fa-exclamation-circle notif-icon-warning'
    };

    list.innerHTML = data.notifications.map(function (n) {
      var iconClass = iconMap[n.type] || 'fa-bell notif-icon-info';
      var faIcon    = iconClass.split(' ')[0];
      var bgClass   = iconClass.split(' ')[1] || 'notif-icon-info';
      return '<div class="notif-item ' + (n.is_read ? '' : 'unread') + '" onclick="markNotifRead(' + n.id + ',this)">' +
        '<div class="notif-item-icon ' + bgClass + '"><i class="fas ' + faIcon + '"></i></div>' +
        '<div style="flex:1">' +
          '<div class="notif-item-msg">' + escHtml(n.message) + '</div>' +
          '<div class="notif-item-time">' + timeAgo(n.created_at) + '</div>' +
        '</div>' +
      '</div>';
    }).join('');
  });
}

function markNotifRead(id, el) {
  ajax('POST', 'notifications/read/' + id, {}, function () {
    el && el.classList.remove('unread');
  });
}

function timeAgo(datetime) {
  var diff = Math.floor((Date.now() - new Date(datetime)) / 1000);
  if (diff < 60)     return 'just now';
  if (diff < 3600)   return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400)  return Math.floor(diff / 3600) + 'h ago';
  return Math.floor(diff / 86400) + 'd ago';
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
