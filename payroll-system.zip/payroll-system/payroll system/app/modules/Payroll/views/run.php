﻿<?php
// Position allowance config for JS
$posConfig = [
    'CEO'             => ['rate' => 0.10, 'taxable' => false],
    'COO'             => ['rate' => 0.08, 'taxable' => true],
    'CTO'             => ['rate' => 0.08, 'taxable' => true],
    'CISO'            => ['rate' => 0.08, 'taxable' => true],
    'Director'        => ['rate' => 0.07, 'taxable' => true],
    'Dept Head'       => ['rate' => 0.05, 'taxable' => true],
    'Normal Employee' => ['rate' => 0,    'taxable' => true],
];
$posConfigJson = json_encode($posConfig);
?>

<div class="page-header">
  <div>
    <div class="page-header-title">Run Payroll</div>
    <div class="page-header-sub">Process monthly salaries with Ethiopian tax rules</div>
  </div>
  <a href="<?= url('payroll') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem">

  <!-- Left: Run Payroll -->
  <div>
    <div class="card" style="margin-bottom:1.25rem">
      <div class="card-header">
        <span class="card-title"><i class="fas fa-play-circle" style="color:#10b981;margin-right:8px"></i>Process Monthly Payroll</span>
      </div>
      <div class="card-body">
        <div style="background:#f0fdf4;border:1.5px solid #bbf7d0;border-radius:10px;padding:14px;margin-bottom:18px;font-size:.82rem;color:#065f46">
          <strong><i class="fas fa-info-circle"></i> Ethiopian Payroll Rules Applied:</strong>
          <ul style="padding-left:16px;margin-top:6px;line-height:2">
            <li>Earned Salary = Worked Days &times; (Basic &divide; 30)</li>
            <li>CEO: 10% position allowance (non-taxable)</li>
            <li>COO/CTO/CISO/Director/Dept Head: taxable position allowance</li>
            <li>Positioned employees: 2,220 ETB transport (non-taxable)</li>
            <li>Normal employees: 600 ETB transport (non-taxable)</li>
            <li>Full-time: Employee 7% + Employer 11% pension</li>
            <li>Ethiopian progressive income tax slabs</li>
          </ul>
        </div>

        <form id="runPayrollForm">
          <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
          <div class="form-group">
            <label class="form-label">Pay Month <span class="required">*</span></label>
            <input type="month" name="month" class="form-control" value="<?= e($month) ?>" required>
          </div>
          <button type="button" class="btn btn-success btn-lg" style="width:100%" onclick="runPayroll()" id="runBtn">
            <i class="fas fa-play-circle"></i> Run Payroll for All Employees
          </button>
        </form>

        <div id="runResults" style="display:none;margin-top:16px"></div>
      </div>
    </div>

    <!-- Active Employees -->
    <div class="card">
      <div class="card-header">
        <span class="card-title"><i class="fas fa-users" style="color:#6366f1;margin-right:8px"></i>Active Employees (<?= count($employees) ?>)</span>
      </div>
      <div style="max-height:380px;overflow-y:auto">
        <table style="width:100%;border-collapse:collapse;font-size:.82rem">
          <thead>
            <tr style="background:#f8fafc">
              <th style="padding:8px 12px;text-align:left;font-size:.7rem;font-weight:700;text-transform:uppercase;color:#94a3b8;border-bottom:1px solid #e2e8f0">Employee</th>
              <th style="padding:8px 12px;text-align:left;font-size:.7rem;font-weight:700;text-transform:uppercase;color:#94a3b8;border-bottom:1px solid #e2e8f0">Position</th>
              <th style="padding:8px 12px;text-align:right;font-size:.7rem;font-weight:700;text-transform:uppercase;color:#94a3b8;border-bottom:1px solid #e2e8f0">Basic</th>
              <th style="padding:8px 12px;text-align:center;font-size:.7rem;font-weight:700;text-transform:uppercase;color:#94a3b8;border-bottom:1px solid #e2e8f0">Type</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($employees as $emp): ?>
            <tr style="border-bottom:1px solid #f1f5f9;cursor:pointer" onclick="loadPreview(<?= $emp['id'] ?>)"
                onmouseover="this.style.background='#f0f4ff'" onmouseout="this.style.background=''">
              <td style="padding:9px 12px;font-weight:600;color:#0f172a"><?= e($emp['name'] ?? 'Employee') ?></td>
              <td style="padding:9px 12px;color:#64748b"><?= e($emp['position_title'] ?? $emp['position'] ?? '') ?></td>
              <td style="padding:9px 12px;text-align:right;font-weight:600">ETB <?= number_format((float)$emp['basic_salary'], 0) ?></td>
              <td style="padding:9px 12px;text-align:center">
                <span style="font-size:.68rem;font-weight:700;padding:2px 8px;border-radius:999px;background:<?= ($emp['employment_type']??'full_time')==='full_time'?'#d1fae5':'#dbeafe' ?>;color:<?= ($emp['employment_type']??'full_time')==='full_time'?'#065f46':'#1e40af' ?>">
                  <?= ($emp['employment_type']??'full_time')==='full_time'?'Full-time':'Part-time' ?>
                </span>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Right: Live Calculator -->
  <div>
    <div class="card">
      <div class="card-header">
        <span class="card-title"><i class="fas fa-calculator" style="color:#6366f1;margin-right:8px"></i>Live Payroll Calculator</span>
        <span style="font-size:.75rem;color:#94a3b8">Click an employee to load</span>
      </div>
      <div class="card-body">

        <!-- Manual inputs -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem">Basic Salary (ETB)</label>
            <input type="number" id="calcBasic" class="form-control" placeholder="0.00" step="0.01" oninput="recalculate()">
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem">Worked Days</label>
            <input type="number" id="calcWorkedDays" class="form-control" value="30" min="1" max="31" oninput="recalculate()">
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem">Position Title</label>
            <select id="calcPosition" class="form-control" onchange="recalculate()">
              <?php foreach (array_keys($posConfig) as $pt): ?>
              <option value="<?= $pt ?>"><?= $pt ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem">Employment Type</label>
            <select id="calcEmpType" class="form-control" onchange="recalculate()">
              <option value="full_time">Full-time</option>
              <option value="part_time">Part-time</option>
            </select>
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem">Other / Commission (ETB)</label>
            <input type="number" id="calcOther" class="form-control" value="0" step="0.01" min="0" oninput="recalculate()">
          </div>
        </div>

        <!-- Results Table -->
        <div id="calcResults" style="background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;overflow:hidden">
          <div style="padding:.75rem 1rem;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:.82rem;font-weight:700">
            <i class="fas fa-table"></i> Payroll Breakdown
          </div>
          <table style="width:100%;border-collapse:collapse;font-size:.82rem">
            <tbody id="calcTable">
              <tr><td colspan="2" style="padding:20px;text-align:center;color:#94a3b8">Enter basic salary to calculate</td></tr>
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>

</div>

<script>
var posConfig = <?= $posConfigJson ?>;
var positionedTitles = ['CEO','COO','CTO','CISO','Director','Dept Head'];

// ── Ethiopian Tax Slabs ──────────────────────────────────────
var taxSlabs = [
  [0,      600,    0,    0],
  [601,   1650,   10,   60],
  [1651,  3200,   15,   142.5],
  [3201,  5250,   20,   302.5],
  [5251,  7800,   25,   565],
  [7801, 10900,   30,   965],
  [10901,    0,   35,  1500],
];

function calcEthiopianTax(taxable) {
  if (taxable <= 0) return 0;
  for (var i = 0; i < taxSlabs.length; i++) {
    var s = taxSlabs[i];
    var inRange = taxable >= s[0] && (s[1] === 0 || taxable <= s[1]);
    if (inRange) {
      if (s[2] === 0) return 0;
      return Math.max(0, Math.round((taxable * s[2] / 100 - s[3]) * 100) / 100);
    }
  }
  return 0;
}

function etb(v) { return 'ETB ' + parseFloat(v).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2}); }

function recalculate() {
  var basic       = parseFloat(document.getElementById('calcBasic').value) || 0;
  var workedDays  = parseInt(document.getElementById('calcWorkedDays').value) || 30;
  var position    = document.getElementById('calcPosition').value;
  var empType     = document.getElementById('calcEmpType').value;
  var otherComm   = parseFloat(document.getElementById('calcOther').value) || 0;

  if (basic <= 0) {
    document.getElementById('calcTable').innerHTML = '<tr><td colspan="2" style="padding:20px;text-align:center;color:#94a3b8">Enter basic salary to calculate</td></tr>';
    return;
  }

  // Calculations
  var earnedSalary = Math.round(workedDays * (basic / 30) * 100) / 100;

  var pa = posConfig[position] || { rate: 0, taxable: true };
  var posAllow = Math.round(basic * pa.rate * 100) / 100;
  var posAllowTaxable    = pa.taxable ? posAllow : 0;
  var posAllowNonTaxable = pa.taxable ? 0 : posAllow;

  var isPositioned = positionedTitles.includes(position);
  var transAllow   = isPositioned ? 2220 : 600;
  var transAllowNonTaxable = transAllow;
  var transAllowTaxable    = 0;

  var grossPay     = Math.round((earnedSalary + posAllow + transAllow + otherComm) * 100) / 100;
  var taxableIncome = Math.round((earnedSalary + posAllowTaxable + transAllowTaxable + otherComm) * 100) / 100;
  var incomeTax    = calcEthiopianTax(taxableIncome);

  var empPension   = empType === 'full_time' ? Math.round(basic * 0.07 * 100) / 100 : 0;
  var emplrPension = empType === 'full_time' ? Math.round(basic * 0.11 * 100) / 100 : 0;
  var totalPension = Math.round((empPension + emplrPension) * 100) / 100;
  var totalDed     = Math.round((incomeTax + empPension) * 100) / 100;
  var netPayment   = Math.round((grossPay - totalDed) * 100) / 100;

  var rows = [
    ['Basic Salary',                    etb(basic),              ''],
    ['Worked Days',                     workedDays + ' days',    ''],
    ['Earned Salary',                   etb(earnedSalary),       'color:#6366f1;font-weight:700'],
    ['─── Position Allowance ───',      '',                      'color:#94a3b8;font-size:.72rem'],
    ['  Non-Taxable',                   etb(posAllowNonTaxable), ''],
    ['  Taxable',                       etb(posAllowTaxable),    ''],
    ['─── Transport Allowance ───',     '',                      'color:#94a3b8;font-size:.72rem'],
    ['  Non-Taxable (' + (isPositioned?'2,220':'600') + ' ETB)', etb(transAllowNonTaxable), ''],
    ['  Taxable',                       etb(transAllowTaxable),  ''],
    ['Other / Commission',              etb(otherComm),          ''],
    ['Gross Pay',                       etb(grossPay),           'color:#10b981;font-weight:800;font-size:.9rem'],
    ['Taxable Income',                  etb(taxableIncome),      'color:#6366f1;font-weight:700'],
    ['Income Tax',                      etb(incomeTax),          'color:#ef4444;font-weight:700'],
    ['Employee Pension (7%)',           etb(empPension),         'color:#ef4444'],
    ['Employer Pension (11%)',          etb(emplrPension),       'color:#64748b'],
    ['Total Pension',                   etb(totalPension),       ''],
    ['Total Deductions',                etb(totalDed),           'color:#ef4444;font-weight:800;font-size:.9rem'],
    ['NET PAYMENT',                     etb(netPayment),         'color:#0f172a;font-weight:900;font-size:1rem'],
  ];

  var html = '';
  rows.forEach(function(r) {
    var isTotal = r[0] === 'NET PAYMENT';
    var bg = isTotal ? 'background:linear-gradient(135deg,#6366f1,#8b5cf6)' : '';
    var lc = isTotal ? 'color:#fff' : 'color:#374151';
    var vc = isTotal ? 'color:#fff' : (r[2] || 'color:#0f172a');
    html += '<tr style="border-bottom:1px solid #f1f5f9;' + bg + '">'
          + '<td style="padding:7px 12px;' + lc + ';font-size:.82rem">' + r[0] + '</td>'
          + '<td style="padding:7px 12px;text-align:right;' + vc + ';font-size:.82rem">' + r[1] + '</td>'
          + '</tr>';
  });
  document.getElementById('calcTable').innerHTML = html;
}

function loadPreview(empId) {
  var basic = 0;
  // Find employee in the table and populate calculator
  ajax('GET', 'payroll/preview?employee_id=' + empId, {}, function(data) {
    if (data.success && data.employee) {
      var emp = data.employee;
      document.getElementById('calcBasic').value      = emp.basic_salary || 0;
      document.getElementById('calcWorkedDays').value = 30;
      document.getElementById('calcPosition').value   = emp.position_title || 'Normal Employee';
      document.getElementById('calcEmpType').value    = emp.employment_type || 'full_time';
      document.getElementById('calcOther').value      = emp.other_commission || 0;
      recalculate();
    }
  });
}

function runPayroll() {
  var form  = document.getElementById('runPayrollForm');
  var btn   = document.getElementById('runBtn');
  var month = form.querySelector('[name="month"]').value;

  if (!month) { showToast('Please select a pay month.', 'error'); return; }
  if (!confirm('Run payroll for ' + month + '?\nThis will process all active employees using Ethiopian tax rules.')) return;

  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';

  var fd = new FormData(form);
  ajax('POST', 'payroll/run', fd, function(data) {
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-play-circle"></i> Run Payroll for All Employees';

    if (data.success) {
      showToast(data.message, 'success');
      var r = data.results;
      document.getElementById('runResults').style.display = 'block';
      document.getElementById('runResults').innerHTML =
        '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">'
        + '<div style="background:#d1fae5;border-radius:10px;padding:14px;text-align:center"><div style="font-size:1.5rem;font-weight:800;color:#10b981">' + r.success.length + '</div><div style="font-size:.75rem;color:#065f46;font-weight:600">Processed</div></div>'
        + '<div style="background:#fef3c7;border-radius:10px;padding:14px;text-align:center"><div style="font-size:1.5rem;font-weight:800;color:#f59e0b">' + r.skipped.length + '</div><div style="font-size:.75rem;color:#92400e;font-weight:600">Skipped</div></div>'
        + '<div style="background:#fee2e2;border-radius:10px;padding:14px;text-align:center"><div style="font-size:1.5rem;font-weight:800;color:#ef4444">' + r.errors.length + '</div><div style="font-size:.75rem;color:#991b1b;font-weight:600">Errors</div></div>'
        + '</div>'
        + '<div style="margin-top:12px"><a href="' + (typeof BASE_URL !== \'undefined\' ? BASE_URL : \'\') + '/payroll" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i> View Payroll</a></div>';
    } else {
      showToast(data.message || 'Failed to run payroll.', 'error');
    }
  });
}

// Auto-calculate on load
recalculate();
</script>
