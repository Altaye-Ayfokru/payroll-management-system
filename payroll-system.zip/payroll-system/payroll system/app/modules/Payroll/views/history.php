<div class="page-header">
  <div>
    <div class="page-header-title">Payroll History</div>
    <div class="page-header-sub">All payroll records</div>
  </div>
</div>

<div class="card">
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th>Employee</th>
          <th>Month</th>
          <th>Basic</th>
          <th>Gross</th>
          <th>Net Salary</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($payrolls)): ?>
        <tr><td colspan="7">
          <div class="empty-state">
            <div class="empty-state-icon"><i class="fas fa-history"></i></div>
            <div class="empty-state-title">No payroll history yet</div>
          </div>
        </td></tr>
        <?php else: ?>
        <?php foreach ($payrolls as $p): ?>
        <tr>
          <td>
            <div class="emp-info-name"><?= e($p['employee_name']) ?></div>
            <div class="emp-info-code"><?= e($p['department']) ?></div>
          </td>
          <td><?= e($p['pay_month']) ?></td>
          <td><?= formatCurrency((float)$p['basic_salary']) ?></td>
          <td><?= formatCurrency((float)$p['gross_salary']) ?></td>
          <td><strong style="color:#10b981"><?= formatCurrency((float)$p['net_salary']) ?></strong></td>
          <td><?= statusBadge($p['status']) ?></td>
          <td>
            <a href="<?= url('payroll/payslip/' . $p['id']) ?>" class="btn btn-outline btn-sm">
              <i class="fas fa-file-invoice"></i> Payslip
            </a>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if (isset($pager) && $pager['total_pages'] > 1): ?>
  <div class="pagination">
    <?php if ($pager['has_prev']): ?>
    <a href="?page=<?= $pager['current_page'] - 1 ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a>
    <?php endif; ?>
    <?php for ($i = max(1, $pager['current_page'] - 2); $i <= min($pager['total_pages'], $pager['current_page'] + 2); $i++): ?>
    <a href="?page=<?= $i ?>" class="page-btn <?= $i === $pager['current_page'] ? 'active' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($pager['has_next']): ?>
    <a href="?page=<?= $pager['current_page'] + 1 ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</div>
