﻿<!-- Hero Banner -->
<div class="page-hero hero-payroll">
  <div class="hero-orb hero-orb-1"></div>
  <div class="hero-orb hero-orb-2"></div>
  <div class="page-hero-content">
    <div class="hero-badge"><span class="hero-badge-dot"></span> Payroll Processing</div>
    <div class="page-hero-title">Monthly Payroll</div>
    <div class="page-hero-sub">Process salaries, approve payroll, and generate payslips with Ethiopian tax rules applied automatically.</div>
    <div class="page-hero-actions">
      <a href="<?= url('payroll/run') ?>" class="page-hero-btn page-hero-btn-white">
        <i class="fas fa-play-circle"></i> Run Payroll
      </a>
      <a href="<?= url('payroll/export?month=' . $month) ?>" class="page-hero-btn page-hero-btn-outline">
        <i class="fas fa-download"></i> Export CSV
      </a>
    </div>
  </div>
  <img src="<?= asset('images/hero-payroll.svg') ?>" alt="" class="page-hero-illustration" aria-hidden="true">
</div>

<div class="page-header">
  <div>
    <div class="page-header-title">Payroll</div>
    <div class="page-header-sub">Manage and process employee salaries</div>
  </div>
  <div class="page-header-actions">
    <a href="<?= url('payroll/run') ?>" class="btn btn-primary"><i class="fas fa-play-circle"></i> Run Payroll</a>
    <a href="<?= url('payroll/export?month=' . $month) ?>" class="btn btn-outline"><i class="fas fa-download"></i> Export CSV</a>
  </div>
</div>

<!-- Month Filter -->
<div class="filter-bar">
  <form method="GET" action="<?= url('payroll') ?>" style="display:flex;gap:10px;align-items:center">
    <label class="form-label" style="margin:0;white-space:nowrap">Pay Month:</label>
    <input type="month" name="month" class="form-control" value="<?= e($month) ?>" style="width:auto">
    <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button>
  </form>
</div>

<!-- Summary Cards -->
<?php if (!empty($summary)): ?>
<div class="stats-grid" style="margin-bottom:20px">
  <div class="stat-card stat-card-primary">
    <div class="stat-icon stat-icon-primary"><i class="fas fa-users"></i></div>
    <div class="stat-body">
      <div class="stat-value"><?= $summary['count'] ?></div>
      <div class="stat-label">Employees Processed</div>
    </div>
  </div>
  <div class="stat-card stat-card-success">
    <div class="stat-icon stat-icon-success"><i class="fas fa-money-bill-wave"></i></div>
    <div class="stat-body">
      <div class="stat-value"><?= formatCurrency($summary['total_gross']) ?></div>
      <div class="stat-label">Total Gross</div>
    </div>
  </div>
  <div class="stat-card stat-card-info">
    <div class="stat-icon stat-icon-info"><i class="fas fa-hand-holding-usd"></i></div>
    <div class="stat-body">
      <div class="stat-value"><?= formatCurrency($summary['total_net']) ?></div>
      <div class="stat-label">Total Net Payroll</div>
    </div>
  </div>
  <div class="stat-card stat-card-warning">
    <div class="stat-icon stat-icon-warning"><i class="fas fa-receipt"></i></div>
    <div class="stat-body">
      <div class="stat-value"><?= formatCurrency($summary['total_tax']) ?></div>
      <div class="stat-label">Total Tax</div>
    </div>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th>Employee</th>
          <th>Basic</th>
          <th>Allowances</th>
          <th>Overtime</th>
          <th>Gross</th>
          <th>Deductions</th>
          <th>Tax</th>
          <th>Net Salary</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($payrolls)): ?>
        <tr>
          <td colspan="10">
            <div class="empty-state">
              <div class="empty-state-icon"><i class="fas fa-money-bill-wave"></i></div>
              <div class="empty-state-title">No payroll for <?= e($month) ?></div>
              <div class="empty-state-text"><a href="<?= url('payroll/run') ?>" class="btn btn-primary btn-sm" style="margin-top:10px"><i class="fas fa-play"></i> Run Payroll Now</a></div>
            </div>
          </td>
        </tr>
        <?php else: ?>
        <?php foreach ($payrolls as $p): ?>
        <tr>
          <td>
            <div class="emp-cell">
              <div>
                <div class="emp-info-name"><?= e($p['employee_name']) ?></div>
                <div class="emp-info-code"><?= e($p['department']) ?></div>
              </div>
            </div>
          </td>
          <td><?= formatCurrency((float)$p['basic_salary']) ?></td>
          <td><?= formatCurrency((float)$p['house_allowance'] + (float)$p['transport_allowance'] + (float)$p['medical_allowance']) ?></td>
          <td><?= formatCurrency((float)$p['overtime_pay']) ?></td>
          <td><strong><?= formatCurrency((float)$p['gross_salary']) ?></strong></td>
          <td style="color:#ef4444"><?= formatCurrency((float)$p['total_deductions']) ?></td>
          <td style="color:#f59e0b"><?= formatCurrency((float)$p['tax']) ?></td>
          <td><strong style="color:#10b981"><?= formatCurrency((float)$p['net_salary']) ?></strong></td>
          <td><?= statusBadge($p['status']) ?></td>
          <td>
            <div style="display:flex;gap:5px">
              <a href="<?= url('payroll/payslip/' . $p['id']) ?>" class="btn btn-outline btn-sm btn-icon" title="View Payslip">
                <i class="fas fa-file-invoice"></i>
              </a>
              <?php if ($p['status'] === 'pending'): ?>
              <button class="btn btn-success btn-sm btn-icon" title="Approve"
                      onclick="payrollAction('approve', <?= $p['id'] ?>)">
                <i class="fas fa-check"></i>
              </button>
              <button class="btn btn-danger btn-sm btn-icon" title="Reject"
                      onclick="payrollAction('reject', <?= $p['id'] ?>)">
                <i class="fas fa-times"></i>
              </button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
function payrollAction(action, id) {
  const label = action === 'approve' ? 'approve' : 'reject';
  if (!confirm(`Are you sure you want to ${label} this payroll?`)) return;
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', `payroll/${action}/${id}`, { csrf_token: csrf }, data => {
    if (data.success) { showToast(data.message, 'success'); setTimeout(() => location.reload(), 800); }
    else showToast(data.message || 'Failed', 'error');
  });
}
</script>
