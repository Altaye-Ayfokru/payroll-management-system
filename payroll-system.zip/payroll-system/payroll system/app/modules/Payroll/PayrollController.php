<?php
require_once CORE_PATH . '/Controller.php';
require_once APP_PATH . '/helpers/validator.php';
require_once APP_PATH . '/modules/Payroll/PayrollModel.php';
require_once APP_PATH . '/modules/Payroll/PayrollService.php';
require_once APP_PATH . '/modules/Employee/EmployeeModel.php';

class PayrollController extends Controller {
    private PayrollModel   $model;
    private PayrollService $service;

    public function __construct() {
        $this->model   = new PayrollModel();
        $this->service = new PayrollService();
    }

    public function index(): void {
        $this->requireRole('admin', 'hr');
        $month = $_GET['month'] ?? date('Y-m');
        $page  = max(1, (int)($_GET['page'] ?? 1));
        $pager = paginate($this->model->count(), ITEMS_PER_PAGE, $page);

        $this->view('payroll.index', [
            'payrolls'  => $this->model->getByMonth($month),
            'summary'   => $this->buildSummary($month),
            'month'     => $month,
            'pager'     => $pager,
            'pageTitle' => 'Payroll',
            'flash'     => $this->getFlash(),
            'csrf'      => csrfToken(),
        ]);
    }

    public function runPage(): void {
        $this->requireRole('admin', 'hr');
        $this->view('payroll.run', [
            'month'     => date('Y-m'),
            'employees' => (new EmployeeModel())->findBy('status', 'active'),
            'pageTitle' => 'Run Payroll',
            'csrf'      => csrfToken(),
        ]);
    }

    public function run(): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) { $this->json(['success' => false, 'message' => 'Invalid token'], 403); return; }

        $month   = $_POST['month'] ?? date('Y-m');
        $results = $this->service->runMonthlyPayroll($month, currentUserId());

        logActivity(currentUserId(), "Ran payroll for {$month}");

        if ($this->isAjax()) {
            $this->json([
                'success' => true,
                'message' => count($results['success']) . ' payrolls processed.',
                'results' => $results,
            ]);
            return;
        }
        $this->flash('success', count($results['success']) . ' payrolls processed for ' . $month);
        $this->redirect('payroll');
    }

    /**
     * AJAX: Preview payroll calculation for a single employee
     */
    public function preview(): void {
        $this->requireRole('admin', 'hr');
        $empId = (int)($_GET['employee_id'] ?? 0);
        if (!$empId) { $this->json(['error' => 'Employee ID required'], 400); return; }

        $emp = (new EmployeeModel())->getWithUser($empId);
        if (!$emp) { $this->json(['error' => 'Employee not found'], 404); return; }

        $workedDays = (int)($_GET['worked_days'] ?? 30);
        $emp['other_commission'] = (float)($_GET['other_commission'] ?? $emp['other_commission'] ?? 0);

        $calc = $this->service->preview($emp, $workedDays);
        $this->json(['success' => true, 'data' => $calc, 'employee' => $emp]);
    }

    public function history(): void {
        $this->requireAuth();
        $page  = max(1, (int)($_GET['page'] ?? 1));
        $pager = paginate($this->model->count(), ITEMS_PER_PAGE, $page);

        $this->view('payroll.history', [
            'payrolls'  => $this->model->getWithEmployee(ITEMS_PER_PAGE, $pager['offset']),
            'pager'     => $pager,
            'pageTitle' => 'Payroll History',
        ]);
    }

    public function payslip(string $id): void {
        $this->requireAuth();
        $payslip = $this->model->getPayslip((int)$id);
        if (!$payslip) { $this->redirect('payroll/history'); return; }

        // Employees can only see their own payslip
        if (currentUserRole() === 'employee') {
            $emp = (new EmployeeModel())->getByUserId(currentUserId());
            if (!$emp || $emp['id'] !== (int)$payslip['employee_id']) {
                $this->redirect('dashboard'); return;
            }
        }

        $this->view('payroll.payslip', ['payslip' => $payslip, 'pageTitle' => 'Payslip']);
    }

    public function approve(string $id): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) { $this->json(['success' => false, 'message' => 'Invalid token'], 403); return; }

        $payroll = $this->model->findById((int)$id);
        if (!$payroll) { $this->json(['success' => false, 'message' => 'Not found'], 404); return; }

        $this->model->update((int)$id, [
            'status'      => 'approved',
            'approved_by' => currentUserId(),
            'approved_at' => date('Y-m-d H:i:s'),
        ]);

        // Notify employee
        $emp = (new EmployeeModel())->findById($payroll['employee_id']);
        if ($emp) {
            $db = Database::getInstance();
            $db->prepare(
                "INSERT INTO notifications (user_id,message,type,is_read,created_at)
                 VALUES (:uid,:msg,'success',0,NOW())"
            )->execute([':uid' => $emp['user_id'],
                        ':msg' => "Your payroll for {$payroll['pay_month']} has been approved!"]);
        }

        logActivity(currentUserId(), "Approved payroll #{$id}");
        $this->json(['success' => true, 'message' => 'Payroll approved']);
    }

    public function reject(string $id): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) { $this->json(['success' => false, 'message' => 'Invalid token'], 403); return; }

        $this->model->update((int)$id, ['status' => 'rejected']);
        logActivity(currentUserId(), "Rejected payroll #{$id}");
        $this->json(['success' => true, 'message' => 'Payroll rejected']);
    }

    public function export(): void {
        $this->requireRole('admin', 'hr');
        $month    = $_GET['month'] ?? date('Y-m');
        $payrolls = $this->model->getByMonth($month);

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="payroll_' . $month . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['#','Employee','Dept','Basic','House','Transport','Medical',
                       'Overtime','Gross','PF','Insurance','Tax','Deductions','Net','Status']);
        foreach ($payrolls as $i => $p) {
            fputcsv($out, [
                $i+1, $p['employee_name'], $p['department'],
                $p['basic_salary'], $p['house_allowance'], $p['transport_allowance'],
                $p['medical_allowance'], $p['overtime_pay'], $p['gross_salary'],
                $p['provident_fund'], $p['insurance'], $p['tax'],
                $p['total_deductions'], $p['net_salary'], $p['status'],
            ]);
        }
        fclose($out);
        exit;
    }

    private function buildSummary(string $month): array {
        $payrolls = $this->model->getByMonth($month);
        $summary  = ['total_gross' => 0, 'total_net' => 0, 'total_tax' => 0,
                     'total_deductions' => 0, 'count' => count($payrolls),
                     'pending' => 0, 'approved' => 0];
        foreach ($payrolls as $p) {
            $summary['total_gross']      += $p['gross_salary'];
            $summary['total_net']        += $p['net_salary'];
            $summary['total_tax']        += $p['tax'];
            $summary['total_deductions'] += $p['total_deductions'];
            $summary[$p['status']]       = ($summary[$p['status']] ?? 0) + 1;
        }
        return $summary;
    }
}
