﻿<div class="page-header">
  <div>
    <div class="page-header-title">Leave Approvals</div>
    <div class="page-header-sub"><?= count($pending) ?> pending request(s)</div>
  </div>
  <a href="<?= url('leaves') ?>" class="btn btn-outline"><i class="fas fa-list"></i> All Leaves</a>
</div>

<?php if (empty($pending)): ?>
<div class="card">
  <div class="card-body">
    <div class="empty-state">
      <div class="empty-state-icon"><i class="fas fa-check-double"></i></div>
      <div class="empty-state-title">All caught up!</div>
      <div class="empty-state-text">No pending leave requests</div>
    </div>
  </div>
</div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:14px">
  <?php foreach ($pending as $l): ?>
  <div class="card">
    <div class="card-body" style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
      <div style="flex:1;min-width:200px">
        <div style="font-weight:700;font-size:.95rem"><?= e($l['employee_name']) ?></div>
        <div style="font-size:.78rem;color:#64748b"><?= e($l['position']) ?> Â· <?= e($l['department']) ?></div>
      </div>
      <div style="flex:1;min-width:160px">
        <span class="badge badge-primary" style="margin-bottom:4px"><?= ucfirst($l['leave_type']) ?></span>
        <div style="font-size:.82rem;color:#374151;margin-top:4px">
          <i class="fas fa-calendar" style="color:#6366f1"></i>
          <?= formatDate($l['start_date']) ?> â†’ <?= formatDate($l['end_date']) ?>
        </div>
        <div style="font-size:.75rem;color:#64748b;margin-top:2px">
          <?= (new DateTime($l['start_date']))->diff(new DateTime($l['end_date']))->days + 1 ?> day(s)
        </div>
      </div>
      <?php if ($l['reason']): ?>
      <div style="flex:2;min-width:200px;font-size:.82rem;color:#475569;background:#f8fafc;padding:8px 12px;border-radius:8px">
        <i class="fas fa-quote-left" style="color:#94a3b8;margin-right:4px"></i><?= e($l['reason']) ?>
      </div>
      <?php endif; ?>
      <div style="display:flex;gap:8px;flex-shrink:0">
        <button class="btn btn-success btn-sm" onclick="leaveAction('approve', <?= $l['id'] ?>)">
          <i class="fas fa-check"></i> Approve
        </button>
        <button class="btn btn-danger btn-sm" onclick="leaveReject(<?= $l['id'] ?>)">
          <i class="fas fa-times"></i> Reject
        </button>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Reject Modal -->
<div class="modal-overlay" id="rejectModal" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">Reject Leave Request</span>
      <button class="modal-close" onclick="closeModal('rejectModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label class="form-label">Reason for Rejection</label>
        <textarea id="rejectReason" class="form-control" rows="3" placeholder="Optional reason..."></textarea>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('rejectModal')">Cancel</button>
      <button class="btn btn-danger" onclick="confirmReject()"><i class="fas fa-times"></i> Reject</button>
    </div>
  </div>
</div>

<script>
let rejectId = null;
function leaveAction(action, id) {
  if (!confirm(`${action === 'approve' ? 'Approve' : 'Reject'} this leave request?`)) return;
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', `leaves/${action}/${id}`, { csrf_token: csrf }, data => {
    if (data.success) { showToast(data.message, 'success'); setTimeout(() => location.reload(), 800); }
    else showToast(data.message || 'Failed', 'error');
  });
}
function leaveReject(id) {
  rejectId = id;
  document.getElementById('rejectReason').value = '';
  openModal('rejectModal');
}
function confirmReject() {
  const reason = document.getElementById('rejectReason').value;
  const csrf   = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', `leaves/reject/${rejectId}`, { csrf_token: csrf, reason }, data => {
    if (data.success) { showToast('Leave rejected.', 'success'); closeModal('rejectModal'); setTimeout(() => location.reload(), 800); }
    else showToast(data.message || 'Failed', 'error');
  });
}
</script>
