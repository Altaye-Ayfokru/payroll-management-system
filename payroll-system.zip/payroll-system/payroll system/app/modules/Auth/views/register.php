<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register — PayrollPro</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= asset('css/dashboard.css') ?>">
<link rel="stylesheet" href="<?= asset('css/forms.css') ?>">
<style>
  body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
  .auth-card { background: #fff; border-radius: 20px; padding: 40px; width: 100%; max-width: 440px; box-shadow: 0 20px 60px rgba(0,0,0,.2); }
  .auth-logo { text-align: center; margin-bottom: 24px; }
  .auth-logo-icon { width: 52px; height: 52px; border-radius: 14px; background: linear-gradient(135deg, #6366f1, #8b5cf6); display: inline-flex; align-items: center; justify-content: center; color: #fff; font-size: 1.3rem; margin-bottom: 10px; }
  .auth-title { font-size: 1.3rem; font-weight: 800; color: #0f172a; }
  .auth-sub   { font-size: .82rem; color: #64748b; margin-top: 3px; }
  .auth-footer { text-align: center; margin-top: 18px; font-size: .85rem; color: #64748b; }
  .auth-footer a { color: #6366f1; font-weight: 600; }
</style>
</head>
<body>
<div class="auth-card">
  <div class="auth-logo">
    <div class="auth-logo-icon"><i class="fas fa-coins"></i></div>
    <div class="auth-title">Create Account</div>
    <div class="auth-sub">Join PayrollPro today</div>
  </div>

  <?php if (!empty($error)): ?>
  <div class="flash-message flash-error" style="margin-bottom:16px">
    <i class="fas fa-exclamation-circle"></i> <?= e($error) ?>
  </div>
  <?php endif; ?>

  <form method="POST" action="<?= url('auth/register') ?>">
    <?= csrfField() ?>
    <div class="form-group">
      <label class="form-label">Full Name <span class="required">*</span></label>
      <div class="input-group">
        <i class="fas fa-user input-group-icon"></i>
        <input type="text" name="name" class="form-control <?= isset($errors['name']) ? 'is-invalid' : '' ?>"
               placeholder="John Smith" value="<?= e($old['name'] ?? '') ?>" required>
      </div>
      <?php if (isset($errors['name'])): ?><div class="form-error"><?= e($errors['name']) ?></div><?php endif; ?>
    </div>
    <div class="form-group">
      <label class="form-label">Email Address <span class="required">*</span></label>
      <div class="input-group">
        <i class="fas fa-envelope input-group-icon"></i>
        <input type="email" name="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>"
               placeholder="you@example.com" value="<?= e($old['email'] ?? '') ?>" required>
      </div>
      <?php if (isset($errors['email'])): ?><div class="form-error"><?= e($errors['email']) ?></div><?php endif; ?>
    </div>
    <div class="form-group">
      <label class="form-label">Password <span class="required">*</span></label>
      <div class="input-group">
        <i class="fas fa-lock input-group-icon"></i>
        <input type="password" name="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>"
               placeholder="Min. 8 characters" required>
      </div>
      <?php if (isset($errors['password'])): ?><div class="form-error"><?= e($errors['password']) ?></div><?php endif; ?>
      <div class="form-hint">At least 8 characters</div>
    </div>
    <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top:8px">
      <i class="fas fa-user-plus"></i> Create Account
    </button>
  </form>

  <div class="auth-footer">
    Already have an account? <a href="<?= url('auth/login') ?>">Sign in</a>
  </div>
</div>
</body>
</html>
