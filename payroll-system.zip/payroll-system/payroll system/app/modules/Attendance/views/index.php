﻿<?php
// Load employees list for HR add-record modal
$empList = [];
if (isHR()) {
    try {
        $db = Database::getInstance();
        $empList = $db->query(
            "SELECT e.id, u.name, e.employee_code, e.department
             FROM employees e JOIN users u ON u.id = e.user_id
             WHERE e.status='active' AND e.deleted_at IS NULL
             ORDER BY u.name ASC"
        )->fetchAll();
    } catch (Exception $ex) { $empList = []; }
}
?>

<!-- Hero Banner -->
<div class="page-hero hero-attendance">
  <div class="hero-orb hero-orb-1"></div>
  <div class="hero-orb hero-orb-2"></div>
  <div class="page-hero-content">
    <div class="hero-badge"><span class="hero-badge-dot"></span> <?= date('l, F d Y') ?></div>
    <div class="page-hero-title">Attendance Tracking</div>
    <div class="page-hero-sub">Monitor daily check-ins, track overtime, and manage attendance records for all employees.</div>
    <div class="page-hero-actions">
      <?php if (isHR()): ?>
      <button onclick="openModal('addAttendanceModal')" class="page-hero-btn page-hero-btn-white">
        <i class="fas fa-plus"></i> Add Record
      </button>
      <?php endif; ?>
      <a href="<?= url('attendance/calendar') ?>" class="page-hero-btn page-hero-btn-outline">
        <i class="fas fa-calendar"></i> Calendar View
      </a>
    </div>
  </div>
  <svg class="page-hero-illustration" viewBox="0 0 280 180" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="20" y="20" width="240" height="140" rx="16" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.2)" stroke-width="1.5"/>
    <rect x="20" y="20" width="240" height="44" rx="16" fill="rgba(255,255,255,0.15)"/>
    <rect x="20" y="48" width="240" height="16" fill="rgba(255,255,255,0.15)"/>
    <rect x="36" y="30" width="60" height="8" rx="4" fill="rgba(255,255,255,0.8)"/>
    <rect x="36" y="42" width="40" height="6" rx="3" fill="rgba(255,255,255,0.5)"/>
    <circle cx="220" cy="38" r="14" fill="rgba(255,255,255,0.2)"/>
    <path d="M214 38 L218 42 L226 34" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <g transform="translate(36,76)">
      <circle r="10" fill="#4ade80"/><text y="4" text-anchor="middle" font-size="8" fill="white" font-weight="bold">P</text>
    </g>
    <g transform="translate(80,76)">
      <circle r="10" fill="#4ade80"/><text y="4" text-anchor="middle" font-size="8" fill="white" font-weight="bold">P</text>
    </g>
    <g transform="translate(124,76)">
      <circle r="10" fill="#fbbf24"/><text y="4" text-anchor="middle" font-size="8" fill="white" font-weight="bold">L</text>
    </g>
    <g transform="translate(168,76)">
      <circle r="10" fill="#4ade80"/><text y="4" text-anchor="middle" font-size="8" fill="white" font-weight="bold">P</text>
    </g>
    <g transform="translate(212,76)">
      <circle r="10" fill="#f87171"/><text y="4" text-anchor="middle" font-size="8" fill="white" font-weight="bold">A</text>
    </g>
    <rect x="36" y="104" width="208" height="8" rx="4" fill="rgba(255,255,255,0.1)"/>
    <rect x="36" y="104" width="156" height="8" rx="4" fill="rgba(74,222,128,0.6)"/>
    <rect x="36" y="120" width="208" height="6" rx="3" fill="rgba(255,255,255,0.08)"/>
    <rect x="36" y="130" width="208" height="6" rx="3" fill="rgba(255,255,255,0.08)"/>
    <rect x="36" y="140" width="140" height="6" rx="3" fill="rgba(255,255,255,0.08)"/>
  </svg>
</div>

<div class="page-header">
  <div>
    <div class="page-header-title">Attendance</div>
    <div class="page-header-sub"><?= date('l, F d Y') ?></div>
  </div>
  <div class="page-header-actions">
    <a href="<?= url('attendance/calendar') ?>" class="btn btn-outline">
      <i class="fas fa-calendar"></i> Calendar View
    </a>
    <a href="<?= url('attendance/report') ?>" class="btn btn-outline">
      <i class="fas fa-chart-bar"></i> Report
    </a>
    <?php if (isHR()): ?>
    <button class="btn btn-primary" onclick="openModal('addAttendanceModal')">
      <i class="fas fa-plus"></i> Add Record
    </button>
    <?php endif; ?>
  </div>
</div>

<!-- Stats Row -->
<div class="summary-row" style="margin-bottom:20px">
  <div class="summary-chip">
    <div class="summary-chip-icon" style="background:#d1fae5;color:#10b981"><i class="fas fa-user-check"></i></div>
    <div><div class="summary-chip-val"><?= $todayStats['present'] ?? 0 ?></div><div class="summary-chip-label">Present</div></div>
  </div>
  <div class="summary-chip">
    <div class="summary-chip-icon" style="background:#fee2e2;color:#ef4444"><i class="fas fa-user-times"></i></div>
    <div><div class="summary-chip-val"><?= $todayStats['absent'] ?? 0 ?></div><div class="summary-chip-label">Absent</div></div>
  </div>
  <div class="summary-chip">
    <div class="summary-chip-icon" style="background:#fef3c7;color:#f59e0b"><i class="fas fa-clock"></i></div>
    <div><div class="summary-chip-val"><?= $todayStats['late'] ?? 0 ?></div><div class="summary-chip-label">Late</div></div>
  </div>
  <div class="summary-chip">
    <div class="summary-chip-icon" style="background:#e0e7ff;color:#6366f1"><i class="fas fa-users"></i></div>
    <div><div class="summary-chip-val"><?= $todayStats['total'] ?? 0 ?></div><div class="summary-chip-label">Total Staff</div></div>
  </div>
</div>

<div style="display:grid;grid-template-columns:<?= isset($myEmployee) ? '2fr 1fr' : '1fr' ?>;gap:20px">

  <!-- Attendance Table -->
  <div>
    <!-- Date Filter -->
    <div class="filter-bar">
      <form method="GET" action="<?= url('attendance') ?>" style="display:flex;gap:10px;align-items:center">
        <label style="font-size:.82rem;font-weight:600;color:#374151;white-space:nowrap">Filter by date:</label>
        <input type="date" name="date" class="form-control" value="<?= e($date) ?>" style="width:auto">
        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button>
        <?php if ($date !== date('Y-m-d')): ?>
        <a href="<?= url('attendance') ?>" class="btn btn-outline btn-sm"><i class="fas fa-times"></i> Today</a>
        <?php endif; ?>
      </form>
    </div>

    <div class="card">
      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Employee</th>
              <th>Date</th>
              <th>Check In</th>
              <th>Check Out</th>
              <th>Hours</th>
              <th>Overtime</th>
              <th>Status</th>
              <?php if (isHR()): ?><th>Actions</th><?php endif; ?>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($records)): ?>
            <tr><td colspan="<?= isHR() ? 8 : 7 ?>">
              <div class="empty-state">
                <div class="empty-state-icon"><i class="fas fa-clock"></i></div>
                <div class="empty-state-title">No attendance records for <?= e($date) ?></div>
                <?php if (isHR()): ?>
                <div class="empty-state-text">
                  <button class="btn btn-primary btn-sm" style="margin-top:10px" onclick="openModal('addAttendanceModal')">
                    <i class="fas fa-plus"></i> Add Record
                  </button>
                </div>
                <?php endif; ?>
              </div>
            </td></tr>
            <?php else: ?>
            <?php foreach ($records as $r): ?>
            <tr>
              <td>
                <div class="emp-cell">
                  <div>
                    <div class="emp-info-name"><?= e($r['employee_name']) ?></div>
                    <div class="emp-info-code"><?= e($r['department'] ?? '') ?></div>
                  </div>
                </div>
              </td>
              <td><?= formatDate($r['date'], 'M d, Y') ?></td>
              <td><?= $r['check_in'] ? date('h:i A', strtotime($r['check_in'])) : '<span style="color:#94a3b8">—</span>' ?></td>
              <td><?= $r['check_out'] ? date('h:i A', strtotime($r['check_out'])) : '<span style="color:#94a3b8">—</span>' ?></td>
              <td><?= ($r['hours_worked'] ?? 0) > 0 ? round($r['hours_worked'], 2) . 'h' : '<span style="color:#94a3b8">—</span>' ?></td>
              <td>
                <?php if (($r['overtime_hours'] ?? 0) > 0): ?>
                <span style="color:#f59e0b;font-weight:600"><?= round($r['overtime_hours'], 2) ?>h</span>
                <?php else: ?>
                <span style="color:#94a3b8">—</span>
                <?php endif; ?>
              </td>
              <td><?= statusBadge($r['status']) ?></td>
              <?php if (isHR()): ?>
              <td>
                <button class="btn btn-outline btn-sm btn-icon" title="Edit"
                        onclick="editRecord(<?= $r['id'] ?>, '<?= e($r['check_in'] ?? '') ?>', '<?= e($r['check_out'] ?? '') ?>', '<?= e($r['status']) ?>')">
                  <i class="fas fa-edit"></i>
                </button>
              </td>
              <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <?php if (isset($pager) && $pager['total_pages'] > 1): ?>
      <div class="pagination">
        <?php if ($pager['has_prev']): ?>
        <a href="?page=<?= $pager['current_page'] - 1 ?>&date=<?= urlencode($date) ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a>
        <?php endif; ?>
        <?php for ($i = max(1, $pager['current_page'] - 2); $i <= min($pager['total_pages'], $pager['current_page'] + 2); $i++): ?>
        <a href="?page=<?= $i ?>&date=<?= urlencode($date) ?>" class="page-btn <?= $i === $pager['current_page'] ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
        <?php if ($pager['has_next']): ?>
        <a href="?page=<?= $pager['current_page'] + 1 ?>&date=<?= urlencode($date) ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Right: Check-in Widget (employees only) -->
  <?php if (isset($myEmployee)): ?>
  <div>
    <div class="checkin-widget" style="margin-bottom:20px">
      <div class="checkin-time" id="liveClock">--:--:--</div>
      <div class="checkin-date"><?= date('l, F d Y') ?></div>
      <?php if (!empty($myRecord)): ?>
        <div class="checkin-status">
          <i class="fas fa-check-circle"></i>
          Checked in at <?= date('h:i A', strtotime($myRecord['check_in'])) ?>
          <?php if (!empty($myRecord['check_out'])): ?>
          &middot; Out at <?= date('h:i A', strtotime($myRecord['check_out'])) ?>
          <?php endif; ?>
        </div>
      <?php else: ?>
        <div class="checkin-status">Not checked in yet today</div>
      <?php endif; ?>
      <div class="checkin-btns">
        <button class="checkin-btn checkin-btn-in" id="checkInBtn"
                <?= !empty($myRecord) ? 'disabled' : '' ?>
                onclick="doCheckIn()">
          <i class="fas fa-sign-in-alt"></i> Check In
        </button>
        <button class="checkin-btn checkin-btn-out" id="checkOutBtn"
                <?= (empty($myRecord) || !empty($myRecord['check_out'])) ? 'disabled' : '' ?>
                onclick="doCheckOut()">
          <i class="fas fa-sign-out-alt"></i> Check Out
        </button>
      </div>
    </div>

    <?php if (!empty($mySummary)): ?>
    <div class="card">
      <div class="card-header"><span class="card-title"><i class="fas fa-calendar-alt" style="color:#6366f1;margin-right:6px"></i>This Month</span></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <div style="text-align:center;padding:12px;background:#d1fae5;border-radius:10px">
            <div style="font-size:1.4rem;font-weight:800;color:#10b981"><?= $mySummary['present_days'] ?? 0 ?></div>
            <div style="font-size:.72rem;color:#065f46;font-weight:600">Present</div>
          </div>
          <div style="text-align:center;padding:12px;background:#fee2e2;border-radius:10px">
            <div style="font-size:1.4rem;font-weight:800;color:#ef4444"><?= $mySummary['absent_days'] ?? 0 ?></div>
            <div style="font-size:.72rem;color:#991b1b;font-weight:600">Absent</div>
          </div>
          <div style="text-align:center;padding:12px;background:#fef3c7;border-radius:10px">
            <div style="font-size:1.4rem;font-weight:800;color:#f59e0b"><?= $mySummary['late_days'] ?? 0 ?></div>
            <div style="font-size:.72rem;color:#92400e;font-weight:600">Late</div>
          </div>
          <div style="text-align:center;padding:12px;background:#e0e7ff;border-radius:10px">
            <div style="font-size:1.4rem;font-weight:800;color:#6366f1"><?= round($mySummary['total_hours'] ?? 0, 1) ?>h</div>
            <div style="font-size:.72rem;color:#4f46e5;font-weight:600">Hours</div>
          </div>
        </div>
        <?php if (($mySummary['overtime_hours'] ?? 0) > 0): ?>
        <div style="margin-top:10px;padding:10px;background:#fef3c7;border-radius:8px;text-align:center;font-size:.82rem">
          <i class="fas fa-star" style="color:#f59e0b"></i>
          <strong><?= round($mySummary['overtime_hours'], 1) ?>h</strong> overtime this month
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

</div><!-- /grid -->

<!-- ═══ ADD ATTENDANCE MODAL ═══ -->
<?php if (isHR()): ?>
<div class="modal-overlay" id="addAttendanceModal" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title"><i class="fas fa-plus-circle" style="color:#6366f1;margin-right:8px"></i>Add Attendance Record</span>
      <button class="modal-close" onclick="closeModal('addAttendanceModal')"><i class="fas fa-times"></i></button>
    </div>
    <form id="addAttForm" method="POST" action="<?= url('attendance/store') ?>">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Employee <span style="color:#ef4444">*</span></label>
          <select name="employee_id" class="form-control" required>
            <option value="">Select employee...</option>
            <?php foreach ($empList as $emp): ?>
            <option value="<?= (int)$emp['id'] ?>">
              <?= e($emp['name']) ?> (<?= e($emp['employee_code']) ?>) — <?= e($emp['department']) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Date <span style="color:#ef4444">*</span></label>
          <input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>" required>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
          <div class="form-group">
            <label class="form-label">Check In Time</label>
            <input type="time" name="check_in" class="form-control" value="09:00">
          </div>
          <div class="form-group">
            <label class="form-label">Check Out Time</label>
            <input type="time" name="check_out" class="form-control" value="18:00">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Status <span style="color:#ef4444">*</span></label>
          <select name="status" class="form-control" required>
            <option value="present">Present</option>
            <option value="absent">Absent</option>
            <option value="late">Late</option>
            <option value="half_day">Half Day</option>
            <option value="holiday">Holiday</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Notes</label>
          <input type="text" name="notes" class="form-control" placeholder="Optional notes...">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('addAttendanceModal')">Cancel</button>
        <button type="submit" class="btn btn-primary" id="addAttBtn">
          <i class="fas fa-save"></i> Save Record
        </button>
      </div>
    </form>
  </div>
</div>

<!-- EDIT ATTENDANCE MODAL -->
<div class="modal-overlay" id="editAttendanceModal" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title"><i class="fas fa-edit" style="color:#6366f1;margin-right:8px"></i>Edit Attendance Record</span>
      <button class="modal-close" onclick="closeModal('editAttendanceModal')"><i class="fas fa-times"></i></button>
    </div>
    <form id="editAttForm">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="record_id" id="editRecordId">
      <div class="modal-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
          <div class="form-group">
            <label class="form-label">Check In</label>
            <input type="time" name="check_in" id="editCheckIn" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">Check Out</label>
            <input type="time" name="check_out" id="editCheckOut" class="form-control">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" id="editStatus" class="form-control">
            <option value="present">Present</option>
            <option value="absent">Absent</option>
            <option value="late">Late</option>
            <option value="half_day">Half Day</option>
            <option value="holiday">Holiday</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('editAttendanceModal')">Cancel</button>
        <button type="button" class="btn btn-primary" onclick="saveEdit()">
          <i class="fas fa-save"></i> Update
        </button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<script>
/* ── Check In / Out ── */
function doCheckIn() {
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', 'attendance/checkin', { csrf_token: csrf }, data => {
    if (data.success) {
      showToast('Checked in at ' + data.check_in, 'success');
      document.getElementById('checkInBtn').disabled  = true;
      document.getElementById('checkOutBtn').disabled = false;
      setTimeout(() => location.reload(), 1200);
    } else {
      showToast(data.message || 'Check-in failed', 'error');
    }
  });
}

function doCheckOut() {
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', 'attendance/checkout', { csrf_token: csrf }, data => {
    if (data.success) {
      showToast('Checked out. ' + data.hours_worked + 'h worked.', 'success');
      document.getElementById('checkOutBtn').disabled = true;
      setTimeout(() => location.reload(), 1200);
    } else {
      showToast(data.message || 'Check-out failed', 'error');
    }
  });
}

/* ── Add Record Form Submit ── */
<?php if (isHR()): ?>
document.getElementById('addAttForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const btn = document.getElementById('addAttBtn');
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

  const fd = new FormData(this);

  // Calculate hours_worked from check_in / check_out
  const ci = fd.get('check_in');
  const co = fd.get('check_out');
  if (ci && co) {
    const [ch, cm] = ci.split(':').map(Number);
    const [oh, om] = co.split(':').map(Number);
    const hours = ((oh * 60 + om) - (ch * 60 + cm)) / 60;
    if (hours > 0) {
      fd.append('hours_worked', hours.toFixed(2));
      const ot = Math.max(0, hours - 8);
      fd.append('overtime_hours', ot.toFixed(2));
    }
  }

  fetch(this.action, {
    method: 'POST',
    headers: { 'X-Requested-With': 'XMLHttpRequest' },
    body: fd
  })
  .then(function(r) {
    return r.text().then(function(text) {
      try { return JSON.parse(text); }
      catch(e) {
        console.error('Server response:', text.substring(0, 500));
        throw new Error('Server error: ' + text.substring(0, 120));
      }
    });
  })
  .then(function(data) {
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-save"></i> Save Record';
    if (data.success) {
      showToast('Attendance record added!', 'success');
      closeModal('addAttendanceModal');
      setTimeout(function() { location.reload(); }, 800);
    } else {
      showToast(data.message || 'Failed to save', 'error');
    }
  })
  .catch(function(err) {
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-save"></i> Save Record';
    showToast(err.message || 'Network error — check PHP error log', 'error');
    console.error('Attendance store error:', err);
  });
});

/* ── Edit Record ── */
function editRecord(id, checkIn, checkOut, status) {
  document.getElementById('editRecordId').value = id;
  document.getElementById('editCheckIn').value  = checkIn;
  document.getElementById('editCheckOut').value = checkOut;
  document.getElementById('editStatus').value   = status;
  openModal('editAttendanceModal');
}

function saveEdit() {
  const id     = document.getElementById('editRecordId').value;
  const csrf   = document.querySelector('meta[name="csrf-token"]').content;
  const ci     = document.getElementById('editCheckIn').value;
  const co     = document.getElementById('editCheckOut').value;
  const status = document.getElementById('editStatus').value;

  let hours = 0, ot = 0;
  if (ci && co) {
    const [ch, cm] = ci.split(':').map(Number);
    const [oh, om] = co.split(':').map(Number);
    hours = ((oh * 60 + om) - (ch * 60 + cm)) / 60;
    ot    = Math.max(0, hours - 8);
  }

  ajax('POST', `attendance/update/${id}`, {
    csrf_token: csrf,
    check_in: ci,
    check_out: co,
    status: status,
    hours_worked: hours.toFixed(2),
    overtime_hours: ot.toFixed(2)
  }, data => {
    if (data.success) {
      showToast('Record updated!', 'success');
      closeModal('editAttendanceModal');
      setTimeout(() => location.reload(), 800);
    } else {
      showToast(data.message || 'Update failed', 'error');
    }
  });
}
<?php endif; ?>
</script>
