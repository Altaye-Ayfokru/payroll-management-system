<?php
/**
 * Employee Module — Model
 * Handles all DB operations for employees
 */
class EmployeeModel extends Model {
    protected string $table      = 'employees';
    protected string $primaryKey = 'id';

    public function getAllWithUsers(int $limit = ITEMS_PER_PAGE, int $offset = 0, string $dept = ''): array {
        $where  = $dept ? "AND e.department = :dept" : "";
        $params = [':limit' => $limit, ':offset' => $offset];
        if ($dept) $params[':dept'] = $dept;

        return $this->query(
            "SELECT e.*, u.name, u.email, u.phone, u.avatar, u.role
             FROM employees e
             JOIN users u ON u.id = e.user_id
             WHERE e.deleted_at IS NULL {$where}
             ORDER BY e.created_at DESC
             LIMIT :limit OFFSET :offset",
            $params
        );
    }

    public function getWithUser(int $id): ?array {
        return $this->queryOne(
            "SELECT e.*, u.name, u.email, u.phone, u.avatar
             FROM employees e
             JOIN users u ON u.id = e.user_id
             WHERE e.id = :id AND e.deleted_at IS NULL",
            [':id' => $id]
        );
    }

    public function getByUserId(int $userId): ?array {
        return $this->queryOne(
            "SELECT e.*, u.name, u.email, u.avatar, u.phone
             FROM employees e
             JOIN users u ON u.id = e.user_id
             WHERE e.user_id = :uid AND e.deleted_at IS NULL",
            [':uid' => $userId]
        );
    }

    public function search(string $term, int $limit = ITEMS_PER_PAGE, int $offset = 0): array {
        $like = '%' . $term . '%';
        return $this->query(
            "SELECT e.*, u.name, u.email, u.avatar
             FROM employees e
             JOIN users u ON u.id = e.user_id
             WHERE e.deleted_at IS NULL
               AND (u.name LIKE :t1 OR u.email LIKE :t2
                    OR e.position LIKE :t3 OR e.department LIKE :t4
                    OR e.employee_code LIKE :t5)
             ORDER BY u.name ASC
             LIMIT :limit OFFSET :offset",
            [':t1'=>$like,':t2'=>$like,':t3'=>$like,':t4'=>$like,':t5'=>$like,
             ':limit'=>$limit,':offset'=>$offset]
        );
    }

    public function countFiltered(string $dept = ''): int {
        $where  = $dept ? "AND department = :dept" : "";
        $params = $dept ? [':dept' => $dept] : [];
        $stmt   = $this->db->prepare(
            "SELECT COUNT(*) FROM employees WHERE deleted_at IS NULL {$where}"
        );
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    }

    public function countActive(): int {
        $stmt = $this->db->query(
            "SELECT COUNT(*) FROM employees WHERE status='active' AND deleted_at IS NULL"
        );
        return (int)$stmt->fetchColumn();
    }

    public function getDepartments(): array {
        return $this->query(
            "SELECT DISTINCT department FROM employees
             WHERE deleted_at IS NULL AND department IS NOT NULL
             ORDER BY department"
        );
    }

    public function getTotalSalaryBudget(): float {
        $stmt = $this->db->query(
            "SELECT COALESCE(SUM(basic_salary),0) FROM employees
             WHERE status='active' AND deleted_at IS NULL"
        );
        return (float)$stmt->fetchColumn();
    }

    public function softDelete(int $id): bool {
        return $this->execute(
            "UPDATE employees SET deleted_at = NOW() WHERE id = :id",
            [':id' => $id]
        );
    }

    public function getNextCode(): string {
        $stmt = $this->db->query("SELECT MAX(id) FROM employees");
        $max  = (int)$stmt->fetchColumn();
        return 'EMP' . str_pad($max + 1, 4, '0', STR_PAD_LEFT);
    }
}
