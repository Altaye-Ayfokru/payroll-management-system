<?php
require_once CORE_PATH . '/Controller.php';
require_once APP_PATH . '/helpers/validator.php';
require_once APP_PATH . '/models/User.php';
require_once APP_PATH . '/modules/Employee/EmployeeModel.php';
require_once APP_PATH . '/modules/Employee/EmployeeService.php';

class EmployeeController extends Controller {
    private EmployeeService $service;

    public function __construct() {
        $this->service = new EmployeeService();
    }

    public function index(): void {
        $this->requireRole('admin', 'hr');
        $page   = max(1, (int)($_GET['page'] ?? 1));
        $search = trim($_GET['search'] ?? '');
        $dept   = trim($_GET['dept'] ?? '');

        $result = $this->service->listEmployees($page, $search, $dept);
        $depts  = (new EmployeeModel())->getDepartments();

        $this->view('employees.list', array_merge($result, [
            'departments' => $depts,
            'search'      => $search,
            'dept'        => $dept,
            'pageTitle'   => 'Employees',
            'flash'       => $this->getFlash(),
        ]));
    }

    public function create(): void {
        $this->requireRole('admin', 'hr');
        $this->view('employees.create', [
            'pageTitle' => 'Add Employee',
            'csrf'      => csrfToken(),
        ]);
    }

    public function store(): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) $this->json(['success' => false, 'message' => 'Invalid token'], 403);

        $v = new Validator($_POST);
        $v->required('name')->required('email')->email('email')
          ->required('position')->required('department')
          ->required('basic_salary')->positive('basic_salary')
          ->required('hire_date')->date('hire_date');

        if (!$v->passes()) {
            $this->view('employees.create', [
                'errors' => $v->errors(), 'old' => $_POST,
                'pageTitle' => 'Add Employee', 'csrf' => csrfToken(),
            ]);
            return;
        }

        $result = $this->service->createEmployee($_POST, $_FILES['avatar'] ?? null);

        if (!$result['success']) {
            $this->view('employees.create', [
                'errors' => ['email' => $result['error']], 'old' => $_POST,
                'pageTitle' => 'Add Employee', 'csrf' => csrfToken(),
            ]);
            return;
        }

        logActivity(currentUserId(), "Created employee {$result['code']}");
        $this->flash('success', 'Employee added successfully!');
        $this->redirect('employees');
    }

    public function edit(string $id): void {
        $this->requireRole('admin', 'hr');
        $employee = $this->service->getEmployee((int)$id);
        if (!$employee) { $this->redirect('employees'); return; }

        $this->view('employees.edit', [
            'employee' => $employee, 'pageTitle' => 'Edit Employee', 'csrf' => csrfToken(),
        ]);
    }

    public function update(string $id): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) $this->json(['success' => false, 'message' => 'Invalid token'], 403);

        $v = new Validator($_POST);
        $v->required('name')->required('position')->required('department')
          ->required('basic_salary')->positive('basic_salary');

        if (!$v->passes()) {
            $employee = $this->service->getEmployee((int)$id);
            $this->view('employees.edit', [
                'errors' => $v->errors(), 'employee' => $employee,
                'pageTitle' => 'Edit Employee', 'csrf' => csrfToken(),
            ]);
            return;
        }

        $this->service->updateEmployee((int)$id, $_POST, $_FILES['avatar'] ?? null);
        logActivity(currentUserId(), "Updated employee #{$id}");
        $this->flash('success', 'Employee updated!');
        $this->redirect('employees');
    }

    public function delete(string $id): void {
        $this->requireRole('admin');
        if (!validateCsrf()) $this->json(['success' => false, 'message' => 'Invalid token'], 403);

        $this->service->deleteEmployee((int)$id);
        logActivity(currentUserId(), "Deleted employee #{$id}");

        if ($this->isAjax()) $this->json(['success' => true]);
        $this->flash('success', 'Employee removed.');
        $this->redirect('employees');
    }

    public function profile(string $id): void {
        $this->requireAuth();
        $employee = $this->service->getEmployee((int)$id);
        if (!$employee) { $this->redirect('employees'); return; }

        // Employees can only view their own profile
        if (currentUserRole() === 'employee') {
            $myEmp = (new EmployeeModel())->getByUserId(currentUserId());
            if (!$myEmp || (int)$myEmp['id'] !== (int)$id) {
                $this->redirect('dashboard'); return;
            }
        }

        $this->view('employees.view', ['employee' => $employee, 'pageTitle' => 'Employee Profile']);
    }

    public function search(): void {
        $this->requireRole('admin', 'hr');
        $term = trim($_GET['q'] ?? '');
        $this->json(['data' => (new EmployeeModel())->search($term, 10, 0)]);
    }
}
