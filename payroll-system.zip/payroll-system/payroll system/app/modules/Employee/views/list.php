﻿<!-- Hero Banner -->
<div class="page-hero hero-employees">
  <div class="hero-orb hero-orb-1"></div>
  <div class="hero-orb hero-orb-2"></div>
  <div class="page-hero-content">
    <div class="hero-badge"><span class="hero-badge-dot"></span> HR Management</div>
    <div class="page-hero-title">Employee Directory</div>
    <div class="page-hero-sub">Manage your workforce — add, edit, and track all employee profiles and salary structures.</div>
    <div class="page-hero-actions">
      <a href="<?= url('employees/create') ?>" class="page-hero-btn page-hero-btn-white">
        <i class="fas fa-user-plus"></i> Add Employee
      </a>
      <a href="<?= url('reports') ?>" class="page-hero-btn page-hero-btn-outline">
        <i class="fas fa-chart-bar"></i> View Reports
      </a>
    </div>
  </div>
  <img src="<?= asset('images/hero-employees.svg') ?>" alt="" class="page-hero-illustration" aria-hidden="true">
</div>

<div class="page-header">
  <div>
    <div class="page-header-title">Employees</div>
    <div class="page-header-sub"><?= number_format($pager['total']) ?> total employees</div>
  </div>
  <div class="page-header-actions">
    <a href="<?= url('employees/create') ?>" class="btn btn-primary">
      <i class="fas fa-user-plus"></i> Add Employee
    </a>
  </div>
</div>

<!-- Filter Bar -->
<div class="filter-bar">
  <form method="GET" action="<?= url('employees') ?>" style="display:flex;gap:10px;flex-wrap:wrap;width:100%">
    <div class="search-bar" style="flex:1;min-width:200px">
      <i class="fas fa-search"></i>
      <input type="text" name="search" placeholder="Search by name, email, position..." value="<?= e($search) ?>">
    </div>
    <select name="dept" class="form-control" style="width:auto">
      <option value="">All Departments</option>
      <?php foreach ($departments as $d): ?>
      <option value="<?= e($d['department']) ?>" <?= $dept === $d['department'] ? 'selected' : '' ?>>
        <?= e($d['department']) ?>
      </option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
    <?php if ($search || $dept): ?>
    <a href="<?= url('employees') ?>" class="btn btn-outline"><i class="fas fa-times"></i> Clear</a>
    <?php endif; ?>
  </form>
</div>

<div class="card">
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th>Employee</th>
          <th>Department</th>
          <th>Position</th>
          <th>Basic Salary</th>
          <th>Hire Date</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($employees)): ?>
        <tr>
          <td colspan="7">
            <div class="empty-state">
              <div class="empty-state-icon"><i class="fas fa-users"></i></div>
              <div class="empty-state-title">No employees found</div>
              <div class="empty-state-text">Add your first employee to get started</div>
            </div>
          </td>
        </tr>
        <?php else: ?>
        <?php foreach ($employees as $emp): ?>
        <tr>
          <td>
            <div class="emp-cell">
              <?php
              $empId   = (int)($emp['id'] ?? 0);
              $empName = $emp['name'] ?? '';
              if (!empty($emp['avatar'])) {
                  echo '<img src="' . e(getAvatarUrl($emp['avatar'], $empName, $empId)) . '" alt="" class="avatar avatar-sm" style="border:2px solid #e0e7ff">';
              } else {
                  echo renderAvatarSvg($empName, $empId, 36);
              }
              ?>
              <div>
                <div class="emp-info-name"><?= e($emp['name']) ?></div>
                <div class="emp-info-code"><?= e($emp['employee_code']) ?> &middot; <?= e($emp['email']) ?></div>
              </div>
            </div>
          </td>
          <td><span class="dept-badge"><?= e($emp['department']) ?></span></td>
          <td><?= e($emp['position']) ?></td>
          <td><strong><?= formatCurrency((float)$emp['basic_salary']) ?></strong></td>
          <td><?= formatDate($emp['hire_date']) ?></td>
          <td><?= statusBadge($emp['status']) ?></td>
          <td>
            <div style="display:flex;gap:6px">
              <a href="<?= url('employees/view/' . $emp['id']) ?>" class="btn btn-outline btn-sm btn-icon" title="View">
                <i class="fas fa-eye"></i>
              </a>
              <a href="<?= url('employees/edit/' . $emp['id']) ?>" class="btn btn-outline btn-sm btn-icon" title="Edit">
                <i class="fas fa-edit"></i>
              </a>
              <?php if (isAdmin()): ?>
              <button class="btn btn-danger btn-sm btn-icon" title="Delete"
                      onclick="deleteEmployee(<?= $emp['id'] ?>, this)">
                <i class="fas fa-trash"></i>
              </button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($pager['total_pages'] > 1): ?>
  <div class="pagination">
    <?php if ($pager['has_prev']): ?>
    <a href="?page=<?= $pager['current_page'] - 1 ?>&search=<?= urlencode($search) ?>&dept=<?= urlencode($dept) ?>" class="page-btn">
      <i class="fas fa-chevron-left"></i>
    </a>
    <?php endif; ?>
    <?php for ($i = max(1, $pager['current_page'] - 2); $i <= min($pager['total_pages'], $pager['current_page'] + 2); $i++): ?>
    <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&dept=<?= urlencode($dept) ?>"
       class="page-btn <?= $i === $pager['current_page'] ? 'active' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($pager['has_next']): ?>
    <a href="?page=<?= $pager['current_page'] + 1 ?>&search=<?= urlencode($search) ?>&dept=<?= urlencode($dept) ?>" class="page-btn">
      <i class="fas fa-chevron-right"></i>
    </a>
    <?php endif; ?>
    <span style="margin-left:auto;font-size:.78rem;color:#64748b">
      Showing <?= count($employees) ?> of <?= $pager['total'] ?>
    </span>
  </div>
  <?php endif; ?>
</div>

<script>
function deleteEmployee(id, btn) {
  if (!confirm('Delete this employee? This action cannot be undone.')) return;
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', `employees/delete/${id}`, { csrf_token: csrf }, data => {
    if (data.success) {
      btn.closest('tr').style.opacity = '0';
      btn.closest('tr').style.transition = 'opacity .3s';
      setTimeout(() => { btn.closest('tr').remove(); showToast('Employee deleted.', 'success'); }, 300);
    } else {
      showToast(data.message || 'Failed to delete.', 'error');
    }
  });
}
</script>
