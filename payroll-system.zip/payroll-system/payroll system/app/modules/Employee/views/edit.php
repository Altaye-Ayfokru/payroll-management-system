<div class="page-header">
  <div>
    <div class="page-header-title">Edit Employee</div>
    <div class="page-header-sub"><?= e($employee['name']) ?> · <?= e($employee['employee_code']) ?></div>
  </div>
  <a href="<?= url('employees') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<div class="card" style="max-width:800px">
  <div class="card-body">
    <form method="POST" action="<?= url('employees/update/' . $employee['id']) ?>" enctype="multipart/form-data">
      <?= csrfField() ?>

      <div class="avatar-upload">
        <?php if (!empty($employee['avatar'])): ?>
        <img src="<?= e(url($employee['avatar'])) ?>"
             alt="Preview" class="avatar-preview" id="avatarPreview">
        <?php else: ?>
        <div id="avatarPreview" style="width:72px;height:72px;border-radius:50%;overflow:hidden;border:3px solid #e0e7ff">
          <?= renderAvatarSvg($employee['name'] ?? 'E', (int)($employee['id'] ?? 0), 72) ?>
        </div>
        <?php endif; ?>
        <div>
          <label class="avatar-upload-btn" for="avatarInput">
            <i class="fas fa-camera"></i> Change Photo
          </label>
          <input type="file" name="avatar" id="avatarInput" class="avatar-upload-input" accept="image/*"
                 onchange="document.getElementById('avatarPreview').src = URL.createObjectURL(this.files[0])">
        </div>
      </div>

      <div class="form-section">
        <div class="form-section-title"><i class="fas fa-user"></i> Personal Information</div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Full Name</label>
            <input type="text" name="name" class="form-control" value="<?= e($employee['name']) ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">Phone</label>
            <input type="text" name="phone" class="form-control" value="<?= e($employee['phone'] ?? '') ?>">
          </div>
        </div>
      </div>

      <div class="form-section">
        <div class="form-section-title"><i class="fas fa-briefcase"></i> Job Information</div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Position</label>
            <input type="text" name="position" class="form-control" value="<?= e($employee['position']) ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">Department</label>
            <input type="text" name="department" class="form-control" value="<?= e($employee['department']) ?>" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Status</label>
            <select name="status" class="form-control">
              <option value="active"     <?= $employee['status'] === 'active'     ? 'selected' : '' ?>>Active</option>
              <option value="inactive"   <?= $employee['status'] === 'inactive'   ? 'selected' : '' ?>>Inactive</option>
              <option value="terminated" <?= $employee['status'] === 'terminated' ? 'selected' : '' ?>>Terminated</option>
            </select>
          </div>
        </div>
      </div>

      <div class="form-section">
        <div class="form-section-title"><i class="fas fa-dollar-sign"></i> Salary Structure</div>
        <div class="form-row-3">
          <div class="form-group">
            <label class="form-label">Basic Salary</label>
            <input type="number" name="basic_salary" class="form-control" value="<?= $employee['basic_salary'] ?>" step="0.01" min="0" required>
          </div>
          <div class="form-group">
            <label class="form-label">House Allowance</label>
            <input type="number" name="house_allowance" class="form-control" value="<?= $employee['house_allowance'] ?>" step="0.01" min="0">
          </div>
          <div class="form-group">
            <label class="form-label">Transport Allowance</label>
            <input type="number" name="transport_allowance" class="form-control" value="<?= $employee['transport_allowance'] ?>" step="0.01" min="0">
          </div>
        </div>
        <div class="form-row-3">
          <div class="form-group">
            <label class="form-label">Medical Allowance</label>
            <input type="number" name="medical_allowance" class="form-control" value="<?= $employee['medical_allowance'] ?>" step="0.01" min="0">
          </div>
          <div class="form-group">
            <label class="form-label">Insurance Deduction</label>
            <input type="number" name="insurance_deduction" class="form-control" value="<?= $employee['insurance_deduction'] ?>" step="0.01" min="0">
          </div>
        </div>
      </div>

      <div class="form-section">
        <div class="form-section-title"><i class="fas fa-university"></i> Bank Details</div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Bank Name</label>
            <input type="text" name="bank_name" class="form-control" value="<?= e($employee['bank_name'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Account Number</label>
            <input type="text" name="bank_account" class="form-control" value="<?= e($employee['bank_account'] ?? '') ?>">
          </div>
        </div>
      </div>

      <div style="display:flex;gap:10px;justify-content:flex-end">
        <a href="<?= url('employees') ?>" class="btn btn-outline">Cancel</a>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Employee</button>
      </div>
    </form>
  </div>
</div>
