<div class="page-header">
  <div>
    <div class="page-header-title">Settings</div>
    <div class="page-header-sub">Configure tax rules, salary components, and system settings</div>
  </div>
</div>

<!-- Tabs -->
<div style="display:flex;gap:4px;margin-bottom:20px;border-bottom:2px solid #e2e8f0;padding-bottom:0">
  <button class="tab-btn active" onclick="showTab('general')">General</button>
  <button class="tab-btn" onclick="showTab('tax')">Tax Rules</button>
  <button class="tab-btn" onclick="showTab('salary')">Salary Components</button>
</div>
<style>
.tab-btn { padding:10px 18px;background:none;border:none;cursor:pointer;font-weight:600;font-size:.875rem;color:#64748b;border-bottom:2px solid transparent;margin-bottom:-2px;transition:all .2s; }
.tab-btn.active { color:#6366f1;border-bottom-color:#6366f1; }
.tab-content { display:none; }
.tab-content.active { display:block; }
</style>

<!-- General Settings -->
<div class="tab-content active" id="tab-general">
  <div class="card" style="max-width:700px">
    <div class="card-header"><span class="card-title">Company Settings</span></div>
    <div class="card-body">
      <form method="POST" action="<?= url('settings/general') ?>">
        <?= csrfField() ?>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Company Name</label>
            <input type="text" name="company_name" class="form-control" value="<?= e($settings['company_name'] ?? 'PayrollPro Inc.') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Company Email</label>
            <input type="email" name="company_email" class="form-control" value="<?= e($settings['company_email'] ?? '') ?>">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Phone</label>
            <input type="text" name="company_phone" class="form-control" value="<?= e($settings['company_phone'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Currency Symbol</label>
            <input type="text" name="currency_symbol" class="form-control" value="<?= e($settings['currency_symbol'] ?? '$') ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Company Address</label>
          <textarea name="company_address" class="form-control" rows="2"><?= e($settings['company_address'] ?? '') ?></textarea>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Work Start Time</label>
            <input type="time" name="work_start_time" class="form-control" value="<?= e($settings['work_start_time'] ?? '09:00') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Work End Time</label>
            <input type="time" name="work_end_time" class="form-control" value="<?= e($settings['work_end_time'] ?? '18:00') ?>">
          </div>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Settings</button>
      </form>
    </div>
  </div>
</div>

<!-- Tax Rules -->
<div class="tab-content" id="tab-tax">
  <div class="card">
    <div class="card-header">
      <span class="card-title">Tax Rules</span>
      <button class="btn btn-primary btn-sm" onclick="addTaxRow()"><i class="fas fa-plus"></i> Add Rule</button>
    </div>
    <div class="card-body">
      <form method="POST" action="<?= url('settings/tax') ?>">
        <?= csrfField() ?>
        <div id="taxRules">
          <?php foreach ($taxRules as $i => $rule): ?>
          <div class="form-row" style="align-items:end;margin-bottom:10px" id="taxRow<?= $i ?>">
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Rule Name</label>
              <input type="text" name="tax_name[]" class="form-control" value="<?= e($rule['name']) ?>" required>
            </div>
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Rate (%)</label>
              <input type="number" name="tax_percentage[]" class="form-control" value="<?= $rule['percentage'] ?>" step="0.01" min="0" max="100" required>
            </div>
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Min Salary</label>
              <input type="number" name="min_salary[]" class="form-control" value="<?= $rule['min_salary'] ?>" step="0.01" min="0">
            </div>
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Max Salary (0=unlimited)</label>
              <input type="number" name="max_salary[]" class="form-control" value="<?= $rule['max_salary'] ?>" step="0.01" min="0">
            </div>
            <button type="button" class="btn btn-danger btn-sm btn-icon" onclick="this.closest('[id^=taxRow]').remove()">
              <i class="fas fa-trash"></i>
            </button>
          </div>
          <?php endforeach; ?>
        </div>
        <button type="submit" class="btn btn-primary" style="margin-top:16px"><i class="fas fa-save"></i> Save Tax Rules</button>
      </form>
    </div>
  </div>
</div>

<!-- Salary Components -->
<div class="tab-content" id="tab-salary">
  <div class="card">
    <div class="card-header">
      <span class="card-title">Salary Components</span>
      <button class="btn btn-primary btn-sm" onclick="addComponentRow()"><i class="fas fa-plus"></i> Add Component</button>
    </div>
    <div class="card-body">
      <form method="POST" action="<?= url('settings/salary') ?>">
        <?= csrfField() ?>
        <div id="components">
          <?php foreach ($salaryComponents as $i => $c): ?>
          <div class="form-row" style="align-items:end;margin-bottom:10px">
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Component Name</label>
              <input type="text" name="component_name[]" class="form-control" value="<?= e($c['name']) ?>" required>
            </div>
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Type</label>
              <select name="component_type[]" class="form-control">
                <option value="allowance" <?= $c['type'] === 'allowance' ? 'selected' : '' ?>>Allowance</option>
                <option value="deduction" <?= $c['type'] === 'deduction' ? 'selected' : '' ?>>Deduction</option>
              </select>
            </div>
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Default Amount</label>
              <input type="number" name="component_amount[]" class="form-control" value="<?= $c['amount'] ?>" step="0.01" min="0">
            </div>
            <button type="button" class="btn btn-danger btn-sm btn-icon" onclick="this.closest('.form-row').remove()">
              <i class="fas fa-trash"></i>
            </button>
          </div>
          <?php endforeach; ?>
        </div>
        <button type="submit" class="btn btn-primary" style="margin-top:16px"><i class="fas fa-save"></i> Save Components</button>
      </form>
    </div>
  </div>
</div>

<script>
function showTab(name) {
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  event.target.classList.add('active');
}
let taxIdx = <?= count($taxRules) ?>;
function addTaxRow() {
  const div = document.createElement('div');
  div.className = 'form-row';
  div.style.cssText = 'align-items:end;margin-bottom:10px';
  div.id = 'taxRow' + taxIdx++;
  div.innerHTML = `
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Rule Name</label><input type="text" name="tax_name[]" class="form-control" required></div>
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Rate (%)</label><input type="number" name="tax_percentage[]" class="form-control" step="0.01" min="0" max="100" required></div>
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Min Salary</label><input type="number" name="min_salary[]" class="form-control" step="0.01" min="0" value="0"></div>
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Max Salary</label><input type="number" name="max_salary[]" class="form-control" step="0.01" min="0" value="0"></div>
    <button type="button" class="btn btn-danger btn-sm btn-icon" onclick="this.closest('[id^=taxRow]').remove()"><i class="fas fa-trash"></i></button>`;
  document.getElementById('taxRules').appendChild(div);
}
function addComponentRow() {
  const div = document.createElement('div');
  div.className = 'form-row';
  div.style.cssText = 'align-items:end;margin-bottom:10px';
  div.innerHTML = `
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Name</label><input type="text" name="component_name[]" class="form-control" required></div>
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Type</label><select name="component_type[]" class="form-control"><option value="allowance">Allowance</option><option value="deduction">Deduction</option></select></div>
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Amount</label><input type="number" name="component_amount[]" class="form-control" step="0.01" min="0" value="0"></div>
    <button type="button" class="btn btn-danger btn-sm btn-icon" onclick="this.closest('.form-row').remove()"><i class="fas fa-trash"></i></button>`;
  document.getElementById('components').appendChild(div);
}
</script>
