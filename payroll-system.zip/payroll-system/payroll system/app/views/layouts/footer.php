<?php if (!empty($_SESSION['user_id'])): ?>
  </main>
</div><!-- /main-wrapper -->
<?php endif; ?>
<script src="<?= asset('js/app.js') ?>"></script>
<script src="<?= asset('js/ajax.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="<?= asset('js/charts.js') ?>"></script>
</body>
</html>
