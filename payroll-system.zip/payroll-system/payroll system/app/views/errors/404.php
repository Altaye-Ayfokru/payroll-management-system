<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>404 — PayrollPro</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
<style>
  body { font-family: 'Inter', sans-serif; background: #f1f5f9; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
  .box { text-align: center; padding: 48px; }
  .code { font-size: 6rem; font-weight: 800; background: linear-gradient(135deg, #6366f1, #8b5cf6); -webkit-background-clip: text; -webkit-text-fill-color: transparent; line-height: 1; }
  .title { font-size: 1.4rem; font-weight: 700; color: #0f172a; margin: 12px 0 8px; }
  .sub { color: #64748b; margin-bottom: 24px; }
  .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 22px; background: #6366f1; color: #fff; border-radius: 8px; font-weight: 600; text-decoration: none; }
</style>
</head>
<body>
<div class="box">
  <div class="code">404</div>
  <div class="title">Page Not Found</div>
  <div class="sub">The page you're looking for doesn't exist or has been moved.</div>
  <a href="javascript:history.back()" class="btn">← Go Back</a>
</div>
</body>
</html>
