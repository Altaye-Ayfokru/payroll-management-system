<?php
/**
 * Application Routes
 */
$routes = [
    // Auth
    ['method' => 'GET',  'path' => '',                        'controller' => 'AuthController',       'action' => 'loginPage'],
    ['method' => 'GET',  'path' => 'auth/login',              'controller' => 'AuthController',       'action' => 'loginPage'],
    ['method' => 'POST', 'path' => 'auth/login',              'controller' => 'AuthController',       'action' => 'login'],
    ['method' => 'GET',  'path' => 'auth/logout',             'controller' => 'AuthController',       'action' => 'logout'],
    ['method' => 'GET',  'path' => 'auth/register',           'controller' => 'AuthController',       'action' => 'registerPage'],
    ['method' => 'POST', 'path' => 'auth/register',           'controller' => 'AuthController',       'action' => 'register'],

    // Dashboard
    ['method' => 'GET',  'path' => 'dashboard',               'controller' => 'DashboardController',  'action' => 'index'],

    // Employees
    ['method' => 'GET',  'path' => 'employees',               'controller' => 'EmployeeController',   'action' => 'index'],
    ['method' => 'GET',  'path' => 'employees/create',        'controller' => 'EmployeeController',   'action' => 'create'],
    ['method' => 'POST', 'path' => 'employees/store',         'controller' => 'EmployeeController',   'action' => 'store'],
    ['method' => 'GET',  'path' => 'employees/edit/{id}',     'controller' => 'EmployeeController',   'action' => 'edit'],
    ['method' => 'POST', 'path' => 'employees/update/{id}',   'controller' => 'EmployeeController',   'action' => 'update'],
    ['method' => 'POST', 'path' => 'employees/delete/{id}',   'controller' => 'EmployeeController',   'action' => 'delete'],
    ['method' => 'GET',  'path' => 'employees/view/{id}',     'controller' => 'EmployeeController',   'action' => 'profile'],
    ['method' => 'GET',  'path' => 'employees/search',        'controller' => 'EmployeeController',   'action' => 'search'],

    // Payroll
    ['method' => 'GET',  'path' => 'payroll',                 'controller' => 'PayrollController',    'action' => 'index'],
    ['method' => 'GET',  'path' => 'payroll/run',             'controller' => 'PayrollController',    'action' => 'runPage'],
    ['method' => 'POST', 'path' => 'payroll/run',             'controller' => 'PayrollController',    'action' => 'run'],
    ['method' => 'GET',  'path' => 'payroll/history',         'controller' => 'PayrollController',    'action' => 'history'],
    ['method' => 'GET',  'path' => 'payroll/payslip/{id}',    'controller' => 'PayrollController',    'action' => 'payslip'],
    ['method' => 'POST', 'path' => 'payroll/approve/{id}',    'controller' => 'PayrollController',    'action' => 'approve'],
    ['method' => 'POST', 'path' => 'payroll/reject/{id}',     'controller' => 'PayrollController',    'action' => 'reject'],
    ['method' => 'GET',  'path' => 'payroll/export',          'controller' => 'PayrollController',    'action' => 'export'],
    ['method' => 'GET',  'path' => 'payroll/preview',         'controller' => 'PayrollController',    'action' => 'preview'],

    // Attendance
    ['method' => 'GET',  'path' => 'attendance',              'controller' => 'AttendanceController', 'action' => 'index'],
    ['method' => 'POST', 'path' => 'attendance/checkin',      'controller' => 'AttendanceController', 'action' => 'checkIn'],
    ['method' => 'POST', 'path' => 'attendance/checkout',     'controller' => 'AttendanceController', 'action' => 'checkOut'],
    ['method' => 'GET',  'path' => 'attendance/calendar',     'controller' => 'AttendanceController', 'action' => 'calendar'],
    ['method' => 'GET',  'path' => 'attendance/report',       'controller' => 'AttendanceController', 'action' => 'report'],
    ['method' => 'POST', 'path' => 'attendance/store',        'controller' => 'AttendanceController', 'action' => 'store'],
    ['method' => 'POST', 'path' => 'attendance/update/{id}',  'controller' => 'AttendanceController', 'action' => 'update'],

    // Leaves
    ['method' => 'GET',  'path' => 'leaves',                  'controller' => 'LeaveController',      'action' => 'index'],
    ['method' => 'GET',  'path' => 'leaves/request',          'controller' => 'LeaveController',      'action' => 'requestPage'],
    ['method' => 'POST', 'path' => 'leaves/store',            'controller' => 'LeaveController',      'action' => 'store'],
    ['method' => 'GET',  'path' => 'leaves/approvals',        'controller' => 'LeaveController',      'action' => 'approvals'],
    ['method' => 'POST', 'path' => 'leaves/approve/{id}',     'controller' => 'LeaveController',      'action' => 'approve'],
    ['method' => 'POST', 'path' => 'leaves/reject/{id}',      'controller' => 'LeaveController',      'action' => 'reject'],

    // Reports
    ['method' => 'GET',  'path' => 'reports',                 'controller' => 'ReportController',     'action' => 'index'],
    ['method' => 'GET',  'path' => 'reports/salary',          'controller' => 'ReportController',     'action' => 'salary'],
    ['method' => 'GET',  'path' => 'reports/attendance',      'controller' => 'ReportController',     'action' => 'attendance'],
    ['method' => 'GET',  'path' => 'reports/tax',             'controller' => 'ReportController',     'action' => 'tax'],
    ['method' => 'GET',  'path' => 'reports/export',          'controller' => 'ReportController',     'action' => 'export'],

    // Settings
    ['method' => 'GET',  'path' => 'settings',                'controller' => 'SettingsController',   'action' => 'index'],
    ['method' => 'POST', 'path' => 'settings/tax',            'controller' => 'SettingsController',   'action' => 'saveTax'],
    ['method' => 'POST', 'path' => 'settings/salary',         'controller' => 'SettingsController',   'action' => 'saveSalary'],
    ['method' => 'POST', 'path' => 'settings/general',        'controller' => 'SettingsController',   'action' => 'saveGeneral'],

    // Notifications (AJAX)
    ['method' => 'GET',  'path' => 'notifications',           'controller' => 'NotificationController','action' => 'index'],
    ['method' => 'POST', 'path' => 'notifications/read/{id}', 'controller' => 'NotificationController','action' => 'markRead'],
    ['method' => 'POST', 'path' => 'notifications/read-all',  'controller' => 'NotificationController','action' => 'markAllRead'],

    // Users / Roles
    ['method' => 'GET',  'path' => 'users',                   'controller' => 'UserController',       'action' => 'index'],
    ['method' => 'POST', 'path' => 'users/update/{id}',       'controller' => 'UserController',       'action' => 'update'],
    ['method' => 'POST', 'path' => 'users/delete/{id}',       'controller' => 'UserController',       'action' => 'delete'],

    // Profile
    ['method' => 'GET',  'path' => 'profile',                 'controller' => 'UserController',       'action' => 'profile'],
    ['method' => 'POST', 'path' => 'profile/update',          'controller' => 'UserController',       'action' => 'updateProfile'],
];
