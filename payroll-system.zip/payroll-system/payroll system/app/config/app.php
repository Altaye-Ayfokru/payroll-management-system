<?php
/**
 * Application Configuration
 */

// Detect base URL automatically
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptDir = dirname($_SERVER['SCRIPT_NAME'] ?? '');
$baseUrl = rtrim($protocol . '://' . $host . $scriptDir, '/');

define('BASE_URL', $baseUrl);
define('APP_NAME', 'PayrollPro');
define('APP_VERSION', '1.0.0');
define('APP_ENV', 'development'); // 'production' in live

// Timezone
date_default_timezone_set('Asia/Dhaka');

// Error reporting
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Session config
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Strict');

// Upload settings
define('UPLOAD_PATH', STORAGE_PATH . '/uploads');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

// Pagination
define('ITEMS_PER_PAGE', 15);

// Logger class (simple file logger)
class Logger {
    public static function error(string $message): void {
        self::write('ERROR', $message);
    }
    public static function info(string $message): void {
        self::write('INFO', $message);
    }
    private static function write(string $level, string $message): void {
        $logFile = STORAGE_PATH . '/logs/app_' . date('Y-m-d') . '.log';
        $line = '[' . date('Y-m-d H:i:s') . '] [' . $level . '] ' . $message . PHP_EOL;
        @file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
    }
}
