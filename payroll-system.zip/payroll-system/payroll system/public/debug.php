<?php
/**
 * PayrollPro Debug Script
 * Visit: http://localhost/payroll%20system/public/debug.php
 * DELETE after use!
 */
if (!in_array($_SERVER['REMOTE_ADDR'], ['127.0.0.1', '::1'])) die('Localhost only.');

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo '<style>body{font-family:monospace;padding:20px;background:#f1f5f9}
.ok{color:green;font-weight:bold}.err{color:red;font-weight:bold}
.box{background:#fff;padding:16px;border-radius:8px;margin-bottom:16px;box-shadow:0 2px 8px rgba(0,0,0,.1)}
h2{margin-bottom:10px;font-size:1rem;color:#333}
table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:6px 10px;font-size:.85rem}
th{background:#f8f8f8}</style>';

echo '<h1 style="color:#6366f1;margin-bottom:20px">PayrollPro Debug</h1>';

// ── 1. PHP Version ──────────────────────────────────────────
echo '<div class="box"><h2>1. PHP Version</h2>';
echo '<span class="ok">PHP ' . PHP_VERSION . '</span>';
echo ' | Extensions: ';
echo extension_loaded('pdo_mysql') ? '<span class="ok">pdo_mysql ✓</span>' : '<span class="err">pdo_mysql ✗ MISSING</span>';
echo ' | ';
echo extension_loaded('mbstring') ? '<span class="ok">mbstring ✓</span>' : '<span class="err">mbstring ✗</span>';
echo '</div>';

// ── 2. File Paths ───────────────────────────────────────────
echo '<div class="box"><h2>2. File Paths</h2>';
$root = dirname(__DIR__);
echo 'ROOT: ' . $root . '<br>';
echo 'index.php exists: ';
echo file_exists($root . '/public/index.php') ? '<span class="ok">YES ✓</span>' : '<span class="err">NO ✗</span>';
echo '<br>config/database.php exists: ';
echo file_exists($root . '/app/config/database.php') ? '<span class="ok">YES ✓</span>' : '<span class="err">NO ✗</span>';
echo '</div>';

// ── 3. Database Connection ──────────────────────────────────
echo '<div class="box"><h2>3. Database Connection</h2>';
$cfg = require $root . '/app/config/database.php';
echo "Host: {$cfg['host']} | DB: {$cfg['dbname']} | User: {$cfg['username']}<br>";
try {
    $pdo = new PDO(
        "mysql:host={$cfg['host']};dbname={$cfg['dbname']};charset=utf8mb4",
        $cfg['username'], $cfg['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    echo '<span class="ok">✓ Connected to MySQL successfully</span>';
} catch (PDOException $e) {
    echo '<span class="err">✗ Connection FAILED: ' . $e->getMessage() . '</span>';
    echo '<br><br><b>Fix:</b> Check app/config/database.php and make sure MySQL is running in XAMPP.';
    die('</div>');
}
echo '</div>';

// ── 4. Tables ───────────────────────────────────────────────
echo '<div class="box"><h2>4. Database Tables</h2>';
$tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
if (empty($tables)) {
    echo '<span class="err">✗ NO TABLES FOUND — you need to import database/setup.sql in phpMyAdmin!</span>';
} else {
    echo '<span class="ok">✓ Found ' . count($tables) . ' tables:</span> ';
    echo implode(', ', $tables);
}
echo '</div>';

// ── 5. Users in DB ──────────────────────────────────────────
echo '<div class="box"><h2>5. Users in Database</h2>';
try {
    $users = $pdo->query("SELECT id, name, email, role, is_active, LEFT(password,30) as hash_preview FROM users")->fetchAll(PDO::FETCH_ASSOC);
    if (empty($users)) {
        echo '<span class="err">✗ NO USERS FOUND — import database/setup.sql first!</span>';
    } else {
        echo '<table><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Active</th><th>Hash Preview</th></tr>';
        foreach ($users as $u) {
            echo "<tr><td>{$u['id']}</td><td>{$u['name']}</td><td>{$u['email']}</td><td>{$u['role']}</td><td>{$u['is_active']}</td><td>{$u['hash_preview']}...</td></tr>";
        }
        echo '</table>';
    }
} catch (Exception $e) {
    echo '<span class="err">✗ users table missing: ' . $e->getMessage() . '</span>';
}
echo '</div>';

// ── 6. Password Verification Test ───────────────────────────
echo '<div class="box"><h2>6. Password Hash Test</h2>';
try {
    $row = $pdo->query("SELECT password FROM users WHERE email='admin@payrollpro.com'")->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        echo '<span class="err">✗ admin@payrollpro.com not found in DB</span>';
    } else {
        echo 'Stored hash: <code>' . htmlspecialchars($row['password']) . '</code><br><br>';
        $tests = ['Admin123', 'admin123', 'Admin@123', 'password', 'Hr1234'];
        foreach ($tests as $pwd) {
            $ok = password_verify($pwd, $row['password']);
            echo ($ok ? '<span class="ok">✓' : '<span class="err">✗') . " password_verify('{$pwd}') = " . ($ok ? 'TRUE' : 'false') . '</span><br>';
        }
    }
} catch (Exception $e) {
    echo '<span class="err">Error: ' . $e->getMessage() . '</span>';
}
echo '</div>';

// ── 7. Fix Passwords NOW ────────────────────────────────────
echo '<div class="box"><h2>7. Reset All Passwords Now</h2>';
if (isset($_GET['fix'])) {
    $updates = [
        ['admin@payrollpro.com',  'Admin123'],
        ['hr@payrollpro.com',     'Hr1234'],
        ['john@payrollpro.com',   'John123'],
        ['sarah@payrollpro.com',  'Sarah123'],
        ['mike@payrollpro.com',   'Mike123'],
        ['emily@payrollpro.com',  'Emily123'],
        ['robert@payrollpro.com', 'Robert123'],
    ];
    $stmt = $pdo->prepare("UPDATE users SET password=:h WHERE email=:e");
    foreach ($updates as [$email, $pwd]) {
        $hash = password_hash($pwd, PASSWORD_BCRYPT, ['cost' => 10]);
        $stmt->execute([':h' => $hash, ':e' => $email]);
        $ok = password_verify($pwd, $hash);
        echo ($ok ? '<span class="ok">✓' : '<span class="err">✗') . " {$email} → {$pwd} (verify: " . ($ok ? 'OK' : 'FAIL') . ")</span><br>";
    }
    echo '<br><span class="ok">✓ Done! <a href="?">Refresh to verify</a> | <a href="./">Go to Login</a></span>';
} else {
    echo '<a href="?fix=1" style="background:#6366f1;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:bold">▶ Click to Reset All Passwords</a>';
    echo '<br><br>This will set:<br>';
    echo '• admin@payrollpro.com → <b>Admin123</b><br>';
    echo '• hr@payrollpro.com → <b>Hr1234</b><br>';
    echo '• john@payrollpro.com → <b>John123</b><br>';
    echo '• (other employees → their name + 123)';
}
echo '</div>';

// ── 8. .htaccess Check ──────────────────────────────────────
echo '<div class="box"><h2>8. .htaccess / mod_rewrite</h2>';
echo 'SCRIPT_NAME: ' . $_SERVER['SCRIPT_NAME'] . '<br>';
echo 'REQUEST_URI: ' . $_SERVER['REQUEST_URI'] . '<br>';
$htaccess = file_get_contents(__DIR__ . '/.htaccess');
echo 'RewriteBase in .htaccess: ';
preg_match('/RewriteBase\s+(.+)/', $htaccess, $m);
echo isset($m[1]) ? '<span class="ok">' . trim($m[1]) . ' ✓</span>' : '<span class="err">NOT SET</span>';
echo '</div>';

echo '<p style="color:#94a3b8;font-size:.8rem">Delete this file after use: public/debug.php</p>';
