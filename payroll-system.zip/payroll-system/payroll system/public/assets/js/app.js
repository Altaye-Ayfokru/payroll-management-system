/**
 * PayrollPro — app.js
 * Sidebar, dropdowns, notifications, modals, flash
 */
'use strict';

document.addEventListener('DOMContentLoaded', function () {

  /* ── Sidebar toggle ── */
  var sidebar        = document.getElementById('sidebar');
  var mainWrapper    = document.getElementById('mainWrapper');
  var sidebarOverlay = document.getElementById('sidebarOverlay');
  var topbarMenuBtn  = document.getElementById('topbarMenuBtn');
  var sidebarToggle  = document.getElementById('sidebarToggle');

  function openSidebar() {
    if (!sidebar) return;
    sidebar.classList.add('open');
    if (sidebarOverlay) sidebarOverlay.style.display = 'block';
  }

  window.closeSidebar = function () {
    if (!sidebar) return;
    sidebar.classList.remove('open');
    if (sidebarOverlay) sidebarOverlay.style.display = 'none';
  };

  function toggleSidebar() {
    if (window.innerWidth <= 1024) {
      sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    } else {
      // Desktop collapse
      sidebar && sidebar.classList.toggle('collapsed');
      if (mainWrapper) {
        mainWrapper.style.marginLeft = sidebar.classList.contains('collapsed') ? '72px' : '260px';
      }
    }
  }

  topbarMenuBtn && topbarMenuBtn.addEventListener('click', toggleSidebar);
  sidebarToggle && sidebarToggle.addEventListener('click', toggleSidebar);

  /* ── Notification dropdown ── */
  var notifBtn      = document.getElementById('notifBtn');
  var notifDropdown = document.getElementById('notifDropdown');
  var profileBtn    = document.getElementById('profileBtn');
  var profileDrop   = document.getElementById('profileDropdown');

  function closeAllDropdowns() {
    notifDropdown && notifDropdown.classList.remove('open');
    profileDrop   && profileDrop.classList.remove('open');
  }

  notifBtn && notifBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    var isOpen = notifDropdown.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) {
      notifDropdown.classList.add('open');
      loadNotifications();
    }
  });

  profileBtn && profileBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    var isOpen = profileDrop.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) profileDrop.classList.add('open');
  });

  document.addEventListener('click', closeAllDropdowns);

  /* ── Mark all read ── */
  var markAllBtn = document.getElementById('markAllRead');
  markAllBtn && markAllBtn.addEventListener('click', function () {
    ajax('POST', 'notifications/read-all', {}, function () {
      var badge = document.getElementById('notifBadge');
      if (badge) badge.style.display = 'none';
      document.querySelectorAll('.notif-item.unread').forEach(function (el) {
        el.classList.remove('unread');
      });
    });
  });

  /* ── Auto-dismiss flash ── */
  var flash = document.getElementById('flashMsg');
  if (flash) setTimeout(function () {
    flash.style.transition = 'opacity .4s';
    flash.style.opacity = '0';
    setTimeout(function () { flash.remove(); }, 400);
  }, 5000);

  /* ── Modal helpers ── */
  window.openModal = function (id) {
    var m = document.getElementById(id);
    if (m) { m.style.display = 'flex'; document.body.style.overflow = 'hidden'; }
  };
  window.closeModal = function (id) {
    var m = document.getElementById(id);
    if (m) { m.style.display = 'none'; document.body.style.overflow = ''; }
  };

  document.querySelectorAll('.modal-overlay').forEach(function (overlay) {
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closeModal(overlay.id);
    });
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay[style*="flex"]').forEach(function (m) {
        m.style.display = 'none';
        document.body.style.overflow = '';
      });
    }
  });

  /* ── Avatar preview ── */
  document.querySelectorAll('.avatar-upload-input, input[type="file"][accept*="image"]').forEach(function (input) {
    input.addEventListener('change', function () {
      var preview = document.querySelector('.avatar-preview, #avatarPreview');
      if (preview && this.files[0]) {
        preview.src = URL.createObjectURL(this.files[0]);
      }
    });
  });

  /* ── Live clock ── */
  var clockEl = document.getElementById('liveClock');
  if (clockEl) {
    var tick = function () {
      clockEl.textContent = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      });
    };
    tick();
    setInterval(tick, 1000);
  }

  /* ── Confirm delete ── */
  document.querySelectorAll('[data-confirm]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      if (!confirm(btn.dataset.confirm || 'Are you sure?')) e.preventDefault();
    });
  });

  /* ── Clickable table rows ── */
  document.querySelectorAll('tr[data-href]').forEach(function (row) {
    row.style.cursor = 'pointer';
    row.addEventListener('click', function () { window.location = row.dataset.href; });
  });

  /* ── Load notifications on page load ── */
  loadNotifications();

  /* ── Ripple keyframe (inject once) ── */
  if (!document.getElementById('rippleStyle')) {
    var s = document.createElement('style');
    s.id = 'rippleStyle';
    s.textContent = '@keyframes ripple{0%{transform:scale(0);opacity:.6}100%{transform:scale(2.5);opacity:0}}';
    document.head.appendChild(s);
  }
});

/* ── Load Notifications ── */
function loadNotifications() {
  ajax('GET', 'notifications', {}, function (data) {
    var badge = document.getElementById('notifBadge');
    var list  = document.getElementById('notifList');
    if (!list) return;

    var count = data.unread_count || 0;
    if (badge) {
      badge.textContent = count > 9 ? '9+' : count;
      badge.style.display = count > 0 ? 'flex' : 'none';
    }

    if (!data.notifications || !data.notifications.length) {
      list.innerHTML = '<div class="notif-empty"><i class="fas fa-check-circle"></i><span>All caught up!</span></div>';
      return;
    }

    var iconMap = {
      payroll: 'fa-money-bill-wave notif-icon-payroll',
      success: 'fa-check-circle notif-icon-success',
      warning: 'fa-exclamation-triangle notif-icon-warning',
      info:    'fa-info-circle notif-icon-info',
      leave:   'fa-calendar-check notif-icon-info',
      danger:  'fa-exclamation-circle notif-icon-warning'
    };

    list.innerHTML = data.notifications.map(function (n) {
      var iconClass = iconMap[n.type] || 'fa-bell notif-icon-info';
      var faIcon    = iconClass.split(' ')[0];
      var bgClass   = iconClass.split(' ')[1] || 'notif-icon-info';
      return '<div class="notif-item ' + (n.is_read ? '' : 'unread') + '" onclick="markNotifRead(' + n.id + ',this)">' +
        '<div class="notif-item-icon ' + bgClass + '"><i class="fas ' + faIcon + '"></i></div>' +
        '<div style="flex:1">' +
          '<div class="notif-item-msg">' + escHtml(n.message) + '</div>' +
          '<div class="notif-item-time">' + timeAgo(n.created_at) + '</div>' +
        '</div>' +
      '</div>';
    }).join('');
  });
}

function markNotifRead(id, el) {
  ajax('POST', 'notifications/read/' + id, {}, function () {
    el && el.classList.remove('unread');
  });
}

function timeAgo(datetime) {
  var diff = Math.floor((Date.now() - new Date(datetime)) / 1000);
  if (diff < 60)     return 'just now';
  if (diff < 3600)   return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400)  return Math.floor(diff / 3600) + 'h ago';
  return Math.floor(diff / 86400) + 'd ago';
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
