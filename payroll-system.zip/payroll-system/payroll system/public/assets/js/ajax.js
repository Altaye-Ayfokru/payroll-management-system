/**
 * PayrollPro — ajax.js
 * Reusable AJAX helpers + form submission
 */

/* ── Resolve BASE_URL from the meta tag injected by header.php ── */
var BASE_URL = (function () {
  var meta = document.querySelector('meta[name="base-url"]');
  if (meta && meta.content) return meta.content.replace(/\/$/, '');
  // Fallback: strip the last path segment (works for /public/ subfolder)
  var path = window.location.pathname.replace(/\/[^/]*$/, '');
  return window.location.origin + path;
}());

/**
 * Build a full URL from a relative path
 */
function buildUrl(path) {
  path = path.replace(/^\//, '');
  return BASE_URL + '/' + path;
}

/**
 * Core AJAX function
 * @param {string} method    GET | POST
 * @param {string} path      URL path relative to BASE_URL  OR  full URL
 * @param {object|FormData}  data
 * @param {function}         onSuccess(json)
 * @param {function}         onError(err)
 */
function ajax(method, path, data, onSuccess, onError) {
  // Accept both relative paths and full URLs
  var url = (path.startsWith('http://') || path.startsWith('https://'))
    ? path
    : buildUrl(path);

  var opts = {
    method: method,
    headers: { 'X-Requested-With': 'XMLHttpRequest' }
  };

  if (method === 'POST') {
    var fd;
    if (data instanceof FormData) {
      fd = data;
      // Ensure CSRF token is present
      if (!fd.has('csrf_token')) {
        var csrfMeta  = document.querySelector('meta[name="csrf-token"]');
        var csrfInput = document.querySelector('input[name="csrf_token"]');
        var token = (csrfMeta && csrfMeta.content) || (csrfInput && csrfInput.value) || '';
        if (token) fd.append('csrf_token', token);
      }
    } else {
      fd = new FormData();
      var csrfMeta2  = document.querySelector('meta[name="csrf-token"]');
      var csrfInput2 = document.querySelector('input[name="csrf_token"]');
      var token2 = (csrfMeta2 && csrfMeta2.content) || (csrfInput2 && csrfInput2.value) || '';
      if (token2) fd.append('csrf_token', token2);
      if (data && typeof data === 'object') {
        Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
      }
    }
    opts.body = fd;
  }

  fetch(url, opts)
    .then(function (response) {
      // Try to parse JSON regardless of status code
      return response.text().then(function (text) {
        var json;
        try {
          json = JSON.parse(text);
        } catch (e) {
          // Server returned non-JSON (PHP error, redirect HTML, etc.)
          console.error('Non-JSON response from', url, ':', text.substring(0, 300));
          throw new Error('Server returned non-JSON response. Check PHP error logs.');
        }
        return json;
      });
    })
    .then(function (json) {
      if (onSuccess) onSuccess(json);
    })
    .catch(function (err) {
      console.error('AJAX error [' + method + ' ' + url + ']:', err.message || err);
      if (onError) {
        onError(err);
      } else {
        showToast(err.message || 'Network error. Please try again.', 'error');
      }
    });
}

/* ── AJAX form submit helper ─────────────────────────────────
   Usage: <form data-ajax="true" data-success="Saved!" data-reload="true">
   ─────────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function () {

  document.querySelectorAll('form[data-ajax]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      var btn      = form.querySelector('[type="submit"]');
      var origText = btn ? btn.innerHTML : '';
      if (btn) {
        btn.disabled  = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
      }

      // Use the form's action attribute as the URL
      var actionUrl = form.action || buildUrl('');

      var fd = new FormData(form);

      ajax('POST', actionUrl, fd, function (data) {
        if (btn) { btn.disabled = false; btn.innerHTML = origText; }

        if (data && data.success) {
          var msg = form.dataset.success || data.message || 'Saved successfully!';
          showToast(msg, 'success');
          if (data.redirect) setTimeout(function () { window.location = data.redirect; }, 800);
          if (form.dataset.closeModal) closeModal(form.dataset.closeModal);
          if (form.dataset.reload) setTimeout(function () { window.location.reload(); }, 800);
        } else {
          var errMsg = (data && data.message) ? data.message : 'An error occurred.';
          showToast(errMsg, 'error');
          if (data && data.errors) {
            Object.keys(data.errors).forEach(function (field) {
              var input = form.querySelector('[name="' + field + '"]');
              if (input) {
                input.classList.add('is-invalid');
                var errEl = input.parentElement.querySelector('.form-error');
                if (!errEl) {
                  errEl = document.createElement('div');
                  errEl.className = 'form-error';
                  input.after(errEl);
                }
                errEl.textContent = data.errors[field];
              }
            });
          }
        }
      }, function (err) {
        if (btn) { btn.disabled = false; btn.innerHTML = origText; }
        showToast((err && err.message) || 'Network error. Please try again.', 'error');
      });
    });
  });

  /* ── Approve/Reject data-action buttons ── */
  document.querySelectorAll('[data-action]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var action = this.dataset.action;
      var id     = this.dataset.id;
      if (!confirm('Are you sure you want to ' + action + ' this?')) return;

      ajax('POST', action + '/' + id, {}, function (data) {
        if (data && data.success) {
          showToast(data.message || 'Done!', 'success');
          setTimeout(function () { window.location.reload(); }, 800);
        } else {
          showToast((data && data.message) || 'Failed.', 'error');
        }
      });
    });
  });
});

/* ── Toast notification ──────────────────────────────────── */
function showToast(message, type) {
  type = type || 'info';

  var container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.style.cssText = [
      'position:fixed', 'bottom:24px', 'right:24px', 'z-index:9999',
      'display:flex', 'flex-direction:column', 'gap:8px', 'max-width:380px'
    ].join(';');
    document.body.appendChild(container);
  }

  var icons  = { success:'check-circle', error:'exclamation-circle', warning:'exclamation-triangle', info:'info-circle' };
  var colors = { success:'#10b981', error:'#ef4444', warning:'#f59e0b', info:'#3b82f6' };
  var color  = colors[type] || colors.info;
  var icon   = icons[type]  || icons.info;

  // Inject animation once
  if (!document.getElementById('toastStyle')) {
    var s = document.createElement('style');
    s.id = 'toastStyle';
    s.textContent = '@keyframes slideInRight{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}';
    document.head.appendChild(s);
  }

  var toast = document.createElement('div');
  toast.style.cssText = [
    'display:flex', 'align-items:center', 'gap:10px',
    'padding:12px 16px', 'background:#fff', 'border-radius:10px',
    'box-shadow:0 4px 20px rgba(0,0,0,.15)',
    'border-left:4px solid ' + color,
    'font-size:.875rem', 'font-weight:500', 'color:#0f172a',
    'animation:slideInRight .3s ease', 'min-width:240px'
  ].join(';');
  toast.innerHTML = '<i class="fas fa-' + icon + '" style="color:' + color + ';flex-shrink:0"></i>'
                  + '<span>' + escHtml(String(message)) + '</span>';

  container.appendChild(toast);
  setTimeout(function () {
    toast.style.transition = 'opacity .3s';
    toast.style.opacity = '0';
    setTimeout(function () { toast.remove(); }, 300);
  }, 4500);
}
