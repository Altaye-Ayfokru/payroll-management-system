/**
 * PayrollPro — charts.js
 * All Chart.js configurations — colorful, animated, enterprise-grade
 */
(function () {
  'use strict';

  // ── Palette ──────────────────────────────────────────────
  var C = {
    primary:   '#6366f1',
    secondary: '#8b5cf6',
    success:   '#10b981',
    warning:   '#f59e0b',
    danger:    '#ef4444',
    info:      '#3b82f6',
    pink:      '#ec4899',
    teal:      '#14b8a6',
    orange:    '#f97316',
    indigo:    '#4f46e5',
    multi: ['#6366f1','#10b981','#f59e0b','#3b82f6','#ec4899','#14b8a6','#f97316','#8b5cf6','#ef4444','#84cc16']
  };

  // ── Shared tooltip style ─────────────────────────────────
  var tooltipDefaults = {
    backgroundColor: '#0f172a',
    titleColor: '#f1f5f9',
    bodyColor: '#94a3b8',
    borderColor: '#1e293b',
    borderWidth: 1,
    padding: 12,
    cornerRadius: 10,
    displayColors: true,
    boxPadding: 4
  };

  // ── Shared animation ─────────────────────────────────────
  var animDefaults = { duration: 1000, easing: 'easeOutQuart' };

  // ── Currency formatter ───────────────────────────────────
  function fmtCurrency(v) {
    if (v >= 1000000) return '$' + (v / 1000000).toFixed(1) + 'M';
    if (v >= 1000)    return '$' + (v / 1000).toFixed(0) + 'k';
    return '$' + v.toFixed(0);
  }

  // ── Gradient helper ──────────────────────────────────────
  function makeGradient(ctx, color, alpha1, alpha2) {
    var g = ctx.createLinearGradient(0, 0, 0, ctx.canvas.height);
    g.addColorStop(0,   color.replace(')', ',' + alpha1 + ')').replace('rgb', 'rgba'));
    g.addColorStop(1,   color.replace(')', ',' + alpha2 + ')').replace('rgb', 'rgba'));
    return g;
  }

  // ── Hex to rgba ──────────────────────────────────────────
  function hexRgba(hex, a) {
    var r = parseInt(hex.slice(1,3),16);
    var g = parseInt(hex.slice(3,5),16);
    var b = parseInt(hex.slice(5,7),16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  }

  // ── Init all charts when DOM ready ───────────────────────
  function initAll() {
    if (typeof Chart === 'undefined') {
      setTimeout(initAll, 100);
      return;
    }

    Chart.defaults.font.family = "'Inter', system-ui, sans-serif";
    Chart.defaults.font.size   = 12;
    Chart.defaults.color       = '#64748b';

    initPayrollTrend();
    initDeptDoughnut();
    initAttendanceBar();
    initSalaryReport();
    initPayrollTrendReport();
    initAttendanceReport();
    initTaxReport();
    initLeaveTypeChart();
    initHeadcountChart();
    initOvertimeChart();
  }

  // ════════════════════════════════════════════════════════
  // 1. PAYROLL TREND — Dashboard (line chart, gradient fill)
  // ════════════════════════════════════════════════════════
  function initPayrollTrend() {
    var el = document.getElementById('payrollTrendChart');
    if (!el) return;

    var labels = JSON.parse(el.getAttribute('data-labels') || el.getAttribute('data-trend') && '[]' || '[]');
    var values = JSON.parse(el.getAttribute('data-values') || '[]');

    // Fallback: old data-trend format
    if (!labels.length && el.getAttribute('data-trend')) {
      var raw = JSON.parse(el.getAttribute('data-trend') || '[]');
      labels  = raw.map(function(r){ return r.pay_month || r; });
      values  = raw.map(function(r){ return parseFloat(r.total || 0); });
    }

    var ctx = el.getContext('2d');
    var grad = ctx.createLinearGradient(0, 0, 0, 260);
    grad.addColorStop(0,   hexRgba(C.primary, 0.25));
    grad.addColorStop(0.6, hexRgba(C.primary, 0.05));
    grad.addColorStop(1,   hexRgba(C.primary, 0));

    new Chart(el, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Net Payroll',
          data: values,
          borderColor: C.primary,
          borderWidth: 3,
          backgroundColor: grad,
          fill: true,
          tension: 0.45,
          pointBackgroundColor: C.primary,
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 5,
          pointHoverRadius: 8,
          pointHoverBackgroundColor: C.secondary,
          pointHoverBorderWidth: 3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        animation: animDefaults,
        plugins: {
          legend: { display: false },
          tooltip: Object.assign({}, tooltipDefaults, {
            callbacks: {
              label: function(ctx) {
                return '  Net: ' + fmtCurrency(ctx.parsed.y);
              }
            }
          })
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { color: '#94a3b8', font: { size: 11, weight: '500' } },
            border: { display: false }
          },
          y: {
            grid: { color: '#f1f5f9', drawBorder: false },
            ticks: { color: '#94a3b8', callback: fmtCurrency },
            border: { display: false }
          }
        }
      }
    });
  }

  // ════════════════════════════════════════════════════════
  // 2. DEPARTMENT DOUGHNUT — Dashboard
  // ════════════════════════════════════════════════════════
  function initDeptDoughnut() {
    var el = document.getElementById('deptDoughnutChart') ||
             document.getElementById('deptSalaryChart');
    if (!el) return;

    var labels = JSON.parse(el.getAttribute('data-labels') || '[]');
    var values = JSON.parse(el.getAttribute('data-values') || '[]');
    var colors = JSON.parse(el.getAttribute('data-colors') || JSON.stringify(C.multi));

    // Fallback: old data-dept format
    if (!labels.length && el.getAttribute('data-dept')) {
      var raw = JSON.parse(el.getAttribute('data-dept') || '[]');
      labels  = raw.map(function(r){ return r.department; });
      values  = raw.map(function(r){ return parseFloat(r.total_salary || r.total_net || 0); });
      colors  = C.multi.slice(0, labels.length);
    }

    if (!labels.length) return;

    new Chart(el, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [{
          data: values,
          backgroundColor: colors,
          borderColor: '#fff',
          borderWidth: 3,
          hoverBorderWidth: 4,
          hoverOffset: 10
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        animation: { animateRotate: true, animateScale: true, duration: 1200, easing: 'easeOutQuart' },
        plugins: {
          legend: {
            position: 'bottom',
            labels: { padding: 14, usePointStyle: true, pointStyleWidth: 10, font: { size: 11 } }
          },
          tooltip: Object.assign({}, tooltipDefaults, {
            callbacks: {
              label: function(ctx) {
                var total = ctx.dataset.data.reduce(function(a,b){ return a+b; }, 0);
                var pct   = total > 0 ? ((ctx.parsed / total) * 100).toFixed(1) : 0;
                return '  ' + ctx.label + ': ' + fmtCurrency(ctx.parsed) + ' (' + pct + '%)';
              }
            }
          })
        }
      }
    });
  }

  // ════════════════════════════════════════════════════════
  // 3. ATTENDANCE BAR — Dashboard today stats
  // ════════════════════════════════════════════════════════
  function initAttendanceBar() {
    var el = document.getElementById('attendanceTodayChart');
    if (!el) return;

    var stats = JSON.parse(el.getAttribute('data-stats') || '{}');

    new Chart(el, {
      type: 'bar',
      data: {
        labels: ['Present', 'Absent', 'Late'],
        datasets: [{
          data: [stats.present || 0, stats.absent || 0, stats.late || 0],
          backgroundColor: [
            hexRgba(C.success, 0.85),
            hexRgba(C.danger,  0.85),
            hexRgba(C.warning, 0.85)
          ],
          borderColor: [C.success, C.danger, C.warning],
          borderWidth: 2,
          borderRadius: 8,
          borderSkipped: false
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: animDefaults,
        plugins: {
          legend: { display: false },
          tooltip: Object.assign({}, tooltipDefaults, {
            callbacks: {
              label: function(ctx) { return '  ' + ctx.label + ': ' + ctx.parsed.y + ' employees'; }
            }
          })
        },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#94a3b8' }, border: { display: false } },
          y: { grid: { color: '#f1f5f9' }, beginAtZero: true, ticks: { stepSize: 1, color: '#94a3b8' }, border: { display: false } }
        }
      }
    });
  }

  // ════════════════════════════════════════════════════════
  // 4. SALARY REPORT — Grouped bar (Gross / Net / Tax)
  // ════════════════════════════════════════════════════════
  function initSalaryReport() {
    var el = document.getElementById('salaryReportChart');
    if (!el) return;

    var raw    = JSON.parse(el.getAttribute('data-payrolls') || '[]');
    var labels = raw.map(function(r){ return r.employee_name || r.name || ''; });

    new Chart(el, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Gross Salary',
            data: raw.map(function(r){ return parseFloat(r.gross_salary || 0); }),
            backgroundColor: hexRgba(C.primary, 0.8),
            borderColor: C.primary,
            borderWidth: 1,
            borderRadius: 5,
            borderSkipped: false
          },
          {
            label: 'Net Salary',
            data: raw.map(function(r){ return parseFloat(r.net_salary || 0); }),
            backgroundColor: hexRgba(C.success, 0.8),
            borderColor: C.success,
            borderWidth: 1,
            borderRadius: 5,
            borderSkipped: false
          },
          {
            label: 'Tax',
            data: raw.map(function(r){ return parseFloat(r.tax || 0); }),
            backgroundColor: hexRgba(C.danger, 0.7),
            borderColor: C.danger,
            borderWidth: 1,
            borderRadius: 5,
            borderSkipped: false
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: animDefaults,
        plugins: {
          legend: { position: 'top', labels: { usePointStyle: true, padding: 16 } },
          tooltip: Object.assign({}, tooltipDefaults, {
            callbacks: {
              label: function(ctx) { return '  ' + ctx.dataset.label + ': ' + fmtCurrency(ctx.parsed.y); }
            }
          })
        },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#94a3b8', maxRotation: 45 }, border: { display: false } },
          y: { grid: { color: '#f1f5f9' }, ticks: { color: '#94a3b8', callback: fmtCurrency }, border: { display: false } }
        }
      }
    });
  }

  // ════════════════════════════════════════════════════════
  // 5. PAYROLL TREND REPORT — Multi-line (Net + Tax)
  // ════════════════════════════════════════════════════════
  function initPayrollTrendReport() {
    var el = document.getElementById('payrollTrendReportChart');
    if (!el) return;

    var raw = JSON.parse(el.getAttribute('data-trend') || '[]');
    var labels = raw.map(function(r){ return r.pay_month || ''; });

    var ctx   = el.getContext('2d');
    var grad1 = ctx.createLinearGradient(0, 0, 0, 280);
    grad1.addColorStop(0, hexRgba(C.primary, 0.2));
    grad1.addColorStop(1, hexRgba(C.primary, 0));

    var grad2 = ctx.createLinearGradient(0, 0, 0, 280);
    grad2.addColorStop(0, hexRgba(C.danger, 0.15));
    grad2.addColorStop(1, hexRgba(C.danger, 0));

    new Chart(el, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Net Payroll',
            data: raw.map(function(r){ return parseFloat(r.total || 0); }),
            borderColor: C.primary,
            backgroundColor: grad1,
            fill: true,
            tension: 0.45,
            borderWidth: 3,
            pointBackgroundColor: C.primary,
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 8
          },
          {
            label: 'Total Tax',
            data: raw.map(function(r){ return parseFloat(r.total_tax || 0); }),
            borderColor: C.danger,
            backgroundColor: grad2,
            fill: true,
            tension: 0.45,
            borderWidth: 2,
            borderDash: [5, 3],
            pointBackgroundColor: C.danger,
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 4,
            pointHoverRadius: 7
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        animation: animDefaults,
        plugins: {
          legend: { position: 'top', labels: { usePointStyle: true, padding: 16 } },
          tooltip: Object.assign({}, tooltipDefaults, {
            callbacks: {
              label: function(ctx) { return '  ' + ctx.dataset.label + ': ' + fmtCurrency(ctx.parsed.y); }
            }
          })
        },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#94a3b8' }, border: { display: false } },
          y: { grid: { color: '#f1f5f9' }, ticks: { color: '#94a3b8', callback: fmtCurrency }, border: { display: false } }
        }
      }
    });
  }

  // ════════════════════════════════════════════════════════
  // 6. ATTENDANCE REPORT — Stacked bar by status
  // ════════════════════════════════════════════════════════
  function initAttendanceReport() {
    var el = document.getElementById('attendanceReportChart');
    if (!el) return;

    var raw = JSON.parse(el.getAttribute('data-records') || '[]');
    if (!raw.length) return;

    // Group by employee
    var empMap = {};
    raw.forEach(function(r) {
      var name = r.employee_name || 'Unknown';
      if (!empMap[name]) empMap[name] = { present: 0, absent: 0, late: 0, half_day: 0 };
      empMap[name][r.status] = (empMap[name][r.status] || 0) + 1;
    });

    var labels  = Object.keys(empMap).slice(0, 12);
    var present = labels.map(function(n){ return empMap[n].present || 0; });
    var absent  = labels.map(function(n){ return empMap[n].absent  || 0; });
    var late    = labels.map(function(n){ return empMap[n].late    || 0; });

    new Chart(el, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          { label: 'Present', data: present, backgroundColor: hexRgba(C.success, 0.85), borderRadius: 4, stack: 'att' },
          { label: 'Late',    data: late,    backgroundColor: hexRgba(C.warning, 0.85), borderRadius: 4, stack: 'att' },
          { label: 'Absent',  data: absent,  backgroundColor: hexRgba(C.danger,  0.85), borderRadius: 4, stack: 'att' }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: animDefaults,
        plugins: {
          legend: { position: 'top', labels: { usePointStyle: true, padding: 16 } },
          tooltip: Object.assign({}, tooltipDefaults)
        },
        scales: {
          x: { stacked: true, grid: { display: false }, ticks: { color: '#94a3b8', maxRotation: 45 }, border: { display: false } },
          y: { stacked: true, grid: { color: '#f1f5f9' }, ticks: { color: '#94a3b8', stepSize: 1 }, border: { display: false } }
        }
      }
    });
  }

  // ════════════════════════════════════════════════════════
  // 7. TAX REPORT — Horizontal bar
  // ════════════════════════════════════════════════════════
  function initTaxReport() {
    var el = document.getElementById('taxReportChart');
    if (!el) return;

    var raw    = JSON.parse(el.getAttribute('data-payrolls') || '[]');
    var labels = raw.map(function(r){ return r.employee_name || ''; });

    new Chart(el, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Income Tax',
            data: raw.map(function(r){ return parseFloat(r.tax || 0); }),
            backgroundColor: hexRgba(C.warning, 0.85),
            borderColor: C.warning,
            borderWidth: 1,
            borderRadius: 5
          },
          {
            label: 'Provident Fund',
            data: raw.map(function(r){ return parseFloat(r.provident_fund || 0); }),
            backgroundColor: hexRgba(C.info, 0.85),
            borderColor: C.info,
            borderWidth: 1,
            borderRadius: 5
          },
          {
            label: 'Insurance',
            data: raw.map(function(r){ return parseFloat(r.insurance || 0); }),
            backgroundColor: hexRgba(C.secondary, 0.85),
            borderColor: C.secondary,
            borderWidth: 1,
            borderRadius: 5
          }
        ]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        animation: animDefaults,
        plugins: {
          legend: { position: 'top', labels: { usePointStyle: true, padding: 16 } },
          tooltip: Object.assign({}, tooltipDefaults, {
            callbacks: {
              label: function(ctx) { return '  ' + ctx.dataset.label + ': ' + fmtCurrency(ctx.parsed.x); }
            }
          })
        },
        scales: {
          x: { grid: { color: '#f1f5f9' }, ticks: { color: '#94a3b8', callback: fmtCurrency }, border: { display: false } },
          y: { grid: { display: false }, ticks: { color: '#94a3b8' }, border: { display: false } }
        }
      }
    });
  }

  // ════════════════════════════════════════════════════════
  // 8. LEAVE TYPE PIE — Leave reports
  // ════════════════════════════════════════════════════════
  function initLeaveTypeChart() {
    var el = document.getElementById('leaveTypeChart');
    if (!el) return;

    var raw = JSON.parse(el.getAttribute('data-leaves') || '[]');
    if (!raw.length) return;

    // Count by type
    var typeMap = {};
    raw.forEach(function(r) {
      var t = r.leave_type || 'other';
      typeMap[t] = (typeMap[t] || 0) + 1;
    });

    var labels = Object.keys(typeMap).map(function(t){ return t.charAt(0).toUpperCase() + t.slice(1); });
    var values = Object.values(typeMap);
    var colors = [C.primary, C.danger, C.warning, C.pink, C.teal, C.orange, C.secondary];

    new Chart(el, {
      type: 'pie',
      data: {
        labels: labels,
        datasets: [{
          data: values,
          backgroundColor: colors.slice(0, labels.length),
          borderColor: '#fff',
          borderWidth: 3,
          hoverOffset: 8
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { animateRotate: true, animateScale: true, duration: 1000, easing: 'easeOutQuart' },
        plugins: {
          legend: { position: 'right', labels: { usePointStyle: true, padding: 14, font: { size: 11 } } },
          tooltip: Object.assign({}, tooltipDefaults, {
            callbacks: {
              label: function(ctx) {
                var total = ctx.dataset.data.reduce(function(a,b){ return a+b; }, 0);
                var pct   = total > 0 ? ((ctx.parsed / total) * 100).toFixed(1) : 0;
                return '  ' + ctx.label + ': ' + ctx.parsed + ' (' + pct + '%)';
              }
            }
          })
        }
      }
    });
  }

  // ════════════════════════════════════════════════════════
  // 9. HEADCOUNT TREND — Line chart
  // ════════════════════════════════════════════════════════
  function initHeadcountChart() {
    var el = document.getElementById('headcountChart');
    if (!el) return;

    var raw = JSON.parse(el.getAttribute('data-headcount') || '[]');
    if (!raw.length) return;

    var ctx  = el.getContext('2d');
    var grad = ctx.createLinearGradient(0, 0, 0, 200);
    grad.addColorStop(0, hexRgba(C.teal, 0.3));
    grad.addColorStop(1, hexRgba(C.teal, 0));

    new Chart(el, {
      type: 'line',
      data: {
        labels: raw.map(function(r){ return r.month || ''; }),
        datasets: [{
          label: 'Headcount',
          data: raw.map(function(r){ return parseInt(r.count || 0); }),
          borderColor: C.teal,
          backgroundColor: grad,
          fill: true,
          tension: 0.4,
          borderWidth: 3,
          pointBackgroundColor: C.teal,
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 5,
          pointHoverRadius: 8
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: animDefaults,
        plugins: {
          legend: { display: false },
          tooltip: Object.assign({}, tooltipDefaults)
        },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#94a3b8' }, border: { display: false } },
          y: { grid: { color: '#f1f5f9' }, beginAtZero: true, ticks: { color: '#94a3b8', stepSize: 1 }, border: { display: false } }
        }
      }
    });
  }

  // ════════════════════════════════════════════════════════
  // 10. OVERTIME CHART — Area chart
  // ════════════════════════════════════════════════════════
  function initOvertimeChart() {
    var el = document.getElementById('overtimeChart');
    if (!el) return;

    var raw = JSON.parse(el.getAttribute('data-overtime') || '[]');
    if (!raw.length) return;

    var ctx  = el.getContext('2d');
    var grad = ctx.createLinearGradient(0, 0, 0, 200);
    grad.addColorStop(0, hexRgba(C.orange, 0.3));
    grad.addColorStop(1, hexRgba(C.orange, 0));

    new Chart(el, {
      type: 'line',
      data: {
        labels: raw.map(function(r){ return r.employee_name || ''; }),
        datasets: [{
          label: 'Overtime Hours',
          data: raw.map(function(r){ return parseFloat(r.overtime_hours || 0); }),
          borderColor: C.orange,
          backgroundColor: grad,
          fill: true,
          tension: 0.4,
          borderWidth: 3,
          pointBackgroundColor: C.orange,
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 5,
          pointHoverRadius: 8
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: animDefaults,
        plugins: {
          legend: { display: false },
          tooltip: Object.assign({}, tooltipDefaults, {
            callbacks: {
              label: function(ctx) { return '  Overtime: ' + ctx.parsed.y + 'h'; }
            }
          })
        },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#94a3b8', maxRotation: 45 }, border: { display: false } },
          y: { grid: { color: '#f1f5f9' }, beginAtZero: true, ticks: { color: '#94a3b8', callback: function(v){ return v + 'h'; } }, border: { display: false } }
        }
      }
    });
  }

  // ── Boot ─────────────────────────────────────────────────
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

}());
