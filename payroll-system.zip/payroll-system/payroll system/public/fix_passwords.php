<?php
/**
 * PayrollPro — Password Fix Script
 * Run once: http://localhost/payroll-system/public/fix_passwords.php
 * DELETE this file after running it!
 */

// Security: only allow from localhost
if (!in_array($_SERVER['REMOTE_ADDR'], ['127.0.0.1', '::1'])) {
    die('Access denied.');
}

define('ROOT_PATH', dirname(__DIR__));
define('APP_PATH',  ROOT_PATH . '/app');
define('CORE_PATH', ROOT_PATH . '/core');

$config = require APP_PATH . '/config/database.php';

try {
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8mb4",
        $config['username'],
        $config['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die('<h2 style="color:red">DB Error: ' . $e->getMessage() . '</h2>
         <p>Make sure MySQL is running and the database <b>payroll_pro</b> exists.<br>
         Import <b>database/setup.sql</b> in phpMyAdmin first.</p>');
}

// New passwords — letters + numbers as requested
$users = [
    ['email' => 'admin@payrollpro.com',  'password' => 'Admin123',  'role' => 'Admin'],
    ['email' => 'hr@payrollpro.com',     'password' => 'Hr1234',    'role' => 'HR'],
    ['email' => 'john@payrollpro.com',   'password' => 'John123',   'role' => 'Employee'],
    ['email' => 'sarah@payrollpro.com',  'password' => 'Sarah123',  'role' => 'Employee'],
    ['email' => 'mike@payrollpro.com',   'password' => 'Mike123',   'role' => 'Employee'],
    ['email' => 'emily@payrollpro.com',  'password' => 'Emily123',  'role' => 'Employee'],
    ['email' => 'robert@payrollpro.com', 'password' => 'Robert123', 'role' => 'Employee'],
];

$results = [];
$stmt = $pdo->prepare("UPDATE users SET password = :hash WHERE email = :email");

foreach ($users as $u) {
    $hash = password_hash($u['password'], PASSWORD_BCRYPT, ['cost' => 10]);
    $stmt->execute([':hash' => $hash, ':email' => $u['email']]);
    $affected = $stmt->rowCount();
    $results[] = [
        'email'    => $u['email'],
        'password' => $u['password'],
        'role'     => $u['role'],
        'status'   => $affected > 0 ? 'success' : 'not found',
    ];
}

// Verify one hash works
$check = $pdo->prepare("SELECT password FROM users WHERE email = 'admin@payrollpro.com'");
$check->execute();
$row = $check->fetch(PDO::FETCH_ASSOC);
$verified = $row && password_verify('Admin123', $row['password']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PayrollPro — Password Fix</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', sans-serif; background: #f1f5f9; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px; }
  .card { background: #fff; border-radius: 16px; padding: 36px; max-width: 600px; width: 100%; box-shadow: 0 8px 32px rgba(0,0,0,.12); }
  h1 { font-size: 1.4rem; color: #0f172a; margin-bottom: 6px; }
  .sub { color: #64748b; font-size: .9rem; margin-bottom: 24px; }
  .status-ok  { background: #d1fae5; border-left: 4px solid #10b981; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; color: #065f46; font-weight: 600; }
  .status-err { background: #fee2e2; border-left: 4px solid #ef4444; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; color: #991b1b; font-weight: 600; }
  table { width: 100%; border-collapse: collapse; font-size: .875rem; margin-bottom: 24px; }
  th { background: #f8fafc; padding: 10px 12px; text-align: left; font-size: .75rem; text-transform: uppercase; letter-spacing: .04em; color: #64748b; border-bottom: 2px solid #e2e8f0; }
  td { padding: 10px 12px; border-bottom: 1px solid #f1f5f9; }
  .badge-success { background: #d1fae5; color: #065f46; padding: 2px 10px; border-radius: 20px; font-size: .75rem; font-weight: 600; }
  .badge-error   { background: #fee2e2; color: #991b1b; padding: 2px 10px; border-radius: 20px; font-size: .75rem; font-weight: 600; }
  .pwd { font-family: monospace; background: #f1f5f9; padding: 2px 8px; border-radius: 4px; font-weight: 700; color: #6366f1; }
  .btn { display: inline-block; background: #6366f1; color: #fff; padding: 12px 28px; border-radius: 8px; font-weight: 700; text-decoration: none; font-size: .95rem; margin-right: 10px; }
  .btn-outline { background: transparent; border: 2px solid #6366f1; color: #6366f1; }
  .warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 12px 16px; border-radius: 8px; color: #92400e; font-size: .85rem; margin-bottom: 20px; }
  .warning strong { display: block; margin-bottom: 4px; }
</style>
</head>
<body>
<div class="card">
  <h1>🔐 PayrollPro — Password Reset</h1>
  <p class="sub">All user passwords have been updated with correct bcrypt hashes.</p>

  <?php if ($verified): ?>
  <div class="status-ok">✅ Verification passed — Admin123 hash is valid. Login will work!</div>
  <?php else: ?>
  <div class="status-err">❌ Verification failed — something went wrong. Check DB connection.</div>
  <?php endif; ?>

  <div class="warning">
    <strong>⚠️ Delete this file after use!</strong>
    This file resets passwords and should not be left on the server.<br>
    Delete: <code>public/fix_passwords.php</code>
  </div>

  <table>
    <thead>
      <tr><th>Role</th><th>Email</th><th>New Password</th><th>Status</th></tr>
    </thead>
    <tbody>
      <?php foreach ($results as $r): ?>
      <tr>
        <td><?= $r['role'] ?></td>
        <td><?= $r['email'] ?></td>
        <td><span class="pwd"><?= $r['password'] ?></span></td>
        <td>
          <?php if ($r['status'] === 'success'): ?>
            <span class="badge-success">✓ Updated</span>
          <?php else: ?>
            <span class="badge-error">✗ Not found</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <a href="<?= dirname($_SERVER['SCRIPT_NAME']) ?>/" class="btn">→ Go to Login</a>
  <a href="fix_passwords.php?delete=1" class="btn btn-outline">🗑 Delete This File</a>
</div>
</body>
</html>
<?php
// Self-delete option
if (isset($_GET['delete'])) {
    unlink(__FILE__);
    echo '<script>alert("File deleted!"); window.location="' . dirname($_SERVER["SCRIPT_NAME"]) . '/";</script>';
}
