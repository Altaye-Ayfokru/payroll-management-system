<?php
/**
 * PayrollPro - Entry Point
 * All requests are routed through this file
 */

define('ROOT_PATH', dirname(__DIR__));
define('APP_PATH', ROOT_PATH . '/app');
define('CORE_PATH', ROOT_PATH . '/core');
define('STORAGE_PATH', ROOT_PATH . '/storage');
define('PUBLIC_PATH', __DIR__);

// Autoload core classes
require_once CORE_PATH . '/App.php';
require_once CORE_PATH . '/Database.php';
require_once CORE_PATH . '/Controller.php';
require_once CORE_PATH . '/Model.php';
require_once CORE_PATH . '/Router.php';

// Load helpers
require_once APP_PATH . '/helpers/functions.php';
require_once APP_PATH . '/helpers/validator.php';
require_once APP_PATH . '/helpers/avatar.php';

// Load config
require_once APP_PATH . '/config/app.php';
require_once APP_PATH . '/config/database.php';
require_once APP_PATH . '/config/routes.php';

// Boot the application
$app = new App();
$app->run();
