<?php
/**
 * PayrollPro — Master Reset & Diagnostic Tool
 * Visit: http://localhost/payroll%20system/public/reset.php
 * DELETE this file after use!
 */
if (!in_array($_SERVER['REMOTE_ADDR'], ['127.0.0.1', '::1', '::ffff:127.0.0.1'])) {
    die('Localhost only.');
}
error_reporting(E_ALL);
ini_set('display_errors', 1);

$root = dirname(__DIR__);

// ── Load DB config ──────────────────────────────────────────
$cfg = null;
$cfgFile = $root . '/app/config/database.php';
if (file_exists($cfgFile)) {
    $cfg = require $cfgFile;
}

// ── Connect ─────────────────────────────────────────────────
$pdo = null;
$dbError = '';
if ($cfg) {
    try {
        $pdo = new PDO(
            "mysql:host={$cfg['host']};dbname={$cfg['dbname']};charset=utf8mb4",
            $cfg['username'],
            $cfg['password'],
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
    } catch (PDOException $e) {
        $dbError = $e->getMessage();
    }
}

// ── Handle actions ──────────────────────────────────────────
$message = '';
$msgType = '';

// ACTION: Reset passwords
if (isset($_POST['action']) && $_POST['action'] === 'reset' && $pdo) {
    $users = [
        ['admin@payrollpro.com', 'Admin123',  'admin'],
        ['hr@payrollpro.com',    'Hr1234',    'hr'],
        ['john@payrollpro.com',  'John123',   'employee'],
        ['sarah@payrollpro.com', 'Sarah123',  'employee'],
        ['mike@payrollpro.com',  'Mike123',   'employee'],
        ['emily@payrollpro.com', 'Emily123',  'employee'],
        ['robert@payrollpro.com','Robert123', 'employee'],
    ];
    $stmt = $pdo->prepare("UPDATE users SET password = :h WHERE email = :e");
    $count = 0;
    foreach ($users as [$email, $pwd]) {
        $hash = password_hash($pwd, PASSWORD_BCRYPT, ['cost' => 10]);
        $stmt->execute([':h' => $hash, ':e' => $email]);
        if ($stmt->rowCount() > 0) $count++;
    }
    // Verify
    $row = $pdo->query("SELECT password FROM users WHERE email='admin@payrollpro.com'")->fetch();
    $ok  = $row && password_verify('Admin123', $row['password']);
    $message = $ok
        ? "✅ Passwords reset for {$count} users. Verification PASSED — Admin123 works!"
        : "⚠️ Updated {$count} rows but verification FAILED. Check DB manually.";
    $msgType = $ok ? 'success' : 'warning';
}

// ACTION: Create tables + seed if missing
if (isset($_POST['action']) && $_POST['action'] === 'seed' && $pdo) {
    $setupFile = $root . '/database/setup.sql';
    if (file_exists($setupFile)) {
        $sql = file_get_contents($setupFile);
        // Split on semicolons, skip empty
        $statements = array_filter(array_map('trim', explode(';', $sql)));
        $errors = [];
        foreach ($statements as $stmt) {
            if (empty($stmt) || str_starts_with(ltrim($stmt), '--')) continue;
            try { $pdo->exec($stmt); } catch (PDOException $e) {
                // Ignore duplicate entry errors
                if (!str_contains($e->getMessage(), 'Duplicate entry') &&
                    !str_contains($e->getMessage(), 'already exists')) {
                    $errors[] = $e->getMessage();
                }
            }
        }
        $message = empty($errors)
            ? "✅ Database seeded successfully!"
            : "⚠️ Seeded with " . count($errors) . " warnings (duplicates ignored).";
        $msgType = 'success';
    } else {
        $message = "❌ setup.sql not found at: {$setupFile}";
        $msgType = 'error';
    }
}

// ACTION: Delete this file
if (isset($_GET['delete'])) {
    @unlink(__FILE__);
    header('Location: ./');
    exit;
}

// ── Gather diagnostics ──────────────────────────────────────
$tables = [];
$users  = [];
$hashTests = [];

if ($pdo) {
    try {
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {}

    if (in_array('users', $tables)) {
        try {
            $users = $pdo->query("SELECT id, name, email, role, is_active, LEFT(password,30) AS hash_preview FROM users")->fetchAll();
        } catch (Exception $e) {}

        // Test passwords against admin
        try {
            $row = $pdo->query("SELECT password FROM users WHERE email='admin@payrollpro.com'")->fetch();
            if ($row) {
                $testPwds = ['Admin123','admin123','Admin@123','password','Hr1234','John123'];
                foreach ($testPwds as $pwd) {
                    $hashTests[$pwd] = password_verify($pwd, $row['password']);
                }
            }
        } catch (Exception $e) {}
    }
}

$phpVersion = PHP_VERSION;
$hasPdoMysql = extension_loaded('pdo_mysql');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PayrollPro — Reset Tool</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',system-ui,sans-serif;background:#f1f5f9;padding:24px;color:#1e293b}
.container{max-width:860px;margin:0 auto}
h1{font-size:1.5rem;font-weight:800;color:#0f172a;margin-bottom:4px}
.subtitle{color:#64748b;font-size:.9rem;margin-bottom:24px}
.card{background:#fff;border-radius:14px;padding:24px;margin-bottom:20px;box-shadow:0 2px 8px rgba(0,0,0,.08);border:1px solid #e2e8f0}
.card h2{font-size:1rem;font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.ok  {color:#10b981} .err {color:#ef4444} .warn{color:#f59e0b}
.badge{display:inline-flex;align-items:center;padding:2px 10px;border-radius:20px;font-size:.75rem;font-weight:600}
.badge-ok   {background:#d1fae5;color:#065f46}
.badge-err  {background:#fee2e2;color:#991b1b}
.badge-warn {background:#fef3c7;color:#92400e}
.badge-info {background:#dbeafe;color:#1e40af}
table{width:100%;border-collapse:collapse;font-size:.85rem}
th{background:#f8fafc;padding:8px 12px;text-align:left;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;color:#64748b;border-bottom:2px solid #e2e8f0}
td{padding:9px 12px;border-bottom:1px solid #f1f5f9;vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:#fafbff}
.mono{font-family:monospace;font-size:.8rem;background:#f1f5f9;padding:2px 6px;border-radius:4px}
.btn{display:inline-flex;align-items:center;gap:8px;padding:10px 22px;border-radius:10px;font-weight:700;font-size:.9rem;cursor:pointer;border:none;transition:all .2s;text-decoration:none}
.btn-primary{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;box-shadow:0 4px 12px rgba(99,102,241,.35)}
.btn-primary:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(99,102,241,.45)}
.btn-success{background:linear-gradient(135deg,#10b981,#059669);color:#fff;box-shadow:0 4px 12px rgba(16,185,129,.35)}
.btn-success:hover{transform:translateY(-1px)}
.btn-danger{background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff}
.btn-outline{background:transparent;border:2px solid #e2e8f0;color:#374151}
.btn-outline:hover{border-color:#6366f1;color:#6366f1}
.alert{padding:14px 18px;border-radius:10px;margin-bottom:20px;font-weight:600;font-size:.9rem;display:flex;align-items:center;gap:10px}
.alert-success{background:#d1fae5;color:#065f46;border-left:4px solid #10b981}
.alert-warning{background:#fef3c7;color:#92400e;border-left:4px solid #f59e0b}
.alert-error  {background:#fee2e2;color:#991b1b;border-left:4px solid #ef4444}
.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:16px}
.section-label{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#94a3b8;margin-bottom:8px}
.cred-box{background:linear-gradient(135deg,#f0f4ff,#faf5ff);border:1px solid #ddd6fe;border-radius:12px;padding:16px;margin-top:16px}
.cred-row{display:flex;align-items:center;justify-content:space-between;padding:6px 0;border-bottom:1px solid rgba(99,102,241,.1)}
.cred-row:last-child{border-bottom:none}
.cred-email{font-size:.85rem;font-weight:600;color:#374151}
.cred-pwd{font-family:monospace;background:#e0e7ff;color:#4f46e5;padding:3px 10px;border-radius:6px;font-size:.82rem;font-weight:700}
</style>
</head>
<body>
<div class="container">

  <h1>🔧 PayrollPro — Reset &amp; Diagnostic Tool</h1>
  <p class="subtitle">Diagnose and fix login issues. Delete this file after use.</p>

  <?php if ($message): ?>
  <div class="alert alert-<?= $msgType === 'success' ? 'success' : ($msgType === 'warning' ? 'warning' : 'error') ?>">
    <?= htmlspecialchars($message) ?>
  </div>
  <?php endif; ?>

  <!-- ── Step 1: System Check ── -->
  <div class="card">
    <h2>1️⃣ System Check</h2>
    <table>
      <tr>
        <td>PHP Version</td>
        <td><span class="mono"><?= $phpVersion ?></span></td>
        <td><?= version_compare($phpVersion, '8.0') >= 0 ? '<span class="badge badge-ok">✓ OK</span>' : '<span class="badge badge-err">✗ Need 8.0+</span>' ?></td>
      </tr>
      <tr>
        <td>PDO MySQL Extension</td>
        <td><span class="mono">pdo_mysql</span></td>
        <td><?= $hasPdoMysql ? '<span class="badge badge-ok">✓ Loaded</span>' : '<span class="badge badge-err">✗ Missing</span>' ?></td>
      </tr>
      <tr>
        <td>DB Config File</td>
        <td><span class="mono">app/config/database.php</span></td>
        <td><?= $cfg ? '<span class="badge badge-ok">✓ Found</span>' : '<span class="badge badge-err">✗ Missing</span>' ?></td>
      </tr>
      <?php if ($cfg): ?>
      <tr>
        <td>DB Host / Name</td>
        <td><span class="mono"><?= htmlspecialchars($cfg['host']) ?> / <?= htmlspecialchars($cfg['dbname']) ?></span></td>
        <td><span class="badge badge-info">Config</span></td>
      </tr>
      <?php endif; ?>
      <tr>
        <td>Database Connection</td>
        <td><?= $pdo ? '<span class="mono">Connected</span>' : '<span class="mono" style="color:#ef4444">' . htmlspecialchars($dbError) . '</span>' ?></td>
        <td><?= $pdo ? '<span class="badge badge-ok">✓ Connected</span>' : '<span class="badge badge-err">✗ Failed</span>' ?></td>
      </tr>
    </table>
  </div>

  <?php if (!$pdo): ?>
  <div class="card">
    <h2>⚠️ Cannot connect to database</h2>
    <p style="color:#64748b;margin-bottom:12px">Error: <strong><?= htmlspecialchars($dbError) ?></strong></p>
    <p style="color:#64748b;font-size:.9rem">Make sure:</p>
    <ul style="color:#64748b;font-size:.9rem;padding-left:20px;margin-top:8px;line-height:2">
      <li>MySQL is running in XAMPP Control Panel</li>
      <li>The database <strong>payroll_pro</strong> exists in phpMyAdmin</li>
      <li>Credentials in <code>app/config/database.php</code> are correct</li>
    </ul>
  </div>
  <?php else: ?>

  <!-- ── Step 2: Tables ── -->
  <div class="card">
    <h2>2️⃣ Database Tables</h2>
    <?php if (empty($tables)): ?>
    <div class="alert alert-error">No tables found! You need to import <strong>database/setup.sql</strong> in phpMyAdmin.</div>
    <form method="POST">
      <input type="hidden" name="action" value="seed">
      <button type="submit" class="btn btn-success">⚡ Auto-Import setup.sql Now</button>
    </form>
    <?php else: ?>
    <p style="color:#64748b;font-size:.85rem;margin-bottom:12px">Found <strong><?= count($tables) ?></strong> tables: <?= implode(', ', array_map('htmlspecialchars', $tables)) ?></p>
    <?php $required = ['users','employees','attendance','leaves','payroll','tax_rules','salary_components','notifications','activity_logs'];
    $missing = array_diff($required, $tables);
    if ($missing): ?>
    <div class="alert alert-warning">Missing tables: <strong><?= implode(', ', $missing) ?></strong></div>
    <form method="POST">
      <input type="hidden" name="action" value="seed">
      <button type="submit" class="btn btn-success">⚡ Re-import setup.sql</button>
    </form>
    <?php else: ?>
    <span class="badge badge-ok">✓ All required tables present</span>
    <?php endif; ?>
    <?php endif; ?>
  </div>

  <!-- ── Step 3: Users ── -->
  <div class="card">
    <h2>3️⃣ Users in Database</h2>
    <?php if (empty($users)): ?>
    <div class="alert alert-error">No users found! Import setup.sql first.</div>
    <?php else: ?>
    <table>
      <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Active</th><th>Hash (first 30 chars)</th></tr></thead>
      <tbody>
        <?php foreach ($users as $u): ?>
        <tr>
          <td><?= (int)$u['id'] ?></td>
          <td><?= htmlspecialchars($u['name']) ?></td>
          <td><?= htmlspecialchars($u['email']) ?></td>
          <td><span class="badge badge-info"><?= htmlspecialchars($u['role']) ?></span></td>
          <td><?= $u['is_active'] ? '<span class="badge badge-ok">Yes</span>' : '<span class="badge badge-err">No</span>' ?></td>
          <td><span class="mono"><?= htmlspecialchars($u['hash_preview']) ?>...</span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

  <!-- ── Step 4: Password Test ── -->
  <div class="card">
    <h2>4️⃣ Password Verification Test (admin account)</h2>
    <?php if (empty($hashTests)): ?>
    <div class="alert alert-warning">admin@payrollpro.com not found in database.</div>
    <?php else: ?>
    <table>
      <thead><tr><th>Password Tested</th><th>Result</th></tr></thead>
      <tbody>
        <?php foreach ($hashTests as $pwd => $result): ?>
        <tr>
          <td><span class="mono"><?= htmlspecialchars($pwd) ?></span></td>
          <td>
            <?php if ($result): ?>
            <span class="badge badge-ok">✓ MATCHES — use this password!</span>
            <?php else: ?>
            <span class="badge badge-err">✗ No match</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php $anyMatch = in_array(true, $hashTests); ?>
    <?php if (!$anyMatch): ?>
    <div class="alert alert-error" style="margin-top:16px">
      ⚠️ None of the test passwords match! The hash in the database is wrong. Click "Reset Passwords" below.
    </div>
    <?php endif; ?>
    <?php endif; ?>
  </div>

  <!-- ── Step 5: Fix ── -->
  <div class="card">
    <h2>5️⃣ Fix — Reset All Passwords</h2>
    <p style="color:#64748b;font-size:.9rem;margin-bottom:16px">
      This generates fresh bcrypt hashes using <strong>your PHP <?= $phpVersion ?></strong> and updates all user passwords.
    </p>

    <form method="POST">
      <input type="hidden" name="action" value="reset">
      <button type="submit" class="btn btn-primary">🔑 Reset All Passwords Now</button>
    </form>

    <div class="cred-box">
      <div class="section-label">New credentials after reset</div>
      <?php $creds = [
        ['Admin',    'admin@payrollpro.com',  'Admin123'],
        ['HR',       'hr@payrollpro.com',     'Hr1234'],
        ['Employee', 'john@payrollpro.com',   'John123'],
        ['Employee', 'sarah@payrollpro.com',  'Sarah123'],
        ['Employee', 'mike@payrollpro.com',   'Mike123'],
        ['Employee', 'emily@payrollpro.com',  'Emily123'],
        ['Employee', 'robert@payrollpro.com', 'Robert123'],
      ]; ?>
      <?php foreach ($creds as [$role, $email, $pwd]): ?>
      <div class="cred-row">
        <span class="cred-email"><strong><?= $role ?></strong> — <?= $email ?></span>
        <span class="cred-pwd"><?= $pwd ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- ── Step 6: Go to Login ── -->
  <div class="card">
    <h2>6️⃣ Go to Login</h2>
    <p style="color:#64748b;font-size:.9rem;margin-bottom:16px">
      After resetting passwords, click below to go to the login page.
    </p>
    <div class="actions">
      <a href="./" class="btn btn-primary">→ Go to Login Page</a>
      <a href="?delete=1" class="btn btn-danger"
         onclick="return confirm('Delete this file? Make sure you have reset passwords first.')">
        🗑 Delete This File
      </a>
    </div>
  </div>

  <?php endif; // $pdo ?>

</div>
</body>
</html>
