# PayrollPro — Enterprise Payroll Management System

A full-stack, modular payroll system built with PHP (OOP/MVC), MySQL, and Vanilla JS.

---

## ▶️ How to Run (XAMPP — Step by Step)

### Step 1 — Start XAMPP

1. Open **XAMPP Control Panel**
2. Click **Start** next to **Apache**
3. Click **Start** next to **MySQL**

Both status lights should turn green.

---

### Step 2 — Place the Project

Your project folder is already at:
```
C:\xampp\htdocs\payroll system\
```

> ⚠️ **Important:** The folder name has a space. Rename it to avoid URL issues:
> `C:\xampp\htdocs\payroll-system\`
>
> In Windows Explorer → right-click the folder → Rename → `payroll-system`

---

### Step 3 — Import the Database

1. Open your browser → go to **`http://localhost/phpmyadmin`**
2. Click the **Import** tab at the top
3. Click **Choose File** → select:
   ```
   C:\xampp\htdocs\payroll-system\database\setup.sql
   ```
4. Leave all settings as default
5. Click **Go** at the bottom

✅ You should see: *"Import has been successfully finished"*

This creates the `payroll_pro` database with all 9 tables and demo data.

---

### Step 4 — Check Database Config

Open `app/config/database.php` — it should already match XAMPP defaults:

```php
return [
    'host'     => 'localhost',
    'dbname'   => 'payroll_pro',
    'username' => 'root',
    'password' => '',        // leave blank for XAMPP default
];
```

If your MySQL has a password, add it to the `password` field.

---

### Step 5 — Open the App

Open your browser and go to:

```
http://localhost/payroll-system/public/
```

You should see the **PayrollPro login page**.

---

### Step 6 — Log In

| Role | Email | Password |
|------|-------|----------|
| **Admin** | admin@payrollpro.com | Admin@123 |
| **HR Manager** | hr@payrollpro.com | Hr@123 |
| **Employee** | john@payrollpro.com | Emp@123 |
| **Employee** | sarah@payrollpro.com | Emp@123 |
| **Employee** | mike@payrollpro.com | Emp@123 |

---

## 🔧 Troubleshooting

| Problem | Fix |
|---------|-----|
| **Blank white page** | Make sure `APP_ENV = 'development'` in `app/config/app.php` to see errors |
| **404 on all pages** | Enable `mod_rewrite` in Apache — open `C:\xampp\apache\conf\httpd.conf`, find `#LoadModule rewrite_module` and remove the `#`, then restart Apache |
| **Database connection failed** | Check MySQL is running in XAMPP. Verify `payroll_pro` database exists in phpMyAdmin |
| **"Access denied" for MySQL** | Your MySQL has a password — add it to `app/config/database.php` |
| **Images not loading** | Make sure you're accessing via `http://localhost/payroll-system/public/` not by opening files directly |
| **Session errors** | Make sure `storage/logs/` folder exists and Apache has write permission to it |

---

## 🚀 Quick Setup Summary

```
1. Start XAMPP (Apache + MySQL)
2. Rename folder: payroll system → payroll-system
3. Import database/setup.sql in phpMyAdmin
4. Open http://localhost/payroll-system/public/
5. Login: admin@payrollpro.com / password
```

---

## 🔑 All Demo Accounts

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@payrollpro.com | password |
| HR | hr@payrollpro.com | password |
| Employee | john@payrollpro.com | password |
| Employee | sarah@payrollpro.com | password |
| Employee | mike@payrollpro.com | password |
| Employee | emily@payrollpro.com | password |
| Employee | robert@payrollpro.com | password |

---

## 📁 Project Structure

```
payroll-system/
├── public/                  ← Web root (point browser here)
│   ├── index.php            ← Entry point for all requests
│   ├── .htaccess            ← URL rewriting rules
│   └── assets/
│       ├── css/
│       │   ├── dashboard.css    ← Layout, sidebar, topbar, cards
│       │   ├── forms.css        ← Forms, modals, inputs
│       │   └── components.css   ← Payslip, calendar, charts
│       ├── js/
│       │   ├── app.js           ← Sidebar, dropdowns, modals
│       │   ├── ajax.js          ← AJAX helpers, toast notifications
│       │   └── charts.js        ← Chart.js configurations
│       └── images/
│
├── app/
│   ├── modules/             ← Feature modules (MVC per feature)
│   │   ├── Auth/            ← Login, register, logout
│   │   ├── Dashboard/       ← Analytics + stats
│   │   ├── Employee/        ← Employee CRUD + profiles
│   │   ├── Payroll/         ← Payroll engine + payslips
│   │   ├── Attendance/      ← Check-in/out + calendar
│   │   ├── Leave/           ← Leave requests + approvals
│   │   ├── Report/          ← Salary, attendance, tax reports
│   │   ├── Settings/        ← Tax rules, salary components
│   │   ├── Notification/    ← Real-time bell notifications
│   │   └── User/            ← User management + profile
│   │
│   ├── models/              ← Shared base models
│   ├── helpers/             ← functions.php, validator.php
│   ├── middleware/          ← Auth + role middleware
│   └── config/              ← database.php, app.php, routes.php
│
├── core/                    ← Framework engine
│   ├── App.php              ← Bootstrap + session start
│   ├── Router.php           ← URL dispatcher
│   ├── Controller.php       ← Base controller (view, json, redirect)
│   ├── Model.php            ← Base model (PDO + CRUD)
│   └── Database.php         ← PDO singleton connection
│
├── database/
│   ├── migrations/          ← Individual SQL table files
│   ├── seeds/               ← Sample data SQL
│   └── setup.sql            ← ⭐ Import this in phpMyAdmin
│
├── storage/
│   ├── logs/                ← App error logs (auto-created)
│   ├── uploads/avatars/     ← Employee photo uploads
│   └── reports/             ← Generated report files
│
└── README.md                ← This file
```

---

## ✅ Features

| Module | What it does |
|--------|-------------|
| **Dashboard** | Stats cards, payroll trend chart, attendance today, activity log |
| **Employees** | Add/edit/delete employees, photo upload, salary structure |
| **Payroll** | Run monthly payroll, auto-calculate tax + deductions, approve/reject, payslip PDF |
| **Attendance** | Employee check-in/out, calendar view, overtime tracking |
| **Leave** | Apply for leave, HR approval workflow, leave balance |
| **Reports** | Salary, attendance, tax reports with charts + CSV export |
| **Settings** | Configure tax brackets, salary components, company info |
| **Notifications** | Real-time bell with AJAX, mark read/unread |
| **Users** | Role management (Admin/HR/Employee), profile editing |

---

## 🔒 Security

- PDO prepared statements — no SQL injection possible
- Passwords hashed with bcrypt (cost 12)
- CSRF tokens on every POST form
- Session ID regenerated on login
- Role-based middleware on every route
- Soft deletes preserve data integrity
- HTTP-only session cookies

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | PHP 8.1+ (OOP, MVC, no framework) |
| Database | MySQL / MariaDB |
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| Charts | Chart.js 4.4 |
| Icons | Font Awesome 6.5 |
| Fonts | Google Fonts — Inter |
| Server | Apache (XAMPP) |
