<?php
/**
 * Core Router — dispatches URL to module controllers
 */
class Router {
    private array $routes = [];

    // Map controller name → module directory
    private array $moduleMap = [
        'AuthController'         => 'Auth',
        'DashboardController'    => 'Dashboard',
        'EmployeeController'     => 'Employee',
        'PayrollController'      => 'Payroll',
        'AttendanceController'   => 'Attendance',
        'LeaveController'        => 'Leave',
        'ReportController'       => 'Report',
        'SettingsController'     => 'Settings',
        'NotificationController' => 'Notification',
        'UserController'         => 'User',
    ];

    public function add(string $method, string $path, string $controller, string $action): void {
        $this->routes[] = compact('method', 'path', 'controller', 'action');
    }

    public function dispatch(): void {
        $url    = trim($_GET['url'] ?? '', '/');
        $method = $_SERVER['REQUEST_METHOD'];

        foreach ($this->routes as $route) {
            $pattern = $this->buildPattern($route['path']);
            if ($route['method'] === $method && preg_match($pattern, $url, $matches)) {
                $this->callController($route['controller'], $route['action'], $matches);
                return;
            }
        }

        $this->notFound();
    }

    private function buildPattern(string $path): string {
        $path = preg_replace('/\{(\w+)\}/', '(?P<$1>[^/]+)', $path);
        return '#^' . $path . '$#';
    }

    private function callController(string $name, string $action, array $params = []): void {
        // Resolve file from module map
        $module = $this->moduleMap[$name] ?? null;
        if ($module) {
            $file = APP_PATH . "/modules/{$module}/{$name}.php";
        } else {
            $file = APP_PATH . "/controllers/{$name}.php";
        }

        if (!file_exists($file)) { $this->notFound(); return; }
        require_once $file;

        if (!class_exists($name)) { $this->notFound(); return; }

        $controller = new $name();
        if (!method_exists($controller, $action)) { $this->notFound(); return; }

        $args = array_filter($params, 'is_string', ARRAY_FILTER_USE_KEY);
        call_user_func_array([$controller, $action], $args);
    }

    private function notFound(): void {
        http_response_code(404);
        $file = APP_PATH . '/views/errors/404.php';
        if (file_exists($file)) require_once $file;
        else echo '<h1>404 — Page Not Found</h1>';
    }
}
