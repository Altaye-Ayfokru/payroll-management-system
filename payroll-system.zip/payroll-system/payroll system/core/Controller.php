<?php
/**
 * Base Controller — all controllers extend this
 */
abstract class Controller {

    /**
     * Render a view with layout (header + footer)
     * Looks in app/modules/<Module>/views/ first, then app/views/
     */
    protected function view(string $view, array $data = []): void {
        extract($data);
        $viewFile = $this->resolveView($view);
        if (!$viewFile) throw new RuntimeException("View not found: {$view}");

        require_once APP_PATH . '/views/layouts/header.php';
        require_once $viewFile;
        require_once APP_PATH . '/views/layouts/footer.php';
    }

    /**
     * Render a view WITHOUT layout (for auth pages, etc.)
     */
    protected function viewRaw(string $view, array $data = []): void {
        extract($data);
        $viewFile = $this->resolveView($view);
        if (!$viewFile) throw new RuntimeException("View not found: {$view}");
        require_once $viewFile;
    }

    /**
     * Resolve view path: check modules first, then legacy views/
     * Accepts dot notation: 'employees.list' → employees/list.php
     */
    private function resolveView(string $view): ?string {
        $path = str_replace('.', '/', $view) . '.php';

        // Module map: view prefix → module name
        $moduleMap = [
            'auth'       => 'Auth',
            'dashboard'  => 'Dashboard',
            'employees'  => 'Employee',
            'payroll'    => 'Payroll',
            'attendance' => 'Attendance',
            'leaves'     => 'Leave',
            'reports'    => 'Report',
            'settings'   => 'Settings',
            'users'      => 'User',
            'notifications' => 'Notification',
        ];

        $prefix = explode('/', $path)[0];
        if (isset($moduleMap[$prefix])) {
            $module    = $moduleMap[$prefix];
            $subPath   = substr($path, strlen($prefix) + 1);
            $moduleFile = APP_PATH . "/modules/{$module}/views/{$subPath}";
            if (file_exists($moduleFile)) return $moduleFile;
        }

        // Fallback to legacy views/
        $legacyFile = APP_PATH . '/views/' . $path;
        if (file_exists($legacyFile)) return $legacyFile;

        return null;
    }

    protected function json(mixed $data, int $status = 200): void {
        http_response_code($status);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    protected function redirect(string $path): void {
        header('Location: ' . BASE_URL . '/' . ltrim($path, '/'));
        exit;
    }

    protected function isPost(): bool  { return $_SERVER['REQUEST_METHOD'] === 'POST'; }
    protected function isAjax(): bool  {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }

    protected function input(string $key, mixed $default = null): mixed {
        return $_POST[$key] ?? $_GET[$key] ?? $default;
    }

    protected function sanitize(string $value): string {
        return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
    }

    protected function validateCsrf(): void {
        $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
            $this->json(['error' => 'Invalid CSRF token'], 403);
        }
    }

    protected function requireAuth(): void {
        if (empty($_SESSION['user_id'])) {
            if ($this->isAjax()) $this->json(['error' => 'Unauthorized'], 401);
            $this->redirect('auth/login');
        }
    }

    protected function requireRole(string ...$roles): void {
        $this->requireAuth();
        if (!in_array($_SESSION['user_role'] ?? '', $roles)) {
            if ($this->isAjax()) $this->json(['error' => 'Forbidden'], 403);
            $this->redirect('dashboard');
        }
    }

    protected function currentUser(): ?array { return $_SESSION['user'] ?? null; }

    protected function flash(string $type, string $message): void {
        $_SESSION['flash'] = compact('type', 'message');
    }

    protected function getFlash(): ?array {
        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);
        return $flash;
    }
}
