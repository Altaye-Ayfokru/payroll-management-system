<?php if (!empty($_SESSION['user_id'])): ?>
  </main>
  <!-- Footer -->
  <footer style="padding:1rem 1.75rem;border-top:1px solid var(--border,#e2e8f0);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.5rem;font-size:.75rem;color:var(--text-lighter,#94a3b8);background:var(--white,#fff)">
    <span>&copy; <?= date('Y') ?> <strong style="color:var(--primary,#6366f1)">PayrollPro</strong> &mdash; HR &amp; Payroll Management System</span>
    <span style="display:flex;align-items:center;gap:1rem">
      <span>v2.0.0</span>
      <span style="display:flex;align-items:center;gap:.375rem">
        <span style="width:7px;height:7px;border-radius:50%;background:#10b981;display:inline-block;animation:pulseDot 2s ease-in-out infinite"></span>
        System Online
      </span>
    </span>
  </footer>
</div><!-- /main-wrapper -->
<?php endif; ?>
<script src="<?= asset('js/app.js') ?>"></script>
<script src="<?= asset('js/ajax.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="<?= asset('js/charts.js') ?>"></script>
</body>
</html>
