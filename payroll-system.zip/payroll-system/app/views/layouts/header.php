﻿<!DOCTYPE html>
<html lang="en" id="htmlRoot">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="base-url" content="<?= BASE_URL ?>">
<meta name="csrf-token" content="<?= csrfToken() ?>">
<title><?= e($pageTitle ?? 'Dashboard') ?> — PayrollPro</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= asset('css/dashboard.css') ?>">
<link rel="stylesheet" href="<?= asset('css/forms.css') ?>">
<link rel="stylesheet" href="<?= asset('css/components.css') ?>">
<link rel="stylesheet" href="<?= asset('css/animations.css') ?>">
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
<script>
// Apply dark mode before render to prevent flash
(function(){
  if(localStorage.getItem('darkMode')==='true'){
    document.documentElement.setAttribute('data-theme','dark');
  }
})();
</script>
<style>
/* ── Dark mode overrides for inline-styled elements ── */
[data-theme="dark"] .topbar {
  background: rgba(15,23,42,0.97) !important;
  border-bottom-color: #334155 !important;
  box-shadow: 0 1px 3px rgba(0,0,0,.3) !important;
}
[data-theme="dark"] .main-wrapper {
  background: #0f172a !important;
}
[data-theme="dark"] .topbar-breadcrumb .breadcrumb-page {
  color: #f1f5f9 !important;
}
[data-theme="dark"] .topbar-date {
  background: #1e293b !important;
  border-color: #334155 !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .topbar-menu-btn,
[data-theme="dark"] .topbar-icon-btn {
  color: #94a3b8 !important;
}
[data-theme="dark"] .topbar-menu-btn:hover,
[data-theme="dark"] .topbar-icon-btn:hover {
  background: #1e293b !important;
  border-color: #334155 !important;
  color: #f1f5f9 !important;
}
[data-theme="dark"] #darkModeToggle {
  color: #fbbf24 !important;
}
[data-theme="dark"] .topbar-username { color: #f1f5f9 !important; }
[data-theme="dark"] .topbar-userrole { color: #94a3b8 !important; }
[data-theme="dark"] .topbar-profile-btn {
  border-color: #334155 !important;
}
[data-theme="dark"] .topbar-profile-btn:hover {
  background: #1e293b !important;
  border-color: #475569 !important;
}
[data-theme="dark"] .notif-dropdown,
[data-theme="dark"] .profile-dropdown {
  background: #1e293b !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .profile-dropdown-header {
  background: linear-gradient(135deg,rgba(99,102,241,.15),rgba(139,92,246,.15)) !important;
}
[data-theme="dark"] .profile-dropdown a { color: #cbd5e1 !important; }
[data-theme="dark"] .profile-dropdown a:hover { background: #0f172a !important; }
[data-theme="dark"] .dropdown-divider { background: #334155 !important; }
[data-theme="dark"] .notif-header {
  border-bottom-color: #334155 !important;
  color: #f1f5f9 !important;
}
[data-theme="dark"] .notif-item { border-bottom-color: #0f172a !important; }
[data-theme="dark"] .notif-item:hover { background: #0f172a !important; }
[data-theme="dark"] .notif-item.unread { background: rgba(99,102,241,.1) !important; }
[data-theme="dark"] .notif-item-msg { color: #f1f5f9 !important; }
[data-theme="dark"] .notif-item-time { color: #64748b !important; }
[data-theme="dark"] .page-content { background: #0f172a; }
[data-theme="dark"] .card {
  background: #1e293b !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .card-header {
  background: #1e293b !important;
  border-bottom-color: #334155 !important;
}
[data-theme="dark"] .card-title { color: #f1f5f9 !important; }
[data-theme="dark"] .card-body { color: #cbd5e1; }
[data-theme="dark"] table thead th {
  background: #0f172a !important;
  color: #64748b !important;
  border-bottom-color: #334155 !important;
}
[data-theme="dark"] table tbody tr { border-bottom-color: #1e293b !important; }
[data-theme="dark"] table tbody tr:hover { background: #1e293b !important; }
[data-theme="dark"] table td { color: #cbd5e1 !important; }
[data-theme="dark"] .form-control {
  background: #0f172a !important;
  border-color: #334155 !important;
  color: #f1f5f9 !important;
}
[data-theme="dark"] .form-control:focus {
  border-color: #6366f1 !important;
  box-shadow: 0 0 0 3px rgba(99,102,241,.15) !important;
}
[data-theme="dark"] .form-label { color: #cbd5e1 !important; }
[data-theme="dark"] .form-hint  { color: #64748b !important; }
[data-theme="dark"] .page-header-title { color: #f1f5f9 !important; }
[data-theme="dark"] .page-header-sub   { color: #94a3b8 !important; }
[data-theme="dark"] .filter-bar .form-control,
[data-theme="dark"] .search-bar {
  background: #0f172a !important;
  border-color: #334155 !important;
  color: #f1f5f9 !important;
}
[data-theme="dark"] .search-bar input {
  color: #f1f5f9 !important;
  background: transparent !important;
}
[data-theme="dark"] .modal {
  background: #1e293b !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .modal-header { border-bottom-color: #334155 !important; }
[data-theme="dark"] .modal-title  { color: #f1f5f9 !important; }
[data-theme="dark"] .modal-footer { border-top-color: #334155 !important; background: #0f172a !important; }
[data-theme="dark"] .modal-body   { color: #cbd5e1; }
[data-theme="dark"] .summary-chip {
  background: #1e293b !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .summary-chip-val   { color: #f1f5f9 !important; }
[data-theme="dark"] .summary-chip-label { color: #94a3b8 !important; }
[data-theme="dark"] .empty-state-title  { color: #94a3b8 !important; }
[data-theme="dark"] .empty-state-text   { color: #64748b !important; }
[data-theme="dark"] .empty-state-icon   { color: #475569 !important; }
[data-theme="dark"] .flash-success { background: rgba(16,185,129,.15) !important; color: #6ee7b7 !important; }
[data-theme="dark"] .flash-error   { background: rgba(239,68,68,.15)  !important; color: #fca5a5 !important; }
[data-theme="dark"] .flash-warning { background: rgba(245,158,11,.15) !important; color: #fcd34d !important; }
[data-theme="dark"] .flash-info    { background: rgba(59,130,246,.15) !important; color: #93c5fd !important; }
[data-theme="dark"] .dept-badge    { background: #1e293b !important; color: #94a3b8 !important; }
[data-theme="dark"] .leave-balance-card {
  background: #0f172a !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .leave-balance-type  { color: #94a3b8 !important; }
[data-theme="dark"] .leave-balance-label { color: #64748b !important; }
[data-theme="dark"] .stat-card {
  background: #1e293b !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .stat-value { color: #f1f5f9 !important; }
[data-theme="dark"] .stat-label { color: #94a3b8 !important; }
[data-theme="dark"] .pagination { border-top-color: #334155 !important; }
[data-theme="dark"] .page-btn {
  background: #1e293b !important;
  border-color: #334155 !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .page-btn:hover {
  background: linear-gradient(135deg,rgba(99,102,241,.15),rgba(139,92,246,.15)) !important;
  border-color: #6366f1 !important;
  color: #a5b4fc !important;
}
[data-theme="dark"] .page-btn.active {
  background: linear-gradient(135deg,#6366f1,#8b5cf6) !important;
  border-color: transparent !important;
  color: #fff !important;
}
[data-theme="dark"] .btn-outline {
  border-color: #334155 !important;
  color: #94a3b8 !important;
}
[data-theme="dark"] .btn-outline:hover {
  background: linear-gradient(135deg,rgba(99,102,241,.12),rgba(139,92,246,.12)) !important;
  border-color: #6366f1 !important;
  color: #a5b4fc !important;
}
[data-theme="dark"] .btn-light {
  background: linear-gradient(135deg,#1e293b,#0f172a) !important;
  color: #cbd5e1 !important;
  border-color: #334155 !important;
}
[data-theme="dark"] .filter-bar { background: transparent; }
[data-theme="dark"] body { background: #0f172a; color: #f1f5f9; }

/* ── Dark mode icon toggle ── */
[data-theme="dark"] #darkModeIcon { color: #fbbf24; }

/* ── Smooth transition for dark mode switch ── */
body, .topbar, .main-wrapper, .card, .card-header, .modal,
.form-control, .btn-outline, .page-btn, .stat-card, .summary-chip {
  transition: background-color 0.25s ease, border-color 0.25s ease, color 0.2s ease;
}

/* ══════════════════════════════════════════════════════
   THEME PALETTE PICKER
══════════════════════════════════════════════════════ */
.theme-picker-wrapper {
  position: relative;
}

.theme-picker-dropdown {
  position: absolute;
  top: calc(100% + 10px);
  right: 0;
  width: 280px;
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 18px;
  box-shadow: 0 24px 48px rgba(0,0,0,.14), 0 4px 12px rgba(0,0,0,.08);
  z-index: 600;
  display: none;
  animation: themeDropIn .22s cubic-bezier(.34,1.2,.64,1);
  overflow: hidden;
}
.theme-picker-dropdown.open { display: block; }

@keyframes themeDropIn {
  from { opacity:0; transform:translateY(-10px) scale(.97); }
  to   { opacity:1; transform:translateY(0) scale(1); }
}

.theme-picker-header {
  padding: .875rem 1.125rem .625rem;
  font-size: .82rem;
  font-weight: 700;
  color: #0f172a;
  border-bottom: 1px solid #f1f5f9;
}

.theme-grid {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 6px;
  padding: .875rem 1rem;
}

.theme-swatch {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 5px;
  padding: 8px 4px 6px;
  border-radius: 12px;
  border: 2px solid transparent;
  background: #f8fafc;
  cursor: pointer;
  transition: all .18s ease;
  position: relative;
  font-family: inherit;
}
.theme-swatch:hover {
  background: #f0f4ff;
  border-color: #a5b4fc;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(99,102,241,.15);
}
.theme-swatch.active {
  border-color: #6366f1;
  background: #eef2ff;
  box-shadow: 0 0 0 3px rgba(99,102,241,.15);
}

.swatch-preview {
  display: flex;
  gap: 2px;
  border-radius: 8px;
  overflow: hidden;
  width: 36px;
  height: 24px;
  flex-shrink: 0;
  box-shadow: 0 2px 6px rgba(0,0,0,.12);
}
.swatch-preview span {
  flex: 1;
  display: block;
}

.swatch-label {
  font-size: .6rem;
  font-weight: 600;
  color: #64748b;
  text-align: center;
  line-height: 1.2;
  white-space: nowrap;
}
.theme-swatch.active .swatch-label { color: #6366f1; }

.swatch-check {
  position: absolute;
  top: 4px;
  right: 4px;
  font-size: .55rem;
  color: #6366f1;
  display: none;
}
.theme-swatch.active .swatch-check { display: block; }

.theme-picker-footer {
  padding: .5rem 1rem .75rem;
  border-top: 1px solid #f1f5f9;
  text-align: center;
}

/* ── Theme palette icon color ── */
#themePickerIcon { color: #6366f1; }

/* ── Dark mode theme picker ── */
[data-theme="dark"] .theme-picker-dropdown {
  background: #1e293b !important;
  border-color: #334155 !important;
  box-shadow: 0 24px 48px rgba(0,0,0,.4) !important;
}
[data-theme="dark"] .theme-picker-header {
  color: #f1f5f9 !important;
  border-bottom-color: #334155 !important;
}
[data-theme="dark"] .theme-swatch {
  background: #0f172a !important;
}
[data-theme="dark"] .theme-swatch:hover {
  background: #1e293b !important;
  border-color: #6366f1 !important;
}
[data-theme="dark"] .theme-swatch.active {
  background: rgba(99,102,241,.15) !important;
  border-color: #6366f1 !important;
}
[data-theme="dark"] .swatch-label { color: #94a3b8 !important; }
[data-theme="dark"] .theme-swatch.active .swatch-label { color: #a5b4fc !important; }
[data-theme="dark"] .theme-picker-footer { border-top-color: #334155 !important; }

/* ══════════════════════════════════════════════════════
   THEME CSS VARIABLES — applied to :root
══════════════════════════════════════════════════════ */
:root {
  --theme-primary:   #6366f1;
  --theme-secondary: #8b5cf6;
  --theme-accent:    #a855f7;
  --theme-sidebar-from: #0f172a;
  --theme-sidebar-to:   #1e293b;
  --theme-active-bg: rgba(99,102,241,.18);
  --theme-active-border: #6366f1;
  --theme-active-icon: #a5b4fc;
  --theme-brand-icon-from: #6366f1;
  --theme-brand-icon-to:   #8b5cf6;
  --theme-hero-employees: linear-gradient(135deg,#4f46e5,#6366f1,#8b5cf6);
  --theme-hero-payroll:   linear-gradient(135deg,#059669,#10b981,#14b8a6);
  --theme-hero-attendance:linear-gradient(135deg,#2563eb,#3b82f6,#6366f1);
  --theme-hero-leaves:    linear-gradient(135deg,#d97706,#f59e0b,#fbbf24);
  --theme-hero-loans:     linear-gradient(135deg,#7c3aed,#8b5cf6,#a855f7);
  --theme-hero-reports:   linear-gradient(135deg,#0f172a,#1e293b,#312e81);
}

/* Apply theme variables to sidebar */
.sidebar {
  background: linear-gradient(180deg, var(--theme-sidebar-from) 0%, var(--theme-sidebar-to) 100%) !important;
}
.nav-item.active {
  background: var(--theme-active-bg) !important;
  border-left-color: var(--theme-active-border) !important;
}
.nav-item.active i { color: var(--theme-active-icon) !important; }
.brand-icon {
  background: linear-gradient(135deg, var(--theme-brand-icon-from), var(--theme-brand-icon-to)) !important;
}
.btn-primary {
  background: linear-gradient(135deg, var(--theme-primary), var(--theme-secondary), var(--theme-accent)) !important;
}
.hero-employees  { background: var(--theme-hero-employees) !important; }
.hero-payroll    { background: var(--theme-hero-payroll)   !important; }
.hero-attendance { background: var(--theme-hero-attendance)!important; }
.hero-leaves     { background: var(--theme-hero-leaves)    !important; }
.hero-loans      { background: var(--theme-hero-loans)     !important; }
.hero-reports    { background: var(--theme-hero-reports)   !important; }
</style>
<style>
.sidebar{background:linear-gradient(180deg,#0f172a 0%,#1e293b 100%)}
.nav-item{display:flex;align-items:center;gap:.75rem;padding:.625rem .875rem;border-radius:10px;color:#94a3b8;font-size:.875rem;font-weight:500;text-decoration:none;transition:all .2s;margin:.1rem .75rem}
.nav-item i{width:20px;text-align:center;flex-shrink:0;font-size:1rem}
.nav-item span{flex:1;white-space:nowrap;overflow:hidden}
.nav-item:hover{color:#f1f5f9;background:rgba(255,255,255,.07)}
.nav-item.active{color:#fff;background:rgba(99,102,241,.18);border-left:3px solid #6366f1;padding-left:calc(.875rem - 3px)}
.nav-item.active i{color:#a5b4fc}
.nav-item-danger:hover{color:#fca5a5;background:rgba(239,68,68,.12)}
.nav-section-label{font-size:.65rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(148,163,184,.5);padding:1.1rem 1.5rem .35rem}
.sidebar-brand{display:flex;align-items:center;gap:.875rem;padding:1.25rem 1.5rem;border-bottom:1px solid rgba(255,255,255,.06)}
.brand-icon{width:40px;height:40px;border-radius:12px;flex-shrink:0;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.1rem;box-shadow:0 4px 12px rgba(99,102,241,.4)}
.brand-name{display:block;font-size:1rem;font-weight:700;color:#f1f5f9}
.brand-tagline{display:block;font-size:.68rem;color:#64748b}
.sidebar-toggle-btn{margin-left:auto;background:none;border:none;color:#64748b;cursor:pointer;font-size:1rem;padding:4px;border-radius:6px}
.sidebar-toggle-btn:hover{color:#f1f5f9}
.sidebar-user{display:flex;align-items:center;gap:.75rem;padding:.875rem 1.25rem;margin:.75rem;border-radius:12px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.07)}
.sidebar-avatar{width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid rgba(99,102,241,.5);flex-shrink:0}
.sidebar-user-name{display:block;font-size:.85rem;font-weight:600;color:#f1f5f9}
.sidebar-user-role{display:inline-flex;align-items:center;gap:4px;font-size:.68rem;font-weight:600;padding:1px 8px;border-radius:20px;margin-top:2px}
.badge-role-admin{background:rgba(99,102,241,.25);color:#a5b4fc}
.badge-role-hr{background:rgba(139,92,246,.25);color:#c4b5fd}
.badge-role-employee{background:rgba(16,185,129,.25);color:#6ee7b7}
.sidebar-nav{flex:1;overflow-y:auto;padding:.5rem 0}
.sidebar-nav::-webkit-scrollbar{width:3px}
.sidebar-nav::-webkit-scrollbar-thumb{background:rgba(255,255,255,.1);border-radius:4px}
.topbar{position:sticky;top:0;z-index:400;height:64px;background:rgba(255,255,255,.97);backdrop-filter:blur(12px);border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.topbar-left{display:flex;align-items:center;gap:1rem}
.topbar-menu-btn{width:38px;height:38px;border-radius:10px;display:flex;align-items:center;justify-content:center;color:#64748b;background:transparent;border:1px solid transparent;cursor:pointer;transition:all .2s;font-size:1.1rem}
.topbar-menu-btn:hover{background:#f1f5f9;border-color:#e2e8f0;color:#0f172a}
.topbar-breadcrumb{display:flex;align-items:center;gap:.375rem;font-size:.875rem}
.breadcrumb-icon{color:#94a3b8}
.breadcrumb-sep{color:#cbd5e1}
.breadcrumb-page{font-weight:700;color:#0f172a}
.topbar-right{display:flex;align-items:center;gap:.5rem}
.topbar-date{display:flex;align-items:center;gap:.5rem;padding:.375rem .875rem;border-radius:20px;background:#f1f5f9;border:1px solid #e2e8f0;font-size:.8rem;color:#64748b;font-weight:500;white-space:nowrap}
.topbar-date i{color:#6366f1}
.topbar-icon-btn{position:relative;width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;color:#64748b;background:transparent;border:1px solid transparent;cursor:pointer;transition:all .2s;font-size:1.1rem}
.topbar-icon-btn:hover{background:#f1f5f9;border-color:#e2e8f0;color:#0f172a}
.notif-badge{position:absolute;top:6px;right:6px;min-width:16px;height:16px;padding:0 4px;border-radius:8px;background:#ef4444;color:#fff;font-size:.6rem;font-weight:700;display:flex;align-items:center;justify-content:center;border:2px solid #fff;animation:pulse 2s infinite}
@keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.1)}}
.notif-wrapper,.profile-wrapper{position:relative}
.notif-dropdown,.profile-dropdown{position:absolute;top:calc(100% + 8px);right:0;background:#fff;border:1px solid #e2e8f0;border-radius:16px;box-shadow:0 20px 40px rgba(0,0,0,.12);z-index:500;display:none;animation:dropIn .2s ease}
.notif-dropdown.open,.profile-dropdown.open{display:block}
@keyframes dropIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
.notif-dropdown{width:340px}
.notif-header{display:flex;align-items:center;justify-content:space-between;padding:.875rem 1.125rem;border-bottom:1px solid #f1f5f9;font-weight:700;font-size:.875rem}
.notif-mark-all{background:none;border:none;cursor:pointer;color:#6366f1;font-size:.75rem;font-weight:600}
.notif-list{max-height:300px;overflow-y:auto}
.notif-item{display:flex;gap:.75rem;padding:.875rem 1.125rem;border-bottom:1px solid #f8fafc;cursor:pointer;transition:background .15s}
.notif-item:hover{background:#f8fafc}
.notif-item.unread{background:#f0f4ff}
.notif-item-icon{width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.8rem;flex-shrink:0}
.notif-icon-payroll{background:#e0e7ff;color:#6366f1}
.notif-icon-success{background:#d1fae5;color:#10b981}
.notif-icon-warning{background:#fef3c7;color:#f59e0b}
.notif-icon-info{background:#dbeafe;color:#3b82f6}
.notif-item-msg{font-size:.8rem;color:#0f172a;line-height:1.4}
.notif-item-time{font-size:.7rem;color:#94a3b8;margin-top:2px}
.notif-empty{padding:24px;text-align:center;color:#94a3b8;font-size:.85rem}
.notif-empty i{display:block;font-size:1.5rem;margin-bottom:6px;color:#10b981}
.topbar-profile-btn{display:flex;align-items:center;gap:.625rem;padding:.375rem .75rem .375rem .375rem;border-radius:20px;border:1px solid #e2e8f0;background:transparent;cursor:pointer;transition:all .2s}
.topbar-profile-btn:hover{background:#f1f5f9;border-color:#cbd5e1}
.topbar-avatar{width:30px;height:30px;border-radius:50%;object-fit:cover;border:2px solid #a5b4fc}
.topbar-user-info{display:flex;flex-direction:column}
.topbar-username{font-size:.82rem;font-weight:700;color:#0f172a;white-space:nowrap}
.topbar-userrole{font-size:.68rem;color:#64748b}
.topbar-chevron{color:#94a3b8;font-size:.75rem;transition:transform .2s}
.profile-dropdown{width:220px;padding:.5rem}
.profile-dropdown-header{display:flex;align-items:center;gap:.75rem;padding:.875rem 1rem;background:linear-gradient(135deg,#f0f4ff,#faf5ff);border-radius:10px;margin-bottom:.375rem}
.profile-dropdown a{display:flex;align-items:center;gap:.75rem;padding:.625rem .875rem;border-radius:8px;font-size:.85rem;color:#374151;transition:background .15s}
.profile-dropdown a:hover{background:#f1f5f9}
.profile-dropdown a i{width:16px;color:#64748b}
.profile-dropdown a.text-danger{color:#ef4444}
.profile-dropdown a.text-danger:hover{background:#fef2f2}
.dropdown-divider{height:1px;background:#f1f5f9;margin:.375rem 0}
.flash-message{display:flex;align-items:center;gap:.75rem;padding:.875rem 1.25rem;margin:0 1.5rem .5rem;border-radius:10px;font-size:.875rem;font-weight:500;animation:slideDown .3s ease}
@keyframes slideDown{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
.flash-success{background:#d1fae5;color:#065f46;border-left:4px solid #10b981}
.flash-error{background:#fee2e2;color:#991b1b;border-left:4px solid #ef4444}
.flash-warning{background:#fef3c7;color:#92400e;border-left:4px solid #f59e0b}
.flash-info{background:#dbeafe;color:#1e40af;border-left:4px solid #3b82f6}
.flash-close{margin-left:auto;background:none;border:none;cursor:pointer;opacity:.6;font-size:.9rem}
.main-wrapper{margin-left:260px;min-height:100vh;display:flex;flex-direction:column;transition:margin-left .3s ease;background:#f8fafc}
.page-content{flex:1;padding:1.75rem}
@media(max-width:1024px){
  .sidebar{transform:translateX(-100%);transition:transform .3s ease;z-index:500}
  .sidebar.open{transform:translateX(0)}
  .main-wrapper{margin-left:0}
  .topbar-date{display:none}
}
@media(max-width:768px){
  .page-content{padding:1rem}
  .topbar-username,.topbar-userrole{display:none}
}
</style>
</head>
<body>
<?php if (!empty($_SESSION['user_id'])): ?>
<div id="sidebarOverlay" onclick="closeSidebar()" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.5);z-index:499;backdrop-filter:blur(2px)"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-coins"></i></div>
    <div><span class="brand-name">PayrollPro</span><span class="brand-tagline">HR &amp; Payroll Suite</span></div>
    <button class="sidebar-toggle-btn" id="sidebarToggle"><i class="fas fa-bars"></i></button>
  </div>
  <div class="sidebar-user">
    <?php
    $sName = $_SESSION['user_name'] ?? 'User';
    $sId   = (int)($_SESSION['user_id'] ?? 0);
    $sAvatar = $_SESSION['user']['avatar'] ?? '';
    if (!empty($sAvatar)):
    ?>
    <img src="<?= e(getAvatarUrl($sAvatar, $sName, $sId)) ?>" alt="Avatar" class="sidebar-avatar">
    <?php else: ?>
    <div style="width:36px;height:36px;border-radius:50%;flex-shrink:0;overflow:hidden">
      <?= renderAvatarSvg($sName, $sId, 36) ?>
    </div>
    <?php endif; ?>
    <div>
      <span class="sidebar-user-name"><?= e($_SESSION['user_name'] ?? 'User') ?></span>
      <span class="sidebar-user-role badge-role-<?= e($_SESSION['user_role'] ?? 'employee') ?>">
        <i class="fas fa-<?= $_SESSION['user_role']==='admin'?'shield-alt':($_SESSION['user_role']==='hr'?'user-tie':'user') ?>"></i>
        <?= ucfirst($_SESSION['user_role'] ?? 'employee') ?>
      </span>
    </div>
  </div>
  <nav class="sidebar-nav">
    <?php $uri = $_SERVER['REQUEST_URI'] ?? ''; ?>
    <div class="nav-section-label">Main</div>
    <a href="<?= url('dashboard') ?>" class="nav-item <?= str_contains($uri,'dashboard')?'active':'' ?>"><i class="fas fa-th-large"></i><span>Dashboard</span></a>
    <?php if (isHR()): ?>
    <div class="nav-section-label">HR Management</div>
    <a href="<?= url('employees') ?>" class="nav-item <?= str_contains($uri,'employees')?'active':'' ?>"><i class="fas fa-users"></i><span>Employees</span></a>
    <a href="<?= url('payroll') ?>" class="nav-item <?= (str_contains($uri,'payroll') && !str_contains($uri,'history'))?'active':'' ?>"><i class="fas fa-money-bill-wave"></i><span>Payroll</span></a>
    <a href="<?= url('attendance') ?>" class="nav-item <?= str_contains($uri,'attendance')?'active':'' ?>"><i class="fas fa-clock"></i><span>Attendance</span></a>
    <a href="<?= url('leaves/approvals') ?>" class="nav-item <?= str_contains($uri,'leaves')?'active':'' ?>"><i class="fas fa-calendar-check"></i><span>Leave Approvals</span></a>
    <a href="<?= url('loans') ?>" class="nav-item <?= str_contains($uri,'loans')?'active':'' ?>"><i class="fas fa-hand-holding-usd"></i><span>Loans</span></a>
    <a href="<?= url('reports') ?>" class="nav-item <?= str_contains($uri,'reports')?'active':'' ?>"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
    <?php endif; ?>
    <?php if ($_SESSION['user_role']==='employee'): ?>
    <div class="nav-section-label">My Workspace</div>
    <a href="<?= url('attendance') ?>" class="nav-item <?= str_contains($uri,'attendance')?'active':'' ?>"><i class="fas fa-clock"></i><span>My Attendance</span></a>
    <a href="<?= url('leaves') ?>" class="nav-item <?= str_contains($uri,'leaves')?'active':'' ?>"><i class="fas fa-calendar-alt"></i><span>My Leaves</span></a>
    <a href="<?= url('payroll/history') ?>" class="nav-item <?= str_contains($uri,'payroll')?'active':'' ?>"><i class="fas fa-file-invoice-dollar"></i><span>My Payslips</span></a>
    <a href="<?= url('loans') ?>" class="nav-item <?= str_contains($uri,'loans')?'active':'' ?>"><i class="fas fa-hand-holding-usd"></i><span>My Loans</span></a>
    <?php endif; ?>
    <?php if (isAdmin()): ?>
    <div class="nav-section-label">Administration</div>
    <a href="<?= url('users') ?>" class="nav-item <?= str_contains($uri,'/users')?'active':'' ?>"><i class="fas fa-user-shield"></i><span>Users &amp; Roles</span></a>
    <a href="<?= url('settings') ?>" class="nav-item <?= str_contains($uri,'settings')?'active':'' ?>"><i class="fas fa-cog"></i><span>Settings</span></a>
    <?php endif; ?>
    <div class="nav-section-label">Account</div>
    <a href="<?= url('profile') ?>" class="nav-item <?= str_contains($uri,'profile')?'active':'' ?>"><i class="fas fa-user-circle"></i><span>My Profile</span></a>
    <a href="<?= url('auth/logout') ?>" class="nav-item nav-item-danger"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
  </nav>
</aside>
<div class="main-wrapper" id="mainWrapper">
  <header class="topbar">
    <div class="topbar-left">
      <button class="topbar-menu-btn" id="topbarMenuBtn"><i class="fas fa-bars"></i></button>
      <div class="topbar-breadcrumb">
        <span class="breadcrumb-icon"><i class="fas fa-home"></i></span>
        <span class="breadcrumb-sep">/</span>
        <span class="breadcrumb-page"><?= e($pageTitle ?? 'Dashboard') ?></span>
      </div>
    </div>
    <div class="topbar-right">
      <div class="topbar-date"><i class="fas fa-calendar-day"></i><span><?= date('D, M d Y') ?></span></div>

      <!-- Dark Mode Toggle -->
      <button class="topbar-icon-btn" id="darkModeToggle"
              title="Switch to Dark Mode"
              onclick="toggleDarkMode()"
              style="transition:color .2s,background .2s">
        <i class="fas fa-moon" id="darkModeIcon"
           style="transition:transform .3s ease,color .2s ease;font-size:1rem"></i>
      </button>

      <!-- ── Theme Palette Picker ── -->
      <div class="theme-picker-wrapper" id="themePickerWrapper">
        <button class="topbar-icon-btn" id="themePickerBtn" title="Change Theme">
          <i class="fas fa-palette" id="themePickerIcon" style="font-size:1rem"></i>
        </button>
        <div class="theme-picker-dropdown" id="themePickerDropdown">
          <div class="theme-picker-header">
            <i class="fas fa-palette" style="color:#6366f1;margin-right:6px"></i>
            Choose Theme
          </div>
          <div class="theme-grid">

            <!-- Default -->
            <button class="theme-swatch active" data-theme-name="default" onclick="applyTheme('default',this)" title="Default">
              <span class="swatch-preview">
                <span style="background:#6366f1"></span>
                <span style="background:#8b5cf6"></span>
                <span style="background:#f8fafc"></span>
              </span>
              <span class="swatch-label">Default</span>
              <i class="fas fa-check swatch-check"></i>
            </button>

            <!-- Neon -->
            <button class="theme-swatch" data-theme-name="neon" onclick="applyTheme('neon',this)" title="Neon">
              <span class="swatch-preview">
                <span style="background:#00ff88"></span>
                <span style="background:#ff00ff"></span>
                <span style="background:#0a0a1a"></span>
              </span>
              <span class="swatch-label">Neon</span>
              <i class="fas fa-check swatch-check"></i>
            </button>

            <!-- Sunset -->
            <button class="theme-swatch" data-theme-name="sunset" onclick="applyTheme('sunset',this)" title="Sunset">
              <span class="swatch-preview">
                <span style="background:#f97316"></span>
                <span style="background:#ec4899"></span>
                <span style="background:#fff7ed"></span>
              </span>
              <span class="swatch-label">Sunset</span>
              <i class="fas fa-check swatch-check"></i>
            </button>

            <!-- Ocean -->
            <button class="theme-swatch" data-theme-name="ocean" onclick="applyTheme('ocean',this)" title="Ocean">
              <span class="swatch-preview">
                <span style="background:#0ea5e9"></span>
                <span style="background:#06b6d4"></span>
                <span style="background:#f0f9ff"></span>
              </span>
              <span class="swatch-label">Ocean</span>
              <i class="fas fa-check swatch-check"></i>
            </button>

            <!-- Forest -->
            <button class="theme-swatch" data-theme-name="forest" onclick="applyTheme('forest',this)" title="Forest">
              <span class="swatch-preview">
                <span style="background:#16a34a"></span>
                <span style="background:#15803d"></span>
                <span style="background:#f0fdf4"></span>
              </span>
              <span class="swatch-label">Forest</span>
              <i class="fas fa-check swatch-check"></i>
            </button>

            <!-- Rose -->
            <button class="theme-swatch" data-theme-name="rose" onclick="applyTheme('rose',this)" title="Rose">
              <span class="swatch-preview">
                <span style="background:#f43f5e"></span>
                <span style="background:#e11d48"></span>
                <span style="background:#fff1f2"></span>
              </span>
              <span class="swatch-label">Rose</span>
              <i class="fas fa-check swatch-check"></i>
            </button>

            <!-- Flower -->
            <button class="theme-swatch" data-theme-name="flower" onclick="applyTheme('flower',this)" title="Flower">
              <span class="swatch-preview">
                <span style="background:#d946ef"></span>
                <span style="background:#a21caf"></span>
                <span style="background:#fdf4ff"></span>
              </span>
              <span class="swatch-label">Flower</span>
              <i class="fas fa-check swatch-check"></i>
            </button>

            <!-- Midnight -->
            <button class="theme-swatch" data-theme-name="midnight" onclick="applyTheme('midnight',this)" title="Midnight">
              <span class="swatch-preview">
                <span style="background:#818cf8"></span>
                <span style="background:#312e81"></span>
                <span style="background:#0f0f23"></span>
              </span>
              <span class="swatch-label">Midnight</span>
              <i class="fas fa-check swatch-check"></i>
            </button>

            <!-- Amber -->
            <button class="theme-swatch" data-theme-name="amber" onclick="applyTheme('amber',this)" title="Amber">
              <span class="swatch-preview">
                <span style="background:#f59e0b"></span>
                <span style="background:#d97706"></span>
                <span style="background:#fffbeb"></span>
              </span>
              <span class="swatch-label">Amber</span>
              <i class="fas fa-check swatch-check"></i>
            </button>

            <!-- Slate -->
            <button class="theme-swatch" data-theme-name="slate" onclick="applyTheme('slate',this)" title="Slate">
              <span class="swatch-preview">
                <span style="background:#475569"></span>
                <span style="background:#1e293b"></span>
                <span style="background:#f8fafc"></span>
              </span>
              <span class="swatch-label">Slate</span>
              <i class="fas fa-check swatch-check"></i>
            </button>

          </div>
          <div class="theme-picker-footer">
            <button onclick="applyTheme('default',document.querySelector('[data-theme-name=default]'))"
                    style="font-size:.72rem;color:#94a3b8;background:none;border:none;cursor:pointer;padding:0">
              <i class="fas fa-undo" style="margin-right:4px"></i>Reset to Default
            </button>
          </div>
        </div>
      </div>

      <div class="notif-wrapper" id="notifWrapper">
        <button class="topbar-icon-btn" id="notifBtn">
          <i class="fas fa-bell"></i>
          <span class="notif-badge" id="notifBadge" style="display:none">0</span>
        </button>
        <div class="notif-dropdown" id="notifDropdown">
          <div class="notif-header">
            <span><i class="fas fa-bell" style="color:#6366f1;margin-right:6px"></i>Notifications</span>
            <button class="notif-mark-all" id="markAllRead">Mark all read</button>
          </div>
          <div class="notif-list" id="notifList">
            <div class="notif-empty"><i class="fas fa-check-circle"></i><span>All caught up!</span></div>
          </div>
        </div>
      </div>
      <div class="profile-wrapper" id="profileWrapper">
        <button class="topbar-profile-btn" id="profileBtn">
          <?php
          $tName   = $_SESSION['user_name'] ?? 'U';
          $tId     = (int)($_SESSION['user_id'] ?? 0);
          $tAvatar = $_SESSION['user']['avatar'] ?? '';
          if (!empty($tAvatar)):
          ?>
          <img src="<?= e(url($tAvatar)) ?>" alt="Avatar" class="topbar-avatar">
          <?php else: ?>
          <div style="width:30px;height:30px;border-radius:50%;overflow:hidden;flex-shrink:0;border:2px solid #a5b4fc">
            <?= renderAvatarSvg($tName, $tId, 30) ?>
          </div>
          <?php endif; ?>
          <div class="topbar-user-info">
            <span class="topbar-username"><?= e($_SESSION['user_name'] ?? '') ?></span>
            <span class="topbar-userrole"><?= ucfirst($_SESSION['user_role'] ?? '') ?></span>
          </div>
          <i class="fas fa-chevron-down topbar-chevron"></i>
        </button>
        <div class="profile-dropdown" id="profileDropdown">
          <div class="profile-dropdown-header">
            <?php if (!empty($_SESSION['user']['avatar'])): ?>
            <img src="<?= e(url($_SESSION['user']['avatar'])) ?>" alt="" style="width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #a5b4fc;flex-shrink:0">
            <?php else: ?>
            <div style="width:40px;height:40px;border-radius:50%;overflow:hidden;flex-shrink:0;border:2px solid #a5b4fc">
              <?= renderAvatarSvg($_SESSION['user_name'] ?? 'U', (int)($_SESSION['user_id'] ?? 0), 40) ?>
            </div>
            <?php endif; ?>
            <div>
              <div style="font-weight:700;font-size:.875rem;color:#0f172a"><?= e($_SESSION['user_name'] ?? '') ?></div>
              <div style="font-size:.72rem;color:#64748b"><?= e($_SESSION['user']['email'] ?? '') ?></div>
            </div>
          </div>
          <div class="dropdown-divider"></div>
          <a href="<?= url('profile') ?>"><i class="fas fa-user-circle"></i> My Profile</a>
          <?php if (isAdmin()): ?><a href="<?= url('settings') ?>"><i class="fas fa-cog"></i> Settings</a><?php endif; ?>
          <div class="dropdown-divider"></div>
          <a href="<?= url('auth/logout') ?>" class="text-danger"><i class="fas fa-sign-out-alt"></i> Sign Out</a>
        </div>
      </div>
    </div>
  </header>
  <?php
  $flash = $_SESSION['flash'] ?? null;
  unset($_SESSION['flash']);
  if ($flash):
  ?>
  <div class="flash-message flash-<?= e($flash['type']) ?>" id="flashMsg">
    <i class="fas fa-<?= $flash['type']==='success'?'check-circle':($flash['type']==='error'?'exclamation-circle':'info-circle') ?>"></i>
    <span><?= e($flash['message']) ?></span>
    <button class="flash-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
  </div>
  <?php endif; ?>
  <main class="page-content">
<?php endif; ?>


