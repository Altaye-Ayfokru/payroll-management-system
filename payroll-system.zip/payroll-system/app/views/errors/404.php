<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>404 — Page Not Found | PayrollPro</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',sans-serif;background:linear-gradient(135deg,#0f172a 0%,#1e293b 50%,#312e81 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;color:#fff}
.container{text-align:center;padding:2rem;max-width:520px}
.code{font-size:8rem;font-weight:900;line-height:1;background:linear-gradient(135deg,#6366f1,#8b5cf6,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;animation:pulse 3s ease-in-out infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.7}}
.title{font-size:1.75rem;font-weight:800;margin:.5rem 0;letter-spacing:-.02em}
.desc{color:rgba(255,255,255,.65);font-size:.95rem;line-height:1.6;margin-bottom:2rem}
.btns{display:flex;gap:1rem;justify-content:center;flex-wrap:wrap}
.btn{display:inline-flex;align-items:center;gap:.5rem;padding:.75rem 1.5rem;border-radius:10px;font-weight:700;font-size:.9rem;text-decoration:none;transition:all .2s}
.btn-primary{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;box-shadow:0 4px 16px rgba(99,102,241,.4)}
.btn-primary:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(99,102,241,.5);color:#fff}
.btn-outline{background:rgba(255,255,255,.1);color:#fff;border:1.5px solid rgba(255,255,255,.25)}
.btn-outline:hover{background:rgba(255,255,255,.2);transform:translateY(-2px);color:#fff}
.icon{font-size:4rem;margin-bottom:1rem;animation:float 3s ease-in-out infinite}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
.orb{position:fixed;border-radius:50%;filter:blur(80px);opacity:.15;pointer-events:none}
.orb1{width:400px;height:400px;background:#6366f1;top:-100px;left:-100px}
.orb2{width:300px;height:300px;background:#ec4899;bottom:-80px;right:-80px}
</style>
</head>
<body>
<div class="orb orb1"></div>
<div class="orb orb2"></div>
<div class="container">
  <div class="icon">🔍</div>
  <div class="code">404</div>
  <div class="title">Page Not Found</div>
  <div class="desc">The page you're looking for doesn't exist or has been moved. Let's get you back on track.</div>
  <div class="btns">
    <a href="<?= defined('BASE_URL') ? BASE_URL . '/dashboard' : '/dashboard' ?>" class="btn btn-primary">
      🏠 Go to Dashboard
    </a>
    <a href="javascript:history.back()" class="btn btn-outline">← Go Back</a>
  </div>
</div>
</body>
</html>
