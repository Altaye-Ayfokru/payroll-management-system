<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>403 — Access Denied | PayrollPro</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',sans-serif;background:linear-gradient(135deg,#0f172a 0%,#1e293b 50%,#312e81 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;color:#fff}
.container{text-align:center;padding:2rem;max-width:480px}
.code{font-size:8rem;font-weight:900;line-height:1;background:linear-gradient(135deg,#6366f1,#8b5cf6,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.title{font-size:1.75rem;font-weight:800;margin:.5rem 0;letter-spacing:-.02em}
.desc{color:rgba(255,255,255,.65);font-size:.95rem;line-height:1.6;margin-bottom:2rem}
.btn{display:inline-flex;align-items:center;gap:.5rem;padding:.75rem 1.5rem;border-radius:10px;font-weight:700;font-size:.9rem;text-decoration:none;transition:all .2s;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;box-shadow:0 4px 16px rgba(99,102,241,.4)}
.btn:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(99,102,241,.5)}
.icon{font-size:4rem;margin-bottom:1rem;opacity:.8}
</style>
</head>
<body>
<div class="container">
  <div class="icon">🔒</div>
  <div class="code">403</div>
  <div class="title">Access Denied</div>
  <div class="desc">You don't have permission to access this page. Please contact your administrator if you believe this is an error.</div>
  <a href="javascript:history.back()" class="btn">← Go Back</a>
</div>
</body>
</html>
