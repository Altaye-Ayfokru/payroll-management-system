<?php
$trendJson   = json_encode($trend      ?? []);
$deptJson    = json_encode($deptSalary ?? []);
$month       = $month ?? date('Y-m');
$monthLabel  = date('F Y', strtotime($month . '-01'));

// Summary totals
$totalBudget  = array_sum(array_column($deptSalary ?? [], 'total_salary'));
$totalEmpDept = array_sum(array_column($deptSalary ?? [], 'emp_count'));
$avgSalary    = $totalEmpDept > 0 ? $totalBudget / $totalEmpDept : 0;
?>

<style>
.rpt-hero{background:linear-gradient(135deg,#0f172a 0%,#1e293b 50%,#312e81 100%);border-radius:20px;padding:2rem 2.5rem;margin-bottom:1.75rem;color:#fff;position:relative;overflow:hidden}
.rpt-hero::before{content:'';position:absolute;inset:0;background:url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Ccircle cx='20' cy='20' r='15'/%3E%3C/g%3E%3C/svg%3E");pointer-events:none}
.rpt-hero-content{position:relative;z-index:1}
.rpt-hero h1{font-size:1.75rem;font-weight:800;margin-bottom:.375rem;letter-spacing:-.02em}
.rpt-hero p{opacity:.75;font-size:.9rem;margin-bottom:1.25rem}
.rpt-hero-pills{display:flex;gap:.75rem;flex-wrap:wrap}
.rpt-pill{display:inline-flex;align-items:center;gap:.5rem;padding:.375rem .875rem;border-radius:999px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);font-size:.8rem;font-weight:600;color:#fff;text-decoration:none;transition:all .2s}
.rpt-pill:hover{background:rgba(255,255,255,.22);color:#fff}
.rpt-pill.active{background:rgba(99,102,241,.5);border-color:#6366f1}
.rpt-nav{display:flex;gap:.5rem;margin-bottom:1.5rem;flex-wrap:wrap}
.rpt-nav a{display:inline-flex;align-items:center;gap:.5rem;padding:.5rem 1rem;border-radius:10px;font-size:.85rem;font-weight:600;text-decoration:none;transition:all .2s;border:1.5px solid #e2e8f0;color:#374151;background:#fff}
.rpt-nav a:hover{border-color:#6366f1;color:#6366f1;background:#eef2ff}
.rpt-nav a.active{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border-color:transparent;box-shadow:0 4px 12px rgba(99,102,241,.35)}
.chart-card{background:#fff;border-radius:16px;border:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(0,0,0,.06);overflow:hidden;transition:box-shadow .2s}
.chart-card:hover{box-shadow:0 4px 16px rgba(0,0,0,.1)}
.chart-card-header{display:flex;align-items:center;justify-content:space-between;padding:1.125rem 1.5rem;border-bottom:1px solid #f1f5f9}
.chart-card-title{font-size:.95rem;font-weight:700;color:#0f172a;display:flex;align-items:center;gap:.5rem}
.chart-card-icon{width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.8rem;color:#fff}
.chart-card-body{padding:1.25rem 1.5rem}
.chart-wrap{position:relative;height:260px}
.chart-wrap-sm{position:relative;height:200px}
.kpi-row{display:grid;grid-template-columns:repeat(4,1fr);gap:1.25rem;margin-bottom:1.75rem}
.kpi-card{background:#fff;border-radius:14px;padding:1.25rem 1.5rem;border:1px solid #e2e8f0;box-shadow:0 1px 3px rgba(0,0,0,.05);position:relative;overflow:hidden;transition:all .25s}
.kpi-card::before{content:'';position:absolute;left:0;top:0;bottom:0;width:4px;border-radius:4px 0 0 4px}
.kpi-card:hover{transform:translateY(-3px);box-shadow:0 8px 24px rgba(0,0,0,.1)}
.kpi-card.kpi-blue::before{background:linear-gradient(180deg,#3b82f6,#6366f1)}
.kpi-card.kpi-green::before{background:linear-gradient(180deg,#10b981,#059669)}
.kpi-card.kpi-purple::before{background:linear-gradient(180deg,#8b5cf6,#6366f1)}
.kpi-card.kpi-amber::before{background:linear-gradient(180deg,#f59e0b,#f97316)}
.kpi-icon{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;color:#fff;margin-bottom:.875rem}
.kpi-blue  .kpi-icon{background:linear-gradient(135deg,#3b82f6,#6366f1);box-shadow:0 4px 10px rgba(59,130,246,.35)}
.kpi-green .kpi-icon{background:linear-gradient(135deg,#10b981,#059669);box-shadow:0 4px 10px rgba(16,185,129,.35)}
.kpi-purple.kpi-icon{background:linear-gradient(135deg,#8b5cf6,#6366f1);box-shadow:0 4px 10px rgba(139,92,246,.35)}
.kpi-amber .kpi-icon{background:linear-gradient(135deg,#f59e0b,#f97316);box-shadow:0 4px 10px rgba(245,158,11,.35)}
.kpi-purple .kpi-icon{background:linear-gradient(135deg,#8b5cf6,#6366f1);box-shadow:0 4px 10px rgba(139,92,246,.35)}
.kpi-num{font-size:1.75rem;font-weight:800;color:#0f172a;line-height:1;letter-spacing:-.03em}
.kpi-label{font-size:.78rem;color:#64748b;font-weight:500;margin-top:4px}
.dept-row{display:flex;align-items:center;gap:.75rem;padding:.625rem 0;border-bottom:1px solid #f8fafc}
.dept-row:last-child{border-bottom:none}
.dept-bar-wrap{flex:1;height:8px;background:#f1f5f9;border-radius:999px;overflow:hidden}
.dept-bar-fill{height:100%;border-radius:999px;background:linear-gradient(90deg,#6366f1,#8b5cf6);transition:width .8s cubic-bezier(.4,0,.2,1)}
@media(max-width:1100px){.kpi-row{grid-template-columns:repeat(2,1fr)}}
@media(max-width:640px){.kpi-row{grid-template-columns:1fr}}
</style>

<!-- Hero Banner -->
<div class="page-hero hero-reports">
  <div class="hero-orb hero-orb-1"></div>
  <div class="hero-orb hero-orb-2"></div>
  <div class="page-hero-content">
    <div class="hero-badge"><span class="hero-badge-dot"></span> Analytics</div>
    <div class="page-hero-title">Reports &amp; Analytics</div>
    <div class="page-hero-sub">Comprehensive insights across payroll, workforce, attendance, and tax data.</div>
    <div class="page-hero-actions">
      <a href="<?= url('reports/export?type=salary&month=' . $month) ?>" class="page-hero-btn page-hero-btn-white">
        <i class="fas fa-download"></i> Export Salary
      </a>
      <a href="<?= url('reports/salary') ?>" class="page-hero-btn page-hero-btn-outline">
        <i class="fas fa-money-bill"></i> Salary Report
      </a>
    </div>
  </div>
  <svg class="page-hero-illustration" viewBox="0 0 280 180" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="20" y="20" width="240" height="140" rx="16" fill="rgba(255,255,255,0.1)" stroke="rgba(255,255,255,0.2)" stroke-width="1.5"/>
    <rect x="36" y="36" width="60" height="8" rx="4" fill="rgba(255,255,255,0.7)"/>
    <rect x="36" y="48" width="40" height="5" rx="2.5" fill="rgba(255,255,255,0.4)"/>
    <!-- Bar chart -->
    <g transform="translate(36,70)">
      <rect x="0"  y="50" width="18" height="30" rx="4" fill="rgba(165,180,252,0.7)"/>
      <rect x="24" y="35" width="18" height="45" rx="4" fill="rgba(129,140,248,0.8)"/>
      <rect x="48" y="20" width="18" height="60" rx="4" fill="rgba(99,102,241,0.9)"/>
      <rect x="72" y="30" width="18" height="50" rx="4" fill="rgba(129,140,248,0.8)"/>
      <rect x="96" y="10" width="18" height="70" rx="4" fill="rgba(79,70,229,1)"/>
      <rect x="120" y="25" width="18" height="55" rx="4" fill="rgba(129,140,248,0.8)"/>
      <rect x="144" y="15" width="18" height="65" rx="4" fill="rgba(99,102,241,0.9)"/>
      <line x1="0" y1="82" x2="170" y2="82" stroke="rgba(255,255,255,0.2)" stroke-width="1"/>
    </g>
    <!-- Line chart overlay -->
    <polyline points="54,100 78,88 102,76 126,82 150,68 174,72 198,60" stroke="rgba(74,222,128,0.8)" stroke-width="2.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="54"  cy="100" r="3" fill="#4ade80"/>
    <circle cx="102" cy="76"  r="3" fill="#4ade80"/>
    <circle cx="150" cy="68"  r="3" fill="#4ade80"/>
    <circle cx="198" cy="60"  r="4" fill="#4ade80"/>
  </svg>
</div>

<!-- Hero Banner -->
<div class="rpt-hero">
  <div class="rpt-hero-content">
    <h1><i class="fas fa-chart-bar" style="margin-right:.5rem;opacity:.8"></i>Reports &amp; Analytics</h1>
    <p>Comprehensive insights across payroll, workforce, attendance, and tax data</p>
    <div class="rpt-hero-pills">
      <a href="<?= url('reports/export?type=salary&month=' . $month) ?>" class="rpt-pill">
        <i class="fas fa-download"></i> Export Salary CSV
      </a>
      <a href="<?= url('reports/export?type=attendance&month=' . $month) ?>" class="rpt-pill">
        <i class="fas fa-download"></i> Export Attendance CSV
      </a>
      <span class="rpt-pill"><i class="fas fa-calendar"></i> <?= $monthLabel ?></span>
    </div>
  </div>
</div>

<!-- Report Navigation -->
<div class="rpt-nav">
  <a href="<?= url('reports') ?>" class="active"><i class="fas fa-th-large"></i> Overview</a>
  <a href="<?= url('reports/salary') ?>"><i class="fas fa-money-bill-wave"></i> Salary</a>
  <a href="<?= url('reports/attendance') ?>"><i class="fas fa-clock"></i> Attendance</a>
  <a href="<?= url('reports/tax') ?>"><i class="fas fa-receipt"></i> Tax</a>
</div>

<!-- KPI Cards -->
<div class="kpi-row">
  <div class="kpi-card kpi-blue">
    <div class="kpi-icon"><i class="fas fa-users"></i></div>
    <div class="kpi-num"><?= number_format($totalEmpDept) ?></div>
    <div class="kpi-label">Active Employees</div>
  </div>
  <div class="kpi-card kpi-green">
    <div class="kpi-icon"><i class="fas fa-money-bill-wave"></i></div>
    <div class="kpi-num" style="font-size:1.4rem"><?= formatCurrency($totalBudget) ?></div>
    <div class="kpi-label">Total Salary Budget</div>
  </div>
  <div class="kpi-card kpi-purple">
    <div class="kpi-icon"><i class="fas fa-calculator"></i></div>
    <div class="kpi-num" style="font-size:1.4rem"><?= formatCurrency($avgSalary) ?></div>
    <div class="kpi-label">Average Salary</div>
  </div>
  <div class="kpi-card kpi-amber">
    <div class="kpi-icon"><i class="fas fa-building"></i></div>
    <div class="kpi-num"><?= count($deptSalary ?? []) ?></div>
    <div class="kpi-label">Departments</div>
  </div>
</div>

<!-- Charts Row 1: Trend + Doughnut -->
<div style="display:grid;grid-template-columns:2fr 1fr;gap:1.25rem;margin-bottom:1.5rem">

  <!-- Payroll Trend -->
  <div class="chart-card">
    <div class="chart-card-header">
      <div class="chart-card-title">
        <div class="chart-card-icon" style="background:linear-gradient(135deg,#6366f1,#8b5cf6)"><i class="fas fa-chart-line"></i></div>
        Payroll Trend — Last 12 Months
      </div>
      <span style="font-size:.75rem;color:#94a3b8;font-weight:500">Net payroll &amp; tax</span>
    </div>
    <div class="chart-card-body">
      <div class="chart-wrap">
        <canvas id="payrollTrendReportChart" data-trend='<?= $trendJson ?>'></canvas>
      </div>
    </div>
  </div>

  <!-- Dept Doughnut -->
  <div class="chart-card">
    <div class="chart-card-header">
      <div class="chart-card-title">
        <div class="chart-card-icon" style="background:linear-gradient(135deg,#10b981,#14b8a6)"><i class="fas fa-chart-pie"></i></div>
        Salary by Department
      </div>
    </div>
    <div class="chart-card-body">
      <div class="chart-wrap-sm">
        <canvas id="deptSalaryChart" data-dept='<?= $deptJson ?>'></canvas>
      </div>
    </div>
  </div>

</div>

<!-- Department Breakdown Table + Bar -->
<div class="chart-card" style="margin-bottom:1.5rem">
  <div class="chart-card-header">
    <div class="chart-card-title">
      <div class="chart-card-icon" style="background:linear-gradient(135deg,#3b82f6,#6366f1)"><i class="fas fa-building"></i></div>
      Department Salary Breakdown
    </div>
    <span style="font-size:.75rem;color:#94a3b8">Sorted by total budget</span>
  </div>
  <div class="chart-card-body">
    <?php if (empty($deptSalary)): ?>
    <div style="text-align:center;padding:2rem;color:#94a3b8">
      <i class="fas fa-chart-bar" style="font-size:2rem;margin-bottom:.5rem;display:block;opacity:.4"></i>
      No department data available. Run payroll first.
    </div>
    <?php else: ?>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:2rem">
      <!-- Table -->
      <div>
        <?php
        $grandTotal = array_sum(array_column($deptSalary, 'total_salary'));
        $colors = ['#6366f1','#10b981','#f59e0b','#3b82f6','#ec4899','#14b8a6','#f97316','#8b5cf6'];
        foreach ($deptSalary as $i => $d):
          $avg = $d['emp_count'] > 0 ? $d['total_salary'] / $d['emp_count'] : 0;
          $pct = $grandTotal > 0 ? round(($d['total_salary'] / $grandTotal) * 100, 1) : 0;
          $col = $colors[$i % count($colors)];
        ?>
        <div class="dept-row">
          <div style="width:10px;height:10px;border-radius:3px;background:<?= e($col) ?>;flex-shrink:0"></div>
          <div style="flex:1;min-width:0">
            <div style="font-size:.85rem;font-weight:600;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e($d['department']) ?></div>
            <div style="font-size:.72rem;color:#94a3b8"><?= $d['emp_count'] ?> employees &middot; avg <?= formatCurrency($avg) ?></div>
          </div>
          <div style="text-align:right;flex-shrink:0">
            <div style="font-size:.85rem;font-weight:700;color:#0f172a"><?= formatCurrency((float)$d['total_salary']) ?></div>
            <div style="font-size:.72rem;color:#94a3b8"><?= $pct ?>%</div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <!-- Progress bars -->
      <div>
        <?php foreach ($deptSalary as $i => $d):
          $pct = $grandTotal > 0 ? round(($d['total_salary'] / $grandTotal) * 100, 1) : 0;
          $col = $colors[$i % count($colors)];
        ?>
        <div style="margin-bottom:1rem">
          <div style="display:flex;justify-content:space-between;font-size:.78rem;margin-bottom:5px">
            <span style="font-weight:600;color:#374151"><?= e($d['department']) ?></span>
            <span style="color:#64748b"><?= $pct ?>%</span>
          </div>
          <div style="height:10px;background:#f1f5f9;border-radius:999px;overflow:hidden">
            <div style="height:100%;width:<?= $pct ?>%;background:<?= e($col) ?>;border-radius:999px;transition:width 1s ease;animation:progressFill 1.2s ease both"></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Quick Links to sub-reports -->
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1.25rem">
  <?php
  $quickLinks = [
    ['url' => 'reports/salary',     'icon' => 'fa-money-bill-wave', 'color' => '#10b981', 'bg' => '#ecfdf5', 'title' => 'Salary Report',     'desc' => 'Gross, net, deductions per employee'],
    ['url' => 'reports/attendance', 'icon' => 'fa-clock',           'color' => '#3b82f6', 'bg' => '#eff6ff', 'title' => 'Attendance Report',  'desc' => 'Daily check-in/out and overtime'],
    ['url' => 'reports/tax',        'icon' => 'fa-receipt',         'color' => '#f59e0b', 'bg' => '#fffbeb', 'title' => 'Tax Report',         'desc' => 'Income tax and deduction breakdown'],
  ];
  foreach ($quickLinks as $ql):
  ?>
  <a href="<?= url($ql['url']) ?>" style="display:flex;align-items:center;gap:1rem;padding:1.25rem;background:#fff;border-radius:14px;border:1px solid #e2e8f0;text-decoration:none;transition:all .2s;box-shadow:0 1px 3px rgba(0,0,0,.05)" onmouseover="this.style.transform='translateY(-3px)';this.style.boxShadow='0 8px 24px rgba(0,0,0,.1)'" onmouseout="this.style.transform='';this.style.boxShadow='0 1px 3px rgba(0,0,0,.05)'">
    <div style="width:48px;height:48px;border-radius:12px;background:<?= $ql['bg'] ?>;color:<?= $ql['color'] ?>;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0">
      <i class="fas <?= $ql['icon'] ?>"></i>
    </div>
    <div>
      <div style="font-size:.9rem;font-weight:700;color:#0f172a"><?= $ql['title'] ?></div>
      <div style="font-size:.78rem;color:#64748b;margin-top:2px"><?= $ql['desc'] ?></div>
    </div>
    <i class="fas fa-arrow-right" style="margin-left:auto;color:#94a3b8;font-size:.8rem"></i>
  </a>
  <?php endforeach; ?>
</div>
