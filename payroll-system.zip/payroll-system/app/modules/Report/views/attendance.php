<?php
$recordsJson = json_encode(array_slice($records ?? [], 0, 50));
$present     = count(array_filter($records ?? [], fn($r) => in_array($r['status'], ['present','late'])));
$absent      = count(array_filter($records ?? [], fn($r) => $r['status'] === 'absent'));
$late        = count(array_filter($records ?? [], fn($r) => $r['status'] === 'late'));
$totalHrs    = array_sum(array_column($records ?? [], 'hours_worked'));
$otHrs       = array_sum(array_column($records ?? [], 'overtime_hours'));
$monthLabel  = date('F Y', strtotime(($month ?? date('Y-m')) . '-01'));
?>

<style>
.rpt-nav{display:flex;gap:.5rem;margin-bottom:1.5rem;flex-wrap:wrap}
.rpt-nav a{display:inline-flex;align-items:center;gap:.5rem;padding:.5rem 1rem;border-radius:10px;font-size:.85rem;font-weight:600;text-decoration:none;transition:all .2s;border:1.5px solid #e2e8f0;color:#374151;background:#fff}
.rpt-nav a:hover{border-color:#6366f1;color:#6366f1;background:#eef2ff}
.rpt-nav a.active{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border-color:transparent;box-shadow:0 4px 12px rgba(99,102,241,.35)}
</style>

<div class="page-header">
  <div>
    <div class="page-header-title">Attendance Report</div>
    <div class="page-header-sub"><?= $monthLabel ?></div>
  </div>
  <div class="page-header-actions">
    <form method="GET" style="display:flex;gap:8px;align-items:center">
      <input type="month" name="month" class="form-control" value="<?= e($month ?? date('Y-m')) ?>" style="width:auto">
      <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i></button>
    </form>
    <a href="<?= url('reports/export?type=attendance&month=' . ($month ?? date('Y-m'))) ?>" class="btn btn-outline">
      <i class="fas fa-download"></i> Export CSV
    </a>
  </div>
</div>

<div class="rpt-nav">
  <a href="<?= url('reports') ?>"><i class="fas fa-th-large"></i> Overview</a>
  <a href="<?= url('reports/salary') ?>"><i class="fas fa-money-bill-wave"></i> Salary</a>
  <a href="<?= url('reports/attendance') ?>" class="active"><i class="fas fa-clock"></i> Attendance</a>
  <a href="<?= url('reports/tax') ?>"><i class="fas fa-receipt"></i> Tax</a>
</div>

<!-- KPI Row -->
<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:1rem;margin-bottom:1.5rem">
  <?php $kpis = [
    ['icon'=>'fa-user-check',  'color'=>'#10b981','bg'=>'#ecfdf5','val'=>$present,              'lbl'=>'Present Records'],
    ['icon'=>'fa-user-times',  'color'=>'#ef4444','bg'=>'#fef2f2','val'=>$absent,               'lbl'=>'Absent Records'],
    ['icon'=>'fa-clock',       'color'=>'#f59e0b','bg'=>'#fffbeb','val'=>$late,                 'lbl'=>'Late Records'],
    ['icon'=>'fa-hourglass',   'color'=>'#3b82f6','bg'=>'#eff6ff','val'=>round($totalHrs,1).'h','lbl'=>'Total Hours'],
    ['icon'=>'fa-star',        'color'=>'#8b5cf6','bg'=>'#f5f3ff','val'=>round($otHrs,1).'h',   'lbl'=>'Overtime Hours'],
  ]; foreach ($kpis as $k): ?>
  <div style="background:#fff;border-radius:14px;padding:1.125rem;border:1px solid #e2e8f0;box-shadow:0 1px 3px rgba(0,0,0,.05)">
    <div style="width:38px;height:38px;border-radius:10px;background:<?= $k['bg'] ?>;color:<?= $k['color'] ?>;display:flex;align-items:center;justify-content:center;font-size:1rem;margin-bottom:.625rem">
      <i class="fas <?= $k['icon'] ?>"></i>
    </div>
    <div style="font-size:1.5rem;font-weight:800;color:#0f172a;line-height:1"><?= $k['val'] ?></div>
    <div style="font-size:.75rem;color:#64748b;margin-top:3px;font-weight:500"><?= $k['lbl'] ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Stacked Bar Chart -->
<?php if (!empty($records)): ?>
<div style="background:#fff;border-radius:16px;border:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(0,0,0,.06);margin-bottom:1.5rem;overflow:hidden">
  <div style="display:flex;align-items:center;justify-content:space-between;padding:1.125rem 1.5rem;border-bottom:1px solid #f1f5f9">
    <div style="font-size:.95rem;font-weight:700;color:#0f172a;display:flex;align-items:center;gap:.5rem">
      <div style="width:28px;height:28px;border-radius:8px;background:linear-gradient(135deg,#3b82f6,#6366f1);display:flex;align-items:center;justify-content:center;font-size:.8rem;color:#fff"><i class="fas fa-chart-bar"></i></div>
      Attendance by Employee (Stacked)
    </div>
    <span style="font-size:.75rem;color:#94a3b8"><?= $monthLabel ?></span>
  </div>
  <div style="padding:1.25rem 1.5rem">
    <div style="position:relative;height:300px">
      <canvas id="attendanceReportChart" data-records='<?= htmlspecialchars($recordsJson, ENT_QUOTES) ?>'></canvas>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Table -->
<div style="background:#fff;border-radius:16px;border:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(0,0,0,.06);overflow:hidden">
  <div style="overflow-x:auto">
    <table style="width:100%;border-collapse:collapse;font-size:.875rem">
      <thead>
        <tr style="background:#f8fafc">
          <?php foreach (['Employee','Dept','Date','Check In','Check Out','Hours','Overtime','Status'] as $h): ?>
          <th style="padding:.75rem 1rem;text-align:left;font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#94a3b8;border-bottom:2px solid #e2e8f0;white-space:nowrap"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($records)): ?>
        <tr><td colspan="8" style="text-align:center;padding:3rem;color:#94a3b8">
          <i class="fas fa-clock" style="font-size:2rem;display:block;margin-bottom:.5rem;opacity:.4"></i>
          No attendance records found
        </td></tr>
        <?php else: ?>
        <?php foreach ($records as $r): ?>
        <tr style="border-bottom:1px solid #f1f5f9;transition:background .15s" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background=''">
          <td style="padding:.875rem 1rem;font-weight:600;color:#0f172a"><?= e($r['employee_name']) ?></td>
          <td style="padding:.875rem 1rem"><span style="display:inline-flex;padding:2px 10px;border-radius:999px;font-size:.72rem;font-weight:600;background:#eef2ff;color:#6366f1"><?= e($r['department'] ?? '') ?></span></td>
          <td style="padding:.875rem 1rem;color:#374151"><?= formatDate($r['date'], 'M d, Y') ?></td>
          <td style="padding:.875rem 1rem;color:#374151"><?= $r['check_in'] ? date('h:i A', strtotime($r['check_in'])) : '<span style="color:#94a3b8">—</span>' ?></td>
          <td style="padding:.875rem 1rem;color:#374151"><?= $r['check_out'] ? date('h:i A', strtotime($r['check_out'])) : '<span style="color:#94a3b8">—</span>' ?></td>
          <td style="padding:.875rem 1rem;color:#374151"><?= ($r['hours_worked'] ?? 0) > 0 ? round($r['hours_worked'], 2) . 'h' : '<span style="color:#94a3b8">—</span>' ?></td>
          <td style="padding:.875rem 1rem"><?= ($r['overtime_hours'] ?? 0) > 0 ? '<span style="color:#f59e0b;font-weight:600">' . round($r['overtime_hours'], 2) . 'h</span>' : '<span style="color:#94a3b8">—</span>' ?></td>
          <td style="padding:.875rem 1rem"><?= statusBadge($r['status']) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
