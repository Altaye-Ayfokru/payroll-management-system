<?php
$payrollJson = json_encode(array_slice($payrolls ?? [], 0, 20));
$totalTax    = array_sum(array_column($payrolls ?? [], 'tax'));
$totalPF     = array_sum(array_column($payrolls ?? [], 'provident_fund'));
$totalIns    = array_sum(array_column($payrolls ?? [], 'insurance'));
$totalDed    = array_sum(array_column($payrolls ?? [], 'total_deductions'));
$totalGross  = array_sum(array_column($payrolls ?? [], 'gross_salary'));
$effRate     = $totalGross > 0 ? round(($totalTax / $totalGross) * 100, 2) : 0;
$monthLabel  = date('F Y', strtotime(($month ?? date('Y-m')) . '-01'));
?>

<style>
.rpt-nav{display:flex;gap:.5rem;margin-bottom:1.5rem;flex-wrap:wrap}
.rpt-nav a{display:inline-flex;align-items:center;gap:.5rem;padding:.5rem 1rem;border-radius:10px;font-size:.85rem;font-weight:600;text-decoration:none;transition:all .2s;border:1.5px solid #e2e8f0;color:#374151;background:#fff}
.rpt-nav a:hover{border-color:#6366f1;color:#6366f1;background:#eef2ff}
.rpt-nav a.active{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border-color:transparent;box-shadow:0 4px 12px rgba(99,102,241,.35)}
</style>

<div class="page-header">
  <div>
    <div class="page-header-title">Tax Report</div>
    <div class="page-header-sub"><?= $monthLabel ?></div>
  </div>
  <div class="page-header-actions">
    <form method="GET" style="display:flex;gap:8px;align-items:center">
      <input type="month" name="month" class="form-control" value="<?= e($month ?? date('Y-m')) ?>" style="width:auto">
      <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i></button>
    </form>
  </div>
</div>

<div class="rpt-nav">
  <a href="<?= url('reports') ?>"><i class="fas fa-th-large"></i> Overview</a>
  <a href="<?= url('reports/salary') ?>"><i class="fas fa-money-bill-wave"></i> Salary</a>
  <a href="<?= url('reports/attendance') ?>"><i class="fas fa-clock"></i> Attendance</a>
  <a href="<?= url('reports/tax') ?>" class="active"><i class="fas fa-receipt"></i> Tax</a>
</div>

<!-- KPI Row -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1.25rem;margin-bottom:1.5rem">
  <?php $kpis = [
    ['icon'=>'fa-receipt',    'color'=>'#f59e0b','bg'=>'#fffbeb','val'=>formatCurrency($totalTax), 'lbl'=>'Total Income Tax'],
    ['icon'=>'fa-piggy-bank', 'color'=>'#3b82f6','bg'=>'#eff6ff','val'=>formatCurrency($totalPF),  'lbl'=>'Provident Fund'],
    ['icon'=>'fa-shield-alt', 'color'=>'#8b5cf6','bg'=>'#f5f3ff','val'=>formatCurrency($totalIns), 'lbl'=>'Insurance'],
    ['icon'=>'fa-percent',    'color'=>'#ef4444','bg'=>'#fef2f2','val'=>$effRate.'%',               'lbl'=>'Effective Tax Rate'],
  ]; foreach ($kpis as $k): ?>
  <div style="background:#fff;border-radius:14px;padding:1.25rem;border:1px solid #e2e8f0;box-shadow:0 1px 3px rgba(0,0,0,.05)">
    <div style="width:42px;height:42px;border-radius:11px;background:<?= $k['bg'] ?>;color:<?= $k['color'] ?>;display:flex;align-items:center;justify-content:center;font-size:1.1rem;margin-bottom:.75rem">
      <i class="fas <?= $k['icon'] ?>"></i>
    </div>
    <div style="font-size:1.4rem;font-weight:800;color:#0f172a;line-height:1;letter-spacing:-.02em"><?= $k['val'] ?></div>
    <div style="font-size:.78rem;color:#64748b;margin-top:4px;font-weight:500"><?= $k['lbl'] ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Horizontal Bar Chart -->
<?php if (!empty($payrolls)): ?>
<div style="background:#fff;border-radius:16px;border:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(0,0,0,.06);margin-bottom:1.5rem;overflow:hidden">
  <div style="display:flex;align-items:center;justify-content:space-between;padding:1.125rem 1.5rem;border-bottom:1px solid #f1f5f9">
    <div style="font-size:.95rem;font-weight:700;color:#0f172a;display:flex;align-items:center;gap:.5rem">
      <div style="width:28px;height:28px;border-radius:8px;background:linear-gradient(135deg,#f59e0b,#f97316);display:flex;align-items:center;justify-content:center;font-size:.8rem;color:#fff"><i class="fas fa-chart-bar"></i></div>
      Tax &amp; Deductions by Employee
    </div>
    <span style="font-size:.75rem;color:#94a3b8"><?= $monthLabel ?></span>
  </div>
  <div style="padding:1.25rem 1.5rem">
    <div style="position:relative;height:<?= min(400, max(200, count($payrolls) * 40)) ?>px">
      <canvas id="taxReportChart" data-payrolls='<?= htmlspecialchars($payrollJson, ENT_QUOTES) ?>'></canvas>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Table -->
<div style="background:#fff;border-radius:16px;border:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(0,0,0,.06);overflow:hidden">
  <div style="overflow-x:auto">
    <table style="width:100%;border-collapse:collapse;font-size:.875rem">
      <thead>
        <tr style="background:#f8fafc">
          <?php foreach (['Employee','Dept','Gross Salary','Income Tax','Tax Rate','Provident Fund','Insurance','Other','Total Deductions','Net Salary'] as $h): ?>
          <th style="padding:.75rem 1rem;text-align:<?= in_array($h,['Employee','Dept'])?'left':'right' ?>;font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#94a3b8;border-bottom:2px solid #e2e8f0;white-space:nowrap"><?= $h ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($payrolls)): ?>
        <tr><td colspan="10" style="text-align:center;padding:3rem;color:#94a3b8">
          <i class="fas fa-receipt" style="font-size:2rem;display:block;margin-bottom:.5rem;opacity:.4"></i>
          No tax data for <?= e($monthLabel) ?>
        </td></tr>
        <?php else: ?>
        <?php foreach ($payrolls as $p):
          $rate = (float)$p['gross_salary'] > 0 ? round(((float)$p['tax'] / (float)$p['gross_salary']) * 100, 1) : 0;
        ?>
        <tr style="border-bottom:1px solid #f1f5f9;transition:background .15s" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background=''">
          <td style="padding:.875rem 1rem;font-weight:600;color:#0f172a"><?= e($p['employee_name']) ?></td>
          <td style="padding:.875rem 1rem"><span style="display:inline-flex;padding:2px 10px;border-radius:999px;font-size:.72rem;font-weight:600;background:#eef2ff;color:#6366f1"><?= e($p['department']) ?></span></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#374151"><?= formatCurrency((float)$p['gross_salary']) ?></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#f59e0b;font-weight:700"><?= formatCurrency((float)$p['tax']) ?></td>
          <td style="padding:.875rem 1rem;text-align:right"><span style="display:inline-flex;padding:2px 8px;border-radius:999px;font-size:.72rem;font-weight:700;background:#fef3c7;color:#d97706"><?= $rate ?>%</span></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#3b82f6"><?= formatCurrency((float)$p['provident_fund']) ?></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#8b5cf6"><?= formatCurrency((float)$p['insurance']) ?></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#64748b"><?= formatCurrency((float)$p['other_deductions']) ?></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#ef4444;font-weight:700"><?= formatCurrency((float)$p['total_deductions']) ?></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#10b981;font-weight:800"><?= formatCurrency((float)$p['net_salary']) ?></td>
        </tr>
        <?php endforeach; ?>
        <!-- Totals -->
        <tr style="background:#f8fafc;font-weight:700;border-top:2px solid #e2e8f0">
          <td colspan="2" style="padding:.875rem 1rem;text-align:right;font-size:.82rem;color:#64748b;text-transform:uppercase;letter-spacing:.04em">Totals</td>
          <td style="padding:.875rem 1rem;text-align:right;color:#0f172a"><?= formatCurrency($totalGross) ?></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#f59e0b"><?= formatCurrency($totalTax) ?></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#d97706"><?= $effRate ?>%</td>
          <td style="padding:.875rem 1rem;text-align:right;color:#3b82f6"><?= formatCurrency($totalPF) ?></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#8b5cf6"><?= formatCurrency($totalIns) ?></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#64748b"><?= formatCurrency(array_sum(array_column($payrolls,'other_deductions'))) ?></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#ef4444"><?= formatCurrency($totalDed) ?></td>
          <td style="padding:.875rem 1rem;text-align:right;color:#10b981;font-size:1rem"><?= formatCurrency(array_sum(array_column($payrolls,'net_salary'))) ?></td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
