<?php
require_once CORE_PATH . '/Controller.php';
require_once APP_PATH . '/modules/Payroll/PayrollModel.php';
require_once APP_PATH . '/modules/Attendance/AttendanceModel.php';
require_once APP_PATH . '/modules/Employee/EmployeeModel.php';

class ReportController extends Controller {
    public function index(): void {
        $this->requireRole('admin', 'hr');
        $db    = Database::getInstance();
        $month = $_GET['month'] ?? date('Y-m');

        $deptSalary = $db->query(
            "SELECT e.department,
                    COUNT(*) AS emp_count,
                    SUM(e.basic_salary) AS total_salary
             FROM employees e
             WHERE e.status='active' AND e.deleted_at IS NULL
             GROUP BY e.department ORDER BY total_salary DESC"
        )->fetchAll();

        $trend = (new PayrollModel())->getMonthlyTrend(12);

        $this->view('reports.index', [
            'deptSalary' => $deptSalary,
            'trend'      => $trend,
            'month'      => $month,
            'pageTitle'  => 'Reports & Analytics',
        ]);
    }

    public function salary(): void {
        $this->requireRole('admin', 'hr');
        $month = $_GET['month'] ?? date('Y-m');
        $this->view('reports.salary', [
            'payrolls'  => (new PayrollModel())->getByMonth($month),
            'month'     => $month,
            'pageTitle' => 'Salary Report',
        ]);
    }

    public function attendance(): void {
        $this->requireRole('admin', 'hr');
        $month = $_GET['month'] ?? date('Y-m');
        $this->view('reports.attendance', [
            'records'   => (new AttendanceModel())->getAllWithEmployees(null, 500, 0),
            'month'     => $month,
            'pageTitle' => 'Attendance Report',
        ]);
    }

    public function tax(): void {
        $this->requireRole('admin', 'hr');
        $month = $_GET['month'] ?? date('Y-m');
        $this->view('reports.tax', [
            'payrolls'  => (new PayrollModel())->getByMonth($month),
            'month'     => $month,
            'pageTitle' => 'Tax Report',
        ]);
    }

    public function export(): void {
        $this->requireRole('admin', 'hr');
        $type  = $_GET['type']  ?? 'salary';
        $month = $_GET['month'] ?? date('Y-m');

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $type . '_' . $month . '.csv"');
        $out = fopen('php://output', 'w');

        if ($type === 'salary') {
            $rows = (new PayrollModel())->getByMonth($month);
            fputcsv($out, ['Employee','Dept','Basic','Gross','Deductions','Tax','Net','Status']);
            foreach ($rows as $r) {
                fputcsv($out, [$r['employee_name'],$r['department'],$r['basic_salary'],
                    $r['gross_salary'],$r['total_deductions'],$r['tax'],$r['net_salary'],$r['status']]);
            }
        } elseif ($type === 'attendance') {
            $rows = (new AttendanceModel())->getAllWithEmployees(null, 1000, 0);
            fputcsv($out, ['Employee','Date','Check In','Check Out','Hours','Overtime','Status']);
            foreach ($rows as $r) {
                fputcsv($out, [$r['employee_name'],$r['date'],$r['check_in'],
                    $r['check_out'],$r['hours_worked'],$r['overtime_hours'],$r['status']]);
            }
        }

        fclose($out);
        exit;
    }
}
