﻿<?php
/**
 * PayrollPro — Dashboard View
 * Premium HR & Payroll Management System
 */

// Safe defaults for all variables
$totalEmployees   = $totalEmployees   ?? 0;
$totalPayroll     = $totalPayroll     ?? 0.0;
$pendingApprovals = $pendingApprovals ?? 0;
$todayAttendance  = $todayAttendance  ?? ['total'=>0,'present'=>0,'absent'=>0,'late'=>0];
$payrollTrend     = $payrollTrend     ?? [];
$deptBreakdown    = $deptBreakdown    ?? [];
$upcomingLeaves   = $upcomingLeaves   ?? [];
$recentPayroll    = $recentPayroll    ?? [];
$activityLog      = $activityLog      ?? [];
$currentMonth     = $currentMonth     ?? date('Y-m');

$userName  = $_SESSION['user_name'] ?? 'User';
$userRole  = $_SESSION['user_role'] ?? 'employee';
$hour      = (int)date('H');
$greeting  = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
$greetIcon = $hour < 12 ? '&#127749;' : ($hour < 17 ? '&#9728;' : '&#127769;');

$attTotal   = max(1, (int)($todayAttendance['total']   ?? 0));
$attPresent = (int)($todayAttendance['present'] ?? 0);
$attAbsent  = (int)($todayAttendance['absent']  ?? 0);
$attLate    = (int)($todayAttendance['late']    ?? 0);
$attPct     = round(($attPresent / $attTotal) * 100);

// Payroll trend JSON for Chart.js
$trendLabels = [];
$trendValues = [];
foreach ($payrollTrend as $t) {
    $trendLabels[] = date('M Y', strtotime((is_object($t) ? $t->pay_month : $t['pay_month']) . '-01'));
    $trendValues[] = (float)(is_object($t) ? $t->total : $t['total']);
}

// Dept breakdown JSON for Chart.js
$deptLabels = [];
$deptValues = [];
$deptColors = ['#6366f1','#8b5cf6','#10b981','#f59e0b','#ef4444','#3b82f6','#ec4899','#14b8a6','#f97316'];
foreach ($deptBreakdown as $d) {
    $deptLabels[] = is_object($d) ? $d->department : $d['department'];
    $deptValues[] = (float)(is_object($d) ? $d->total_net : $d['total_net']);
}

$trendLabelsJson = json_encode($trendLabels);
$trendValuesJson = json_encode($trendValues);
$deptLabelsJson  = json_encode($deptLabels);
$deptValuesJson  = json_encode($deptValues);
$deptColorsJson  = json_encode(array_slice($deptColors, 0, count($deptLabels)));
?>

<style>
/* ============================================================
   DASHBOARD PAGE — Inline Styles
   ============================================================ */

/* ── Welcome Banner ── */
.db-welcome {
    position: relative;
    border-radius: 20px;
    overflow: hidden;
    padding: 2.25rem 2.5rem;
    margin-bottom: 1.75rem;
    background: linear-gradient(135deg, #4f46e5 0%, #6366f1 30%, #8b5cf6 65%, #a855f7 100%);
    background-size: 300% 300%;
    animation: gradientShift 8s ease infinite, fadeInUp 0.5s ease forwards;
    box-shadow: 0 8px 32px rgba(99,102,241,0.4);
    color: #fff;
}
.db-welcome::before {
    content: '';
    position: absolute;
    inset: 0;
    background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Ccircle cx='30' cy='30' r='20'/%3E%3Ccircle cx='0' cy='0' r='10'/%3E%3Ccircle cx='60' cy='60' r='10'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
    pointer-events: none;
}
.db-welcome-wave {
    position: absolute;
    bottom: 0; right: 0;
    width: 340px; height: 100%;
    opacity: 0.12;
    pointer-events: none;
}
.db-welcome-content { position: relative; z-index: 1; }
.db-welcome-greeting {
    font-size: 0.85rem;
    font-weight: 600;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    opacity: 0.85;
    margin-bottom: 0.35rem;
}
.db-welcome-name {
    font-size: 2rem;
    font-weight: 800;
    line-height: 1.2;
    margin-bottom: 0.5rem;
    letter-spacing: -0.02em;
}
.db-welcome-sub {
    font-size: 0.9rem;
    opacity: 0.8;
    font-weight: 400;
    max-width: 480px;
    line-height: 1.6;
}
.db-welcome-meta {
    display: flex;
    align-items: center;
    gap: 1.25rem;
    margin-top: 1.25rem;
    flex-wrap: wrap;
}
.db-welcome-pill {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.375rem 0.875rem;
    border-radius: 999px;
    background: rgba(255,255,255,0.18);
    backdrop-filter: blur(8px);
    border: 1px solid rgba(255,255,255,0.25);
    font-size: 0.8rem;
    font-weight: 600;
    color: #fff;
    transition: all 0.2s;
}
.db-welcome-pill:hover {
    background: rgba(255,255,255,0.28);
    transform: translateY(-1px);
}
.db-welcome-stats {
    display: flex;
    gap: 2rem;
    margin-top: 1.5rem;
}
.db-welcome-stat-item { text-align: left; }
.db-welcome-stat-num {
    font-size: 1.6rem;
    font-weight: 800;
    line-height: 1;
    display: block;
}
.db-welcome-stat-lbl {
    font-size: 0.72rem;
    opacity: 0.75;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    margin-top: 2px;
    display: block;
}
.db-welcome-badge {
    position: absolute;
    top: 1.5rem; right: 1.75rem;
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    padding: 0.4rem 1rem;
    border-radius: 999px;
    background: rgba(255,255,255,0.2);
    border: 1px solid rgba(255,255,255,0.3);
    font-size: 0.78rem;
    font-weight: 700;
    color: #fff;
    backdrop-filter: blur(8px);
}
.db-welcome-badge .dot {
    width: 7px; height: 7px;
    border-radius: 50%;
    background: #4ade80;
    animation: pulseDot 2s ease-in-out infinite;
}

/* ── Quick Actions ── */
.db-quick-actions {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
    gap: 1rem;
    margin-bottom: 1.75rem;
    animation: fadeInUp 0.5s ease 0.1s both;
}
.db-qa-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 0.75rem;
    padding: 1.25rem 0.75rem;
    border-radius: 16px;
    background: #fff;
    border: 1px solid #e2e8f0;
    text-decoration: none;
    color: #1e293b;
    transition: all 0.25s cubic-bezier(0.34,1.56,0.64,1);
    cursor: pointer;
    position: relative;
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06);
}
.db-qa-card::before {
    content: '';
    position: absolute;
    inset: 0;
    opacity: 0;
    transition: opacity 0.25s;
    border-radius: 16px;
}
.db-qa-card:hover {
    transform: translateY(-5px) scale(1.03);
    box-shadow: 0 12px 28px rgba(0,0,0,0.12);
    border-color: transparent;
}
.db-qa-card:hover::before { opacity: 1; }
.db-qa-icon {
    width: 52px; height: 52px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.35rem;
    color: #fff;
    transition: all 0.25s cubic-bezier(0.34,1.56,0.64,1);
    position: relative;
    z-index: 1;
}
.db-qa-card:hover .db-qa-icon { transform: scale(1.15) rotate(-5deg); }
.db-qa-label {
    font-size: 0.78rem;
    font-weight: 600;
    text-align: center;
    line-height: 1.3;
    color: #374151;
    position: relative;
    z-index: 1;
}
/* Quick action color variants */
.qa-indigo .db-qa-icon  { background: linear-gradient(135deg,#6366f1,#4f46e5); box-shadow: 0 4px 14px rgba(99,102,241,0.4); }
.qa-indigo:hover        { background: linear-gradient(135deg,#eef2ff,#f5f3ff); }
.qa-purple .db-qa-icon  { background: linear-gradient(135deg,#8b5cf6,#7c3aed); box-shadow: 0 4px 14px rgba(139,92,246,0.4); }
.qa-purple:hover        { background: linear-gradient(135deg,#f5f3ff,#fdf4ff); }
.qa-emerald .db-qa-icon { background: linear-gradient(135deg,#10b981,#059669); box-shadow: 0 4px 14px rgba(16,185,129,0.4); }
.qa-emerald:hover       { background: linear-gradient(135deg,#ecfdf5,#f0fdf4); }
.qa-amber .db-qa-icon   { background: linear-gradient(135deg,#f59e0b,#d97706); box-shadow: 0 4px 14px rgba(245,158,11,0.4); }
.qa-amber:hover         { background: linear-gradient(135deg,#fffbeb,#fefce8); }
.qa-blue .db-qa-icon    { background: linear-gradient(135deg,#3b82f6,#2563eb); box-shadow: 0 4px 14px rgba(59,130,246,0.4); }
.qa-blue:hover          { background: linear-gradient(135deg,#eff6ff,#f0f9ff); }
.qa-pink .db-qa-icon    { background: linear-gradient(135deg,#ec4899,#db2777); box-shadow: 0 4px 14px rgba(236,72,153,0.4); }
.qa-pink:hover          { background: linear-gradient(135deg,#fdf2f8,#fce7f3); }
.qa-teal .db-qa-icon    { background: linear-gradient(135deg,#14b8a6,#0d9488); box-shadow: 0 4px 14px rgba(20,184,166,0.4); }
.qa-teal:hover          { background: linear-gradient(135deg,#f0fdfa,#ecfdf5); }
.qa-orange .db-qa-icon  { background: linear-gradient(135deg,#f97316,#ea580c); box-shadow: 0 4px 14px rgba(249,115,22,0.4); }
.qa-orange:hover        { background: linear-gradient(135deg,#fff7ed,#ffedd5); }

/* ── KPI Stat Cards ── */
.db-kpi-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1.25rem;
    margin-bottom: 1.75rem;
    animation: fadeInUp 0.5s ease 0.15s both;
}
.db-stat-card {
    background: #fff;
    border-radius: 16px;
    padding: 1.5rem;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06);
    position: relative;
    overflow: hidden;
    transition: all 0.25s ease;
    display: flex;
    flex-direction: column;
    gap: 0.875rem;
}
.db-stat-card::before {
    content: '';
    position: absolute;
    left: 0; top: 0; bottom: 0;
    width: 4px;
    border-radius: 4px 0 0 4px;
}
.db-stat-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 24px rgba(0,0,0,0.1);
}
.db-stat-card.stat-blue::before   { background: linear-gradient(180deg,#3b82f6,#6366f1); }
.db-stat-card.stat-green::before  { background: linear-gradient(180deg,#10b981,#059669); }
.db-stat-card.stat-amber::before  { background: linear-gradient(180deg,#f59e0b,#f97316); }
.db-stat-card.stat-teal::before   { background: linear-gradient(180deg,#14b8a6,#10b981); }
.db-stat-top {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
}
.db-stat-icon {
    width: 48px; height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    color: #fff;
    flex-shrink: 0;
}
.stat-blue  .db-stat-icon { background: linear-gradient(135deg,#3b82f6,#6366f1); box-shadow: 0 4px 12px rgba(59,130,246,0.35); }
.stat-green .db-stat-icon { background: linear-gradient(135deg,#10b981,#059669); box-shadow: 0 4px 12px rgba(16,185,129,0.35); }
.stat-amber .db-stat-icon { background: linear-gradient(135deg,#f59e0b,#f97316); box-shadow: 0 4px 12px rgba(245,158,11,0.35); }
.stat-teal  .db-stat-icon { background: linear-gradient(135deg,#14b8a6,#10b981); box-shadow: 0 4px 12px rgba(20,184,166,0.35); }
.db-stat-trend {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    padding: 3px 8px;
    border-radius: 999px;
    font-size: 0.72rem;
    font-weight: 700;
}
.trend-up   { background: #dcfce7; color: #16a34a; }
.trend-down { background: #fee2e2; color: #dc2626; }
.trend-neu  { background: #f1f5f9; color: #64748b; }
.db-stat-num {
    font-size: 2rem;
    font-weight: 800;
    color: #0f172a;
    line-height: 1;
    letter-spacing: -0.03em;
}
.db-stat-label {
    font-size: 0.82rem;
    color: #64748b;
    font-weight: 500;
    margin-top: 2px;
}
.db-stat-progress {
    height: 6px;
    background: #f1f5f9;
    border-radius: 999px;
    overflow: hidden;
    margin-top: 0.25rem;
}
.db-stat-progress-bar {
    height: 100%;
    border-radius: 999px;
    animation: progressFill 1.2s ease 0.5s both;
    --progress-value: 0%;
    width: var(--progress-value);
}
.stat-teal .db-stat-progress-bar { background: linear-gradient(90deg,#14b8a6,#10b981); }
.db-stat-sub {
    font-size: 0.72rem;
    color: #94a3b8;
    margin-top: 2px;
}

/* ── Charts Row ── */
.db-charts-row {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 1.25rem;
    margin-bottom: 1.75rem;
    animation: fadeInUp 0.5s ease 0.2s both;
}
.db-card {
    background: #fff;
    border-radius: 16px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06);
    overflow: hidden;
    transition: box-shadow 0.25s;
}
.db-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,0.08); }
.db-card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid #f1f5f9;
}
.db-card-title {
    font-size: 0.95rem;
    font-weight: 700;
    color: #0f172a;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}
.db-card-title-icon {
    width: 28px; height: 28px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.8rem;
    color: #fff;
}
.db-card-badge {
    font-size: 0.72rem;
    font-weight: 600;
    padding: 3px 10px;
    border-radius: 999px;
    background: #f1f5f9;
    color: #64748b;
}
.db-card-body { padding: 1.25rem 1.5rem; }
.db-chart-wrap { position: relative; height: 240px; }

/* ── Bottom Row ── */
.db-bottom-row {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 1.25rem;
    margin-bottom: 1.75rem;
    animation: fadeInUp 0.5s ease 0.25s both;
}

/* ── Table ── */
.db-table { width: 100%; border-collapse: collapse; }
.db-table thead th {
    padding: 0.625rem 1rem;
    font-size: 0.72rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    color: #94a3b8;
    background: #f8fafc;
    border-bottom: 1px solid #e2e8f0;
    white-space: nowrap;
    text-align: left;
}
.db-table tbody tr {
    border-bottom: 1px solid #f1f5f9;
    transition: background 0.15s;
}
.db-table tbody tr:last-child { border-bottom: none; }
.db-table tbody tr:hover { background: #f8fafc; }
.db-table td {
    padding: 0.875rem 1rem;
    font-size: 0.85rem;
    color: #374151;
    vertical-align: middle;
}
.db-emp-cell { display: flex; align-items: center; gap: 0.75rem; }
.db-emp-avatar {
    width: 34px; height: 34px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.8rem;
    font-weight: 700;
    color: #fff;
    flex-shrink: 0;
    background: linear-gradient(135deg,#6366f1,#8b5cf6);
}
.db-emp-name { font-weight: 600; color: #0f172a; font-size: 0.875rem; }
.db-emp-id   { font-size: 0.72rem; color: #94a3b8; }
.db-dept-badge {
    display: inline-flex;
    align-items: center;
    padding: 2px 10px;
    border-radius: 999px;
    font-size: 0.72rem;
    font-weight: 600;
    background: #eef2ff;
    color: #6366f1;
}
.db-salary { font-weight: 700; color: #0f172a; font-size: 0.9rem; }

/* ── Attendance Mini Stats ── */
.db-att-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 0.75rem;
    margin-bottom: 1rem;
}
.db-att-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 0.875rem 0.5rem;
    border-radius: 12px;
    text-align: center;
    transition: transform 0.2s;
}
.db-att-item:hover { transform: translateY(-2px); }
.db-att-circle {
    width: 48px; height: 48px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.1rem;
    font-weight: 800;
    margin-bottom: 0.4rem;
    color: #fff;
}
.att-present .db-att-circle { background: linear-gradient(135deg,#10b981,#059669); box-shadow: 0 4px 10px rgba(16,185,129,0.35); }
.att-absent  .db-att-circle { background: linear-gradient(135deg,#ef4444,#dc2626); box-shadow: 0 4px 10px rgba(239,68,68,0.35); }
.att-late    .db-att-circle { background: linear-gradient(135deg,#f59e0b,#d97706); box-shadow: 0 4px 10px rgba(245,158,11,0.35); }
.att-present { background: #ecfdf5; }
.att-absent  { background: #fef2f2; }
.att-late    { background: #fffbeb; }
.db-att-lbl { font-size: 0.72rem; font-weight: 600; color: #64748b; }
.db-att-bar-wrap {
    background: #f1f5f9;
    border-radius: 999px;
    height: 8px;
    overflow: hidden;
    margin-bottom: 0.5rem;
}
.db-att-bar {
    height: 100%;
    border-radius: 999px;
    background: linear-gradient(90deg,#10b981,#14b8a6);
    animation: progressFill 1.2s ease 0.6s both;
    --progress-value: 0%;
    width: var(--progress-value);
}
.db-att-pct-row {
    display: flex;
    justify-content: space-between;
    font-size: 0.72rem;
    color: #94a3b8;
    margin-bottom: 1rem;
}

/* ── Leave List ── */
.db-leave-list { display: flex; flex-direction: column; gap: 0.625rem; }
.db-leave-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem 1rem;
    border-radius: 10px;
    background: #f8fafc;
    border-left: 3px solid #e2e8f0;
    transition: all 0.2s;
}
.db-leave-item:hover { background: #f1f5f9; transform: translateX(3px); }
.db-leave-item.leave-annual    { border-left-color: #6366f1; }
.db-leave-item.leave-sick      { border-left-color: #ef4444; }
.db-leave-item.leave-casual    { border-left-color: #f59e0b; }
.db-leave-item.leave-maternity { border-left-color: #ec4899; }
.db-leave-item.leave-other     { border-left-color: #14b8a6; }
.db-leave-avatar {
    width: 30px; height: 30px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.7rem;
    font-weight: 700;
    color: #fff;
    flex-shrink: 0;
    background: linear-gradient(135deg,#8b5cf6,#6366f1);
}
.db-leave-name  { font-size: 0.82rem; font-weight: 600; color: #0f172a; }
.db-leave-date  { font-size: 0.72rem; color: #94a3b8; }
.db-leave-type-badge {
    margin-left: auto;
    font-size: 0.68rem;
    font-weight: 700;
    padding: 2px 8px;
    border-radius: 999px;
    white-space: nowrap;
    flex-shrink: 0;
}
.badge-annual    { background: #eef2ff; color: #6366f1; }
.badge-sick      { background: #fee2e2; color: #ef4444; }
.badge-casual    { background: #fef3c7; color: #d97706; }
.badge-maternity { background: #fce7f3; color: #db2777; }
.badge-other     { background: #f0fdfa; color: #0d9488; }

/* ── Activity Timeline ── */
.db-activity {
    animation: fadeInUp 0.5s ease 0.3s both;
}
.db-timeline { position: relative; padding-left: 1.5rem; }
.db-timeline::before {
    content: '';
    position: absolute;
    left: 7px; top: 8px; bottom: 8px;
    width: 2px;
    background: linear-gradient(180deg,#6366f1,#8b5cf6,#10b981,transparent);
    border-radius: 2px;
}
.db-tl-item {
    position: relative;
    padding: 0 0 1rem 1.25rem;
    animation: slideInLeft 0.4s ease both;
}
.db-tl-item:last-child { padding-bottom: 0; }
.db-tl-dot {
    position: absolute;
    left: -1.5rem;
    top: 4px;
    width: 14px; height: 14px;
    border-radius: 50%;
    border: 2px solid #fff;
    box-shadow: 0 0 0 2px currentColor;
    flex-shrink: 0;
}
.db-tl-dot.dot-indigo { color: #6366f1; background: #6366f1; }
.db-tl-dot.dot-green  { color: #10b981; background: #10b981; }
.db-tl-dot.dot-amber  { color: #f59e0b; background: #f59e0b; }
.db-tl-dot.dot-red    { color: #ef4444; background: #ef4444; }
.db-tl-dot.dot-blue   { color: #3b82f6; background: #3b82f6; }
.db-tl-dot.dot-purple { color: #8b5cf6; background: #8b5cf6; }
.db-tl-dot.dot-teal   { color: #14b8a6; background: #14b8a6; }
.db-tl-name  { font-size: 0.85rem; font-weight: 600; color: #0f172a; }
.db-tl-action { font-size: 0.82rem; color: #64748b; margin-top: 1px; }
.db-tl-time  { font-size: 0.72rem; color: #94a3b8; margin-top: 2px; }

/* ── Section Header ── */
.db-section-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1rem;
}
.db-section-title {
    font-size: 1rem;
    font-weight: 700;
    color: #0f172a;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}
.db-section-title-dot {
    width: 8px; height: 8px;
    border-radius: 50%;
    background: linear-gradient(135deg,#6366f1,#8b5cf6);
}
.db-view-all {
    font-size: 0.8rem;
    font-weight: 600;
    color: #6366f1;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 0.3rem;
    transition: all 0.2s;
}
.db-view-all:hover { color: #4f46e5; gap: 0.5rem; }

/* ── Right column stacked ── */
.db-right-col { display: flex; flex-direction: column; gap: 1.25rem; }

/* ── Empty state ── */
.db-empty {
    text-align: center;
    padding: 2rem 1rem;
    color: #94a3b8;
}
.db-empty i { font-size: 2rem; margin-bottom: 0.5rem; display: block; opacity: 0.5; }
.db-empty p { font-size: 0.85rem; }

/* ── Responsive ── */
@media (max-width: 1200px) {
    .db-kpi-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 900px) {
    .db-charts-row, .db-bottom-row { grid-template-columns: 1fr; }
    .db-welcome-stats { gap: 1.25rem; }
    .db-welcome-name  { font-size: 1.5rem; }
    .db-welcome-badge { display: none; }
}
@media (max-width: 640px) {
    .db-kpi-grid { grid-template-columns: 1fr 1fr; }
    .db-quick-actions { grid-template-columns: repeat(3, 1fr); }
    .db-welcome { padding: 1.5rem; }
}
@media (max-width: 400px) {
    .db-kpi-grid { grid-template-columns: 1fr; }
    .db-quick-actions { grid-template-columns: repeat(2, 1fr); }
}
</style>

<!-- ═══════════════════════════════════════════════════════════
     WELCOME BANNER
═══════════════════════════════════════════════════════════ -->
<div class="db-welcome">
    <!-- Decorative SVG wave -->
    <svg class="db-welcome-wave" viewBox="0 0 400 200" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
        <defs>
            <linearGradient id="wg" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#fff;stop-opacity:0.15"/>
                <stop offset="100%" style="stop-color:#fff;stop-opacity:0.03"/>
            </linearGradient>
        </defs>
        <ellipse cx="320" cy="100" rx="200" ry="180" fill="url(#wg)"/>
        <ellipse cx="380" cy="40"  rx="120" ry="100" fill="url(#wg)"/>
        <circle  cx="60"  cy="160" r="80"             fill="url(#wg)"/>
        <circle  cx="200" cy="20"  r="50"             fill="url(#wg)"/>
    </svg>

    <div class="db-welcome-badge">
        <span class="dot"></span>
        <?= date('l, F j, Y') ?>
    </div>

    <div class="db-welcome-content">
        <div class="db-welcome-greeting">
            <?= $greetIcon ?> &nbsp;<?= $greeting ?>
        </div>
        <div class="db-welcome-name">
            <?= e($userName) ?> <span style="opacity:.7">&#128075;</span>
        </div>
        <div class="db-welcome-sub">
            <?php if (isAdmin()): ?>
                You have full administrative access. <?= $pendingApprovals > 0 ? '<strong style="color:#fde68a">' . $pendingApprovals . ' item' . ($pendingApprovals > 1 ? 's' : '') . ' awaiting your approval.</strong>' : 'Everything looks great today.' ?>
            <?php elseif (isHR()): ?>
                Welcome back to your HR dashboard. <?= $pendingApprovals > 0 ? '<strong style="color:#fde68a">' . $pendingApprovals . ' approval' . ($pendingApprovals > 1 ? 's' : '') . ' pending.</strong>' : 'No pending approvals today.' ?>
            <?php else: ?>
                Welcome to your personal workspace. Track your attendance, leaves, and payslips here.
            <?php endif; ?>
        </div>

        <div class="db-welcome-meta">
            <span class="db-welcome-pill">
                <i class="fas fa-calendar-alt"></i>
                <?= date('F Y') ?> Payroll Period
            </span>
            <span class="db-welcome-pill">
                <i class="fas fa-user-shield"></i>
                <?= ucfirst(e($userRole)) ?> Access
            </span>
            <?php if (isHR()): ?>
            <span class="db-welcome-pill">
                <i class="fas fa-users"></i>
                <?= number_format($totalEmployees) ?> Active Employees
            </span>
            <?php endif; ?>
        </div>

        <?php if (isHR()): ?>
        <div class="db-welcome-stats">
            <div class="db-welcome-stat-item">
                <span class="db-welcome-stat-num" id="wStatEmp"><?= number_format($totalEmployees) ?></span>
                <span class="db-welcome-stat-lbl">Employees</span>
            </div>
            <div class="db-welcome-stat-item">
                <span class="db-welcome-stat-num"><?= formatCurrency((float)$totalPayroll) ?></span>
                <span class="db-welcome-stat-lbl">This Month Payroll</span>
            </div>
            <div class="db-welcome-stat-item">
                <span class="db-welcome-stat-num"><?= $attPct ?>%</span>
                <span class="db-welcome-stat-lbl">Present Today</span>
            </div>
            <div class="db-welcome-stat-item">
                <span class="db-welcome-stat-num"><?= number_format($pendingApprovals) ?></span>
                <span class="db-welcome-stat-lbl">Pending</span>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════════
     QUICK ACTIONS
═══════════════════════════════════════════════════════════ -->
<?php if (isHR()): ?>
<div class="db-quick-actions">
    <a href="<?= url('employees/create') ?>" class="db-qa-card qa-indigo">
        <div class="db-qa-icon"><i class="fas fa-user-plus"></i></div>
        <span class="db-qa-label">Add Employee</span>
    </a>
    <a href="<?= url('payroll/run') ?>" class="db-qa-card qa-emerald">
        <div class="db-qa-icon"><i class="fas fa-money-bill-wave"></i></div>
        <span class="db-qa-label">Run Payroll</span>
    </a>
    <a href="<?= url('attendance') ?>" class="db-qa-card qa-blue">
        <div class="db-qa-icon"><i class="fas fa-clock"></i></div>
        <span class="db-qa-label">Attendance</span>
    </a>
    <a href="<?= url('leaves/approvals') ?>" class="db-qa-card qa-amber">
        <div class="db-qa-icon"><i class="fas fa-calendar-check"></i></div>
        <span class="db-qa-label">Leave Approvals</span>
    </a>
    <a href="<?= url('reports') ?>" class="db-qa-card qa-purple">
        <div class="db-qa-icon"><i class="fas fa-chart-bar"></i></div>
        <span class="db-qa-label">Reports</span>
    </a>
    <a href="<?= url('settings') ?>" class="db-qa-card qa-teal">
        <div class="db-qa-icon"><i class="fas fa-cog"></i></div>
        <span class="db-qa-label">Settings</span>
    </a>
</div>
<?php else: ?>
<div class="db-quick-actions">
    <a href="<?= url('attendance') ?>" class="db-qa-card qa-emerald">
        <div class="db-qa-icon"><i class="fas fa-fingerprint"></i></div>
        <span class="db-qa-label">Check In / Out</span>
    </a>
    <a href="<?= url('leaves/request') ?>" class="db-qa-card qa-amber">
        <div class="db-qa-icon"><i class="fas fa-calendar-plus"></i></div>
        <span class="db-qa-label">Apply Leave</span>
    </a>
    <a href="<?= url('payroll/history') ?>" class="db-qa-card qa-indigo">
        <div class="db-qa-icon"><i class="fas fa-file-invoice-dollar"></i></div>
        <span class="db-qa-label">My Payslips</span>
    </a>
    <a href="<?= url('profile') ?>" class="db-qa-card qa-purple">
        <div class="db-qa-icon"><i class="fas fa-user-circle"></i></div>
        <span class="db-qa-label">My Profile</span>
    </a>
    <a href="<?= url('leaves') ?>" class="db-qa-card qa-blue">
        <div class="db-qa-icon"><i class="fas fa-umbrella-beach"></i></div>
        <span class="db-qa-label">My Leaves</span>
    </a>
</div>
<?php endif; ?>

<!-- ═══════════════════════════════════════════════════════════
     KPI STAT CARDS
═══════════════════════════════════════════════════════════ -->
<div class="db-kpi-grid">

    <!-- Total Employees -->
    <div class="db-stat-card stat-blue">
        <div class="db-stat-top">
            <div class="db-stat-icon"><i class="fas fa-users"></i></div>
            <span class="db-stat-trend trend-up"><i class="fas fa-arrow-up"></i> Active</span>
        </div>
        <div>
            <div class="db-stat-num" data-count="<?= (int)$totalEmployees ?>" id="countEmp">0</div>
            <div class="db-stat-label">Total Employees</div>
        </div>
        <div class="db-stat-sub"><i class="fas fa-circle" style="color:#10b981;font-size:.5rem"></i> &nbsp;All active staff members</div>
    </div>

    <!-- Total Payroll -->
    <div class="db-stat-card stat-green">
        <div class="db-stat-top">
            <div class="db-stat-icon"><i class="fas fa-money-bill-wave"></i></div>
            <span class="db-stat-trend trend-up"><i class="fas fa-arrow-up"></i> <?= date('M') ?></span>
        </div>
        <div>
            <div class="db-stat-num" style="font-size:1.5rem"><?= formatCurrency((float)$totalPayroll) ?></div>
            <div class="db-stat-label">Total Payroll</div>
        </div>
        <div class="db-stat-sub"><i class="fas fa-calendar" style="color:#6366f1;font-size:.65rem"></i> &nbsp;<?= date('F Y', strtotime($currentMonth . '-01')) ?></div>
    </div>

    <!-- Pending Approvals -->
    <div class="db-stat-card stat-amber">
        <div class="db-stat-top">
            <div class="db-stat-icon"><i class="fas fa-hourglass-half"></i></div>
            <?php if ($pendingApprovals > 0): ?>
            <span class="db-stat-trend trend-down"><i class="fas fa-exclamation"></i> Action</span>
            <?php else: ?>
            <span class="db-stat-trend trend-neu"><i class="fas fa-check"></i> Clear</span>
            <?php endif; ?>
        </div>
        <div>
            <div class="db-stat-num" data-count="<?= (int)$pendingApprovals ?>" id="countPending">0</div>
            <div class="db-stat-label">Pending Approvals</div>
        </div>
        <div class="db-stat-sub">
            <?php if ($pendingApprovals > 0): ?>
            <a href="<?= url('leaves/approvals') ?>" style="color:#f59e0b;font-weight:600;font-size:.72rem">Review now &rarr;</a>
            <?php else: ?>
            <span style="color:#10b981;font-size:.72rem"><i class="fas fa-check-circle"></i> All caught up!</span>
            <?php endif; ?>
        </div>
    </div>

    <!-- Present Today -->
    <div class="db-stat-card stat-teal">
        <div class="db-stat-top">
            <div class="db-stat-icon"><i class="fas fa-user-check"></i></div>
            <span class="db-stat-trend <?= $attPct >= 80 ? 'trend-up' : ($attPct >= 60 ? 'trend-neu' : 'trend-down') ?>">
                <i class="fas fa-<?= $attPct >= 80 ? 'arrow-up' : ($attPct >= 60 ? 'minus' : 'arrow-down') ?>"></i>
                <?= $attPct ?>%
            </span>
        </div>
        <div>
            <div class="db-stat-num" data-count="<?= $attPresent ?>" id="countPresent">0</div>
            <div class="db-stat-label">Present Today</div>
        </div>
        <div class="db-stat-progress">
            <div class="db-stat-progress-bar" style="--progress-value:<?= $attPct ?>%"></div>
        </div>
        <div class="db-stat-sub"><?= $attPresent ?> of <?= $attTotal ?> employees &bull; <?= $attAbsent ?> absent &bull; <?= $attLate ?> late</div>
    </div>

</div>

<!-- ═══════════════════════════════════════════════════════════
     CHARTS ROW — Payroll Trend + Dept Doughnut
═══════════════════════════════════════════════════════════ -->
<div class="db-charts-row">

    <!-- Payroll Trend Line Chart -->
    <div class="db-card">
        <div class="db-card-header">
            <div class="db-card-title">
                <div class="db-card-title-icon" style="background:linear-gradient(135deg,#6366f1,#8b5cf6)">
                    <i class="fas fa-chart-line"></i>
                </div>
                Payroll Trend
            </div>
            <span class="db-card-badge">Last 6 Months</span>
        </div>
        <div class="db-card-body">
            <div class="db-chart-wrap">
                <canvas id="payrollTrendChart"
                    data-labels='<?= htmlspecialchars($trendLabelsJson, ENT_QUOTES) ?>'
                    data-values='<?= htmlspecialchars($trendValuesJson, ENT_QUOTES) ?>'>
                </canvas>
            </div>
        </div>
    </div>

    <!-- Department Doughnut Chart -->
    <div class="db-card">
        <div class="db-card-header">
            <div class="db-card-title">
                <div class="db-card-title-icon" style="background:linear-gradient(135deg,#10b981,#14b8a6)">
                    <i class="fas fa-chart-pie"></i>
                </div>
                By Department
            </div>
            <span class="db-card-badge"><?= date('M Y', strtotime($currentMonth . '-01')) ?></span>
        </div>
        <div class="db-card-body">
            <div class="db-chart-wrap" style="height:200px">
                <canvas id="deptDoughnutChart"
                    data-labels='<?= htmlspecialchars($deptLabelsJson, ENT_QUOTES) ?>'
                    data-values='<?= htmlspecialchars($deptValuesJson, ENT_QUOTES) ?>'
                    data-colors='<?= htmlspecialchars($deptColorsJson, ENT_QUOTES) ?>'>
                </canvas>
            </div>
            <!-- Legend -->
            <?php if (!empty($deptBreakdown)): ?>
            <div style="margin-top:1rem;display:flex;flex-direction:column;gap:.4rem">
                <?php foreach (array_slice($deptBreakdown, 0, 5) as $i => $d):
                    $dName = is_object($d) ? $d->department : $d['department'];
                    $dNet  = (float)(is_object($d) ? $d->total_net : $d['total_net']);
                    $color = $deptColors[$i % count($deptColors)];
                ?>
                <div style="display:flex;align-items:center;gap:.5rem;font-size:.78rem">
                    <span style="width:10px;height:10px;border-radius:3px;background:<?= e($color) ?>;flex-shrink:0"></span>
                    <span style="flex:1;color:#374151;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= e($dName) ?></span>
                    <span style="color:#64748b;font-weight:600"><?= formatCurrency($dNet) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="db-empty"><i class="fas fa-chart-pie"></i><p>No department data</p></div>
            <?php endif; ?>
        </div>
    </div>

</div>

<!-- ═══════════════════════════════════════════════════════════
     BOTTOM ROW — Recent Payroll + Attendance + Leaves
═══════════════════════════════════════════════════════════ -->
<div class="db-bottom-row">

    <!-- Recent Payroll Table -->
    <div class="db-card">
        <div class="db-card-header">
            <div class="db-card-title">
                <div class="db-card-title-icon" style="background:linear-gradient(135deg,#3b82f6,#6366f1)">
                    <i class="fas fa-file-invoice-dollar"></i>
                </div>
                Recent Payroll
            </div>
            <a href="<?= url('payroll') ?>" class="db-view-all">View all <i class="fas fa-arrow-right"></i></a>
        </div>
        <?php if (!empty($recentPayroll)): ?>
        <div style="overflow-x:auto">
            <table class="db-table">
                <thead>
                    <tr>
                        <th>Employee</th>
                        <th>Department</th>
                        <th>Month</th>
                        <th>Net Salary</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($recentPayroll as $p):
                    $pName   = is_object($p) ? $p->employee_name : $p['employee_name'];
                    $pDept   = is_object($p) ? $p->department    : $p['department'];
                    $pMonth  = is_object($p) ? $p->pay_month     : $p['pay_month'];
                    $pSalary = (float)(is_object($p) ? $p->net_salary : $p['net_salary']);
                    $pStatus = is_object($p) ? $p->status        : $p['status'];
                    $initials = strtoupper(substr($pName, 0, 1) . (strpos($pName, ' ') !== false ? substr($pName, strpos($pName, ' ') + 1, 1) : ''));
                    $avatarColors = ['#6366f1','#8b5cf6','#10b981','#f59e0b','#3b82f6','#ec4899','#14b8a6'];
                    $avatarColor  = $avatarColors[crc32($pName) % count($avatarColors)];
                ?>
                <tr>
                    <td>
                        <div class="db-emp-cell">
                            <div class="db-emp-avatar" style="background:linear-gradient(135deg,<?= e($avatarColor) ?>,<?= e($avatarColor) ?>cc)">
                                <?= e($initials) ?>
                            </div>
                            <div>
                                <div class="db-emp-name"><?= e($pName) ?></div>
                            </div>
                        </div>
                    </td>
                    <td><span class="db-dept-badge"><?= e($pDept) ?></span></td>
                    <td style="color:#64748b;font-size:.82rem"><?= e(date('M Y', strtotime($pMonth . '-01'))) ?></td>
                    <td><span class="db-salary"><?= formatCurrency($pSalary) ?></span></td>
                    <td><?= statusBadge($pStatus) ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="db-card-body">
            <div class="db-empty">
                <i class="fas fa-file-invoice-dollar"></i>
                <p>No payroll records found for this period.</p>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Right Column: Attendance + Leaves -->
    <div class="db-right-col">

        <!-- Today's Attendance -->
        <div class="db-card">
            <div class="db-card-header">
                <div class="db-card-title">
                    <div class="db-card-title-icon" style="background:linear-gradient(135deg,#14b8a6,#10b981)">
                        <i class="fas fa-user-clock"></i>
                    </div>
                    Today's Attendance
                </div>
                <a href="<?= url('attendance') ?>" class="db-view-all">Details <i class="fas fa-arrow-right"></i></a>
            </div>
            <div class="db-card-body">
                <div class="db-att-grid">
                    <div class="db-att-item att-present">
                        <div class="db-att-circle"><?= $attPresent ?></div>
                        <div class="db-att-lbl">Present</div>
                    </div>
                    <div class="db-att-item att-absent">
                        <div class="db-att-circle"><?= $attAbsent ?></div>
                        <div class="db-att-lbl">Absent</div>
                    </div>
                    <div class="db-att-item att-late">
                        <div class="db-att-circle"><?= $attLate ?></div>
                        <div class="db-att-lbl">Late</div>
                    </div>
                </div>
                <div class="db-att-pct-row">
                    <span><?= $attPresent ?> present</span>
                    <span style="font-weight:700;color:#10b981"><?= $attPct ?>% attendance</span>
                </div>
                <div class="db-att-bar-wrap">
                    <div class="db-att-bar" style="--progress-value:<?= $attPct ?>%"></div>
                </div>
                <div style="font-size:.72rem;color:#94a3b8;text-align:center">
                    Total workforce: <?= $attTotal ?> employees
                </div>
            </div>
        </div>

        <!-- Upcoming Leaves -->
        <div class="db-card">
            <div class="db-card-header">
                <div class="db-card-title">
                    <div class="db-card-title-icon" style="background:linear-gradient(135deg,#f59e0b,#f97316)">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    Upcoming Leaves
                </div>
                <a href="<?= url('leaves') ?>" class="db-view-all">View all <i class="fas fa-arrow-right"></i></a>
            </div>
            <div class="db-card-body">
                <?php if (!empty($upcomingLeaves)): ?>
                <div class="db-leave-list">
                    <?php foreach ($upcomingLeaves as $lv):
                        $lvName  = is_object($lv) ? $lv->employee_name : $lv['employee_name'];
                        $lvType  = strtolower(str_replace(' ', '_', is_object($lv) ? $lv->leave_type : $lv['leave_type']));
                        $lvStart = is_object($lv) ? $lv->start_date : $lv['start_date'];
                        $lvTypeLabel = ucfirst(str_replace('_', ' ', $lvType));
                        $lvInitials  = strtoupper(substr($lvName, 0, 1) . (strpos($lvName, ' ') !== false ? substr($lvName, strpos($lvName, ' ') + 1, 1) : ''));
                        $lvBadgeClass = 'badge-' . (in_array($lvType, ['annual','sick','casual','maternity']) ? $lvType : 'other');
                        $lvItemClass  = 'leave-' . (in_array($lvType, ['annual','sick','casual','maternity']) ? $lvType : 'other');
                    ?>
                    <div class="db-leave-item <?= e($lvItemClass) ?>">
                        <div class="db-leave-avatar"><?= e($lvInitials) ?></div>
                        <div style="flex:1;min-width:0">
                            <div class="db-leave-name"><?= e($lvName) ?></div>
                            <div class="db-leave-date"><i class="fas fa-calendar-day" style="font-size:.65rem"></i> <?= e(formatDate($lvStart)) ?></div>
                        </div>
                        <span class="db-leave-type-badge <?= e($lvBadgeClass) ?>"><?= e($lvTypeLabel) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="db-empty">
                    <i class="fas fa-calendar-check"></i>
                    <p>No upcoming leaves scheduled.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

    </div><!-- /db-right-col -->
</div><!-- /db-bottom-row -->

<!-- ═══════════════════════════════════════════════════════════
     ACTIVITY LOG — Timeline
═══════════════════════════════════════════════════════════ -->
<div class="db-activity">
    <div class="db-card">
        <div class="db-card-header">
            <div class="db-card-title">
                <div class="db-card-title-icon" style="background:linear-gradient(135deg,#8b5cf6,#6366f1)">
                    <i class="fas fa-history"></i>
                </div>
                Recent Activity
            </div>
            <span class="db-card-badge">Last 10 actions</span>
        </div>
        <div class="db-card-body">
            <?php if (!empty($activityLog)): ?>
            <?php
            $dotColors = ['dot-indigo','dot-green','dot-amber','dot-red','dot-blue','dot-purple','dot-teal'];
            $tlDelay   = 0;
            ?>
            <div class="db-timeline">
                <?php foreach ($activityLog as $i => $log):
                    $logName   = is_object($log) ? $log->name       : ($log['name']       ?? 'System');
                    $logAction = is_object($log) ? $log->action      : ($log['action']     ?? '');
                    $logTime   = is_object($log) ? $log->created_at  : ($log['created_at'] ?? '');
                    $dotClass  = $dotColors[$i % count($dotColors)];
                    $tlDelay   = $i * 0.05;
                ?>
                <div class="db-tl-item" style="animation-delay:<?= $tlDelay ?>s">
                    <div class="db-tl-dot <?= e($dotClass) ?>"></div>
                    <div class="db-tl-name"><?= e($logName) ?></div>
                    <div class="db-tl-action"><?= e($logAction) ?></div>
                    <div class="db-tl-time"><i class="fas fa-clock" style="font-size:.6rem"></i> <?= e(timeAgo($logTime)) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="db-empty">
                <i class="fas fa-history"></i>
                <p>No recent activity to display.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════════
     DASHBOARD JAVASCRIPT
═══════════════════════════════════════════════════════════ -->
<script>
(function () {
    'use strict';

    /* ── Animated counter ── */
    function animateCounter(el, target, duration) {
        if (!el) return;
        var start     = 0;
        var startTime = null;
        var isFloat   = target !== Math.floor(target);

        function step(timestamp) {
            if (!startTime) startTime = timestamp;
            var progress = Math.min((timestamp - startTime) / duration, 1);
            var ease     = 1 - Math.pow(1 - progress, 3); // ease-out cubic
            var current  = start + (target - start) * ease;
            el.textContent = isFloat
                ? current.toFixed(2)
                : Math.floor(current).toLocaleString();
            if (progress < 1) requestAnimationFrame(step);
            else el.textContent = isFloat ? target.toFixed(2) : target.toLocaleString();
        }
        requestAnimationFrame(step);
    }

    /* ── Run counters when visible ── */
    var counters = document.querySelectorAll('[data-count]');
    if ('IntersectionObserver' in window) {
        var obs = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    var el  = entry.target;
                    var val = parseFloat(el.getAttribute('data-count'));
                    animateCounter(el, val, 1400);
                    obs.unobserve(el);
                }
            });
        }, { threshold: 0.3 });
        counters.forEach(function (c) { obs.observe(c); });
    } else {
        counters.forEach(function (c) {
            c.textContent = parseFloat(c.getAttribute('data-count')).toLocaleString();
        });
    }

    /* ── Chart.js — Payroll Trend ── */
    function initPayrollTrendChart() {
        var canvas = document.getElementById('payrollTrendChart');
        if (!canvas || typeof Chart === 'undefined') return;

        var labels = JSON.parse(canvas.getAttribute('data-labels') || '[]');
        var values = JSON.parse(canvas.getAttribute('data-values') || '[]');

        var gradient = canvas.getContext('2d').createLinearGradient(0, 0, 0, 240);
        gradient.addColorStop(0,   'rgba(99,102,241,0.25)');
        gradient.addColorStop(0.6, 'rgba(99,102,241,0.05)');
        gradient.addColorStop(1,   'rgba(99,102,241,0)');

        new Chart(canvas, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Total Payroll',
                    data: values,
                    borderColor: '#6366f1',
                    borderWidth: 3,
                    backgroundColor: gradient,
                    fill: true,
                    tension: 0.45,
                    pointBackgroundColor: '#6366f1',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 7,
                    pointHoverBackgroundColor: '#8b5cf6',
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#0f172a',
                        titleColor: '#f1f5f9',
                        bodyColor: '#94a3b8',
                        borderColor: '#1e293b',
                        borderWidth: 1,
                        padding: 12,
                        cornerRadius: 10,
                        callbacks: {
                            label: function (ctx) {
                                return ' ' + ctx.parsed.y.toLocaleString('en-US', {
                                    style: 'currency', currency: 'USD', minimumFractionDigits: 0
                                });
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { color: '#94a3b8', font: { size: 11, weight: '500' } },
                        border: { display: false }
                    },
                    y: {
                        grid: { color: '#f1f5f9', drawBorder: false },
                        ticks: {
                            color: '#94a3b8',
                            font: { size: 11 },
                            callback: function (v) {
                                return v >= 1000 ? '$' + (v / 1000).toFixed(0) + 'k' : '$' + v;
                            }
                        },
                        border: { display: false }
                    }
                },
                animation: {
                    duration: 1200,
                    easing: 'easeOutQuart'
                }
            }
        });
    }

    /* ── Chart.js — Department Doughnut ── */
    function initDeptDoughnutChart() {
        var canvas = document.getElementById('deptDoughnutChart');
        if (!canvas || typeof Chart === 'undefined') return;

        var labels = JSON.parse(canvas.getAttribute('data-labels') || '[]');
        var values = JSON.parse(canvas.getAttribute('data-values') || '[]');
        var colors = JSON.parse(canvas.getAttribute('data-colors') || '[]');

        if (!labels.length) return;

        new Chart(canvas, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: values,
                    backgroundColor: colors,
                    borderColor: '#fff',
                    borderWidth: 3,
                    hoverBorderWidth: 4,
                    hoverOffset: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '68%',
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#0f172a',
                        titleColor: '#f1f5f9',
                        bodyColor: '#94a3b8',
                        borderColor: '#1e293b',
                        borderWidth: 1,
                        padding: 12,
                        cornerRadius: 10,
                        callbacks: {
                            label: function (ctx) {
                                var total = ctx.dataset.data.reduce(function (a, b) { return a + b; }, 0);
                                var pct   = total > 0 ? ((ctx.parsed / total) * 100).toFixed(1) : 0;
                                return ' ' + ctx.label + ': ' + pct + '%';
                            }
                        }
                    }
                },
                animation: {
                    animateRotate: true,
                    animateScale: true,
                    duration: 1000,
                    easing: 'easeOutQuart'
                }
            }
        });
    }

    /* ── Init charts after Chart.js loads ── */
    function initCharts() {
        if (typeof Chart !== 'undefined') {
            initPayrollTrendChart();
            initDeptDoughnutChart();
        } else {
            setTimeout(initCharts, 150);
        }
    }

    /* ── Stagger fade-in for timeline items ── */
    function staggerTimeline() {
        var items = document.querySelectorAll('.db-tl-item');
        items.forEach(function (item, i) {
            item.style.opacity = '0';
            item.style.transform = 'translateX(-16px)';
            setTimeout(function () {
                item.style.transition = 'all 0.4s ease';
                item.style.opacity    = '1';
                item.style.transform  = 'translateX(0)';
            }, 80 + i * 60);
        });
    }

    /* ── Quick action ripple effect ── */
    document.querySelectorAll('.db-qa-card').forEach(function (card) {
        card.addEventListener('click', function (e) {
            var ripple = document.createElement('span');
            var rect   = card.getBoundingClientRect();
            var size   = Math.max(rect.width, rect.height);
            ripple.style.cssText = [
                'position:absolute',
                'border-radius:50%',
                'background:rgba(255,255,255,0.4)',
                'width:' + size + 'px',
                'height:' + size + 'px',
                'left:' + (e.clientX - rect.left - size / 2) + 'px',
                'top:' + (e.clientY - rect.top - size / 2) + 'px',
                'animation:ripple 0.6s ease forwards',
                'pointer-events:none'
            ].join(';');
            card.appendChild(ripple);
            setTimeout(function () { ripple.remove(); }, 700);
        });
    });

    /* ── Boot ── */
    document.addEventListener('DOMContentLoaded', function () {
        initCharts();
        staggerTimeline();
    });

    // Also try immediately in case DOM is already ready
    if (document.readyState !== 'loading') {
        initCharts();
        staggerTimeline();
    }

}());
</script>
