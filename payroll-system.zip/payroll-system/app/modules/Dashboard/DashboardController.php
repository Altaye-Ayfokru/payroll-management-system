<?php
require_once CORE_PATH . '/Controller.php';
require_once APP_PATH . '/modules/Employee/EmployeeModel.php';
require_once APP_PATH . '/modules/Payroll/PayrollModel.php';
require_once APP_PATH . '/modules/Attendance/AttendanceModel.php';
require_once APP_PATH . '/modules/Leave/LeaveModel.php';

class DashboardController extends Controller {
    public function index(): void {
        $this->requireAuth();

        $empModel  = new EmployeeModel();
        $payModel  = new PayrollModel();
        $attModel  = new AttendanceModel();
        $leaveModel = new LeaveModel();

        $month  = date('Y-m');
        $userId = currentUserId();
        $role   = currentUserRole();

        // Core stats
        $data = [
            'totalEmployees'   => $empModel->countActive(),
            'totalPayroll'     => $payModel->getTotalByMonth($month),
            'pendingApprovals' => $payModel->getPendingCount() + $leaveModel->getPendingCount(),
            'todayAttendance'  => $attModel->getTodayStats(),
            'payrollTrend'     => $payModel->getMonthlyTrend(6),
            'deptBreakdown'    => $payModel->getDeptBreakdown($month),
            'upcomingLeaves'   => $leaveModel->getUpcoming(5),
            'recentPayroll'    => $payModel->getWithEmployee(5, 0),
            'currentMonth'     => $month,
            'pageTitle'        => 'Dashboard',
            'flash'            => $this->getFlash(),
        ];

        // Employee-specific additions
        if ($role === 'employee') {
            $emp = $empModel->getByUserId($userId);
            if ($emp) {
                $data['myEmployee']   = $emp;
                $data['myPayroll']    = $payModel->getByEmployee($emp['id'], 6);
                $data['myAttendance'] = $attModel->getMonthlySummary($emp['id'], $month);
                $data['myLeaves']     = $leaveModel->getByEmployee($emp['id']);
                $data['myTodayAtt']   = $attModel->getTodayRecord($emp['id']);
            }
        }

        // Unread notifications count
        $db   = Database::getInstance();
        $stmt = $db->prepare("SELECT COUNT(*) FROM notifications WHERE user_id=:uid AND is_read=0");
        $stmt->execute([':uid' => $userId]);
        $data['unreadCount'] = (int)$stmt->fetchColumn();

        // Recent activity log
        $stmt = $db->query(
            "SELECT al.*, u.name FROM activity_logs al
             LEFT JOIN users u ON u.id = al.user_id
             ORDER BY al.created_at DESC LIMIT 10"
        );
        $data['activityLog'] = $stmt->fetchAll();

        $this->view('dashboard.index', $data);
    }
}
