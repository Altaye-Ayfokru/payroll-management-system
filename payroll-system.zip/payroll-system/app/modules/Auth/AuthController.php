<?php
require_once CORE_PATH . '/Controller.php';
require_once APP_PATH . '/models/User.php';
require_once APP_PATH . '/helpers/validator.php';

class AuthController extends Controller {
    private User $userModel;

    public function __construct() {
        $this->userModel = new User();
    }

    public function loginPage(): void {
        if (!empty($_SESSION['user_id'])) { $this->redirect('dashboard'); }
        $this->viewRaw('auth.login', ['csrf' => csrfToken()]);
    }

    public function login(): void {
        if (!validateCsrf()) {
            $this->viewRaw('auth.login', ['error' => 'Security token mismatch.', 'csrf' => csrfToken()]);
            return;
        }

        $email    = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';

        $v = new Validator(['email' => $email, 'password' => $password]);
        $v->required('email')->email('email')->required('password');

        if (!$v->passes()) {
            $this->viewRaw('auth.login', ['error' => $v->firstError(), 'csrf' => csrfToken()]);
            return;
        }

        $user = $this->userModel->findByEmail($email);

        if (!$user || !$this->userModel->verifyPassword($password, $user['password'])) {
            logActivity(0, "Failed login: {$email}");
            $this->viewRaw('auth.login', ['error' => 'Invalid email or password.', 'csrf' => csrfToken()]);
            return;
        }

        if (!$user['is_active']) {
            $this->viewRaw('auth.login', ['error' => 'Your account has been deactivated.', 'csrf' => csrfToken()]);
            return;
        }

        session_regenerate_id(true);
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user']      = $user;

        // Update last login
        $this->userModel->update($user['id'], ['last_login' => date('Y-m-d H:i:s')]);
        logActivity($user['id'], 'Logged in');

        if ($this->isAjax()) {
            $this->json(['success' => true, 'redirect' => url('dashboard')]);
        }
        $this->redirect('dashboard');
    }

    public function logout(): void {
        $uid = $_SESSION['user_id'] ?? 0;
        if ($uid) logActivity($uid, 'Logged out');
        session_destroy();
        $this->redirect('auth/login');
    }

    public function registerPage(): void {
        if (!empty($_SESSION['user_id'])) { $this->redirect('dashboard'); }
        $this->viewRaw('auth.register', ['csrf' => csrfToken()]);
    }

    public function register(): void {
        if (!validateCsrf()) {
            $this->viewRaw('auth.register', ['error' => 'Security token mismatch.', 'csrf' => csrfToken()]);
            return;
        }

        $data = [
            'name'     => trim($_POST['name'] ?? ''),
            'email'    => strtolower(trim($_POST['email'] ?? '')),
            'password' => $_POST['password'] ?? '',
        ];

        $v = new Validator($data);
        $v->required('name')->required('email')->email('email')
          ->required('password')->minLength('password', 8);

        if (!$v->passes()) {
            $this->viewRaw('auth.register', ['errors' => $v->errors(), 'old' => $data, 'csrf' => csrfToken()]);
            return;
        }

        if ($this->userModel->findByEmail($data['email'])) {
            $this->viewRaw('auth.register', [
                'errors' => ['email' => 'Email already registered.'], 'old' => $data, 'csrf' => csrfToken(),
            ]);
            return;
        }

        $uid = $this->userModel->createUser(array_merge($data, ['role' => 'employee']));
        logActivity($uid, 'Registered');
        $this->viewRaw('auth.login', ['success' => 'Account created! Please log in.', 'csrf' => csrfToken()]);
    }
}
