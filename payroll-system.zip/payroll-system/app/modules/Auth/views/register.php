<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Account &mdash; PayrollPro</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --indigo-600: #4f46e5; --violet-600: #7c3aed; --indigo-400: #818cf8;
    --white: #ffffff; --gray-50: #f9fafb; --gray-100: #f3f4f6; --gray-200: #e5e7eb;
    --gray-400: #9ca3af; --gray-500: #6b7280; --gray-600: #4b5563; --gray-700: #374151;
    --gray-900: #111827; --red-50: #fef2f2; --red-200: #fecaca; --red-600: #dc2626;
    --green-50: #f0fdf4; --green-200: #bbf7d0; --green-600: #16a34a;
  }
  html, body { height: 100%; font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; -webkit-font-smoothing: antialiased; }
  body { display: flex; overflow: hidden; height: 100vh; background: var(--white); }

  /* Left Panel */
  .left-panel {
    flex: 1; background: linear-gradient(135deg, #1e1b4b 0%, #312e81 30%, #4f46e5 60%, #7c3aed 100%);
    position: relative; overflow: hidden; display: flex; flex-direction: column;
    align-items: center; justify-content: center; padding: 3rem 2.5rem;
  }
  .left-panel::before {
    content: ''; position: absolute; inset: 0;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
    pointer-events: none; z-index: 0;
  }
  .orb { position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.25; pointer-events: none; }
  .orb-1 { width: 400px; height: 400px; background: #818cf8; top: -100px; left: -100px; animation: orbFloat 8s ease-in-out infinite; }
  .orb-2 { width: 300px; height: 300px; background: #e879f9; bottom: -80px; right: -80px; animation: orbFloat 10s ease-in-out infinite reverse; }
  @keyframes orbFloat { 0%, 100% { transform: translateY(0) scale(1); } 50% { transform: translateY(-30px) scale(1.05); } }

  .left-content { position: relative; z-index: 1; width: 100%; max-width: 520px; display: flex; flex-direction: column; align-items: center; gap: 2rem; }
  .brand { display: flex; align-items: center; gap: 0.75rem; animation: fadeInUp 0.6s ease both; }
  .brand-icon { width: 48px; height: 48px; background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.25); border-radius: 14px; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(10px); }
  .brand-name { font-size: 1.75rem; font-weight: 800; color: #fff; letter-spacing: -0.02em; }
  .brand-name span { color: #e879f9; }
  .brand-tagline { font-size: 0.875rem; color: rgba(255,255,255,0.6); font-weight: 400; text-align: center; animation: fadeInUp 0.6s ease 0.1s both; }

  /* Steps illustration */
  .steps-area { width: 100%; animation: fadeInUp 0.6s ease 0.2s both; }
  .step-item { display: flex; align-items: center; gap: 1rem; padding: 0.875rem 1rem; background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.12); border-radius: 12px; backdrop-filter: blur(10px); margin-bottom: 0.75rem; transition: background 0.2s; }
  .step-item:hover { background: rgba(255,255,255,0.13); }
  .step-num { width: 32px; height: 32px; border-radius: 50%; background: rgba(255,255,255,0.15); border: 1.5px solid rgba(255,255,255,0.3); display: flex; align-items: center; justify-content: center; font-size: 0.8rem; font-weight: 700; color: #fff; flex-shrink: 0; }
  .step-text { color: rgba(255,255,255,0.85); font-size: 0.875rem; font-weight: 500; }
  .step-icon { margin-left: auto; color: rgba(255,255,255,0.5); font-size: 0.9rem; }

  .stats-row { display: flex; gap: 1rem; width: 100%; animation: fadeInUp 0.6s ease 0.3s both; }
  .stat-card { flex: 1; background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.12); border-radius: 12px; padding: 0.875rem; text-align: center; backdrop-filter: blur(10px); }
  .stat-value { font-size: 1.25rem; font-weight: 700; color: #fff; }
  .stat-label { font-size: 0.7rem; color: rgba(255,255,255,0.55); margin-top: 2px; text-transform: uppercase; letter-spacing: 0.05em; }

  @keyframes fadeInUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: translateY(0); } }
  @keyframes slideInLeft { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
  @keyframes shimmer { 0% { background-position: -200% center; } 100% { background-position: 200% center; } }
  @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }

  /* Right Panel */
  .right-panel {
    width: 480px; flex-shrink: 0; background: var(--white); overflow-y: auto; height: 100vh;
    display: flex; flex-direction: column; justify-content: center; padding: 2.5rem 2.75rem;
    position: relative; box-shadow: -20px 0 60px rgba(0,0,0,0.08); animation: slideInLeft 0.5s ease both;
  }
  .right-panel::-webkit-scrollbar { width: 4px; }
  .right-panel::-webkit-scrollbar-thumb { background: var(--gray-200); border-radius: 2px; }
  .right-panel::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; background: linear-gradient(90deg, #6366f1, #8b5cf6, #e879f9); }

  .form-header { margin-bottom: 1.5rem; }
  .form-logo { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1.25rem; }
  .form-logo-icon { width: 36px; height: 36px; background: linear-gradient(135deg, #6366f1, #8b5cf6); border-radius: 10px; display: flex; align-items: center; justify-content: center; }
  .form-logo-name { font-size: 1.125rem; font-weight: 700; color: var(--gray-900); }
  .form-logo-name span { color: #6366f1; }
  .form-title { font-size: 1.5rem; font-weight: 700; color: var(--gray-900); letter-spacing: -0.02em; line-height: 1.2; }
  .form-subtitle { font-size: 0.875rem; color: var(--gray-500); margin-top: 0.375rem; }

  .alert { display: flex; align-items: flex-start; gap: 0.625rem; padding: 0.875rem 1rem; border-radius: 10px; margin-bottom: 1.25rem; font-size: 0.875rem; animation: fadeInUp 0.3s ease both; }
  .alert-error { background: var(--red-50); border: 1px solid var(--red-200); color: var(--red-600); }
  .alert-success { background: var(--green-50); border: 1px solid var(--green-200); color: var(--green-600); }

  .form-group { margin-bottom: 1rem; }
  .form-label { display: block; font-size: 0.8125rem; font-weight: 600; color: var(--gray-700); margin-bottom: 0.4rem; }
  .form-label .req { color: #ef4444; }
  .input-wrapper { position: relative; display: flex; align-items: center; }
  .input-icon { position: absolute; left: 0.875rem; color: var(--gray-400); pointer-events: none; transition: color 0.2s; display: flex; }
  .form-input {
    width: 100%; padding: 0.75rem 0.875rem 0.75rem 2.75rem; border: 1.5px solid var(--gray-200);
    border-radius: 10px; font-size: 0.9375rem; font-family: inherit; color: var(--gray-900);
    background: var(--gray-50); transition: all 0.2s; outline: none;
  }
  .form-input::placeholder { color: var(--gray-400); }
  .form-input:focus { border-color: #6366f1; background: var(--white); box-shadow: 0 0 0 3px rgba(99,102,241,0.12); }
  .form-input.is-invalid { border-color: #ef4444; }
  .form-input.is-invalid:focus { box-shadow: 0 0 0 3px rgba(239,68,68,0.12); }
  .input-wrapper:focus-within .input-icon { color: #6366f1; }
  .form-error { font-size: 0.75rem; color: #ef4444; margin-top: 4px; }
  .form-hint { font-size: 0.75rem; color: var(--gray-400); margin-top: 4px; }

  .password-toggle { position: absolute; right: 0.875rem; background: none; border: none; cursor: pointer; color: var(--gray-400); padding: 0.25rem; display: flex; align-items: center; transition: color 0.2s; border-radius: 4px; }
  .password-toggle:hover { color: #6366f1; }

  /* Password strength */
  .pw-strength { margin-top: 6px; }
  .pw-strength-bar { height: 4px; background: var(--gray-200); border-radius: 2px; overflow: hidden; margin-bottom: 4px; }
  .pw-strength-fill { height: 100%; border-radius: 2px; transition: width 0.3s, background 0.3s; width: 0; }
  .pw-strength-text { font-size: 0.7rem; color: var(--gray-400); }

  .btn-submit {
    width: 100%; padding: 0.875rem; background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white;
    border: none; border-radius: 10px; font-size: 0.9375rem; font-weight: 600; font-family: inherit;
    cursor: pointer; transition: all 0.2s; display: flex; align-items: center; justify-content: center;
    gap: 0.5rem; position: relative; overflow: hidden; letter-spacing: 0.01em;
  }
  .btn-submit::before { content: ''; position: absolute; inset: 0; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent); background-size: 200% 100%; opacity: 0; transition: opacity 0.3s; }
  .btn-submit:hover { transform: translateY(-1px); box-shadow: 0 8px 25px rgba(99,102,241,0.4); }
  .btn-submit:hover::before { opacity: 1; animation: shimmer 1.5s infinite; }
  .btn-submit:active { transform: translateY(0); box-shadow: none; }
  .btn-submit:disabled { opacity: 0.7; cursor: not-allowed; transform: none; }
  .btn-spinner { display: none; width: 18px; height: 18px; border: 2px solid rgba(255,255,255,0.3); border-top-color: white; border-radius: 50%; animation: spin 0.7s linear infinite; }

  .login-link { text-align: center; font-size: 0.875rem; color: var(--gray-500); margin-top: 1.25rem; }
  .login-link a { color: #6366f1; font-weight: 600; text-decoration: none; transition: color 0.2s; }
  .login-link a:hover { color: #4f46e5; text-decoration: underline; }

  .form-footer { margin-top: 1.5rem; padding-top: 1.25rem; border-top: 1px solid var(--gray-100); display: flex; align-items: center; justify-content: center; gap: 0.375rem; font-size: 0.75rem; color: var(--gray-400); }

  @media (max-width: 860px) { .left-panel { display: none; } .right-panel { width: 100%; padding: 2rem 1.5rem; box-shadow: none; } }
  @media (max-width: 400px) { .right-panel { padding: 1.5rem 1.25rem; } }
</style>
</head>
<body>

<!-- LEFT PANEL -->
<div class="left-panel">
  <div class="orb orb-1"></div>
  <div class="orb orb-2"></div>
  <div class="left-content">
    <div class="brand">
      <div class="brand-icon">
        <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
          <rect x="3" y="3" width="8" height="8" rx="2" fill="#a5b4fc"/>
          <rect x="15" y="3" width="8" height="8" rx="2" fill="#e879f9"/>
          <rect x="3" y="15" width="8" height="8" rx="2" fill="#e879f9"/>
          <rect x="15" y="15" width="8" height="8" rx="2" fill="#a5b4fc"/>
        </svg>
      </div>
      <span class="brand-name">Payroll<span>Pro</span></span>
    </div>
    <p class="brand-tagline">HR &amp; Payroll Management System</p>

    <div class="steps-area">
      <div class="step-item">
        <div class="step-num">1</div>
        <span class="step-text">Create your account with name &amp; email</span>
        <i class="fas fa-user step-icon"></i>
      </div>
      <div class="step-item">
        <div class="step-num">2</div>
        <span class="step-text">Admin assigns your role &amp; employee profile</span>
        <i class="fas fa-user-shield step-icon"></i>
      </div>
      <div class="step-item">
        <div class="step-num">3</div>
        <span class="step-text">Access your payslips, attendance &amp; leaves</span>
        <i class="fas fa-chart-bar step-icon"></i>
      </div>
    </div>

    <div class="stats-row">
      <div class="stat-card">
        <div class="stat-value">🔒</div>
        <div class="stat-label">Secure</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">⚡</div>
        <div class="stat-label">Fast</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">ETB</div>
        <div class="stat-label">Ethiopian</div>
      </div>
    </div>
  </div>
</div>

<!-- RIGHT PANEL -->
<div class="right-panel">
  <div class="form-header">
    <div class="form-logo">
      <div class="form-logo-icon">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <rect x="2" y="2" width="6" height="6" rx="1.5" fill="white"/>
          <rect x="12" y="2" width="6" height="6" rx="1.5" fill="rgba(255,255,255,0.6)"/>
          <rect x="2" y="12" width="6" height="6" rx="1.5" fill="rgba(255,255,255,0.6)"/>
          <rect x="12" y="12" width="6" height="6" rx="1.5" fill="white"/>
        </svg>
      </div>
      <span class="form-logo-name">Payroll<span>Pro</span></span>
    </div>
    <h1 class="form-title">Create your account</h1>
    <p class="form-subtitle">Join PayrollPro to manage your HR &amp; payroll</p>
  </div>

  <?php if (!empty($error)): ?>
  <div class="alert alert-error">
    <i class="fas fa-exclamation-circle alert-icon"></i>
    <span><?= e($error) ?></span>
  </div>
  <?php endif; ?>

  <?php if (!empty($errors)): ?>
  <div class="alert alert-error">
    <i class="fas fa-exclamation-circle alert-icon"></i>
    <div>
      <?php foreach ($errors as $err): ?>
      <div><?= e($err) ?></div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <form method="POST" action="<?= url('auth/register') ?>" id="registerForm">
    <input type="hidden" name="csrf_token" value="<?= e($csrf) ?>">

    <div class="form-group">
      <label class="form-label" for="name">Full Name <span class="req">*</span></label>
      <div class="input-wrapper">
        <span class="input-icon">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="5" r="3" stroke="currentColor" stroke-width="1.5"/><path d="M2 14c0-3.314 2.686-6 6-6s6 2.686 6 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
        </span>
        <input type="text" id="name" name="name" class="form-input <?= isset($errors['name']) ? 'is-invalid' : '' ?>"
               placeholder="John Smith" value="<?= e($old['name'] ?? '') ?>" required autocomplete="name">
      </div>
      <?php if (isset($errors['name'])): ?><div class="form-error"><?= e($errors['name']) ?></div><?php endif; ?>
    </div>

    <div class="form-group">
      <label class="form-label" for="email">Email Address <span class="req">*</span></label>
      <div class="input-wrapper">
        <span class="input-icon">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1" y="3" width="14" height="10" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M1 5l7 5 7-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
        </span>
        <input type="email" id="email" name="email" class="form-input <?= isset($errors['email']) ? 'is-invalid' : '' ?>"
               placeholder="you@company.com" value="<?= e($old['email'] ?? '') ?>" required autocomplete="email">
      </div>
      <?php if (isset($errors['email'])): ?><div class="form-error"><?= e($errors['email']) ?></div><?php endif; ?>
    </div>

    <div class="form-group">
      <label class="form-label" for="password">Password <span class="req">*</span></label>
      <div class="input-wrapper">
        <span class="input-icon">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="3" y="7" width="10" height="8" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M5 7V5a3 3 0 016 0v2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="8" cy="11" r="1" fill="currentColor"/></svg>
        </span>
        <input type="password" id="password" name="password" class="form-input <?= isset($errors['password']) ? 'is-invalid' : '' ?>"
               placeholder="Min. 8 characters" required autocomplete="new-password" oninput="checkStrength(this.value)">
        <button type="button" class="password-toggle" onclick="togglePw('password', this)" tabindex="-1">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" id="pwEye"><path d="M1 8s2.5-5 7-5 7 5 7 5-2.5 5-7 5-7-5-7-5z" stroke="currentColor" stroke-width="1.5"/><circle cx="8" cy="8" r="2" stroke="currentColor" stroke-width="1.5"/></svg>
        </button>
      </div>
      <?php if (isset($errors['password'])): ?><div class="form-error"><?= e($errors['password']) ?></div><?php endif; ?>
      <div class="pw-strength">
        <div class="pw-strength-bar"><div class="pw-strength-fill" id="pwStrengthFill"></div></div>
        <div class="pw-strength-text" id="pwStrengthText">Enter a password</div>
      </div>
    </div>

    <button type="submit" class="btn-submit" id="submitBtn">
      <span class="btn-spinner" id="btnSpinner"></span>
      <span id="btnText"><i class="fas fa-user-plus"></i> &nbsp;Create Account</span>
    </button>
  </form>

  <div class="login-link">
    Already have an account? <a href="<?= url('auth/login') ?>">Sign in</a>
  </div>

  <div class="form-footer">
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 1a6 6 0 100 12A6 6 0 007 1zm0 5v4m0-6v.5" stroke="#d1d5db" stroke-width="1.5" stroke-linecap="round"/></svg>
    Your data is encrypted and secure
  </div>
</div>

<script>
function togglePw(id, btn) {
  var input = document.getElementById(id);
  var isText = input.type === 'text';
  input.type = isText ? 'password' : 'text';
  btn.style.color = isText ? '' : '#6366f1';
}

function checkStrength(pw) {
  var fill = document.getElementById('pwStrengthFill');
  var text = document.getElementById('pwStrengthText');
  if (!fill || !text) return;

  var score = 0;
  if (pw.length >= 8)  score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;

  var configs = [
    { w: '0%',   bg: '#e5e7eb', t: 'Enter a password' },
    { w: '25%',  bg: '#ef4444', t: 'Weak' },
    { w: '50%',  bg: '#f59e0b', t: 'Fair' },
    { w: '75%',  bg: '#3b82f6', t: 'Good' },
    { w: '100%', bg: '#10b981', t: 'Strong' },
  ];
  var c = configs[pw.length === 0 ? 0 : score] || configs[0];
  fill.style.width      = c.w;
  fill.style.background = c.bg;
  text.textContent      = c.t;
  text.style.color      = c.bg;
}

document.getElementById('registerForm').addEventListener('submit', function() {
  var btn     = document.getElementById('submitBtn');
  var spinner = document.getElementById('btnSpinner');
  var text    = document.getElementById('btnText');
  btn.disabled = true;
  spinner.style.display = 'block';
  text.style.display    = 'none';
});
</script>
</body>
</html>
