﻿<?php
/**
 * PayrollPro - Login Page
 * Variables: $csrf (string), $error (string|null), $success (string|null)
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In &mdash; PayrollPro</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --indigo-950: #1e1b4b;
    --indigo-900: #312e81;
    --indigo-600: #4f46e5;
    --violet-600: #7c3aed;
    --indigo-400: #818cf8;
    --indigo-300: #a5b4fc;
    --fuchsia-400: #e879f9;
    --white: #ffffff;
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-400: #9ca3af;
    --gray-500: #6b7280;
    --gray-600: #4b5563;
    --gray-700: #374151;
    --gray-900: #111827;
    --red-50: #fef2f2;
    --red-200: #fecaca;
    --red-600: #dc2626;
    --green-50: #f0fdf4;
    --green-200: #bbf7d0;
    --green-600: #16a34a;
  }

  html, body {
    height: 100%;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    -webkit-font-smoothing: antialiased;
  }

  body {
    display: flex;
    overflow: hidden;
    height: 100vh;
    background: var(--white);
  }

  /* ─── LEFT PANEL ─────────────────────────────────────────── */
  .left-panel {
    flex: 1;
    background: linear-gradient(135deg, #1e1b4b 0%, #312e81 30%, #4f46e5 60%, #7c3aed 100%);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 3rem 2.5rem;
  }

  /* Noise texture overlay */
  .left-panel::before {
    content: '';
    position: absolute;
    inset: 0;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
    pointer-events: none;
    z-index: 0;
  }

  /* Glowing orbs */
  .orb {
    position: absolute;
    border-radius: 50%;
    filter: blur(80px);
    opacity: 0.25;
    pointer-events: none;
  }
  .orb-1 { width: 400px; height: 400px; background: #818cf8; top: -100px; left: -100px; animation: orbFloat 8s ease-in-out infinite; }
  .orb-2 { width: 300px; height: 300px; background: #e879f9; bottom: -80px; right: -80px; animation: orbFloat 10s ease-in-out infinite reverse; }
  .orb-3 { width: 200px; height: 200px; background: #a5b4fc; top: 50%; left: 50%; transform: translate(-50%,-50%); animation: orbFloat 6s ease-in-out infinite 2s; }

  @keyframes orbFloat {
    0%, 100% { transform: translateY(0) scale(1); }
    50% { transform: translateY(-30px) scale(1.05); }
  }

  .left-content {
    position: relative;
    z-index: 1;
    width: 100%;
    max-width: 520px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2rem;
  }

  /* Brand */
  .brand {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    animation: fadeInUp 0.6s ease both;
  }
  .brand-icon {
    width: 48px; height: 48px;
    background: rgba(255,255,255,0.15);
    border: 1px solid rgba(255,255,255,0.25);
    border-radius: 14px;
    display: flex; align-items: center; justify-content: center;
    backdrop-filter: blur(10px);
  }
  .brand-name {
    font-size: 1.75rem;
    font-weight: 800;
    color: #fff;
    letter-spacing: -0.02em;
  }
  .brand-name span { color: var(--fuchsia-400); }

  .brand-tagline {
    font-size: 0.875rem;
    color: rgba(255,255,255,0.6);
    font-weight: 400;
    letter-spacing: 0.02em;
    text-align: center;
    animation: fadeInUp 0.6s ease 0.1s both;
  }

  /* Main illustration area */
  .illustration-area {
    position: relative;
    width: 100%;
    height: 280px;
    animation: fadeInUp 0.6s ease 0.2s both;
  }

  /* Payslip document */
  .payslip-card {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 200px;
    animation: float 4s ease-in-out infinite;
    filter: drop-shadow(0 20px 40px rgba(0,0,0,0.4));
  }

  /* Floating coins */
  .coin {
    position: absolute;
    animation: spinFloat var(--dur, 3s) ease-in-out infinite var(--delay, 0s);
    filter: drop-shadow(0 4px 8px rgba(0,0,0,0.3));
  }
  .coin-1 { top: 10%; left: 8%; --dur: 3.5s; --delay: 0s; }
  .coin-2 { top: 20%; right: 10%; --dur: 4s; --delay: 0.5s; }
  .coin-3 { bottom: 15%; left: 15%; --dur: 3s; --delay: 1s; }
  .coin-4 { bottom: 25%; right: 8%; --dur: 4.5s; --delay: 1.5s; }

  /* Chart */
  .chart-svg {
    position: absolute;
    bottom: 0;
    right: 5%;
    animation: float 5s ease-in-out infinite 1s;
    filter: drop-shadow(0 10px 20px rgba(0,0,0,0.3));
  }

  /* Calendar */
  .calendar-svg {
    position: absolute;
    top: 5%;
    left: 5%;
    animation: float 4.5s ease-in-out infinite 0.5s;
    filter: drop-shadow(0 8px 16px rgba(0,0,0,0.3));
  }

  /* Dollar signs */
  .dollar {
    position: absolute;
    font-size: 1.5rem;
    font-weight: 800;
    color: rgba(165,180,252,0.6);
    animation: floatDollar var(--dur, 4s) ease-in-out infinite var(--delay, 0s);
    user-select: none;
  }
  .dollar-1 { top: 5%; right: 25%; --dur: 3s; --delay: 0.2s; }
  .dollar-2 { bottom: 10%; left: 30%; --dur: 4s; --delay: 0.8s; }
  .dollar-3 { top: 40%; left: 3%; --dur: 3.5s; --delay: 1.2s; }

  /* Employee silhouettes */
  .employees-svg {
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    animation: fadeInUp 0.8s ease 0.4s both;
  }

  /* Features list */
  .features {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    width: 100%;
    animation: fadeInUp 0.6s ease 0.3s both;
  }
  .feature-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.625rem 1rem;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 10px;
    backdrop-filter: blur(10px);
    transition: background 0.2s;
  }
  .feature-item:hover { background: rgba(255,255,255,0.13); }
  .feature-icon {
    width: 32px; height: 32px;
    background: rgba(255,255,255,0.12);
    border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
  }
  .feature-text { color: rgba(255,255,255,0.85); font-size: 0.875rem; font-weight: 500; }

  /* Stats row */
  .stats-row {
    display: flex;
    gap: 1rem;
    width: 100%;
    animation: fadeInUp 0.6s ease 0.4s both;
  }
  .stat-card {
    flex: 1;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 12px;
    padding: 0.875rem;
    text-align: center;
    backdrop-filter: blur(10px);
  }
  .stat-value { font-size: 1.25rem; font-weight: 700; color: #fff; }
  .stat-label { font-size: 0.7rem; color: rgba(255,255,255,0.55); margin-top: 2px; text-transform: uppercase; letter-spacing: 0.05em; }

  /* ─── ANIMATIONS ─────────────────────────────────────────── */
  @keyframes float {
    0%, 100% { transform: translate(-50%, -50%) translateY(0); }
    50% { transform: translate(-50%, -50%) translateY(-16px); }
  }
  @keyframes spinFloat {
    0%, 100% { transform: translateY(0) rotate(0deg); }
    25% { transform: translateY(-12px) rotate(10deg); }
    75% { transform: translateY(6px) rotate(-8deg); }
  }
  @keyframes floatDollar {
    0%, 100% { transform: translateY(0) scale(1); opacity: 0.6; }
    50% { transform: translateY(-14px) scale(1.1); opacity: 0.9; }
  }
  @keyframes fadeInUp {
    from { opacity: 0; transform: translateY(24px); }
    to { opacity: 1; transform: translateY(0); }
  }
  @keyframes slideInLeft {
    from { opacity: 0; transform: translateX(-40px); }
    to { opacity: 1; transform: translateX(0); }
  }
  @keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.06); }
  }
  @keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }
  @keyframes barGrow {
    from { transform: scaleY(0); }
    to { transform: scaleY(1); }
  }
  @keyframes shimmer {
    0% { background-position: -200% center; }
    100% { background-position: 200% center; }
  }

  /* ─── RIGHT PANEL ────────────────────────────────────────── */
  .right-panel {
    width: 480px;
    flex-shrink: 0;
    background: var(--white);
    overflow-y: auto;
    height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 2.5rem 2.75rem;
    position: relative;
    box-shadow: -20px 0 60px rgba(0,0,0,0.08);
    animation: slideInLeft 0.5s ease both;
  }

  .right-panel::-webkit-scrollbar { width: 4px; }
  .right-panel::-webkit-scrollbar-track { background: transparent; }
  .right-panel::-webkit-scrollbar-thumb { background: var(--gray-200); border-radius: 2px; }

  /* Top decoration */
  .right-panel::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 4px;
    background: linear-gradient(90deg, #6366f1, #8b5cf6, #e879f9);
  }

  .form-header { margin-bottom: 1.75rem; }
  .form-logo {
    display: flex; align-items: center; gap: 0.5rem;
    margin-bottom: 1.5rem;
  }
  .form-logo-icon {
    width: 36px; height: 36px;
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
  }
  .form-logo-name { font-size: 1.125rem; font-weight: 700; color: var(--gray-900); }
  .form-logo-name span { color: #6366f1; }

  .form-title {
    font-size: 1.625rem;
    font-weight: 700;
    color: var(--gray-900);
    letter-spacing: -0.02em;
    line-height: 1.2;
  }
  .form-subtitle {
    font-size: 0.875rem;
    color: var(--gray-500);
    margin-top: 0.375rem;
  }

  /* Demo credentials */
  .demo-box {
    background: linear-gradient(135deg, #f5f3ff, #ede9fe);
    border: 1px solid #ddd6fe;
    border-radius: 12px;
    padding: 1rem 1.125rem;
    margin-bottom: 1.5rem;
  }
  .demo-box-title {
    font-size: 0.75rem;
    font-weight: 600;
    color: #6366f1;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    margin-bottom: 0.625rem;
    display: flex; align-items: center; gap: 0.375rem;
  }
  .demo-credentials { display: flex; flex-direction: column; gap: 0.375rem; }
  .demo-cred {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0.5rem 0.75rem;
    background: rgba(255,255,255,0.7);
    border: 1px solid rgba(99,102,241,0.15);
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.15s;
    gap: 0.5rem;
  }
  .demo-cred:hover {
    background: rgba(255,255,255,0.95);
    border-color: rgba(99,102,241,0.4);
    transform: translateX(2px);
    box-shadow: 0 2px 8px rgba(99,102,241,0.12);
  }
  .demo-cred-role {
    font-size: 0.7rem;
    font-weight: 600;
    padding: 0.2rem 0.5rem;
    border-radius: 4px;
    flex-shrink: 0;
  }
  .role-admin { background: #fef3c7; color: #92400e; }
  .role-hr { background: #d1fae5; color: #065f46; }
  .role-emp { background: #dbeafe; color: #1e40af; }
  .demo-cred-info { flex: 1; min-width: 0; }
  .demo-cred-email { font-size: 0.75rem; font-weight: 500; color: var(--gray-700); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .demo-cred-pass { font-size: 0.7rem; color: var(--gray-400); }
  .demo-cred-use {
    font-size: 0.7rem;
    color: #6366f1;
    font-weight: 500;
    flex-shrink: 0;
    opacity: 0;
    transition: opacity 0.15s;
  }
  .demo-cred:hover .demo-cred-use { opacity: 1; }

  /* Alerts */
  .alert {
    display: flex;
    align-items: flex-start;
    gap: 0.625rem;
    padding: 0.875rem 1rem;
    border-radius: 10px;
    margin-bottom: 1.25rem;
    font-size: 0.875rem;
    animation: fadeInUp 0.3s ease both;
  }
  .alert-error {
    background: var(--red-50);
    border: 1px solid var(--red-200);
    color: var(--red-600);
  }
  .alert-success {
    background: var(--green-50);
    border: 1px solid var(--green-200);
    color: var(--green-600);
  }
  .alert-icon { flex-shrink: 0; margin-top: 1px; }

  /* Form */
  .form-group { margin-bottom: 1.125rem; }
  .form-label {
    display: block;
    font-size: 0.8125rem;
    font-weight: 600;
    color: var(--gray-700);
    margin-bottom: 0.4rem;
  }
  .input-wrapper {
    position: relative;
    display: flex;
    align-items: center;
  }
  .input-icon {
    position: absolute;
    left: 0.875rem;
    color: var(--gray-400);
    pointer-events: none;
    transition: color 0.2s;
    display: flex;
  }
  .form-input {
    width: 100%;
    padding: 0.75rem 0.875rem 0.75rem 2.75rem;
    border: 1.5px solid var(--gray-200);
    border-radius: 10px;
    font-size: 0.9375rem;
    font-family: inherit;
    color: var(--gray-900);
    background: var(--gray-50);
    transition: all 0.2s;
    outline: none;
  }
  .form-input::placeholder { color: var(--gray-400); }
  .form-input:focus {
    border-color: #6366f1;
    background: var(--white);
    box-shadow: 0 0 0 3px rgba(99,102,241,0.12);
  }
  .form-input:focus + .input-icon,
  .input-wrapper:focus-within .input-icon { color: #6366f1; }
  .input-wrapper:focus-within .input-icon { color: #6366f1; }

  .password-toggle {
    position: absolute;
    right: 0.875rem;
    background: none;
    border: none;
    cursor: pointer;
    color: var(--gray-400);
    padding: 0.25rem;
    display: flex;
    align-items: center;
    transition: color 0.2s;
    border-radius: 4px;
  }
  .password-toggle:hover { color: #6366f1; }

  .form-options {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1.375rem;
  }
  .remember-label {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    cursor: pointer;
    font-size: 0.8125rem;
    color: var(--gray-600);
    user-select: none;
  }
  .remember-checkbox {
    width: 16px; height: 16px;
    accent-color: #6366f1;
    cursor: pointer;
  }
  .forgot-link {
    font-size: 0.8125rem;
    color: #6366f1;
    text-decoration: none;
    font-weight: 500;
    transition: color 0.2s;
  }
  .forgot-link:hover { color: #4f46e5; text-decoration: underline; }

  /* Submit button */
  .btn-submit {
    width: 100%;
    padding: 0.875rem;
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 0.9375rem;
    font-weight: 600;
    font-family: inherit;
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    position: relative;
    overflow: hidden;
    letter-spacing: 0.01em;
  }
  .btn-submit::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent);
    background-size: 200% 100%;
    opacity: 0;
    transition: opacity 0.3s;
  }
  .btn-submit:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 25px rgba(99,102,241,0.4);
  }
  .btn-submit:hover::before { opacity: 1; animation: shimmer 1.5s infinite; }
  .btn-submit:active { transform: translateY(0); box-shadow: none; }
  .btn-submit:disabled { opacity: 0.7; cursor: not-allowed; transform: none; }

  .btn-spinner {
    display: none;
    width: 18px; height: 18px;
    border: 2px solid rgba(255,255,255,0.3);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 0.7s linear infinite;
  }

  /* Divider */
  .divider {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin: 1.25rem 0;
    color: var(--gray-400);
    font-size: 0.8125rem;
  }
  .divider::before, .divider::after {
    content: '';
    flex: 1;
    height: 1px;
    background: var(--gray-200);
  }

  /* Register link */
  .register-link {
    text-align: center;
    font-size: 0.875rem;
    color: var(--gray-500);
  }
  .register-link a {
    color: #6366f1;
    font-weight: 600;
    text-decoration: none;
    transition: color 0.2s;
  }
  .register-link a:hover { color: #4f46e5; text-decoration: underline; }

  /* Footer */
  .form-footer {
    margin-top: 1.5rem;
    padding-top: 1.25rem;
    border-top: 1px solid var(--gray-100);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.375rem;
    font-size: 0.75rem;
    color: var(--gray-400);
  }
  .form-footer svg { color: var(--gray-300); }

  /* ─── RESPONSIVE ─────────────────────────────────────────── */
  @media (max-width: 860px) {
    .left-panel { display: none; }
    .right-panel {
      width: 100%;
      padding: 2rem 1.5rem;
      box-shadow: none;
    }
  }
  @media (max-width: 400px) {
    .right-panel { padding: 1.5rem 1.25rem; }
    .form-title { font-size: 1.375rem; }
  }
</style>
</head>
<body>

<!-- ═══════════════════════════════════════════════════════════
     LEFT PANEL
════════════════════════════════════════════════════════════ -->
<div class="left-panel">
  <!-- Glowing orbs -->
  <div class="orb orb-1"></div>
  <div class="orb orb-2"></div>
  <div class="orb orb-3"></div>

  <div class="left-content">

    <!-- Brand -->
    <div class="brand">
      <div class="brand-icon">
        <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
          <rect x="3" y="3" width="8" height="8" rx="2" fill="#a5b4fc"/>
          <rect x="15" y="3" width="8" height="8" rx="2" fill="#e879f9"/>
          <rect x="3" y="15" width="8" height="8" rx="2" fill="#e879f9"/>
          <rect x="15" y="15" width="8" height="8" rx="2" fill="#a5b4fc"/>
        </svg>
      </div>
      <span class="brand-name">Payroll<span>Pro</span></span>
    </div>

    <p class="brand-tagline">HR &amp; Payroll Management System</p>

    <!-- Illustration area — animated people scene -->
    <div class="illustration-area" style="height:auto;padding:0">
      <?= loginIllustration() ?>
    </div><!-- /illustration-area -->

    <!-- Features -->
    <div class="features">
      <div class="feature-item">
        <div class="feature-icon">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M8 1L10.5 6H15L11 9.5L12.5 15L8 12L3.5 15L5 9.5L1 6H5.5L8 1Z" fill="#fbbf24"/>
          </svg>
        </div>
        <span class="feature-text">Automated payroll processing &amp; tax calculation</span>
      </div>
      <div class="feature-item">
        <div class="feature-icon">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <rect x="1" y="3" width="14" height="11" rx="2" stroke="#a5b4fc" stroke-width="1.5"/>
            <path d="M1 7h14" stroke="#a5b4fc" stroke-width="1.5"/>
            <circle cx="5" cy="11" r="1" fill="#a5b4fc"/>
            <circle cx="8" cy="11" r="1" fill="#a5b4fc"/>
          </svg>
        </div>
        <span class="feature-text">Leave &amp; attendance management</span>
      </div>
      <div class="feature-item">
        <div class="feature-icon">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M2 12 L5 8 L8 10 L11 5 L14 7" stroke="#34d399" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 14 h12" stroke="#34d399" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
        </div>
        <span class="feature-text">Real-time reports &amp; analytics dashboard</span>
      </div>
    </div>

    <!-- Stats -->
    <div class="stats-row">
      <div class="stat-card">
        <div class="stat-value">500+</div>
        <div class="stat-label">Employees</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">99.9%</div>
        <div class="stat-label">Uptime</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">ETB</div>
        <div class="stat-label">Currency</div>
      </div>
    </div>

  </div><!-- /left-content -->
</div><!-- /left-panel -->

<!-- ═══════════════════════════════════════════════════════════
     RIGHT PANEL
════════════════════════════════════════════════════════════ -->
<div class="right-panel">

  <div class="form-header">
    <!-- Logo -->
    <div class="form-logo">
      <div class="form-logo-icon">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <rect x="2" y="2" width="6" height="6" rx="1.5" fill="white"/>
          <rect x="12" y="2" width="6" height="6" rx="1.5" fill="rgba(255,255,255,0.6)"/>
          <rect x="2" y="12" width="6" height="6" rx="1.5" fill="rgba(255,255,255,0.6)"/>
          <rect x="12" y="12" width="6" height="6" rx="1.5" fill="white"/>
        </svg>
      </div>
      <span class="form-logo-name">Payroll<span>Pro</span></span>
    </div>
    <h1 class="form-title">Sign in to your account</h1>
    <p class="form-subtitle">Welcome back! Enter your credentials to continue.</p>
  </div>

  <!-- Demo credentials box -->
  <div class="demo-box">
    <div class="demo-box-title">
      <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
        <circle cx="6" cy="6" r="5" stroke="#6366f1" stroke-width="1.5"/>
        <path d="M6 5v4M6 3.5v.5" stroke="#6366f1" stroke-width="1.5" stroke-linecap="round"/>
      </svg>
      Demo Credentials — click to fill
    </div>
    <div class="demo-credentials">
      <div class="demo-cred" onclick="fillCreds('admin@payrollpro.com','Admin123')" role="button" tabindex="0">
        <span class="demo-cred-role role-admin">Admin</span>
        <div class="demo-cred-info">
          <div class="demo-cred-email">admin@payrollpro.com</div>
          <div class="demo-cred-pass">Password: Admin123</div>
        </div>
        <span class="demo-cred-use">Use &rarr;</span>
      </div>
      <div class="demo-cred" onclick="fillCreds('hr@payrollpro.com','Hr1234')" role="button" tabindex="0">
        <span class="demo-cred-role role-hr">HR</span>
        <div class="demo-cred-info">
          <div class="demo-cred-email">hr@payrollpro.com</div>
          <div class="demo-cred-pass">Password: Hr1234</div>
        </div>
        <span class="demo-cred-use">Use &rarr;</span>
      </div>
      <div class="demo-cred" onclick="fillCreds('john@payrollpro.com','John123')" role="button" tabindex="0">
        <span class="demo-cred-role role-emp">Employee</span>
        <div class="demo-cred-info">
          <div class="demo-cred-email">john@payrollpro.com</div>
          <div class="demo-cred-pass">Password: John123</div>
        </div>
        <span class="demo-cred-use">Use &rarr;</span>
      </div>
    </div>
  </div>

  <!-- Error alert -->
  <?php if (!empty($error ?? '')): ?>
  <div class="alert alert-error" role="alert">
    <svg class="alert-icon" width="18" height="18" viewBox="0 0 18 18" fill="none">
      <circle cx="9" cy="9" r="8" stroke="#dc2626" stroke-width="1.5"/>
      <path d="M9 5v5M9 12.5v.5" stroke="#dc2626" stroke-width="1.5" stroke-linecap="round"/>
    </svg>
    <span><?= htmlspecialchars($error ?? '', ENT_QUOTES, 'UTF-8') ?></span>
  </div>
  <?php endif; ?>

  <!-- Success alert -->
  <?php if (!empty($success ?? '')): ?>
  <div class="alert alert-success" role="alert">
    <svg class="alert-icon" width="18" height="18" viewBox="0 0 18 18" fill="none">
      <circle cx="9" cy="9" r="8" stroke="#16a34a" stroke-width="1.5"/>
      <path d="M5.5 9l2.5 2.5 4.5-5" stroke="#16a34a" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <span><?= htmlspecialchars($success ?? '', ENT_QUOTES, 'UTF-8') ?></span>
  </div>
  <?php endif; ?>

  <!-- Login form -->
  <form method="POST" action="<?php echo htmlspecialchars(rtrim(BASE_URL,'/').'/', ENT_QUOTES, 'UTF-8') ?>auth/login" id="loginForm" novalidate>
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf ?? '', ENT_QUOTES, 'UTF-8') ?>">

    <!-- Email -->
    <div class="form-group">
      <label class="form-label" for="email">Email address</label>
      <div class="input-wrapper">
        <span class="input-icon">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <rect x="1.5" y="3.5" width="15" height="11" rx="2" stroke="currentColor" stroke-width="1.5"/>
            <path d="M1.5 6.5l7.5 5 7.5-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
        </span>
        <input
          type="email"
          id="email"
          name="email"
          class="form-input"
          placeholder="you@company.com"
          autocomplete="email"
          required
          value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
        >
      </div>
    </div>

    <!-- Password -->
    <div class="form-group">
      <label class="form-label" for="password">Password</label>
      <div class="input-wrapper">
        <span class="input-icon">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <rect x="3" y="8" width="12" height="8" rx="2" stroke="currentColor" stroke-width="1.5"/>
            <path d="M6 8V5.5a3 3 0 016 0V8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <circle cx="9" cy="12" r="1.25" fill="currentColor"/>
          </svg>
        </span>
        <input
          type="password"
          id="password"
          name="password"
          class="form-input"
          placeholder="Enter your password"
          autocomplete="current-password"
          required
          style="padding-right: 3rem;"
        >
        <button type="button" class="password-toggle" id="togglePassword" aria-label="Toggle password visibility">
          <!-- Eye icon (show) -->
          <svg id="eyeShow" width="18" height="18" viewBox="0 0 18 18" fill="none">
            <path d="M1 9s3-6 8-6 8 6 8 6-3 6-8 6-8-6-8-6z" stroke="currentColor" stroke-width="1.5"/>
            <circle cx="9" cy="9" r="2.5" stroke="currentColor" stroke-width="1.5"/>
          </svg>
          <!-- Eye-off icon (hide) -->
          <svg id="eyeHide" width="18" height="18" viewBox="0 0 18 18" fill="none" style="display:none;">
            <path d="M1 1l16 16M7.5 7.6A2.5 2.5 0 0011.4 11.5M4.2 4.3C2.3 5.6 1 9 1 9s3 6 8 6c1.6 0 3-.5 4.2-1.3M7 3.1C7.6 3 8.3 3 9 3c5 0 8 6 8 6s-.8 1.6-2.2 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
        </button>
      </div>
    </div>

    <!-- Options row -->
    <div class="form-options">
      <label class="remember-label">
        <input type="checkbox" name="remember" class="remember-checkbox" id="remember">
        Remember me
      </label>
      <a href="#" class="forgot-link">Forgot password?</a>
    </div>

    <!-- Submit -->
    <button type="submit" class="btn-submit" id="submitBtn">
      <span id="btnText">Sign In</span>
      <div class="btn-spinner" id="btnSpinner"></div>
      <svg id="btnArrow" width="18" height="18" viewBox="0 0 18 18" fill="none">
        <path d="M3 9h12M10 5l4 4-4 4" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </button>
  </form>

  <div class="divider">or</div>

  <div class="register-link">
    Don&rsquo;t have an account?
    <a href="<?php echo htmlspecialchars(rtrim(BASE_URL,'/').'/', ENT_QUOTES, 'UTF-8') ?>auth/register">Create account</a>
  </div>

  <div class="form-footer">
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <rect x="2" y="6" width="10" height="7" rx="1.5" stroke="currentColor" stroke-width="1.2"/>
      <path d="M4.5 6V4.5a2.5 2.5 0 015 0V6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/>
    </svg>
    Secured with 256-bit SSL encryption
  </div>

</div><!-- /right-panel -->

<script>
// ── Fill demo credentials ──────────────────────────────────
function fillCreds(email, password) {
  const emailInput = document.getElementById('email');
  const passInput  = document.getElementById('password');
  if (!emailInput || !passInput) return;

  // Animate fill
  emailInput.value = '';
  passInput.value  = '';
  emailInput.focus();

  let i = 0;
  const typeEmail = setInterval(() => {
    emailInput.value += email[i++];
    if (i >= email.length) {
      clearInterval(typeEmail);
      let j = 0;
      const typePass = setInterval(() => {
        passInput.value += password[j++];
        if (j >= password.length) clearInterval(typePass);
      }, 40);
    }
  }, 30);
}

// Keyboard support for demo cred items
document.querySelectorAll('.demo-cred').forEach(el => {
  el.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      el.click();
    }
  });
});

// ── Password toggle ────────────────────────────────────────
const toggleBtn = document.getElementById('togglePassword');
const passField = document.getElementById('password');
const eyeShow   = document.getElementById('eyeShow');
const eyeHide   = document.getElementById('eyeHide');

if (toggleBtn) {
  toggleBtn.addEventListener('click', () => {
    const isPassword = passField.type === 'password';
    passField.type   = isPassword ? 'text' : 'password';
    eyeShow.style.display = isPassword ? 'none'  : 'block';
    eyeHide.style.display = isPassword ? 'block' : 'none';
    toggleBtn.setAttribute('aria-label', isPassword ? 'Hide password' : 'Show password');
  });
}

// ── Form submit spinner ────────────────────────────────────
const loginForm = document.getElementById('loginForm');
const submitBtn = document.getElementById('submitBtn');
const btnText   = document.getElementById('btnText');
const btnSpinner = document.getElementById('btnSpinner');
const btnArrow  = document.getElementById('btnArrow');

if (loginForm) {
  loginForm.addEventListener('submit', function(e) {
    const email    = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;

    // Basic client-side validation
    if (!email || !password) {
      e.preventDefault();
      if (!email) document.getElementById('email').focus();
      else document.getElementById('password').focus();
      return;
    }

    // Show spinner
    submitBtn.disabled = true;
    btnText.textContent = 'Signing in...';
    if (btnSpinner) btnSpinner.style.display = 'block';
    if (btnArrow)   btnArrow.style.display   = 'none';
  });
}

// ── Input focus effects ────────────────────────────────────
document.querySelectorAll('.form-input').forEach(input => {
  input.addEventListener('focus', () => {
    input.closest('.input-wrapper').querySelector('.input-icon').style.color = '#6366f1';
  });
  input.addEventListener('blur', () => {
    input.closest('.input-wrapper').querySelector('.input-icon').style.color = '';
  });
});
</script>

</body>
</html>
