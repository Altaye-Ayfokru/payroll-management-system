﻿<?php
// Load employees list for HR add-record modal
$empList = [];
if (isHR()) {
    try {
        $db = Database::getInstance();
        $empList = $db->query(
            "SELECT e.id, u.name, e.employee_code, e.department
             FROM employees e JOIN users u ON u.id = e.user_id
             WHERE e.status='active' AND e.deleted_at IS NULL
             ORDER BY u.name ASC"
        )->fetchAll();
    } catch (Exception $ex) { $empList = []; }
}
?>

<!-- Hero Banner -->
<div class="page-hero hero-attendance">
  <div class="hero-orb hero-orb-1"></div>
  <div class="hero-orb hero-orb-2"></div>
  <div class="page-hero-content">
    <div class="hero-badge"><span class="hero-badge-dot"></span> <?= date('l, F d Y') ?></div>
    <div class="page-hero-title">Attendance Tracking</div>
    <div class="page-hero-sub">Monitor daily check-ins, track overtime, and manage attendance records for all employees.</div>
    <div class="page-hero-actions">
      <?php if (isHR()): ?>
      <button onclick="openModal('addAttendanceModal')" class="page-hero-btn page-hero-btn-white">
        <i class="fas fa-plus"></i> Add Record
      </button>
      <?php endif; ?>
      <a href="<?= url('attendance/calendar') ?>" class="page-hero-btn page-hero-btn-outline">
        <i class="fas fa-calendar"></i> Calendar View
      </a>
    </div>
  </div>
  <!-- Attendance hero illustration — flat design, proper proportions -->
  <svg class="page-hero-illustration" viewBox="0 0 260 200" fill="none"
       xmlns="http://www.w3.org/2000/svg" style="overflow:visible">
    <defs>
      <filter id="att-sh" x="-10%" y="-10%" width="120%" height="120%">
        <feDropShadow dx="0" dy="4" stdDeviation="6" flood-color="rgba(0,0,0,.2)"/>
      </filter>
      <style>
        .att-p1 { animation: attF1 3.6s ease-in-out infinite; }
        .att-p2 { animation: attF2 4.2s ease-in-out infinite 0.8s; }
        .att-card { animation: attCard 0.7s cubic-bezier(.34,1.2,.64,1) 0.3s both; }
        .att-slip { animation: attSlip 0.7s cubic-bezier(.34,1.2,.64,1) 0.6s both; }
        .att-chk  { animation: attChk  0.5s cubic-bezier(.34,1.56,.64,1) 1.2s both; }
        @keyframes attF1   { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
        @keyframes attF2   { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-11px)} }
        @keyframes attCard { from{opacity:0;transform:translateY(-12px)} to{opacity:1;transform:translateY(0)} }
        @keyframes attSlip { from{opacity:0;transform:translateX(-10px)} to{opacity:1;transform:translateX(0)} }
        @keyframes attChk  { 0%{transform:scale(0)} 70%{transform:scale(1.25)} 100%{transform:scale(1)} }
      </style>
    </defs>

    <!-- ── Ground shadows ── -->
    <ellipse cx="90"  cy="196" rx="52" ry="7" fill="rgba(0,0,0,.18)"/>
    <ellipse cx="185" cy="196" rx="48" ry="7" fill="rgba(0,0,0,.18)"/>

    <!-- ══════════════════════════════════════════
         PERSON 1 — HR Officer
         Teal uniform, dark skin, holding clipboard
    ══════════════════════════════════════════ -->
    <g class="att-p1" transform="translate(42,38)">

      <!-- Legs -->
      <rect x="22" y="118" width="18" height="52" rx="7" fill="#0e7490"/>
      <rect x="44" y="118" width="18" height="52" rx="7" fill="#0e7490"/>
      <!-- Shoes -->
      <ellipse cx="31"  cy="172" rx="16" ry="7" fill="#1e293b"/>
      <ellipse cx="53"  cy="172" rx="16" ry="7" fill="#1e293b"/>

      <!-- Body — teal uniform -->
      <rect x="12" y="62" width="60" height="60" rx="14" fill="#0ea5e9"/>
      <!-- Collar V -->
      <polygon points="42,62 34,78 42,72 50,78" fill="white" opacity=".85"/>
      <!-- Uniform pocket -->
      <rect x="16" y="76" width="18" height="14" rx="3" fill="rgba(255,255,255,.2)"/>
      <rect x="18" y="78" width="14" height="3" rx="1.5" fill="rgba(255,255,255,.5)"/>

      <!-- Left arm — holding clipboard -->
      <rect x="-8" y="68" width="22" height="12" rx="6" fill="#0ea5e9"/>
      <!-- Right arm -->
      <rect x="70" y="68" width="22" height="12" rx="6" fill="#0ea5e9"/>

      <!-- Left hand -->
      <ellipse cx="4"  cy="80" rx="8" ry="6" fill="#c68642"/>
      <!-- Right hand -->
      <ellipse cx="82" cy="80" rx="8" ry="6" fill="#c68642"/>

      <!-- Clipboard in left hand -->
      <g class="att-slip">
        <rect x="-28" y="72" width="38" height="52" rx="5" fill="#f8fafc" filter="url(#att-sh)"/>
        <rect x="-28" y="72" width="38" height="14" rx="5" fill="#6366f1"/>
        <rect x="-28" y="79" width="38" height="7" fill="#6366f1"/>
        <rect x="-24" y="76" width="22" height="4" rx="2" fill="rgba(255,255,255,.8)"/>
        <!-- Rows -->
        <rect x="-24" y="90" width="30" height="3" rx="1.5" fill="#94a3b8"/>
        <rect x="-24" y="96" width="22" height="3" rx="1.5" fill="#94a3b8"/>
        <rect x="-24" y="102" width="26" height="3" rx="1.5" fill="#94a3b8"/>
        <line x1="-24" y1="108" x2="6" y2="108" stroke="#e2e8f0" stroke-width="1" stroke-dasharray="3 2"/>
        <rect x="-24" y="112" width="30" height="6" rx="3" fill="#10b981"/>
        <!-- Check badge -->
        <g class="att-chk">
          <circle cx="8" cy="76" r="9" fill="#10b981"/>
          <path d="M4 76 L7 79 L12 73" stroke="white" stroke-width="2"
                fill="none" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
      </g>

      <!-- Neck -->
      <rect x="36" y="48" width="12" height="16" rx="6" fill="#c68642"/>

      <!-- Head -->
      <circle cx="42" cy="36" r="22" fill="#c68642"/>

      <!-- Hair — natural afro -->
      <ellipse cx="42" cy="18" rx="24" ry="17" fill="#1a0a00"/>
      <ellipse cx="42" cy="15" rx="20" ry="13" fill="#2d1200"/>
      <circle cx="20" cy="26" r="10" fill="#1a0a00"/>
      <circle cx="64" cy="26" r="10" fill="#1a0a00"/>

      <!-- Ears -->
      <ellipse cx="20" cy="36" rx="5" ry="7" fill="#c68642"/>
      <ellipse cx="64" cy="36" rx="5" ry="7" fill="#c68642"/>

      <!-- Eyes -->
      <circle cx="35" cy="36" r="4" fill="white"/>
      <circle cx="49" cy="36" r="4" fill="white"/>
      <circle cx="36" cy="37" r="2.5" fill="#1a0a00"/>
      <circle cx="50" cy="37" r="2.5" fill="#1a0a00"/>
      <!-- Eye shine -->
      <circle cx="37" cy="36" r="1" fill="white"/>
      <circle cx="51" cy="36" r="1" fill="white"/>

      <!-- Smile -->
      <path d="M35 45 Q42 51 49 45" stroke="#8b4513" stroke-width="1.5"
            fill="none" stroke-linecap="round"/>

      <!-- Earring -->
      <circle cx="20" cy="40" r="2.5" fill="#fbbf24"/>
      <circle cx="64" cy="40" r="2.5" fill="#fbbf24"/>

    </g><!-- /person 1 -->

    <!-- ══════════════════════════════════════════
         PERSON 2 — Manager
         Dark suit, medium skin, holding tablet
    ══════════════════════════════════════════ -->
    <g class="att-p2" transform="translate(140,45)">

      <!-- Legs -->
      <rect x="20" y="112" width="18" height="48" rx="7" fill="#1e293b"/>
      <rect x="42" y="112" width="18" height="48" rx="7" fill="#1e293b"/>
      <!-- Shoes -->
      <ellipse cx="29"  cy="162" rx="16" ry="7" fill="#0f172a"/>
      <ellipse cx="51"  cy="162" rx="16" ry="7" fill="#0f172a"/>

      <!-- Suit body -->
      <rect x="10" y="58" width="60" height="58" rx="12" fill="#1e293b"/>
      <!-- Shirt -->
      <rect x="28" y="58" width="24" height="34" rx="4" fill="white"/>
      <!-- Tie -->
      <polygon points="40,60 35,76 40,120 45,76" fill="#6366f1"/>
      <polygon points="36,60 44,60 40,67" fill="#4f46e5"/>
      <!-- Lapels -->
      <polygon points="10,58 28,58 18,84" fill="#0f172a"/>
      <polygon points="70,58 52,58 62,84" fill="#0f172a"/>
      <!-- Pocket square -->
      <polygon points="14,66 22,66 18,58" fill="white" opacity=".8"/>

      <!-- Left arm -->
      <rect x="-4" y="64" width="16" height="12" rx="6" fill="#1e293b"/>
      <!-- Right arm — holding tablet -->
      <rect x="68" y="64" width="16" height="12" rx="6" fill="#1e293b"/>

      <!-- Hands -->
      <ellipse cx="4"  cy="76" rx="8" ry="6" fill="#d4956a"/>
      <ellipse cx="76" cy="76" rx="8" ry="6" fill="#d4956a"/>

      <!-- Tablet in right hand -->
      <rect x="68" y="58" width="46" height="68" rx="8" fill="#0f172a" filter="url(#att-sh)"/>
      <rect x="72" y="62" width="38" height="60" rx="6" fill="#1e293b"/>
      <!-- Tablet header -->
      <rect x="72" y="62" width="38" height="14" rx="6" fill="#0ea5e9"/>
      <rect x="72" y="69" width="38" height="7" fill="#0ea5e9"/>
      <rect x="75" y="65" width="24" height="4" rx="2" fill="rgba(255,255,255,.85)"/>
      <!-- Attendance bars on tablet -->
      <rect x="75" y="80" width="8" height="22" rx="3" fill="#d1fae5"/>
      <rect x="75" y="86" width="8" height="16" rx="3" fill="#10b981"/>
      <rect x="86" y="80" width="8" height="22" rx="3" fill="#fee2e2"/>
      <rect x="86" y="94" width="8" height="8"  rx="3" fill="#ef4444"/>
      <rect x="97" y="80" width="8" height="22" rx="3" fill="#fef3c7"/>
      <rect x="97" y="90" width="8" height="12" rx="3" fill="#f59e0b"/>
      <!-- Labels -->
      <text x="79" y="108" text-anchor="middle" font-size="5.5" fill="#94a3b8"
            font-family="Arial,sans-serif">P</text>
      <text x="90" y="108" text-anchor="middle" font-size="5.5" fill="#94a3b8"
            font-family="Arial,sans-serif">A</text>
      <text x="101" y="108" text-anchor="middle" font-size="5.5" fill="#94a3b8"
            font-family="Arial,sans-serif">L</text>
      <!-- Percentage -->
      <text x="91" y="122" text-anchor="middle" font-size="11" fill="white"
            font-weight="bold" font-family="Arial,sans-serif">87%</text>
      <!-- Home button -->
      <circle cx="91" cy="128" r="3" fill="#334155"/>

      <!-- Neck -->
      <rect x="34" y="44" width="12" height="16" rx="6" fill="#d4956a"/>

      <!-- Head -->
      <circle cx="40" cy="32" r="22" fill="#d4956a"/>

      <!-- Hair — short, dark brown -->
      <ellipse cx="40" cy="13" rx="22" ry="14" fill="#3d1f0a"/>
      <ellipse cx="40" cy="11" rx="18" ry="10" fill="#5c3317"/>

      <!-- Ears -->
      <ellipse cx="18" cy="32" rx="5" ry="7" fill="#d4956a"/>
      <ellipse cx="62" cy="32" rx="5" ry="7" fill="#d4956a"/>

      <!-- Eyes -->
      <circle cx="33" cy="32" r="4" fill="white"/>
      <circle cx="47" cy="32" r="4" fill="white"/>
      <circle cx="34" cy="33" r="2.5" fill="#3d2b1f"/>
      <circle cx="48" cy="33" r="2.5" fill="#3d2b1f"/>
      <circle cx="35" cy="32" r="1" fill="white"/>
      <circle cx="49" cy="32" r="1" fill="white"/>

      <!-- Eyebrows -->
      <path d="M29 26 Q33 23 37 26" stroke="#3d1f0a" stroke-width="1.8"
            fill="none" stroke-linecap="round"/>
      <path d="M43 26 Q47 23 51 26" stroke="#3d1f0a" stroke-width="1.8"
            fill="none" stroke-linecap="round"/>

      <!-- Smile -->
      <path d="M33 41 Q40 47 47 41" stroke="#c0845a" stroke-width="1.5"
            fill="none" stroke-linecap="round"/>

    </g><!-- /person 2 -->

    <!-- ══════════════════════════════════════════
         FLOATING ATTENDANCE CARD (top)
    ══════════════════════════════════════════ -->
    <g class="att-card" transform="translate(60,2)">
      <!-- Card shadow + body -->
      <rect x="0" y="0" width="148" height="82" rx="14" fill="white"
            filter="url(#att-sh)" opacity=".97"/>
      <!-- Blue header -->
      <rect x="0" y="0" width="148" height="28" rx="14" fill="#0ea5e9"/>
      <rect x="0" y="14" width="148" height="14" fill="#0ea5e9"/>
      <text x="12" y="19" font-size="10" fill="white" font-weight="bold"
            font-family="Arial,sans-serif">Today's Attendance</text>

      <!-- Bar chart area -->
      <!-- Present bar -->
      <rect x="14" y="34" width="22" height="32" rx="5" fill="#d1fae5"/>
      <rect x="14" y="44" width="22" height="22" rx="5" fill="#10b981"/>
      <text x="25" y="74" text-anchor="middle" font-size="7" fill="#64748b"
            font-family="Arial,sans-serif">P</text>

      <!-- Absent bar -->
      <rect x="42" y="34" width="22" height="32" rx="5" fill="#fee2e2"/>
      <rect x="42" y="54" width="22" height="12" rx="5" fill="#ef4444"/>
      <text x="53" y="74" text-anchor="middle" font-size="7" fill="#64748b"
            font-family="Arial,sans-serif">A</text>

      <!-- Late bar -->
      <rect x="70" y="34" width="22" height="32" rx="5" fill="#fef3c7"/>
      <rect x="70" y="48" width="22" height="18" rx="5" fill="#f59e0b"/>
      <text x="81" y="74" text-anchor="middle" font-size="7" fill="#64748b"
            font-family="Arial,sans-serif">L</text>

      <!-- Percentage text -->
      <text x="116" y="56" text-anchor="middle" font-size="22" fill="#0f172a"
            font-weight="bold" font-family="Arial,sans-serif">87%</text>
      <text x="116" y="68" text-anchor="middle" font-size="8" fill="#64748b"
            font-family="Arial,sans-serif">Present rate</text>
    </g>

  </svg>
</div>

<div class="page-header">
  <div>
    <div class="page-header-title">Attendance</div>
    <div class="page-header-sub"><?= date('l, F d Y') ?></div>
  </div>
  <div class="page-header-actions">
    <a href="<?= url('attendance/calendar') ?>" class="btn btn-outline">
      <i class="fas fa-calendar"></i> Calendar View
    </a>
    <a href="<?= url('attendance/report') ?>" class="btn btn-outline">
      <i class="fas fa-chart-bar"></i> Report
    </a>
    <?php if (isHR()): ?>
    <button class="btn btn-primary" onclick="openModal('addAttendanceModal')">
      <i class="fas fa-plus"></i> Add Record
    </button>
    <?php endif; ?>
  </div>
</div>

<!-- Stats Row -->
<div class="summary-row" style="margin-bottom:20px">
  <div class="summary-chip">
    <div class="summary-chip-icon" style="background:#d1fae5;color:#10b981"><i class="fas fa-user-check"></i></div>
    <div><div class="summary-chip-val"><?= $todayStats['present'] ?? 0 ?></div><div class="summary-chip-label">Present</div></div>
  </div>
  <div class="summary-chip">
    <div class="summary-chip-icon" style="background:#fee2e2;color:#ef4444"><i class="fas fa-user-times"></i></div>
    <div><div class="summary-chip-val"><?= $todayStats['absent'] ?? 0 ?></div><div class="summary-chip-label">Absent</div></div>
  </div>
  <div class="summary-chip">
    <div class="summary-chip-icon" style="background:#fef3c7;color:#f59e0b"><i class="fas fa-clock"></i></div>
    <div><div class="summary-chip-val"><?= $todayStats['late'] ?? 0 ?></div><div class="summary-chip-label">Late</div></div>
  </div>
  <div class="summary-chip">
    <div class="summary-chip-icon" style="background:#e0e7ff;color:#6366f1"><i class="fas fa-users"></i></div>
    <div><div class="summary-chip-val"><?= $todayStats['total'] ?? 0 ?></div><div class="summary-chip-label">Total Staff</div></div>
  </div>
</div>

<div style="display:grid;grid-template-columns:<?= isset($myEmployee) ? '2fr 1fr' : '1fr' ?>;gap:20px">

  <!-- Attendance Table -->
  <div>
    <!-- Date Filter -->
    <div class="filter-bar">
      <form method="GET" action="<?= url('attendance') ?>" style="display:flex;gap:10px;align-items:center">
        <label style="font-size:.82rem;font-weight:600;color:#374151;white-space:nowrap">Filter by date:</label>
        <input type="date" name="date" class="form-control" value="<?= e($date) ?>" style="width:auto">
        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button>
        <?php if ($date !== date('Y-m-d')): ?>
        <a href="<?= url('attendance') ?>" class="btn btn-outline btn-sm"><i class="fas fa-times"></i> Today</a>
        <?php endif; ?>
      </form>
    </div>

    <div class="card">
      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Employee</th>
              <th>Date</th>
              <th>Check In</th>
              <th>Check Out</th>
              <th>Hours</th>
              <th>Overtime</th>
              <th>Status</th>
              <?php if (isHR()): ?><th>Actions</th><?php endif; ?>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($records)): ?>
            <tr><td colspan="<?= isHR() ? 8 : 7 ?>">
              <div class="empty-state">
                <div class="empty-state-icon"><i class="fas fa-clock"></i></div>
                <div class="empty-state-title">No attendance records for <?= e($date) ?></div>
                <?php if (isHR()): ?>
                <div class="empty-state-text">
                  <button class="btn btn-primary btn-sm" style="margin-top:10px" onclick="openModal('addAttendanceModal')">
                    <i class="fas fa-plus"></i> Add Record
                  </button>
                </div>
                <?php endif; ?>
              </div>
            </td></tr>
            <?php else: ?>
            <?php foreach ($records as $r): ?>
            <tr>
              <td>
                <div class="emp-cell">
                  <div>
                    <div class="emp-info-name"><?= e($r['employee_name']) ?></div>
                    <div class="emp-info-code"><?= e($r['department'] ?? '') ?></div>
                  </div>
                </div>
              </td>
              <td><?= formatDate($r['date'], 'M d, Y') ?></td>
              <td><?= $r['check_in'] ? date('h:i A', strtotime($r['check_in'])) : '<span style="color:#94a3b8">—</span>' ?></td>
              <td><?= $r['check_out'] ? date('h:i A', strtotime($r['check_out'])) : '<span style="color:#94a3b8">—</span>' ?></td>
              <td><?= ($r['hours_worked'] ?? 0) > 0 ? round($r['hours_worked'], 2) . 'h' : '<span style="color:#94a3b8">—</span>' ?></td>
              <td>
                <?php if (($r['overtime_hours'] ?? 0) > 0): ?>
                <span style="color:#f59e0b;font-weight:600"><?= round($r['overtime_hours'], 2) ?>h</span>
                <?php else: ?>
                <span style="color:#94a3b8">—</span>
                <?php endif; ?>
              </td>
              <td><?= statusBadge($r['status']) ?></td>
              <?php if (isHR()): ?>
              <td>
                <button class="btn btn-outline btn-sm btn-icon" title="Edit"
                        onclick="editRecord(<?= $r['id'] ?>, '<?= e($r['check_in'] ?? '') ?>', '<?= e($r['check_out'] ?? '') ?>', '<?= e($r['status']) ?>')">
                  <i class="fas fa-edit"></i>
                </button>
              </td>
              <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <?php if (isset($pager) && $pager['total_pages'] > 1): ?>
      <div class="pagination">
        <?php if ($pager['has_prev']): ?>
        <a href="?page=<?= $pager['current_page'] - 1 ?>&date=<?= urlencode($date) ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a>
        <?php endif; ?>
        <?php for ($i = max(1, $pager['current_page'] - 2); $i <= min($pager['total_pages'], $pager['current_page'] + 2); $i++): ?>
        <a href="?page=<?= $i ?>&date=<?= urlencode($date) ?>" class="page-btn <?= $i === $pager['current_page'] ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
        <?php if ($pager['has_next']): ?>
        <a href="?page=<?= $pager['current_page'] + 1 ?>&date=<?= urlencode($date) ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Right: Check-in Widget (employees only) -->
  <?php if (isset($myEmployee)): ?>
  <div>
    <div class="checkin-widget" style="margin-bottom:20px">
      <div class="checkin-time" id="liveClock">--:--:--</div>
      <div class="checkin-date"><?= date('l, F d Y') ?></div>
      <?php if (!empty($myRecord)): ?>
        <div class="checkin-status">
          <i class="fas fa-check-circle"></i>
          Checked in at <?= date('h:i A', strtotime($myRecord['check_in'])) ?>
          <?php if (!empty($myRecord['check_out'])): ?>
          &middot; Out at <?= date('h:i A', strtotime($myRecord['check_out'])) ?>
          <?php endif; ?>
        </div>
      <?php else: ?>
        <div class="checkin-status">Not checked in yet today</div>
      <?php endif; ?>
      <div class="checkin-btns">
        <button class="checkin-btn checkin-btn-in" id="checkInBtn"
                <?= !empty($myRecord) ? 'disabled' : '' ?>
                onclick="doCheckIn()">
          <i class="fas fa-sign-in-alt"></i> Check In
        </button>
        <button class="checkin-btn checkin-btn-out" id="checkOutBtn"
                <?= (empty($myRecord) || !empty($myRecord['check_out'])) ? 'disabled' : '' ?>
                onclick="doCheckOut()">
          <i class="fas fa-sign-out-alt"></i> Check Out
        </button>
      </div>
    </div>

    <?php if (!empty($mySummary)): ?>
    <div class="card">
      <div class="card-header"><span class="card-title"><i class="fas fa-calendar-alt" style="color:#6366f1;margin-right:6px"></i>This Month</span></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <div style="text-align:center;padding:12px;background:#d1fae5;border-radius:10px">
            <div style="font-size:1.4rem;font-weight:800;color:#10b981"><?= $mySummary['present_days'] ?? 0 ?></div>
            <div style="font-size:.72rem;color:#065f46;font-weight:600">Present</div>
          </div>
          <div style="text-align:center;padding:12px;background:#fee2e2;border-radius:10px">
            <div style="font-size:1.4rem;font-weight:800;color:#ef4444"><?= $mySummary['absent_days'] ?? 0 ?></div>
            <div style="font-size:.72rem;color:#991b1b;font-weight:600">Absent</div>
          </div>
          <div style="text-align:center;padding:12px;background:#fef3c7;border-radius:10px">
            <div style="font-size:1.4rem;font-weight:800;color:#f59e0b"><?= $mySummary['late_days'] ?? 0 ?></div>
            <div style="font-size:.72rem;color:#92400e;font-weight:600">Late</div>
          </div>
          <div style="text-align:center;padding:12px;background:#e0e7ff;border-radius:10px">
            <div style="font-size:1.4rem;font-weight:800;color:#6366f1"><?= round($mySummary['total_hours'] ?? 0, 1) ?>h</div>
            <div style="font-size:.72rem;color:#4f46e5;font-weight:600">Hours</div>
          </div>
        </div>
        <?php if (($mySummary['overtime_hours'] ?? 0) > 0): ?>
        <div style="margin-top:10px;padding:10px;background:#fef3c7;border-radius:8px;text-align:center;font-size:.82rem">
          <i class="fas fa-star" style="color:#f59e0b"></i>
          <strong><?= round($mySummary['overtime_hours'], 1) ?>h</strong> overtime this month
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

</div><!-- /grid -->

<!-- ═══════════════════════════════════════════════════════
     ADD ATTENDANCE MODAL — Redesigned
════════════════════════════════════════════════════════ -->
<?php if (isHR()): ?>

<style>
/* ── Modal overrides for attendance ── */
#addAttendanceModal .modal,
#editAttendanceModal .modal {
  max-width: 600px;
  border-radius: 20px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  max-height: 92vh;
}

#addAttendanceModal .modal form,
#editAttendanceModal .modal form {
  display: flex;
  flex-direction: column;
  min-height: 0;
  flex: 1;
}

#addAttendanceModal .modal .modal-body,
#editAttendanceModal .modal .modal-body {
  overflow-y: auto;
  flex: 1;
  min-height: 0;
}

#addAttendanceModal .modal .modal-footer,
#editAttendanceModal .modal .modal-footer {
  flex-shrink: 0;
}

/* Status option pills */
.status-pills {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 8px;
}
.status-pill {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  padding: 10px 6px;
  border-radius: 12px;
  border: 2px solid #e2e8f0;
  cursor: pointer;
  transition: all .2s;
  background: #fff;
  font-size: .72rem;
  font-weight: 700;
  color: #64748b;
  text-align: center;
  user-select: none;
}
.status-pill:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,.1); }
.status-pill.selected-present  { border-color: #10b981; background: #ecfdf5; color: #065f46; }
.status-pill.selected-absent   { border-color: #ef4444; background: #fef2f2; color: #991b1b; }
.status-pill.selected-late     { border-color: #f59e0b; background: #fffbeb; color: #92400e; }
.status-pill.selected-half_day { border-color: #3b82f6; background: #eff6ff; color: #1e40af; }
.status-pill.selected-holiday  { border-color: #8b5cf6; background: #f5f3ff; color: #5b21b6; }
.status-pill-icon {
  width: 32px; height: 32px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .9rem;
}
.pill-present  .status-pill-icon { background: #d1fae5; color: #10b981; }
.pill-absent   .status-pill-icon { background: #fee2e2; color: #ef4444; }
.pill-late     .status-pill-icon { background: #fef3c7; color: #f59e0b; }
.pill-half_day .status-pill-icon { background: #dbeafe; color: #3b82f6; }
.pill-holiday  .status-pill-icon { background: #ede9fe; color: #8b5cf6; }

/* Hours preview badge */
.hours-preview {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 14px;
  background: linear-gradient(135deg, #f0f4ff, #faf5ff);
  border: 1px solid #ddd6fe;
  border-radius: 10px;
  font-size: .82rem;
  margin-top: 8px;
}
.hours-preview-val {
  font-size: 1.1rem;
  font-weight: 800;
  color: #6366f1;
}
.hours-preview-ot {
  font-size: .78rem;
  color: #f59e0b;
  font-weight: 600;
}

/* Employee select with search */
.emp-select-wrap { position: relative; }
.emp-select-wrap select { padding-left: 40px; }
.emp-select-icon {
  position: absolute;
  left: 12px; top: 50%;
  transform: translateY(-50%);
  color: #94a3b8;
  pointer-events: none;
  font-size: .9rem;
}

/* Modal header gradient */
.modal-header-gradient {
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  padding: 1.25rem 1.5rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.modal-header-gradient .modal-title { color: #fff; font-size: 1rem; font-weight: 700; }
.modal-header-gradient .modal-close { color: rgba(255,255,255,.7); }
.modal-header-gradient .modal-close:hover { color: #fff; background: rgba(255,255,255,.15); }

/* Time input wrapper */
.time-input-wrap {
  position: relative;
}
.time-input-wrap .time-icon {
  position: absolute;
  right: 12px; top: 50%;
  transform: translateY(-50%);
  color: #94a3b8;
  pointer-events: none;
  font-size: .85rem;
}
.time-input-wrap input[type="time"] {
  padding-right: 36px;
}

/* Section label */
.modal-section-label {
  font-size: .7rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .08em;
  color: #94a3b8;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  gap: 6px;
}
.modal-section-label::after {
  content: '';
  flex: 1;
  height: 1px;
  background: #f1f5f9;
}
</style>

<!-- ADD MODAL -->
<div class="modal-overlay" id="addAttendanceModal" style="display:none">
  <div class="modal modal-lg">

    <!-- Gradient Header -->
    <div class="modal-header-gradient">
      <span class="modal-title">
        <i class="fas fa-plus-circle" style="margin-right:8px;opacity:.85"></i>
        Add Attendance Record
      </span>
      <button class="modal-close" onclick="closeModal('addAttendanceModal')">
        <i class="fas fa-times"></i>
      </button>
    </div>

    <form id="addAttForm" method="POST" action="<?= url('attendance/store') ?>">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="status" id="addStatusHidden" value="present">

      <div class="modal-body" style="padding:1.5rem">

        <!-- Employee -->
        <div class="modal-section-label"><i class="fas fa-user"></i> Employee</div>
        <div class="form-group">
          <div class="emp-select-wrap">
            <i class="fas fa-user emp-select-icon"></i>
            <select name="employee_id" class="form-control" required
                    style="padding-left:38px;height:44px;font-size:.875rem">
              <option value="">Select employee...</option>
              <?php foreach ($empList as $emp): ?>
              <option value="<?= (int)$emp['id'] ?>">
                <?= e($emp['name']) ?>
                &nbsp;·&nbsp;<?= e($emp['employee_code']) ?>
                &nbsp;·&nbsp;<?= e($emp['department']) ?>
              </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <!-- Date -->
        <div class="modal-section-label"><i class="fas fa-calendar-day"></i> Date</div>
        <div class="form-group">
          <input type="date" name="date" id="addDate" class="form-control"
                 value="<?= date('Y-m-d') ?>" required
                 style="height:44px;font-size:.875rem">
        </div>

        <!-- Time -->
        <div class="modal-section-label"><i class="fas fa-clock"></i> Time</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:0">
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem;color:#64748b">
              <i class="fas fa-sign-in-alt" style="color:#10b981;margin-right:4px"></i>Check In
            </label>
            <div class="time-input-wrap">
              <input type="time" name="check_in" id="addCheckIn" class="form-control"
                     value="09:00" style="height:44px;font-size:.9rem"
                     oninput="updateHoursPreview()">
              <i class="fas fa-clock time-icon"></i>
            </div>
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem;color:#64748b">
              <i class="fas fa-sign-out-alt" style="color:#ef4444;margin-right:4px"></i>Check Out
            </label>
            <div class="time-input-wrap">
              <input type="time" name="check_out" id="addCheckOut" class="form-control"
                     value="18:00" style="height:44px;font-size:.9rem"
                     oninput="updateHoursPreview()">
              <i class="fas fa-clock time-icon"></i>
            </div>
          </div>
        </div>

        <!-- Hours preview -->
        <div class="hours-preview" id="hoursPreview">
          <i class="fas fa-hourglass-half" style="color:#6366f1;font-size:1rem"></i>
          <div>
            <span class="hours-preview-val" id="hoursVal">9.00h</span>
            <span style="color:#94a3b8;font-size:.78rem"> worked</span>
            <span class="hours-preview-ot" id="otVal" style="margin-left:8px"></span>
          </div>
          <div style="margin-left:auto;font-size:.72rem;color:#94a3b8">auto-calculated</div>
        </div>

        <!-- Status -->
        <div class="modal-section-label" style="margin-top:16px"><i class="fas fa-tag"></i> Status</div>
        <div class="status-pills">
          <?php
          $statusDefs = [
            ['present',  'fa-user-check',    'Present'],
            ['absent',   'fa-user-times',    'Absent'],
            ['late',     'fa-clock',         'Late'],
            ['half_day', 'fa-adjust',        'Half Day'],
            ['holiday',  'fa-umbrella-beach','Holiday'],
          ];
          foreach ($statusDefs as [$val, $icon, $label]):
          ?>
          <div class="status-pill pill-<?= $val ?> <?= $val === 'present' ? 'selected-present' : '' ?>"
               onclick="selectStatus('<?= $val ?>', this)">
            <div class="status-pill-icon"><i class="fas <?= $icon ?>"></i></div>
            <?= $label ?>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- Notes -->
        <div class="form-group" style="margin-top:16px;margin-bottom:0">
          <label class="form-label" style="font-size:.78rem;color:#64748b">
            <i class="fas fa-sticky-note" style="color:#94a3b8;margin-right:4px"></i>Notes
            <span style="color:#94a3b8;font-weight:400">(optional)</span>
          </label>
          <input type="text" name="notes" class="form-control"
                 placeholder="e.g. Doctor appointment, field work..."
                 style="height:42px">
        </div>

      </div><!-- /modal-body -->

      <div class="modal-footer" style="background:#f8fafc;border-top:1px solid #e2e8f0;padding:1rem 1.5rem">
        <button type="button" class="btn btn-outline" onclick="closeModal('addAttendanceModal')">
          <i class="fas fa-times"></i> Cancel
        </button>
        <button type="submit" class="btn btn-primary" id="addAttBtn" style="min-width:140px">
          <i class="fas fa-save"></i> Save Record
        </button>
      </div>
    </form>
  </div>
</div>

<!-- ═══ EDIT ATTENDANCE MODAL ═══ -->
<div class="modal-overlay" id="editAttendanceModal" style="display:none">
  <div class="modal" style="max-width:480px;border-radius:20px;overflow:hidden">

    <div class="modal-header-gradient">
      <span class="modal-title">
        <i class="fas fa-edit" style="margin-right:8px;opacity:.85"></i>
        Edit Attendance Record
      </span>
      <button class="modal-close" onclick="closeModal('editAttendanceModal')">
        <i class="fas fa-times"></i>
      </button>
    </div>

    <form id="editAttForm">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="record_id" id="editRecordId">
      <input type="hidden" name="status" id="editStatusHidden" value="present">

      <div class="modal-body" style="padding:1.5rem">

        <!-- Time -->
        <div class="modal-section-label"><i class="fas fa-clock"></i> Time</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:0">
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem;color:#64748b">
              <i class="fas fa-sign-in-alt" style="color:#10b981;margin-right:4px"></i>Check In
            </label>
            <div class="time-input-wrap">
              <input type="time" id="editCheckIn" class="form-control"
                     style="height:44px;font-size:.9rem" oninput="updateEditHoursPreview()">
              <i class="fas fa-clock time-icon"></i>
            </div>
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem;color:#64748b">
              <i class="fas fa-sign-out-alt" style="color:#ef4444;margin-right:4px"></i>Check Out
            </label>
            <div class="time-input-wrap">
              <input type="time" id="editCheckOut" class="form-control"
                     style="height:44px;font-size:.9rem" oninput="updateEditHoursPreview()">
              <i class="fas fa-clock time-icon"></i>
            </div>
          </div>
        </div>

        <!-- Hours preview -->
        <div class="hours-preview" id="editHoursPreview" style="margin-top:8px">
          <i class="fas fa-hourglass-half" style="color:#6366f1;font-size:1rem"></i>
          <div>
            <span class="hours-preview-val" id="editHoursVal">—</span>
            <span style="color:#94a3b8;font-size:.78rem"> worked</span>
            <span class="hours-preview-ot" id="editOtVal" style="margin-left:8px"></span>
          </div>
        </div>

        <!-- Status -->
        <div class="modal-section-label" style="margin-top:16px"><i class="fas fa-tag"></i> Status</div>
        <div class="status-pills" id="editStatusPills">
          <?php foreach ($statusDefs as [$val, $icon, $label]): ?>
          <div class="status-pill pill-<?= $val ?>"
               onclick="selectEditStatus('<?= $val ?>', this)">
            <div class="status-pill-icon"><i class="fas <?= $icon ?>"></i></div>
            <?= $label ?>
          </div>
          <?php endforeach; ?>
        </div>

      </div>

      <div class="modal-footer" style="background:#f8fafc;border-top:1px solid #e2e8f0;padding:1rem 1.5rem">
        <button type="button" class="btn btn-outline" onclick="closeModal('editAttendanceModal')">
          <i class="fas fa-times"></i> Cancel
        </button>
        <button type="button" class="btn btn-primary" onclick="saveEdit()" style="min-width:130px">
          <i class="fas fa-save"></i> Update
        </button>
      </div>
    </form>
  </div>
</div>

<?php endif; ?>

<script>
/* ══════════════════════════════════════════════════════
   ATTENDANCE PAGE — JavaScript
══════════════════════════════════════════════════════ */

/* ── Check In / Out ─────────────────────────────────── */
function doCheckIn() {
  var csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', 'attendance/checkin', { csrf_token: csrf }, function(data) {
    if (data.success) {
      showToast('Checked in at ' + data.check_in, 'success');
      document.getElementById('checkInBtn').disabled  = true;
      document.getElementById('checkOutBtn').disabled = false;
      setTimeout(function() { location.reload(); }, 1200);
    } else {
      showToast(data.message || 'Check-in failed', 'error');
    }
  });
}

function doCheckOut() {
  var csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', 'attendance/checkout', { csrf_token: csrf }, function(data) {
    if (data.success) {
      showToast('Checked out. ' + data.hours_worked + 'h worked.', 'success');
      document.getElementById('checkOutBtn').disabled = true;
      setTimeout(function() { location.reload(); }, 1200);
    } else {
      showToast(data.message || 'Check-out failed', 'error');
    }
  });
}

<?php if (isHR()): ?>

/* ── Hours preview calculator ───────────────────────── */
function calcHours(ciVal, coVal) {
  if (!ciVal || !coVal) return { hours: 0, ot: 0 };
  var ci = ciVal.split(':').map(Number);
  var co = coVal.split(':').map(Number);
  var mins = (co[0] * 60 + co[1]) - (ci[0] * 60 + ci[1]);
  if (mins <= 0) return { hours: 0, ot: 0 };
  var hours = Math.round(mins / 60 * 100) / 100;
  var ot    = Math.max(0, Math.round((hours - 8) * 100) / 100);
  return { hours: hours, ot: ot };
}

function updateHoursPreview() {
  var ci  = document.getElementById('addCheckIn').value;
  var co  = document.getElementById('addCheckOut').value;
  var res = calcHours(ci, co);
  var hEl = document.getElementById('hoursVal');
  var oEl = document.getElementById('otVal');
  if (hEl) hEl.textContent = res.hours > 0 ? res.hours.toFixed(2) + 'h' : '—';
  if (oEl) oEl.textContent = res.ot > 0 ? '+ ' + res.ot.toFixed(2) + 'h OT' : '';
}

function updateEditHoursPreview() {
  var ci  = document.getElementById('editCheckIn').value;
  var co  = document.getElementById('editCheckOut').value;
  var res = calcHours(ci, co);
  var hEl = document.getElementById('editHoursVal');
  var oEl = document.getElementById('editOtVal');
  if (hEl) hEl.textContent = res.hours > 0 ? res.hours.toFixed(2) + 'h' : '—';
  if (oEl) oEl.textContent = res.ot > 0 ? '+ ' + res.ot.toFixed(2) + 'h OT' : '';
}

/* ── Status pill selection ──────────────────────────── */
function selectStatus(val, el) {
  // Clear all
  document.querySelectorAll('#addAttForm .status-pill').forEach(function(p) {
    p.className = p.className.replace(/\bselected-\S+/g, '').trim();
  });
  // Select clicked
  el.classList.add('selected-' + val);
  document.getElementById('addStatusHidden').value = val;
}

function selectEditStatus(val, el) {
  document.querySelectorAll('#editStatusPills .status-pill').forEach(function(p) {
    p.className = p.className.replace(/\bselected-\S+/g, '').trim();
  });
  el.classList.add('selected-' + val);
  document.getElementById('editStatusHidden').value = val;
}

/* ── Add Record Form Submit ─────────────────────────── */
document.addEventListener('DOMContentLoaded', function() {
  // Init hours preview
  updateHoursPreview();

  var form = document.getElementById('addAttForm');
  if (!form) return;

  form.addEventListener('submit', function(e) {
    e.preventDefault();

    var btn = document.getElementById('addAttBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

    var fd = new FormData(this);

    // Auto-calculate hours
    var ci  = fd.get('check_in');
    var co  = fd.get('check_out');
    var res = calcHours(ci, co);
    if (res.hours > 0) {
      fd.set('hours_worked',   res.hours.toFixed(2));
      fd.set('overtime_hours', res.ot.toFixed(2));
    }

    fetch(this.action, {
      method: 'POST',
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      body: fd
    })
    .then(function(r) {
      return r.text().then(function(text) {
        try { return JSON.parse(text); }
        catch(err) {
          console.error('Non-JSON response:', text.substring(0, 400));
          throw new Error('Server error: ' + text.substring(0, 100));
        }
      });
    })
    .then(function(data) {
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-save"></i> Save Record';
      if (data.success) {
        showToast('Attendance record added successfully!', 'success');
        closeModal('addAttendanceModal');
        setTimeout(function() { location.reload(); }, 900);
      } else {
        showToast(data.message || 'Failed to save record', 'error');
      }
    })
    .catch(function(err) {
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-save"></i> Save Record';
      showToast(err.message || 'Network error', 'error');
      console.error('Attendance store error:', err);
    });
  });
});

/* ── Edit Record ────────────────────────────────────── */
function editRecord(id, checkIn, checkOut, status) {
  document.getElementById('editRecordId').value   = id;
  document.getElementById('editCheckIn').value    = checkIn  || '';
  document.getElementById('editCheckOut').value   = checkOut || '';
  document.getElementById('editStatusHidden').value = status || 'present';

  // Highlight correct status pill
  document.querySelectorAll('#editStatusPills .status-pill').forEach(function(p) {
    p.className = p.className.replace(/\bselected-\S+/g, '').trim();
  });
  var activePill = document.querySelector('#editStatusPills .pill-' + (status || 'present'));
  if (activePill) activePill.classList.add('selected-' + (status || 'present'));

  updateEditHoursPreview();
  openModal('editAttendanceModal');
}

function saveEdit() {
  var id     = document.getElementById('editRecordId').value;
  var csrf   = document.querySelector('meta[name="csrf-token"]').content;
  var ci     = document.getElementById('editCheckIn').value;
  var co     = document.getElementById('editCheckOut').value;
  var status = document.getElementById('editStatusHidden').value;
  var res    = calcHours(ci, co);

  ajax('POST', 'attendance/update/' + id, {
    csrf_token:     csrf,
    check_in:       ci,
    check_out:      co,
    status:         status,
    hours_worked:   res.hours.toFixed(2),
    overtime_hours: res.ot.toFixed(2)
  }, function(data) {
    if (data.success) {
      showToast('Record updated successfully!', 'success');
      closeModal('editAttendanceModal');
      setTimeout(function() { location.reload(); }, 900);
    } else {
      showToast(data.message || 'Update failed', 'error');
    }
  });
}

<?php endif; ?>
</script>
