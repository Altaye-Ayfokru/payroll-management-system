<div class="page-header">
  <div>
    <div class="page-header-title">Attendance Report</div>
    <div class="page-header-sub"><?= date('F Y', strtotime($month . '-01')) ?></div>
  </div>
  <div class="page-header-actions">
    <form method="GET" style="display:flex;gap:8px;align-items:center">
      <input type="month" name="month" class="form-control" value="<?= e($month) ?>" style="width:auto">
      <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i></button>
    </form>
    <a href="<?= url('reports/export?type=attendance&month=' . $month) ?>" class="btn btn-outline">
      <i class="fas fa-download"></i> Export
    </a>
    <a href="<?= url('attendance') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back</a>
  </div>
</div>

<?php
$present = count(array_filter($records, fn($r) => in_array($r['status'], ['present','late'])));
$absent  = count(array_filter($records, fn($r) => $r['status'] === 'absent'));
$late    = count(array_filter($records, fn($r) => $r['status'] === 'late'));
$otHrs   = array_sum(array_column($records, 'overtime_hours'));
?>
<div class="stats-grid" style="margin-bottom:20px">
  <div class="stat-card stat-card-success">
    <div class="stat-icon stat-icon-success"><i class="fas fa-user-check"></i></div>
    <div class="stat-body"><div class="stat-value"><?= $present ?></div><div class="stat-label">Present</div></div>
  </div>
  <div class="stat-card" style="--accent:#ef4444">
    <div class="stat-icon" style="background:#fee2e2;color:#ef4444"><i class="fas fa-user-times"></i></div>
    <div class="stat-body"><div class="stat-value"><?= $absent ?></div><div class="stat-label">Absent</div></div>
  </div>
  <div class="stat-card stat-card-warning">
    <div class="stat-icon stat-icon-warning"><i class="fas fa-clock"></i></div>
    <div class="stat-body"><div class="stat-value"><?= $late ?></div><div class="stat-label">Late</div></div>
  </div>
  <div class="stat-card stat-card-info">
    <div class="stat-icon stat-icon-info"><i class="fas fa-star"></i></div>
    <div class="stat-body"><div class="stat-value"><?= round($otHrs, 1) ?>h</div><div class="stat-label">Overtime</div></div>
  </div>
</div>

<div class="card">
  <div class="table-wrapper">
    <table>
      <thead>
        <tr><th>Employee</th><th>Dept</th><th>Date</th><th>Check In</th><th>Check Out</th><th>Hours</th><th>Overtime</th><th>Status</th></tr>
      </thead>
      <tbody>
        <?php if (empty($records)): ?>
        <tr><td colspan="8"><div class="empty-state"><div class="empty-state-icon"><i class="fas fa-clock"></i></div><div class="empty-state-title">No records found</div></div></td></tr>
        <?php else: ?>
        <?php foreach ($records as $r): ?>
        <tr>
          <td><div class="emp-info-name"><?= e($r['employee_name']) ?></div></td>
          <td><span class="dept-badge"><?= e($r['department']) ?></span></td>
          <td><?= formatDate($r['date'], 'M d, Y') ?></td>
          <td><?= $r['check_in'] ? date('h:i A', strtotime($r['check_in'])) : '—' ?></td>
          <td><?= $r['check_out'] ? date('h:i A', strtotime($r['check_out'])) : '—' ?></td>
          <td><?= $r['hours_worked'] > 0 ? round($r['hours_worked'], 2) . 'h' : '—' ?></td>
          <td><?= $r['overtime_hours'] > 0 ? '<span style="color:#f59e0b;font-weight:600">' . round($r['overtime_hours'], 2) . 'h</span>' : '—' ?></td>
          <td><span class="badge <?= $r['status']==='present'?'badge-success':($r['status']==='absent'?'badge-danger':'badge-warning') ?>"><span class="att-dot att-<?= e($r['status']) ?>"></span><?= ucfirst($r['status']) ?></span></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
