<?php
$dt        = new DateTime($month . '-01');
$daysInMonth = (int)$dt->format('t');
$firstDow  = (int)$dt->format('N'); // 1=Mon, 7=Sun
$today     = date('Y-m-d');
$prevMonth = date('Y-m', strtotime($month . '-01 -1 month'));
$nextMonth = date('Y-m', strtotime($month . '-01 +1 month'));
?>

<div class="page-header">
  <div>
    <div class="page-header-title">Attendance Calendar</div>
    <div class="page-header-sub"><?= date('F Y', strtotime($month . '-01')) ?></div>
  </div>
  <div class="page-header-actions">
    <a href="?month=<?= $prevMonth ?>&employee_id=<?= $empId ?>" class="btn btn-outline btn-sm"><i class="fas fa-chevron-left"></i></a>
    <a href="?month=<?= date('Y-m') ?>&employee_id=<?= $empId ?>" class="btn btn-outline btn-sm">Today</a>
    <a href="?month=<?= $nextMonth ?>&employee_id=<?= $empId ?>" class="btn btn-outline btn-sm"><i class="fas fa-chevron-right"></i></a>
  </div>
</div>

<div class="grid-3-1">
  <!-- Calendar -->
  <div class="card">
    <div class="card-body">
      <!-- Legend -->
      <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px;font-size:.75rem">
        <span><span class="att-dot att-present"></span> Present</span>
        <span><span class="att-dot att-absent"></span> Absent</span>
        <span><span class="att-dot att-late"></span> Late</span>
        <span style="display:inline-flex;align-items:center;gap:4px">
          <span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:#dbeafe"></span> Half Day
        </span>
      </div>

      <div class="calendar-grid">
        <?php foreach (['Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $day): ?>
        <div class="calendar-day-header"><?= $day ?></div>
        <?php endforeach; ?>

        <!-- Empty cells before first day -->
        <?php for ($i = 1; $i < $firstDow; $i++): ?>
        <div class="calendar-day empty"></div>
        <?php endfor; ?>

        <!-- Days -->
        <?php for ($d = 1; $d <= $daysInMonth; $d++):
          $dateStr = $month . '-' . str_pad($d, 2, '0', STR_PAD_LEFT);
          $record  = $calendarData[$dateStr] ?? null;
          $isToday = $dateStr === $today;
          $classes = ['calendar-day'];
          if ($isToday) $classes[] = 'today';
          elseif ($record) $classes[] = $record['status'];
        ?>
        <div class="<?= implode(' ', $classes) ?>"
             title="<?= $record ? ucfirst($record['status']) . ($record['check_in'] ? ' · In: ' . date('h:i A', strtotime($record['check_in'])) : '') : '' ?>">
          <span class="calendar-day-num"><?= $d ?></span>
          <?php if ($record): ?>
          <span class="calendar-day-status"><?= strtoupper(substr($record['status'], 0, 1)) ?></span>
          <?php endif; ?>
        </div>
        <?php endfor; ?>
      </div>
    </div>
  </div>

  <!-- Summary -->
  <div style="display:flex;flex-direction:column;gap:16px">
    <div class="card">
      <div class="card-header"><span class="card-title">Monthly Summary</span></div>
      <div class="card-body">
        <?php $s = $summary; ?>
        <div style="display:flex;flex-direction:column;gap:10px">
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f1f5f9">
            <span style="font-size:.82rem;color:#64748b"><span class="att-dot att-present"></span> Present Days</span>
            <strong style="color:#10b981"><?= $s['present_days'] ?? 0 ?></strong>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f1f5f9">
            <span style="font-size:.82rem;color:#64748b"><span class="att-dot att-absent"></span> Absent Days</span>
            <strong style="color:#ef4444"><?= $s['absent_days'] ?? 0 ?></strong>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f1f5f9">
            <span style="font-size:.82rem;color:#64748b"><span class="att-dot att-late"></span> Late Days</span>
            <strong style="color:#f59e0b"><?= $s['late_days'] ?? 0 ?></strong>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f1f5f9">
            <span style="font-size:.82rem;color:#64748b"><i class="fas fa-clock" style="color:#6366f1;margin-right:4px"></i> Total Hours</span>
            <strong><?= round($s['total_hours'] ?? 0, 1) ?>h</strong>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0">
            <span style="font-size:.82rem;color:#64748b"><i class="fas fa-star" style="color:#f59e0b;margin-right:4px"></i> Overtime</span>
            <strong style="color:#f59e0b"><?= round($s['overtime_hours'] ?? 0, 1) ?>h</strong>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
