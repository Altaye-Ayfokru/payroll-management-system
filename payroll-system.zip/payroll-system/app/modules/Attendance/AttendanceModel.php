<?php
/**
 * Attendance Module — Model
 */
class AttendanceModel extends Model {
    protected string $table = 'attendance';

    public function getTodayRecord(int $empId): ?array {
        return $this->queryOne(
            "SELECT * FROM attendance WHERE employee_id=:eid AND date=CURDATE()",
            [':eid' => $empId]
        );
    }

    public function getAllWithEmployees(?string $date = null, int $limit = ITEMS_PER_PAGE, int $offset = 0): array {
        $where  = $date ? "AND a.date = :date" : "";
        $params = [':limit' => $limit, ':offset' => $offset];
        if ($date) $params[':date'] = $date;

        return $this->query(
            "SELECT a.*, u.name AS employee_name, e.department, e.employee_code
             FROM attendance a
             JOIN employees e ON e.id = a.employee_id
             JOIN users u ON u.id = e.user_id
             WHERE 1=1 {$where}
             ORDER BY a.date DESC, a.check_in DESC
             LIMIT :limit OFFSET :offset",
            $params
        );
    }

    public function getMonthlyByEmployee(int $empId, string $month): array {
        return $this->query(
            "SELECT * FROM attendance
             WHERE employee_id=:eid AND DATE_FORMAT(date,'%Y-%m')=:month
             ORDER BY date ASC",
            [':eid' => $empId, ':month' => $month]
        );
    }

    public function getMonthlySummary(int $empId, string $month): array {
        return $this->queryOne(
            "SELECT
                COUNT(*) AS total_days,
                SUM(status IN ('present','late')) AS present_days,
                SUM(status='absent')              AS absent_days,
                SUM(status='late')                AS late_days,
                SUM(status='half_day')            AS half_days,
                COALESCE(SUM(hours_worked),0)     AS total_hours,
                COALESCE(SUM(overtime_hours),0)   AS overtime_hours
             FROM attendance
             WHERE employee_id=:eid AND DATE_FORMAT(date,'%Y-%m')=:month",
            [':eid' => $empId, ':month' => $month]
        ) ?? [];
    }

    public function getTodayStats(): array {
        // Ensure EmployeeModel is loaded
        if (!class_exists('EmployeeModel')) {
            require_once APP_PATH . '/modules/Employee/EmployeeModel.php';
        }
        $total = (new EmployeeModel())->countActive();
        $stmt  = Database::getInstance()->query(
            "SELECT
                SUM(status IN ('present','late')) AS present,
                SUM(status='absent')              AS absent,
                SUM(status='late')                AS late
             FROM attendance WHERE date=CURDATE()"
        );
        $row = $stmt->fetch() ?: [];
        return [
            'total'   => $total,
            'present' => (int)($row['present'] ?? 0),
            'absent'  => (int)($row['absent']  ?? 0),
            'late'    => (int)($row['late']    ?? 0),
        ];
    }

    public function getCalendarData(int $empId, string $month): array {
        $records  = $this->getMonthlyByEmployee($empId, $month);
        $calendar = [];
        foreach ($records as $r) $calendar[$r['date']] = $r;
        return $calendar;
    }

    /**
     * Public wrapper — check if a record exists for a given employee + date.
     * Used by AttendanceController to avoid calling protected queryOne() directly.
     */
    public function findByEmployeeAndDate(int $empId, string $date): ?array {
        return $this->queryOne(
            "SELECT * FROM attendance WHERE employee_id = :eid AND date = :date LIMIT 1",
            [':eid' => $empId, ':date' => $date]
        );
    }
}
