<?php
/**
 * Attendance Module — Service
 */
class AttendanceService {
    private AttendanceModel $model;

    public function __construct() {
        require_once APP_PATH . '/modules/Attendance/AttendanceModel.php';
        $this->model = new AttendanceModel();
    }

    public function checkIn(int $empId): array {
        if ($this->model->getTodayRecord($empId)) {
            return ['success' => false, 'message' => 'Already checked in today.'];
        }
        $now    = date('H:i:s');
        $status = $now > '09:15:00' ? 'late' : 'present';

        $id = $this->model->insert([
            'employee_id' => $empId,
            'date'        => date('Y-m-d'),
            'check_in'    => $now,
            'status'      => $status,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
        return ['success' => true, 'id' => $id, 'status' => $status, 'check_in' => $now];
    }

    public function checkOut(int $empId): array {
        $record = $this->model->getTodayRecord($empId);
        if (!$record)              return ['success' => false, 'message' => 'No check-in found.'];
        if ($record['check_out'])  return ['success' => false, 'message' => 'Already checked out.'];

        $now         = date('H:i:s');
        $in          = new DateTime($record['check_in']);
        $out         = new DateTime($now);
        $diff        = $in->diff($out);
        $hours       = round($diff->h + $diff->i / 60, 2);
        $overtime    = max(0, round($hours - 8.0, 2));

        $this->model->update($record['id'], [
            'check_out'      => $now,
            'hours_worked'   => $hours,
            'overtime_hours' => $overtime,
        ]);
        return ['success' => true, 'check_out' => $now, 'hours_worked' => $hours, 'overtime' => $overtime];
    }
}
