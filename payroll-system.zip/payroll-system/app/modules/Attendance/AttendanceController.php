<?php
require_once CORE_PATH . '/Controller.php';
require_once APP_PATH . '/helpers/validator.php';
require_once APP_PATH . '/modules/Attendance/AttendanceModel.php';
require_once APP_PATH . '/modules/Attendance/AttendanceService.php';
require_once APP_PATH . '/modules/Employee/EmployeeModel.php';

class AttendanceController extends Controller {
    private AttendanceModel   $model;
    private AttendanceService $service;

    public function __construct() {
        $this->service = new AttendanceService();
        $this->model   = new AttendanceModel();
    }

    public function index(): void {
        $this->requireAuth();
        $date  = $_GET['date'] ?? date('Y-m-d');
        $page  = max(1, (int)($_GET['page'] ?? 1));
        $pager = paginate($this->model->count(), ITEMS_PER_PAGE, $page);

        $data = [
            'records'    => $this->model->getAllWithEmployees($date, ITEMS_PER_PAGE, $pager['offset']),
            'todayStats' => $this->model->getTodayStats(),
            'date'       => $date,
            'pager'      => $pager,
            'pageTitle'  => 'Attendance',
            'flash'      => $this->getFlash(),
            'csrf'       => csrfToken(),
        ];

        if (currentUserRole() === 'employee') {
            $emp = (new EmployeeModel())->getByUserId(currentUserId());
            if ($emp) {
                $data['myRecord']   = $this->model->getTodayRecord($emp['id']);
                $data['myEmployee'] = $emp;
                $data['mySummary']  = $this->model->getMonthlySummary($emp['id'], date('Y-m'));
            }
        }

        $this->view('attendance.index', $data);
    }

    public function checkIn(): void {
        $this->requireAuth();
        header('Content-Type: application/json');
        if (!validateCsrf()) {
            echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']); exit;
        }
        try {
            $emp = (new EmployeeModel())->getByUserId(currentUserId());
            if (!$emp) { echo json_encode(['success' => false, 'message' => 'Employee record not found for your account']); exit; }
            $result = $this->service->checkIn($emp['id']);
            if ($result['success']) logActivity(currentUserId(), 'Checked in at ' . date('H:i'));
            echo json_encode($result);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }

    public function checkOut(): void {
        $this->requireAuth();
        header('Content-Type: application/json');
        if (!validateCsrf()) {
            echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']); exit;
        }
        try {
            $emp = (new EmployeeModel())->getByUserId(currentUserId());
            if (!$emp) { echo json_encode(['success' => false, 'message' => 'Employee record not found for your account']); exit; }
            $result = $this->service->checkOut($emp['id']);
            if ($result['success']) logActivity(currentUserId(), 'Checked out at ' . date('H:i'));
            echo json_encode($result);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }

    public function calendar(): void {
        $this->requireAuth();
        $month = $_GET['month'] ?? date('Y-m');
        $empId = (int)($_GET['employee_id'] ?? 0);

        if (!isHR() || !$empId) {
            $emp   = (new EmployeeModel())->getByUserId(currentUserId());
            $empId = $emp['id'] ?? 0;
        }

        $this->view('attendance.calendar', [
            'calendarData' => $this->model->getCalendarData($empId, $month),
            'summary'      => $this->model->getMonthlySummary($empId, $month),
            'month'        => $month,
            'empId'        => $empId,
            'pageTitle'    => 'Attendance Calendar',
        ]);
    }

    public function store(): void {
        $this->requireRole('admin', 'hr');

        // Always return JSON for this endpoint
        header('Content-Type: application/json');

        if (!validateCsrf()) {
            echo json_encode(['success' => false, 'message' => 'Invalid CSRF token. Please refresh the page.']);
            exit;
        }

        $empId = (int)($_POST['employee_id'] ?? 0);
        $date  = trim($_POST['date'] ?? '');

        if (!$empId || !$date) {
            echo json_encode(['success' => false, 'message' => 'Employee and date are required']);
            exit;
        }

        // Normalise date — accept YYYY-MM-DD or MM/DD/YYYY
        if (preg_match('#^\d{2}/\d{2}/\d{4}$#', $date)) {
            // Convert MM/DD/YYYY → YYYY-MM-DD
            $d = DateTime::createFromFormat('m/d/Y', $date);
            $date = $d ? $d->format('Y-m-d') : '';
        }

        // Validate final format
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            echo json_encode(['success' => false, 'message' => 'Invalid date format. Use YYYY-MM-DD.']);
            exit;
        }

        try {
            // Check for duplicate using public model method
            $existing = $this->model->findByEmployeeAndDate($empId, $date);
            if ($existing) {
                echo json_encode(['success' => false, 'message' => 'Attendance record already exists for this employee on ' . $date]);
                exit;
            }

            $checkIn  = !empty($_POST['check_in'])  ? trim($_POST['check_in'])  : null;
            $checkOut = !empty($_POST['check_out']) ? trim($_POST['check_out']) : null;
            $hours    = (float)($_POST['hours_worked']   ?? 0);
            $overtime = (float)($_POST['overtime_hours'] ?? 0);

            // Auto-calculate hours from check_in / check_out
            if ($checkIn && $checkOut && $hours == 0) {
                try {
                    $in   = new DateTime($checkIn);
                    $out  = new DateTime($checkOut);
                    $diff = $in->diff($out);
                    $hours    = round($diff->h + $diff->i / 60, 2);
                    $overtime = max(0, round($hours - 8, 2));
                } catch (Exception $e) { /* keep 0 */ }
            }

            $id = $this->model->insert([
                'employee_id'    => $empId,
                'date'           => $date,
                'check_in'       => $checkIn,
                'check_out'      => $checkOut,
                'hours_worked'   => $hours,
                'overtime_hours' => $overtime,
                'status'         => $_POST['status'] ?? 'present',
                'created_at'     => date('Y-m-d H:i:s'),
            ]);

            logActivity(currentUserId(), "Added attendance for employee #{$empId} on {$date}");
            echo json_encode(['success' => true, 'id' => $id, 'message' => 'Attendance record added successfully']);

        } catch (Exception $e) {
            Logger::error('Attendance store error: ' . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    public function update(string $id): void {
        $this->requireRole('admin', 'hr');

        header('Content-Type: application/json');

        if (!validateCsrf()) {
            echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
            exit;
        }

        try {
            $checkIn  = !empty($_POST['check_in'])  ? trim($_POST['check_in'])  : null;
            $checkOut = !empty($_POST['check_out']) ? trim($_POST['check_out']) : null;
            $hours    = (float)($_POST['hours_worked']   ?? 0);
            $overtime = (float)($_POST['overtime_hours'] ?? 0);

            if ($checkIn && $checkOut && $hours == 0) {
                try {
                    $in   = new DateTime($checkIn);
                    $out  = new DateTime($checkOut);
                    $diff = $in->diff($out);
                    $hours    = round($diff->h + $diff->i / 60, 2);
                    $overtime = max(0, round($hours - 8, 2));
                } catch (Exception $e) { /* keep 0 */ }
            }

            $this->model->update((int)$id, [
                'check_in'       => $checkIn,
                'check_out'      => $checkOut,
                'hours_worked'   => $hours,
                'overtime_hours' => $overtime,
                'status'         => $_POST['status'] ?? 'present',
            ]);

            logActivity(currentUserId(), "Updated attendance record #{$id}");
            echo json_encode(['success' => true, 'message' => 'Record updated successfully']);

        } catch (Exception $e) {
            Logger::error('Attendance update error: ' . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    public function report(): void {
        $this->requireRole('admin', 'hr');
        $month = $_GET['month'] ?? date('Y-m');
        $this->view('attendance.report', [
            'records'   => $this->model->getAllWithEmployees(null, 500, 0),
            'month'     => $month,
            'pageTitle' => 'Attendance Report',
        ]);
    }
}
