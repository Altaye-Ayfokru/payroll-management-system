<?php
require_once CORE_PATH . '/Controller.php';
require_once APP_PATH . '/helpers/validator.php';
require_once APP_PATH . '/modules/Leave/LeaveModel.php';
require_once APP_PATH . '/modules/Leave/LeaveService.php';
require_once APP_PATH . '/modules/Employee/EmployeeModel.php';

class LeaveController extends Controller {
    private LeaveModel   $model;
    private LeaveService $service;

    public function __construct() {
        $this->service = new LeaveService();
        $this->model   = new LeaveModel();
    }

    public function index(): void {
        $this->requireAuth();
        $role = currentUserRole();

        if ($role === 'employee') {
            $emp    = (new EmployeeModel())->getByUserId(currentUserId());
            $leaves  = $emp ? $this->model->getByEmployee($emp['id']) : [];
            $balance = $emp ? $this->model->getBalance($emp['id'], (int)date('Y')) : [];
            $pager   = null;
        } else {
            $page   = max(1, (int)($_GET['page'] ?? 1));
            $pager  = paginate($this->model->count(), ITEMS_PER_PAGE, $page);
            $leaves  = $this->model->getAllWithEmployees(ITEMS_PER_PAGE, $pager['offset']);
            $balance = [];
        }

        $this->view('leaves.index', [
            'leaves'    => $leaves,
            'balance'   => $balance,
            'pager'     => $pager,
            'pageTitle' => 'Leave Management',
            'flash'     => $this->getFlash(),
        ]);
    }

    public function requestPage(): void {
        $this->requireAuth();
        $this->view('leaves.request', ['pageTitle' => 'Apply for Leave', 'csrf' => csrfToken()]);
    }

    public function store(): void {
        $this->requireAuth();
        if (!validateCsrf()) { $this->json(['success' => false, 'message' => 'Invalid token'], 403); return; }

        $emp = (new EmployeeModel())->getByUserId(currentUserId());
        if (!$emp) { $this->redirect('dashboard'); return; }

        $result = $this->service->apply($emp['id'], $_POST);

        if (!$result['success']) {
            $this->view('leaves.request', [
                'errors' => $result['errors'], 'pageTitle' => 'Apply for Leave', 'csrf' => csrfToken(),
            ]);
            return;
        }

        // Notify HR
        $db = Database::getInstance();
        $db->prepare(
            "INSERT INTO notifications (user_id,message,type,is_read,created_at)
             SELECT id, :msg, 'info', 0, NOW() FROM users WHERE role IN ('admin','hr')"
        )->execute([':msg' => "{$_SESSION['user_name']} applied for {$_POST['leave_type']} leave."]);

        logActivity(currentUserId(), "Applied for leave #{$result['id']}");
        $this->flash('success', 'Leave request submitted!');
        $this->redirect('leaves');
    }

    public function approvals(): void {
        $this->requireRole('admin', 'hr');
        $this->view('leaves.approvals', [
            'pending'   => $this->model->getPending(),
            'pageTitle' => 'Leave Approvals',
            'csrf'      => csrfToken(),
            'flash'     => $this->getFlash(),
        ]);
    }

    public function approve(string $id): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) { $this->json(['success' => false, 'message' => 'Invalid token'], 403); return; }

        $leave = $this->model->findById((int)$id);
        if (!$leave) { $this->json(['success' => false, 'message' => 'Not found'], 404); return; }

        $this->service->approve((int)$id, currentUserId());

        $emp = (new EmployeeModel())->findById($leave['employee_id']);
        if ($emp) {
            $dates = formatDate($leave['start_date']) . ' – ' . formatDate($leave['end_date']);
            Database::getInstance()->prepare(
                "INSERT INTO notifications (user_id,message,type,is_read,created_at)
                 VALUES (:uid,:msg,'success',0,NOW())"
            )->execute([':uid' => $emp['user_id'],
                        ':msg' => "Your {$leave['leave_type']} leave ({$dates}) has been approved."]);
        }

        logActivity(currentUserId(), "Approved leave #{$id}");
        $this->json(['success' => true, 'message' => 'Leave approved']);
    }

    public function reject(string $id): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) { $this->json(['success' => false, 'message' => 'Invalid token'], 403); return; }

        $leave  = $this->model->findById((int)$id);
        $reason = htmlspecialchars(trim($_POST['reason'] ?? ''), ENT_QUOTES, 'UTF-8');

        $this->service->reject((int)$id, $reason);

        $emp = (new EmployeeModel())->findById($leave['employee_id'] ?? 0);
        if ($emp) {
            Database::getInstance()->prepare(
                "INSERT INTO notifications (user_id,message,type,is_read,created_at)
                 VALUES (:uid,:msg,'warning',0,NOW())"
            )->execute([':uid' => $emp['user_id'],
                        ':msg' => "Your {$leave['leave_type']} leave request was rejected." .
                                  ($reason ? " Reason: {$reason}" : '')]);
        }

        logActivity(currentUserId(), "Rejected leave #{$id}");
        $this->json(['success' => true, 'message' => 'Leave rejected']);
    }
}
