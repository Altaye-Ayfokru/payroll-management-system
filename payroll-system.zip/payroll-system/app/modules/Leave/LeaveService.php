<?php
/**
 * Leave Module — Service
 */
class LeaveService {
    private LeaveModel $model;

    public function __construct() {
        require_once APP_PATH . '/modules/Leave/LeaveModel.php';
        require_once APP_PATH . '/helpers/validator.php';
        $this->model = new LeaveModel();
    }

    public function apply(int $empId, array $data): array {
        $v = new Validator($data);
        $v->required('leave_type')->required('start_date')->required('end_date')
          ->date('start_date')->date('end_date');

        if (!$v->passes()) return ['success' => false, 'errors' => $v->errors()];

        if ($data['end_date'] < $data['start_date']) {
            return ['success' => false, 'errors' => ['end_date' => 'End date must be after start date.']];
        }

        $id = $this->model->insert([
            'employee_id' => $empId,
            'leave_type'  => $data['leave_type'],
            'start_date'  => $data['start_date'],
            'end_date'    => $data['end_date'],
            'reason'      => $data['reason'] ?? '',
            'status'      => 'pending',
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return ['success' => true, 'id' => $id];
    }

    public function approve(int $id, int $approvedBy): bool {
        return $this->model->update($id, [
            'status'      => 'approved',
            'approved_by' => $approvedBy,
            'approved_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public function reject(int $id, string $reason = ''): bool {
        return $this->model->update($id, [
            'status'           => 'rejected',
            'rejection_reason' => $reason,
        ]);
    }
}
