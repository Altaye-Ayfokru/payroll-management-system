<div class="page-header">
  <div>
    <div class="page-header-title">Apply for Leave</div>
    <div class="page-header-sub">Submit a new leave request</div>
  </div>
  <a href="<?= url('leaves') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<div class="card" style="max-width:600px">
  <div class="card-body">
    <form method="POST" action="<?= url('leaves/store') ?>">
      <?= csrfField() ?>

      <div class="form-group">
        <label class="form-label">Leave Type <span class="required">*</span></label>
        <select name="leave_type" class="form-control <?= isset($errors['leave_type']) ? 'is-invalid' : '' ?>" required>
          <option value="">Select leave type...</option>
          <option value="annual">Annual Leave</option>
          <option value="sick">Sick Leave</option>
          <option value="casual">Casual Leave</option>
          <option value="maternity">Maternity Leave</option>
          <option value="paternity">Paternity Leave</option>
          <option value="unpaid">Unpaid Leave</option>
          <option value="other">Other</option>
        </select>
        <?php if (isset($errors['leave_type'])): ?><div class="form-error"><?= e($errors['leave_type']) ?></div><?php endif; ?>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Start Date <span class="required">*</span></label>
          <input type="date" name="start_date" class="form-control <?= isset($errors['start_date']) ? 'is-invalid' : '' ?>"
                 min="<?= date('Y-m-d') ?>" required>
          <?php if (isset($errors['start_date'])): ?><div class="form-error"><?= e($errors['start_date']) ?></div><?php endif; ?>
        </div>
        <div class="form-group">
          <label class="form-label">End Date <span class="required">*</span></label>
          <input type="date" name="end_date" class="form-control <?= isset($errors['end_date']) ? 'is-invalid' : '' ?>"
                 min="<?= date('Y-m-d') ?>" required>
          <?php if (isset($errors['end_date'])): ?><div class="form-error"><?= e($errors['end_date']) ?></div><?php endif; ?>
        </div>
      </div>

      <div class="form-group" id="daysPreview" style="display:none">
        <div style="background:#e0e7ff;border-radius:8px;padding:10px 14px;font-size:.85rem;color:#4f46e5">
          <i class="fas fa-info-circle"></i> <strong id="daysCount">0</strong> working day(s) requested
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Reason</label>
        <textarea name="reason" class="form-control" rows="4" placeholder="Briefly describe the reason for your leave..."></textarea>
      </div>

      <div style="display:flex;gap:10px;justify-content:flex-end">
        <a href="<?= url('leaves') ?>" class="btn btn-outline">Cancel</a>
        <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit Request</button>
      </div>
    </form>
  </div>
</div>

<script>
const startInput = document.querySelector('[name="start_date"]');
const endInput   = document.querySelector('[name="end_date"]');
const preview    = document.getElementById('daysPreview');
const daysCount  = document.getElementById('daysCount');

function updateDays() {
  if (startInput.value && endInput.value) {
    const start = new Date(startInput.value);
    const end   = new Date(endInput.value);
    if (end >= start) {
      const diff = Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1;
      daysCount.textContent = diff;
      preview.style.display = 'block';
    }
  }
}
startInput.addEventListener('change', updateDays);
endInput.addEventListener('change', updateDays);
</script>
