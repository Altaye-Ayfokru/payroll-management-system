﻿<div class="page-header">
  <div>
    <div class="page-header-title">Leave Approvals</div>
    <div class="page-header-sub"><?= count($pending) ?> pending request(s)</div>
  </div>
  <a href="<?= url('leaves') ?>" class="btn btn-outline"><i class="fas fa-list"></i> All Leaves</a>
</div>

<?php if (!empty($flash)): ?>
<div class="flash-message flash-<?= e($flash['type']) ?>" id="flashMsg">
  <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
  <?= e($flash['message']) ?>
  <button class="flash-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
</div>
<?php endif; ?>

<?php if (empty($pending)): ?>
<div class="card">
  <div class="card-body">
    <div class="empty-state">
      <div class="empty-state-icon"><i class="fas fa-check-double" style="color:#10b981"></i></div>
      <div class="empty-state-title">All caught up!</div>
      <div class="empty-state-text">No pending leave requests at this time.</div>
    </div>
  </div>
</div>
<?php else: ?>

<!-- Bulk Actions Bar -->
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;padding:.75rem 1rem;background:#fff;border-radius:10px;border:1px solid #e2e8f0;box-shadow:0 1px 3px rgba(0,0,0,.05)">
  <div style="font-size:.85rem;color:#374151">
    <strong><?= count($pending) ?></strong> pending request(s) awaiting review
  </div>
  <div style="display:flex;gap:.5rem">
    <button class="btn btn-success btn-sm" onclick="approveAll()">
      <i class="fas fa-check-double"></i> Approve All
    </button>
  </div>
</div>

<div style="display:flex;flex-direction:column;gap:14px">
  <?php foreach ($pending as $l): ?>
  <?php
  $days = (new DateTime($l['start_date']))->diff(new DateTime($l['end_date']))->days + 1;
  $leaveColors = [
    'annual'    => ['#6366f1', '#e0e7ff'],
    'sick'      => ['#ef4444', '#fee2e2'],
    'casual'    => ['#f59e0b', '#fef3c7'],
    'maternity' => ['#ec4899', '#fce7f3'],
    'paternity' => ['#3b82f6', '#dbeafe'],
    'unpaid'    => ['#64748b', '#f1f5f9'],
    'other'     => ['#14b8a6', '#f0fdfa'],
  ];
  [$lColor, $lBg] = $leaveColors[$l['leave_type']] ?? ['#6366f1', '#e0e7ff'];
  ?>
  <div class="card" style="border-left:4px solid <?= $lColor ?>">
    <div class="card-body" style="padding:1.25rem 1.5rem">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;flex-wrap:wrap">

        <!-- Employee Info -->
        <div style="display:flex;align-items:center;gap:.875rem">
          <div style="width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,<?= $lColor ?>,<?= $lColor ?>cc);display:flex;align-items:center;justify-content:center;color:#fff;font-size:1rem;font-weight:700;flex-shrink:0">
            <?= strtoupper(substr($l['employee_name'], 0, 1)) ?>
          </div>
          <div>
            <div style="font-weight:700;color:#0f172a;font-size:.95rem"><?= e($l['employee_name']) ?></div>
            <div style="font-size:.78rem;color:#64748b;margin-top:1px">
              <?= e($l['position'] ?? '') ?><?= !empty($l['position']) ? ' &middot; ' : '' ?><?= e($l['department']) ?>
            </div>
            <div style="font-size:.72rem;color:#94a3b8;margin-top:2px">Applied <?= timeAgo($l['created_at']) ?></div>
          </div>
        </div>

        <!-- Actions -->
        <div style="display:flex;gap:8px;flex-shrink:0">
          <button class="btn btn-success btn-sm" onclick="leaveAction('approve', <?= $l['id'] ?>)">
            <i class="fas fa-check"></i> Approve
          </button>
          <button class="btn btn-danger btn-sm" onclick="leaveReject(<?= $l['id'] ?>)">
            <i class="fas fa-times"></i> Reject
          </button>
        </div>
      </div>

      <!-- Leave Details -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-top:1rem;padding-top:1rem;border-top:1px solid #f1f5f9">
        <div>
          <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;color:#94a3b8">Leave Type</div>
          <div style="margin-top:3px">
            <span style="display:inline-flex;align-items:center;padding:3px 10px;border-radius:999px;font-size:.75rem;font-weight:700;background:<?= $lBg ?>;color:<?= $lColor ?>">
              <?= ucfirst($l['leave_type']) ?>
            </span>
          </div>
        </div>
        <div>
          <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;color:#94a3b8">From</div>
          <div style="font-size:.875rem;font-weight:600;color:#0f172a;margin-top:3px"><?= formatDate($l['start_date']) ?></div>
        </div>
        <div>
          <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;color:#94a3b8">To</div>
          <div style="font-size:.875rem;font-weight:600;color:#0f172a;margin-top:3px"><?= formatDate($l['end_date']) ?></div>
        </div>
        <div>
          <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;color:#94a3b8">Duration</div>
          <div style="font-size:.875rem;font-weight:700;color:<?= $lColor ?>;margin-top:3px"><?= $days ?> day<?= $days > 1 ? 's' : '' ?></div>
        </div>
        <?php if (!empty($l['reason'])): ?>
        <div style="grid-column:1/-1">
          <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;color:#94a3b8">Reason</div>
          <div style="font-size:.85rem;color:#374151;margin-top:3px;padding:8px 12px;background:#f8fafc;border-radius:8px;border-left:3px solid <?= $lColor ?>">
            <?= e($l['reason']) ?>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Reject Modal -->
<div class="modal-overlay" id="rejectModal" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title"><i class="fas fa-times-circle" style="color:#ef4444;margin-right:8px"></i>Reject Leave Request</span>
      <button class="modal-close" onclick="closeModal('rejectModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label class="form-label">Reason for Rejection (optional)</label>
        <textarea id="rejectReason" class="form-control" rows="3" placeholder="Provide a reason for the employee..."></textarea>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('rejectModal')">Cancel</button>
      <button class="btn btn-danger" onclick="confirmReject()"><i class="fas fa-times"></i> Reject Leave</button>
    </div>
  </div>
</div>

<script>
var rejectId = null;
var pendingIds = <?= json_encode(array_column($pending ?? [], 'id')) ?>;

function leaveAction(action, id) {
  if (!confirm((action === 'approve' ? 'Approve' : 'Reject') + ' this leave request?')) return;
  var csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', 'leaves/' + action + '/' + id, { csrf_token: csrf }, function(data) {
    if (data.success) {
      showToast(data.message, 'success');
      setTimeout(function() { location.reload(); }, 800);
    } else {
      showToast(data.message || 'Failed', 'error');
    }
  });
}

function leaveReject(id) {
  rejectId = id;
  document.getElementById('rejectReason').value = '';
  openModal('rejectModal');
}

function confirmReject() {
  var reason = document.getElementById('rejectReason').value;
  var csrf   = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', 'leaves/reject/' + rejectId, { csrf_token: csrf, reason: reason }, function(data) {
    if (data.success) {
      showToast('Leave rejected.', 'success');
      closeModal('rejectModal');
      setTimeout(function() { location.reload(); }, 800);
    } else {
      showToast(data.message || 'Failed', 'error');
    }
  });
}

function approveAll() {
  if (!pendingIds.length) return;
  if (!confirm('Approve all ' + pendingIds.length + ' pending leave requests?')) return;
  var csrf = document.querySelector('meta[name="csrf-token"]').content;
  var done = 0;
  pendingIds.forEach(function(id) {
    ajax('POST', 'leaves/approve/' + id, { csrf_token: csrf }, function(data) {
      done++;
      if (done === pendingIds.length) {
        showToast('All leaves approved!', 'success');
        setTimeout(function() { location.reload(); }, 1000);
      }
    });
  });
}
</script>
