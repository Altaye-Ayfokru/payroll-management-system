<!-- Hero Banner -->
<div class="page-hero hero-leaves">
  <div class="hero-orb hero-orb-1"></div>
  <div class="hero-orb hero-orb-2"></div>
  <div class="page-hero-content">
    <div class="hero-badge"><span class="hero-badge-dot"></span> Leave Management</div>
    <div class="page-hero-title">Leave Requests</div>
    <div class="page-hero-sub">Apply for leave, track balances, and manage approvals for your entire workforce.</div>
    <div class="page-hero-actions">
      <?php if ($_SESSION['user_role'] === 'employee'): ?>
      <a href="<?= url('leaves/request') ?>" class="page-hero-btn page-hero-btn-white">
        <i class="fas fa-plus"></i> Apply Leave
      </a>
      <?php else: ?>
      <a href="<?= url('leaves/approvals') ?>" class="page-hero-btn page-hero-btn-white">
        <i class="fas fa-clock"></i> Pending Approvals
      </a>
      <?php endif; ?>
    </div>
  </div>
  <svg class="page-hero-illustration" viewBox="0 0 280 180" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="20" y="10" width="240" height="160" rx="16" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.2)" stroke-width="1.5"/>
    <rect x="20" y="10" width="240" height="40" rx="16" fill="rgba(255,255,255,0.15)"/>
    <rect x="20" y="34" width="240" height="16" fill="rgba(255,255,255,0.15)"/>
    <rect x="36" y="18" width="80" height="8" rx="4" fill="rgba(255,255,255,0.8)"/>
    <rect x="36" y="30" width="50" height="5" rx="2.5" fill="rgba(255,255,255,0.5)"/>
    <g transform="translate(36,62)">
      <rect width="200" height="28" rx="8" fill="rgba(255,255,255,0.12)"/>
      <rect x="8" y="8" width="12" height="12" rx="3" fill="#4ade80"/>
      <rect x="28" y="10" width="80" height="6" rx="3" fill="rgba(255,255,255,0.7)"/>
      <rect x="28" y="18" width="50" height="4" rx="2" fill="rgba(255,255,255,0.4)"/>
      <rect x="160" y="8" width="32" height="12" rx="6" fill="rgba(74,222,128,0.3)"/>
      <rect x="166" y="12" width="20" height="4" rx="2" fill="#4ade80"/>
    </g>
    <g transform="translate(36,98)">
      <rect width="200" height="28" rx="8" fill="rgba(255,255,255,0.12)"/>
      <rect x="8" y="8" width="12" height="12" rx="3" fill="#fbbf24"/>
      <rect x="28" y="10" width="70" height="6" rx="3" fill="rgba(255,255,255,0.7)"/>
      <rect x="28" y="18" width="45" height="4" rx="2" fill="rgba(255,255,255,0.4)"/>
      <rect x="160" y="8" width="32" height="12" rx="6" fill="rgba(251,191,36,0.3)"/>
      <rect x="166" y="12" width="20" height="4" rx="2" fill="#fbbf24"/>
    </g>
    <g transform="translate(36,134)">
      <rect width="200" height="28" rx="8" fill="rgba(255,255,255,0.12)"/>
      <rect x="8" y="8" width="12" height="12" rx="3" fill="#f87171"/>
      <rect x="28" y="10" width="90" height="6" rx="3" fill="rgba(255,255,255,0.7)"/>
      <rect x="28" y="18" width="55" height="4" rx="2" fill="rgba(255,255,255,0.4)"/>
      <rect x="160" y="8" width="32" height="12" rx="6" fill="rgba(248,113,113,0.3)"/>
      <rect x="166" y="12" width="20" height="4" rx="2" fill="#f87171"/>
    </g>
  </svg>
</div>

<div class="page-header">
  <div>
    <div class="page-header-title">Leave Management</div>
    <div class="page-header-sub">Track and manage employee leaves</div>
  </div>
  <div class="page-header-actions">
    <?php if ($_SESSION['user_role'] === 'employee'): ?>
    <a href="<?= url('leaves/request') ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Apply Leave</a>
    <?php else: ?>
    <a href="<?= url('leaves/approvals') ?>" class="btn btn-warning"><i class="fas fa-clock"></i> Pending Approvals</a>
    <?php endif; ?>
  </div>
</div>

<!-- Leave Balance (for employees) -->
<?php if (!empty($balance)): ?>
<div class="card" style="margin-bottom:20px">
  <div class="card-header"><span class="card-title"><i class="fas fa-balance-scale" style="color:#6366f1;margin-right:8px"></i>Leave Balance <?= date('Y') ?></span></div>
  <div class="card-body">
    <div class="leave-balance-grid">
      <?php
      $leaveTypes = ['annual' => 20, 'sick' => 10, 'casual' => 7, 'maternity' => 90, 'paternity' => 14];
      $taken = [];
      foreach ($balance as $b) $taken[$b['leave_type']] = (int)$b['days_taken'];
      foreach ($leaveTypes as $type => $allowed):
        $used = $taken[$type] ?? 0;
        $remaining = max(0, $allowed - $used);
      ?>
      <div class="leave-balance-card">
        <div class="leave-balance-type"><?= ucfirst($type) ?></div>
        <div class="leave-balance-days"><?= $remaining ?></div>
        <div class="leave-balance-label"><?= $used ?>/<?= $allowed ?> used</div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Leave Table -->
<div class="card">
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <?php if ($_SESSION['user_role'] !== 'employee'): ?><th>Employee</th><?php endif; ?>
          <th>Type</th>
          <th>From</th>
          <th>To</th>
          <th>Days</th>
          <th>Reason</th>
          <th>Status</th>
          <th>Applied</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($leaves)): ?>
        <tr><td colspan="8">
          <div class="empty-state">
            <div class="empty-state-icon"><i class="fas fa-calendar-times"></i></div>
            <div class="empty-state-title">No leave records found</div>
            <?php if ($_SESSION['user_role'] === 'employee'): ?>
            <div class="empty-state-text"><a href="<?= url('leaves/request') ?>" class="btn btn-primary btn-sm" style="margin-top:10px">Apply for Leave</a></div>
            <?php endif; ?>
          </div>
        </td></tr>
        <?php else: ?>
        <?php foreach ($leaves as $l): ?>
        <tr>
          <?php if ($_SESSION['user_role'] !== 'employee'): ?>
          <td>
            <div class="emp-info-name"><?= e($l['employee_name']) ?></div>
            <div class="emp-info-code"><?= e($l['department']) ?></div>
          </td>
          <?php endif; ?>
          <td>
            <span class="badge badge-primary"><?= ucfirst($l['leave_type']) ?></span>
          </td>
          <td><?= formatDate($l['start_date']) ?></td>
          <td><?= formatDate($l['end_date']) ?></td>
          <td><strong><?= (new DateTime($l['start_date']))->diff(new DateTime($l['end_date']))->days + 1 ?></strong></td>
          <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
            <?= e($l['reason'] ?: '—') ?>
          </td>
          <td><?= statusBadge($l['status']) ?></td>
          <td><?= timeAgo($l['created_at']) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
