<!-- Notification Bell Partial (included in header.php) -->
<!-- This file is a placeholder — notifications render via AJAX in header.php -->
<!-- See: app/views/layouts/header.php for the notification bell HTML -->
<!-- See: public/assets/js/app.js loadNotifications() for the AJAX logic -->
