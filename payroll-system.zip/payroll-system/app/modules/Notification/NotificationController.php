<?php
require_once CORE_PATH . '/Controller.php';

class NotificationController extends Controller {
    public function index(): void {
        $this->requireAuth();
        $uid  = currentUserId();
        $db   = Database::getInstance();

        $stmt = $db->prepare(
            "SELECT * FROM notifications WHERE user_id=:uid ORDER BY created_at DESC LIMIT 30"
        );
        $stmt->execute([':uid' => $uid]);
        $notifications = $stmt->fetchAll();

        $stmt2 = $db->prepare("SELECT COUNT(*) FROM notifications WHERE user_id=:uid AND is_read=0");
        $stmt2->execute([':uid' => $uid]);
        $unread = (int)$stmt2->fetchColumn();

        $this->json(['notifications' => $notifications, 'unread_count' => $unread]);
    }

    public function markRead(string $id): void {
        $this->requireAuth();
        $db   = Database::getInstance();
        $stmt = $db->prepare(
            "UPDATE notifications SET is_read=1 WHERE id=:id AND user_id=:uid"
        );
        $stmt->execute([':id' => (int)$id, ':uid' => currentUserId()]);
        $this->json(['success' => true]);
    }

    public function markAllRead(): void {
        $this->requireAuth();
        $db   = Database::getInstance();
        $stmt = $db->prepare("UPDATE notifications SET is_read=1 WHERE user_id=:uid");
        $stmt->execute([':uid' => currentUserId()]);
        $this->json(['success' => true]);
    }
}
