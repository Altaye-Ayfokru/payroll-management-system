<div class="page-header">
  <div>
    <div class="page-header-title">My Profile</div>
    <div class="page-header-sub">Manage your account information</div>
  </div>
</div>

<div class="grid-2">
  <!-- Profile Card -->
  <div>
    <div class="profile-card" style="margin-bottom:20px">
      <div class="profile-cover"></div>
      <div class="profile-info">
        <?php if (!empty($user['avatar'])): ?>
        <img src="<?= e(url($user['avatar'])) ?>"
             alt="Avatar" class="profile-avatar" id="profileAvatarPreview">
        <?php else: ?>
        <div id="profileAvatarPreview" style="width:80px;height:80px;border-radius:50%;overflow:hidden;border:4px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.15);margin:0 auto">
          <?= renderAvatarSvg($user['name'] ?? 'U', (int)($user['id'] ?? 0), 80) ?>
        </div>
        <?php endif; ?>
        <div class="profile-name"><?= e($user['name']) ?></div>
        <div class="profile-role"><?= ucfirst($user['role']) ?></div>
        <?php if ($employee): ?>
        <div style="font-size:.8rem;color:#64748b;margin-top:4px"><?= e($employee['position']) ?> · <?= e($employee['department']) ?></div>
        <div class="profile-meta">
          <div class="profile-meta-item">
            <div class="profile-meta-val"><?= e($employee['employee_code']) ?></div>
            <div class="profile-meta-label">Employee ID</div>
          </div>
          <div class="profile-meta-item">
            <div class="profile-meta-val"><?= formatDate($employee['hire_date'], 'M Y') ?></div>
            <div class="profile-meta-label">Joined</div>
          </div>
          <div class="profile-meta-item">
            <div class="profile-meta-val"><?= formatCurrency((float)$employee['basic_salary']) ?></div>
            <div class="profile-meta-label">Basic Salary</div>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Edit Form -->
  <div class="card">
    <div class="card-header"><span class="card-title">Edit Profile</span></div>
    <div class="card-body">
      <form method="POST" action="<?= url('profile/update') ?>" enctype="multipart/form-data">
        <?= csrfField() ?>

        <div class="avatar-upload" style="margin-bottom:20px">
          <?php if (!empty($user['avatar'])): ?>
          <img src="<?= e(url($user['avatar'])) ?>"
               alt="" class="avatar-preview" id="avatarPreview">
          <?php else: ?>
          <div id="avatarPreview" style="width:72px;height:72px;border-radius:50%;overflow:hidden;border:3px solid #e0e7ff">
            <?= renderAvatarSvg($user['name'] ?? 'U', (int)($user['id'] ?? 0), 72) ?>
          </div>
          <?php endif; ?>
          <div>
            <label class="avatar-upload-btn" for="avatarInput">
              <i class="fas fa-camera"></i> Change Photo
            </label>
            <input type="file" name="avatar" id="avatarInput" class="avatar-upload-input" accept="image/*"
                   onchange="document.getElementById('avatarPreview').src = URL.createObjectURL(this.files[0])">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Full Name</label>
          <input type="text" name="name" class="form-control" value="<?= e($user['name']) ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" class="form-control" value="<?= e($user['email']) ?>" disabled>
          <div class="form-hint">Email cannot be changed</div>
        </div>

        <div style="border-top:1px solid #e2e8f0;padding-top:16px;margin-top:8px">
          <div class="form-section-title">Change Password</div>
          <div class="form-group">
            <label class="form-label">New Password</label>
            <input type="password" name="new_password" class="form-control" placeholder="Leave blank to keep current">
            <div class="form-hint">Minimum 8 characters</div>
          </div>
        </div>

        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
      </form>
    </div>
  </div>
</div>
