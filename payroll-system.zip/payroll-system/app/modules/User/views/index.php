﻿<div class="page-header">
  <div>
    <div class="page-header-title">User Management</div>
    <div class="page-header-sub">Manage user accounts and roles</div>
  </div>
</div>

<div class="card">
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th>User</th>
          <th>Role</th>
          <th>Department</th>
          <th>Last Login</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
        <tr>
          <td>
            <div class="emp-cell">
              <?php if (!empty($u['avatar'])): ?>
              <img src="<?= e(url($u['avatar'])) ?>" alt="" class="avatar avatar-sm">
              <?php else: ?>
              <div style="width:32px;height:32px;border-radius:50%;overflow:hidden;flex-shrink:0">
                <?= renderAvatarSvg($u['name'] ?? 'U', (int)($u['id'] ?? 0), 32) ?>
              </div>
              <?php endif; ?>
              <div>
                <div class="emp-info-name"><?= e($u['name']) ?></div>
                <div class="emp-info-code"><?= e($u['email']) ?></div>
              </div>
            </div>
          </td>
          <td>
            <select class="form-control" style="width:auto;padding:4px 8px;font-size:.8rem"
                    onchange="updateRole(<?= $u['id'] ?>, this.value)">
              <option value="admin"    <?= $u['role'] === 'admin'    ? 'selected' : '' ?>>Admin</option>
              <option value="hr"       <?= $u['role'] === 'hr'       ? 'selected' : '' ?>>HR</option>
              <option value="employee" <?= $u['role'] === 'employee' ? 'selected' : '' ?>>Employee</option>
            </select>
          </td>
          <td><?= e($u['department'] ?? 'â€”') ?></td>
          <td><?= $u['last_login'] ? timeAgo($u['last_login']) : 'Never' ?></td>
          <td><?= $u['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>' ?></td>
          <td>
            <?php if ($u['id'] !== currentUserId()): ?>
            <button class="btn btn-danger btn-sm btn-icon" onclick="deleteUser(<?= $u['id'] ?>)" title="Delete">
              <i class="fas fa-trash"></i>
            </button>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
function updateRole(id, role) {
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', `users/update/${id}`, { csrf_token: csrf, role }, data => {
    if (data.success) showToast('Role updated.', 'success');
    else showToast('Failed to update role.', 'error');
  });
}
function deleteUser(id) {
  if (!confirm('Delete this user? This cannot be undone.')) return;
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', `users/delete/${id}`, { csrf_token: csrf }, data => {
    if (data.success) { showToast('User deleted.', 'success'); setTimeout(() => location.reload(), 800); }
    else showToast(data.message || 'Failed.', 'error');
  });
}
</script>
