<?php
require_once CORE_PATH . '/Controller.php';
require_once APP_PATH . '/models/User.php';
require_once APP_PATH . '/modules/Employee/EmployeeModel.php';

class UserController extends Controller {
    private User $userModel;

    public function __construct() {
        $this->userModel = new User();
    }

    public function index(): void {
        $this->requireRole('admin');
        $this->view('users.index', [
            'users'     => $this->userModel->getAllWithRoles(),
            'pageTitle' => 'User Management',
            'csrf'      => csrfToken(),
            'flash'     => $this->getFlash(),
        ]);
    }

    public function update(string $id): void {
        $this->requireRole('admin');
        if (!validateCsrf()) $this->json(['success' => false, 'message' => 'Invalid token'], 403);

        $allowed = ['admin', 'hr', 'employee'];
        $role    = in_array($_POST['role'] ?? '', $allowed) ? $_POST['role'] : 'employee';
        $active  = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 1;

        $this->userModel->update((int)$id, ['role' => $role, 'is_active' => $active]);
        logActivity(currentUserId(), "Updated user #{$id}");
        $this->json(['success' => true]);
    }

    public function delete(string $id): void {
        $this->requireRole('admin');
        if (!validateCsrf()) $this->json(['success' => false, 'message' => 'Invalid token'], 403);

        if ((int)$id === currentUserId()) {
            $this->json(['success' => false, 'message' => 'Cannot delete your own account.'], 400);
        }

        $this->userModel->delete((int)$id);
        logActivity(currentUserId(), "Deleted user #{$id}");
        $this->json(['success' => true]);
    }

    public function profile(): void {
        $this->requireAuth();
        $user = $this->userModel->findById(currentUserId());
        $emp  = (new EmployeeModel())->getByUserId(currentUserId());

        $this->view('users.profile', [
            'user'      => $user,
            'employee'  => $emp,
            'pageTitle' => 'My Profile',
            'csrf'      => csrfToken(),
            'flash'     => $this->getFlash(),
        ]);
    }

    public function updateProfile(): void {
        $this->requireAuth();
        if (!validateCsrf()) $this->json(['success' => false, 'message' => 'Invalid token'], 403);

        $update = ['name' => htmlspecialchars(trim($_POST['name'] ?? ''), ENT_QUOTES, 'UTF-8')];

        if (!empty($_FILES['avatar']['name'])) {
            $avatar = uploadFile($_FILES['avatar'], 'avatars');
            if ($avatar) $update['avatar'] = $avatar;
        }

        $this->userModel->update(currentUserId(), $update);

        if (!empty($_POST['new_password'])) {
            if (strlen($_POST['new_password']) < 8) {
                $this->flash('error', 'Password must be at least 8 characters.');
            } else {
                $this->userModel->updatePassword(currentUserId(), $_POST['new_password']);
            }
        }

        $_SESSION['user_name'] = $update['name'];
        logActivity(currentUserId(), 'Updated profile');
        $this->flash('success', 'Profile updated!');
        $this->redirect('profile');
    }
}
