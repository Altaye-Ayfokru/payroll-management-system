<?php
require_once CORE_PATH . '/Controller.php';
require_once APP_PATH . '/helpers/validator.php';
require_once APP_PATH . '/modules/Loan/LoanModel.php';
require_once APP_PATH . '/modules/Employee/EmployeeModel.php';

class LoanController extends Controller {
    private LoanModel $model;

    public function __construct() {
        $this->model = new LoanModel();
    }

    public function index(): void {
        $this->requireAuth();
        $role   = currentUserRole();
        $page   = max(1, (int)($_GET['page'] ?? 1));
        $pager  = paginate($this->model->count(), ITEMS_PER_PAGE, $page);

        if ($role === 'employee') {
            $emp   = (new EmployeeModel())->getByUserId(currentUserId());
            $loans = $emp ? $this->model->getByEmployee($emp['id']) : [];
        } else {
            $loans = $this->model->getAllWithEmployees(ITEMS_PER_PAGE, $pager['offset']);
        }

        $this->view('loans.index', [
            'loans'     => $loans,
            'pager'     => $pager,
            'pageTitle' => 'Loan Management',
            'flash'     => $this->getFlash(),
            'csrf'      => csrfToken(),
        ]);
    }

    public function requestPage(): void {
        $this->requireAuth();
        $this->view('loans.request', [
            'pageTitle' => 'Apply for Loan',
            'csrf'      => csrfToken(),
        ]);
    }

    public function store(): void {
        $this->requireAuth();
        if (!validateCsrf()) { $this->json(['success' => false, 'message' => 'Invalid token'], 403); return; }

        $emp = (new EmployeeModel())->getByUserId(currentUserId());
        if (!$emp) { $this->redirect('dashboard'); return; }

        $v = new Validator($_POST);
        $v->required('loan_type')->required('amount')->positive('amount')
          ->required('repayment_months')->positive('repayment_months');

        if (!$v->passes()) {
            $this->view('loans.request', [
                'errors'    => $v->errors(),
                'old'       => $_POST,
                'pageTitle' => 'Apply for Loan',
                'csrf'      => csrfToken(),
            ]);
            return;
        }

        $amount          = (float)$_POST['amount'];
        $repaymentMonths = (int)$_POST['repayment_months'];
        $monthlyPayment  = round($amount / $repaymentMonths, 2);

        $id = $this->model->insert([
            'employee_id'      => $emp['id'],
            'loan_type'        => htmlspecialchars(trim($_POST['loan_type']), ENT_QUOTES, 'UTF-8'),
            'amount'           => $amount,
            'repayment_months' => $repaymentMonths,
            'monthly_payment'  => $monthlyPayment,
            'reason'           => htmlspecialchars(trim($_POST['reason'] ?? ''), ENT_QUOTES, 'UTF-8'),
            'status'           => 'pending',
            'created_at'       => date('Y-m-d H:i:s'),
        ]);

        // Notify HR
        $db = Database::getInstance();
        $db->prepare(
            "INSERT INTO notifications (user_id,message,type,is_read,created_at)
             SELECT id, :msg, 'info', 0, NOW() FROM users WHERE role IN ('admin','hr')"
        )->execute([':msg' => "{$_SESSION['user_name']} applied for a loan of " . formatCurrency($amount) . "."]);

        logActivity(currentUserId(), "Applied for loan #{$id}");
        $this->flash('success', 'Loan request submitted successfully!');
        $this->redirect('loans');
    }

    public function approvals(): void {
        $this->requireRole('admin', 'hr');
        $this->view('loans.approvals', [
            'pending'   => $this->model->getPending(),
            'pageTitle' => 'Loan Approvals',
            'csrf'      => csrfToken(),
            'flash'     => $this->getFlash(),
        ]);
    }

    public function approve(string $id): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) { $this->json(['success' => false, 'message' => 'Invalid token'], 403); return; }

        $loan = $this->model->findById((int)$id);
        if (!$loan) { $this->json(['success' => false, 'message' => 'Not found'], 404); return; }

        $this->model->update((int)$id, [
            'status'      => 'approved',
            'approved_by' => currentUserId(),
            'approved_at' => date('Y-m-d H:i:s'),
        ]);

        $emp = (new EmployeeModel())->findById($loan['employee_id']);
        if ($emp) {
            Database::getInstance()->prepare(
                "INSERT INTO notifications (user_id,message,type,is_read,created_at)
                 VALUES (:uid,:msg,'success',0,NOW())"
            )->execute([':uid' => $emp['user_id'],
                        ':msg' => "Your loan request of " . formatCurrency((float)$loan['amount']) . " has been approved."]);
        }

        logActivity(currentUserId(), "Approved loan #{$id}");
        $this->json(['success' => true, 'message' => 'Loan approved']);
    }

    public function reject(string $id): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) { $this->json(['success' => false, 'message' => 'Invalid token'], 403); return; }

        $loan   = $this->model->findById((int)$id);
        $reason = htmlspecialchars(trim($_POST['reason'] ?? ''), ENT_QUOTES, 'UTF-8');

        $this->model->update((int)$id, [
            'status'           => 'rejected',
            'rejection_reason' => $reason,
        ]);

        $emp = (new EmployeeModel())->findById($loan['employee_id'] ?? 0);
        if ($emp) {
            Database::getInstance()->prepare(
                "INSERT INTO notifications (user_id,message,type,is_read,created_at)
                 VALUES (:uid,:msg,'warning',0,NOW())"
            )->execute([':uid' => $emp['user_id'],
                        ':msg' => "Your loan request was rejected." . ($reason ? " Reason: {$reason}" : '')]);
        }

        logActivity(currentUserId(), "Rejected loan #{$id}");
        $this->json(['success' => true, 'message' => 'Loan rejected']);
    }

    public function markPaid(string $id): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) { $this->json(['success' => false, 'message' => 'Invalid token'], 403); return; }

        $this->model->update((int)$id, ['status' => 'paid']);
        logActivity(currentUserId(), "Marked loan #{$id} as paid");
        $this->json(['success' => true, 'message' => 'Loan marked as paid']);
    }
}
