<?php
require_once CORE_PATH . '/Model.php';

class LoanModel extends Model {
    protected string $table = 'loans';

    public function getAllWithEmployees(int $limit = 20, int $offset = 0): array {
        return $this->query(
            "SELECT l.*, u.name AS employee_name, e.department, e.employee_code
             FROM loans l
             JOIN employees e ON e.id = l.employee_id
             JOIN users u ON u.id = e.user_id
             WHERE e.deleted_at IS NULL
             ORDER BY l.created_at DESC
             LIMIT :limit OFFSET :offset",
            [':limit' => $limit, ':offset' => $offset]
        );
    }

    public function getByEmployee(int $empId): array {
        return $this->query(
            "SELECT * FROM loans WHERE employee_id = :eid ORDER BY created_at DESC",
            [':eid' => $empId]
        );
    }

    public function getPending(): array {
        return $this->query(
            "SELECT l.*, u.name AS employee_name, e.department, e.employee_code
             FROM loans l
             JOIN employees e ON e.id = l.employee_id
             JOIN users u ON u.id = e.user_id
             WHERE l.status = 'pending' AND e.deleted_at IS NULL
             ORDER BY l.created_at ASC"
        );
    }

    public function getActiveLoans(): array {
        return $this->query(
            "SELECT l.*, u.name AS employee_name, e.department
             FROM loans l
             JOIN employees e ON e.id = l.employee_id
             JOIN users u ON u.id = e.user_id
             WHERE l.status = 'approved' AND e.deleted_at IS NULL
             ORDER BY l.approved_at DESC"
        );
    }

    public function getTotalByEmployee(int $empId): float {
        $stmt = $this->db->prepare(
            "SELECT COALESCE(SUM(amount), 0) FROM loans WHERE employee_id = :eid AND status = 'approved'"
        );
        $stmt->execute([':eid' => $empId]);
        return (float)$stmt->fetchColumn();
    }
}
