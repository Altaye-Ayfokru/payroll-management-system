<div class="page-header">
  <div>
    <div class="page-header-title">Apply for Loan</div>
    <div class="page-header-sub">Submit a loan request for HR review</div>
  </div>
  <a href="<?= url('loans') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<div class="card" style="max-width:640px">
  <div class="card-header">
    <span class="card-title"><i class="fas fa-hand-holding-usd" style="color:#6366f1;margin-right:8px"></i>Loan Application</span>
  </div>
  <div class="card-body">

    <?php if (!empty($errors)): ?>
    <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:10px;padding:14px;margin-bottom:18px">
      <div style="font-weight:700;color:#dc2626;margin-bottom:6px"><i class="fas fa-exclamation-circle"></i> Please fix the following errors:</div>
      <ul style="padding-left:16px;color:#dc2626;font-size:.85rem">
        <?php foreach ($errors as $err): ?>
        <li><?= e($err) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="<?= url('loans/store') ?>">
      <?= csrfField() ?>

      <div class="form-group">
        <label class="form-label">Loan Type <span class="required">*</span></label>
        <select name="loan_type" class="form-control" required>
          <option value="">Select loan type...</option>
          <option value="personal"    <?= ($old['loan_type']??'')==='personal'    ?'selected':'' ?>>Personal Loan</option>
          <option value="emergency"   <?= ($old['loan_type']??'')==='emergency'   ?'selected':'' ?>>Emergency Loan</option>
          <option value="education"   <?= ($old['loan_type']??'')==='education'   ?'selected':'' ?>>Education Loan</option>
          <option value="medical"     <?= ($old['loan_type']??'')==='medical'     ?'selected':'' ?>>Medical Loan</option>
          <option value="housing"     <?= ($old['loan_type']??'')==='housing'     ?'selected':'' ?>>Housing Loan</option>
          <option value="vehicle"     <?= ($old['loan_type']??'')==='vehicle'     ?'selected':'' ?>>Vehicle Loan</option>
          <option value="other"       <?= ($old['loan_type']??'')==='other'       ?'selected':'' ?>>Other</option>
        </select>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Loan Amount (ETB) <span class="required">*</span></label>
          <div class="input-group">
            <i class="fas fa-coins input-group-icon"></i>
            <input type="number" name="amount" id="loanAmount" class="form-control"
                   value="<?= e($old['amount'] ?? '') ?>" placeholder="0.00" step="0.01" min="100"
                   required oninput="updatePreview()">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Repayment Period (months) <span class="required">*</span></label>
          <select name="repayment_months" id="repaymentMonths" class="form-control" required onchange="updatePreview()">
            <option value="">Select period...</option>
            <?php foreach ([3, 6, 9, 12, 18, 24, 36] as $m): ?>
            <option value="<?= $m ?>" <?= ($old['repayment_months']??'')==$m?'selected':'' ?>><?= $m ?> months</option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <!-- Live Preview -->
      <div id="loanPreview" style="display:none;background:linear-gradient(135deg,#f0f4ff,#faf5ff);border:1px solid #ddd6fe;border-radius:12px;padding:16px;margin-bottom:18px">
        <div style="font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#6366f1;margin-bottom:10px">
          <i class="fas fa-calculator"></i> Repayment Preview
        </div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;font-size:.85rem">
          <div style="text-align:center;padding:10px;background:#fff;border-radius:8px;border:1px solid #e0e7ff">
            <div style="font-size:.7rem;color:#64748b;font-weight:600;text-transform:uppercase">Loan Amount</div>
            <div style="font-size:1.1rem;font-weight:800;color:#6366f1;margin-top:4px" id="previewAmount">—</div>
          </div>
          <div style="text-align:center;padding:10px;background:#fff;border-radius:8px;border:1px solid #e0e7ff">
            <div style="font-size:.7rem;color:#64748b;font-weight:600;text-transform:uppercase">Monthly Payment</div>
            <div style="font-size:1.1rem;font-weight:800;color:#10b981;margin-top:4px" id="previewMonthly">—</div>
          </div>
          <div style="text-align:center;padding:10px;background:#fff;border-radius:8px;border:1px solid #e0e7ff">
            <div style="font-size:.7rem;color:#64748b;font-weight:600;text-transform:uppercase">Total Repayment</div>
            <div style="font-size:1.1rem;font-weight:800;color:#0f172a;margin-top:4px" id="previewTotal">—</div>
          </div>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Reason / Purpose</label>
        <textarea name="reason" class="form-control" rows="3"
                  placeholder="Briefly describe the purpose of this loan..."><?= e($old['reason'] ?? '') ?></textarea>
      </div>

      <div style="background:#fef3c7;border:1px solid #fde68a;border-radius:10px;padding:12px;margin-bottom:18px;font-size:.82rem;color:#92400e">
        <i class="fas fa-info-circle"></i>
        <strong>Note:</strong> Loan requests are subject to HR approval. Monthly repayments will be deducted from your salary once approved.
      </div>

      <div style="display:flex;gap:10px;justify-content:flex-end">
        <a href="<?= url('loans') ?>" class="btn btn-outline">Cancel</a>
        <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit Application</button>
      </div>
    </form>
  </div>
</div>

<script>
function updatePreview() {
  var amount  = parseFloat(document.getElementById('loanAmount').value) || 0;
  var months  = parseInt(document.getElementById('repaymentMonths').value) || 0;
  var preview = document.getElementById('loanPreview');

  if (amount > 0 && months > 0) {
    var monthly = amount / months;
    var total   = monthly * months;
    document.getElementById('previewAmount').textContent  = 'ETB ' + amount.toLocaleString('en-US', {minimumFractionDigits:2});
    document.getElementById('previewMonthly').textContent = 'ETB ' + monthly.toLocaleString('en-US', {minimumFractionDigits:2});
    document.getElementById('previewTotal').textContent   = 'ETB ' + total.toLocaleString('en-US', {minimumFractionDigits:2});
    preview.style.display = 'block';
  } else {
    preview.style.display = 'none';
  }
}
</script>
