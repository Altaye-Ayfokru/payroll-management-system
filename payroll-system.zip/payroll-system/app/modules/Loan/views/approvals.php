<div class="page-header">
  <div>
    <div class="page-header-title">Loan Approvals</div>
    <div class="page-header-sub">Review and approve pending loan requests</div>
  </div>
  <a href="<?= url('loans') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> All Loans</a>
</div>

<?php if (!empty($flash)): ?>
<div class="flash-message flash-<?= e($flash['type']) ?>" id="flashMsg">
  <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
  <?= e($flash['message']) ?>
  <button class="flash-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
</div>
<?php endif; ?>

<?php if (empty($pending)): ?>
<div class="card">
  <div class="card-body">
    <div class="empty-state">
      <div class="empty-state-icon"><i class="fas fa-check-circle" style="color:#10b981"></i></div>
      <div class="empty-state-title">No pending loan requests</div>
      <div class="empty-state-text">All loan requests have been processed.</div>
    </div>
  </div>
</div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:14px">
  <?php foreach ($pending as $loan): ?>
  <div class="card" style="border-left:4px solid #f59e0b">
    <div class="card-body" style="padding:1.25rem 1.5rem">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;flex-wrap:wrap">
        <div style="display:flex;align-items:center;gap:1rem">
          <div style="width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.1rem;font-weight:700;flex-shrink:0">
            <?= strtoupper(substr($loan['employee_name'], 0, 1)) ?>
          </div>
          <div>
            <div style="font-weight:700;color:#0f172a;font-size:.95rem"><?= e($loan['employee_name']) ?></div>
            <div style="font-size:.78rem;color:#64748b"><?= e($loan['department']) ?> &middot; <?= e($loan['employee_code']) ?></div>
          </div>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-success btn-sm" onclick="loanAction('approve', <?= $loan['id'] ?>)">
            <i class="fas fa-check"></i> Approve
          </button>
          <button class="btn btn-danger btn-sm" onclick="showRejectModal(<?= $loan['id'] ?>)">
            <i class="fas fa-times"></i> Reject
          </button>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-top:1rem;padding-top:1rem;border-top:1px solid #f1f5f9">
        <div>
          <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;color:#94a3b8">Loan Type</div>
          <div style="font-size:.875rem;font-weight:600;color:#0f172a;margin-top:2px">
            <?= ucfirst(str_replace('_', ' ', $loan['loan_type'])) ?>
          </div>
        </div>
        <div>
          <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;color:#94a3b8">Amount</div>
          <div style="font-size:.875rem;font-weight:700;color:#6366f1;margin-top:2px"><?= formatCurrency((float)$loan['amount']) ?></div>
        </div>
        <div>
          <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;color:#94a3b8">Monthly Payment</div>
          <div style="font-size:.875rem;font-weight:600;color:#10b981;margin-top:2px"><?= formatCurrency((float)$loan['monthly_payment']) ?>/mo</div>
        </div>
        <div>
          <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;color:#94a3b8">Repayment Period</div>
          <div style="font-size:.875rem;font-weight:600;color:#0f172a;margin-top:2px"><?= (int)$loan['repayment_months'] ?> months</div>
        </div>
        <div>
          <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;color:#94a3b8">Applied</div>
          <div style="font-size:.875rem;font-weight:600;color:#0f172a;margin-top:2px"><?= timeAgo($loan['created_at']) ?></div>
        </div>
        <?php if (!empty($loan['reason'])): ?>
        <div style="grid-column:1/-1">
          <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;color:#94a3b8">Reason</div>
          <div style="font-size:.85rem;color:#374151;margin-top:2px"><?= e($loan['reason']) ?></div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Reject Modal -->
<div class="modal-overlay" id="rejectModal" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title"><i class="fas fa-times-circle" style="color:#ef4444;margin-right:8px"></i>Reject Loan Request</span>
      <button class="modal-close" onclick="closeModal('rejectModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body">
      <input type="hidden" id="rejectLoanId">
      <div class="form-group">
        <label class="form-label">Rejection Reason (optional)</label>
        <textarea id="rejectReason" class="form-control" rows="3" placeholder="Provide a reason for rejection..."></textarea>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal('rejectModal')">Cancel</button>
      <button class="btn btn-danger" onclick="confirmReject()"><i class="fas fa-times"></i> Reject Loan</button>
    </div>
  </div>
</div>

<script>
function loanAction(action, id) {
  if (!confirm('Approve this loan request?')) return;
  var csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', 'loans/' + action + '/' + id, { csrf_token: csrf }, function(data) {
    if (data.success) {
      showToast(data.message, 'success');
      setTimeout(function() { location.reload(); }, 800);
    } else {
      showToast(data.message || 'Failed', 'error');
    }
  });
}

function showRejectModal(id) {
  document.getElementById('rejectLoanId').value = id;
  document.getElementById('rejectReason').value = '';
  openModal('rejectModal');
}

function confirmReject() {
  var id     = document.getElementById('rejectLoanId').value;
  var reason = document.getElementById('rejectReason').value;
  var csrf   = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', 'loans/reject/' + id, { csrf_token: csrf, reason: reason }, function(data) {
    if (data.success) {
      showToast(data.message, 'success');
      closeModal('rejectModal');
      setTimeout(function() { location.reload(); }, 800);
    } else {
      showToast(data.message || 'Failed', 'error');
    }
  });
}
</script>
