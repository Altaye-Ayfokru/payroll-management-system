<?php
$role = $_SESSION['user_role'] ?? 'employee';
?>

<!-- Hero Banner -->
<div class="page-hero hero-loans">
  <div class="hero-orb hero-orb-1"></div>
  <div class="hero-orb hero-orb-2"></div>
  <div class="page-hero-content">
    <div class="hero-badge"><span class="hero-badge-dot"></span> Financial Services</div>
    <div class="page-hero-title">Loan Management</div>
    <div class="page-hero-sub">Apply for employee loans, track repayments, and manage approvals with ease.</div>
    <div class="page-hero-actions">
      <?php if ($role === 'employee'): ?>
      <a href="<?= url('loans/request') ?>" class="page-hero-btn page-hero-btn-white">
        <i class="fas fa-plus"></i> Apply for Loan
      </a>
      <?php else: ?>
      <a href="<?= url('loans/approvals') ?>" class="page-hero-btn page-hero-btn-white">
        <i class="fas fa-clock"></i> Pending Approvals
      </a>
      <?php endif; ?>
    </div>
  </div>
  <svg class="page-hero-illustration" viewBox="0 0 280 180" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="20" y="20" width="240" height="140" rx="16" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.2)" stroke-width="1.5"/>
    <circle cx="80" cy="90" r="40" fill="rgba(255,255,255,0.1)" stroke="rgba(255,255,255,0.2)" stroke-width="1.5"/>
    <text x="80" y="96" text-anchor="middle" font-size="22" font-weight="bold" fill="rgba(255,255,255,0.8)">$</text>
    <rect x="140" y="50" width="100" height="12" rx="6" fill="rgba(255,255,255,0.5)"/>
    <rect x="140" y="72" width="80" height="8" rx="4" fill="rgba(255,255,255,0.3)"/>
    <rect x="140" y="92" width="100" height="12" rx="6" fill="rgba(255,255,255,0.5)"/>
    <rect x="140" y="114" width="60" height="8" rx="4" fill="rgba(255,255,255,0.3)"/>
    <rect x="140" y="134" width="90" height="12" rx="6" fill="rgba(74,222,128,0.6)"/>
  </svg>
</div>

<div class="page-header">
  <div>
    <div class="page-header-title">Loan Management</div>
    <div class="page-header-sub">
      <?= $role === 'employee' ? 'Your loan applications and repayment schedule' : 'All employee loan requests' ?>
    </div>
  </div>
  <div class="page-header-actions">
    <?php if ($role === 'employee'): ?>
    <a href="<?= url('loans/request') ?>" class="btn btn-primary">
      <i class="fas fa-plus"></i> Apply for Loan
    </a>
    <?php else: ?>
    <a href="<?= url('loans/approvals') ?>" class="btn btn-warning">
      <i class="fas fa-clock"></i> Pending Approvals
    </a>
    <?php endif; ?>
  </div>
</div>

<?php if (!empty($flash)): ?>
<div class="flash-message flash-<?= e($flash['type']) ?>" id="flashMsg">
  <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
  <?= e($flash['message']) ?>
  <button class="flash-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
</div>
<?php endif; ?>

<!-- Summary Stats (HR/Admin only) -->
<?php if ($role !== 'employee' && !empty($loans)): ?>
<?php
$totalAmount   = array_sum(array_column($loans, 'amount'));
$approvedCount = count(array_filter($loans, fn($l) => $l['status'] === 'approved'));
$pendingCount  = count(array_filter($loans, fn($l) => $l['status'] === 'pending'));
$paidCount     = count(array_filter($loans, fn($l) => $l['status'] === 'paid'));
?>
<div class="summary-row" style="margin-bottom:20px">
  <div class="summary-chip">
    <div class="summary-chip-icon" style="background:#e0e7ff;color:#6366f1"><i class="fas fa-file-invoice-dollar"></i></div>
    <div><div class="summary-chip-val"><?= count($loans) ?></div><div class="summary-chip-label">Total Loans</div></div>
  </div>
  <div class="summary-chip">
    <div class="summary-chip-icon" style="background:#d1fae5;color:#10b981"><i class="fas fa-check-circle"></i></div>
    <div><div class="summary-chip-val"><?= $approvedCount ?></div><div class="summary-chip-label">Approved</div></div>
  </div>
  <div class="summary-chip">
    <div class="summary-chip-icon" style="background:#fef3c7;color:#f59e0b"><i class="fas fa-clock"></i></div>
    <div><div class="summary-chip-val"><?= $pendingCount ?></div><div class="summary-chip-label">Pending</div></div>
  </div>
  <div class="summary-chip">
    <div class="summary-chip-icon" style="background:#ecfdf5;color:#059669"><i class="fas fa-money-bill-wave"></i></div>
    <div><div class="summary-chip-val"><?= formatCurrency($totalAmount) ?></div><div class="summary-chip-label">Total Amount</div></div>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <?php if ($role !== 'employee'): ?><th>Employee</th><?php endif; ?>
          <th>Loan Type</th>
          <th>Amount</th>
          <th>Monthly Payment</th>
          <th>Repayment</th>
          <th>Reason</th>
          <th>Status</th>
          <th>Applied</th>
          <?php if ($role !== 'employee'): ?><th>Actions</th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($loans)): ?>
        <tr><td colspan="<?= $role !== 'employee' ? 9 : 7 ?>">
          <div class="empty-state">
            <div class="empty-state-icon"><i class="fas fa-hand-holding-usd"></i></div>
            <div class="empty-state-title">No loan records found</div>
            <?php if ($role === 'employee'): ?>
            <div class="empty-state-text">
              <a href="<?= url('loans/request') ?>" class="btn btn-primary btn-sm" style="margin-top:10px">
                <i class="fas fa-plus"></i> Apply for a Loan
              </a>
            </div>
            <?php endif; ?>
          </div>
        </td></tr>
        <?php else: ?>
        <?php foreach ($loans as $loan): ?>
        <tr>
          <?php if ($role !== 'employee'): ?>
          <td>
            <div class="emp-info-name"><?= e($loan['employee_name']) ?></div>
            <div class="emp-info-code"><?= e($loan['department'] ?? '') ?></div>
          </td>
          <?php endif; ?>
          <td>
            <span class="badge badge-primary"><?= ucfirst(str_replace('_', ' ', $loan['loan_type'])) ?></span>
          </td>
          <td><strong><?= formatCurrency((float)$loan['amount']) ?></strong></td>
          <td><?= formatCurrency((float)$loan['monthly_payment']) ?>/mo</td>
          <td><?= (int)$loan['repayment_months'] ?> months</td>
          <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
            <?= e($loan['reason'] ?: '—') ?>
          </td>
          <td><?= statusBadge($loan['status']) ?></td>
          <td><?= timeAgo($loan['created_at']) ?></td>
          <?php if ($role !== 'employee'): ?>
          <td>
            <div style="display:flex;gap:5px">
              <?php if ($loan['status'] === 'pending'): ?>
              <button class="btn btn-success btn-sm btn-icon" title="Approve"
                      onclick="loanAction('approve', <?= $loan['id'] ?>)">
                <i class="fas fa-check"></i>
              </button>
              <button class="btn btn-danger btn-sm btn-icon" title="Reject"
                      onclick="loanAction('reject', <?= $loan['id'] ?>)">
                <i class="fas fa-times"></i>
              </button>
              <?php elseif ($loan['status'] === 'approved'): ?>
              <button class="btn btn-outline btn-sm" title="Mark as Paid"
                      onclick="loanAction('mark-paid', <?= $loan['id'] ?>)">
                <i class="fas fa-check-double"></i> Paid
              </button>
              <?php endif; ?>
            </div>
          </td>
          <?php endif; ?>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if (isset($pager) && $pager['total_pages'] > 1): ?>
  <div class="pagination">
    <?php if ($pager['has_prev']): ?>
    <a href="?page=<?= $pager['current_page'] - 1 ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a>
    <?php endif; ?>
    <?php for ($i = max(1, $pager['current_page'] - 2); $i <= min($pager['total_pages'], $pager['current_page'] + 2); $i++): ?>
    <a href="?page=<?= $i ?>" class="page-btn <?= $i === $pager['current_page'] ? 'active' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($pager['has_next']): ?>
    <a href="?page=<?= $pager['current_page'] + 1 ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</div>

<script>
function loanAction(action, id) {
  var label = action === 'approve' ? 'approve' : (action === 'reject' ? 'reject' : 'mark as paid');
  if (!confirm('Are you sure you want to ' + label + ' this loan?')) return;
  var csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', 'loans/' + action + '/' + id, { csrf_token: csrf }, function(data) {
    if (data.success) {
      showToast(data.message, 'success');
      setTimeout(function() { location.reload(); }, 800);
    } else {
      showToast(data.message || 'Failed', 'error');
    }
  });
}
</script>
