<?php
$p = $payslip;
$monthLabel = date('F Y', strtotime(($p['pay_month'] ?? date('Y-m')) . '-01'));

// Helpers
$etb = fn(float $v) => 'ETB ' . number_format($v, 2);
$row = fn(string $label, float $val, string $cls = '') =>
    '<tr><td style="padding:7px 12px;color:#64748b;font-size:.85rem">' . $label . '</td>'
    . '<td style="padding:7px 12px;text-align:right;font-weight:600;font-size:.85rem;' . $cls . '">'
    . 'ETB ' . number_format($val, 2) . '</td></tr>';
?>

<div class="page-header">
  <div>
    <div class="page-header-title">Payslip</div>
    <div class="page-header-sub"><?= e($p['employee_name'] ?? '') ?> &mdash; <?= $monthLabel ?></div>
  </div>
  <div class="page-header-actions">
    <button onclick="window.print()" class="btn btn-outline"><i class="fas fa-print"></i> Print</button>
    <a href="<?= url('payroll/history') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back</a>
  </div>
</div>

<div style="max-width:800px;margin:0 auto">

<!-- ═══ PAYSLIP CARD ═══ -->
<div style="background:#fff;border-radius:20px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.12);border:1px solid #e2e8f0">

  <!-- Header -->
  <div style="background:linear-gradient(135deg,#0f172a 0%,#1e293b 50%,#312e81 100%);padding:2rem 2.5rem;color:#fff;display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:1rem">
    <div>
      <div style="font-size:1.5rem;font-weight:800;letter-spacing:-.02em">PayrollPro</div>
      <div style="font-size:.82rem;opacity:.65;margin-top:2px">HR &amp; Payroll Management System</div>
      <div style="margin-top:1rem;font-size:.75rem;opacity:.6;text-transform:uppercase;letter-spacing:.08em">Pay Slip</div>
      <div style="font-size:1.1rem;font-weight:700;margin-top:2px"><?= $monthLabel ?></div>
    </div>
    <div style="text-align:right">
      <?= statusBadge($p['status'] ?? 'pending') ?>
      <?php if (!empty($p['processed_by_name'])): ?>
      <div style="font-size:.75rem;opacity:.65;margin-top:8px">Processed by: <?= e($p['processed_by_name']) ?></div>
      <?php endif; ?>
      <?php if (!empty($p['approved_by_name'])): ?>
      <div style="font-size:.75rem;opacity:.65">Approved by: <?= e($p['approved_by_name']) ?></div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Employee Info -->
  <div style="display:grid;grid-template-columns:auto 1fr;gap:1.25rem;align-items:center;padding:1.5rem 2.5rem;background:#f8fafc;border-bottom:1px solid #e2e8f0">
    <?php
    $psName = $p['employee_name'] ?? 'E';
    $psId   = (int)($p['employee_id'] ?? 0);
    if (!empty($p['avatar'])): ?>
    <img src="<?= e(url($p['avatar'])) ?>"
         alt="" style="width:64px;height:64px;border-radius:50%;object-fit:cover;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.15)">
    <?php else: ?>
    <div style="width:64px;height:64px;border-radius:50%;overflow:hidden;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.15);flex-shrink:0">
      <?= renderAvatarSvg($psName, $psId, 64) ?>
    </div>
    <?php endif; ?>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:.75rem">
      <?php
      $infoFields = [
        ['Employee Name',    $p['employee_name'] ?? ''],
        ['Employee Code',    $p['employee_code'] ?? ''],
        ['Position',         $p['position_title'] ?? ($p['position'] ?? '')],
        ['Department',       $p['department'] ?? ''],
        ['Employment Date',  !empty($p['hire_date']) ? date('d M Y', strtotime($p['hire_date'])) : ''],
        ['Employment Type',  ucfirst(str_replace('_',' ', $p['employment_type'] ?? 'full_time'))],
        ['Bank',             $p['bank_name'] ?? '—'],
        ['Account No.',      $p['bank_account'] ?? '—'],
        ['Pay Period',       $monthLabel],
      ];
      foreach ($infoFields as [$label, $val]):
      ?>
      <div>
        <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#94a3b8"><?= $label ?></div>
        <div style="font-size:.85rem;font-weight:600;color:#0f172a;margin-top:2px"><?= e($val) ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Payroll Details -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:0;border-bottom:1px solid #e2e8f0">

    <!-- Earnings -->
    <div style="border-right:1px solid #e2e8f0">
      <div style="padding:.875rem 1.25rem;background:#f0fdf4;border-bottom:1px solid #e2e8f0">
        <div style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#10b981;display:flex;align-items:center;gap:.5rem">
          <i class="fas fa-plus-circle"></i> Earnings
        </div>
      </div>
      <table style="width:100%;border-collapse:collapse">
        <?= $row('Basic Salary',                          (float)($p['basic_salary'] ?? 0)) ?>
        <?= $row('Worked Days',                           (float)($p['worked_days'] ?? 0)) ?>
        <?= $row('Earned Salary (Worked × Basic ÷ 30)',   (float)($p['earned_salary'] ?? 0), 'color:#6366f1') ?>
        <tr><td colspan="2" style="padding:4px 12px;font-size:.7rem;color:#94a3b8;background:#f8fafc">Position Allowance</td></tr>
        <?= $row('  Non-Taxable Position Allowance',      (float)($p['position_allowance_nontaxable'] ?? 0)) ?>
        <?= $row('  Taxable Position Allowance',          (float)($p['position_allowance_taxable'] ?? 0)) ?>
        <tr><td colspan="2" style="padding:4px 12px;font-size:.7rem;color:#94a3b8;background:#f8fafc">Transport Allowance</td></tr>
        <?= $row('  Non-Taxable Transport Allowance',     (float)($p['transport_allowance_nontaxable'] ?? 0)) ?>
        <?= $row('  Taxable Transport Allowance',         (float)($p['transport_allowance_taxable'] ?? 0)) ?>
        <?php if (($p['other_commission'] ?? 0) > 0): ?>
        <?= $row('Other / Commission',                    (float)($p['other_commission'] ?? 0)) ?>
        <?php endif; ?>
        <?php if (($p['overtime_pay'] ?? 0) > 0): ?>
        <?= $row('Overtime Pay',                          (float)($p['overtime_pay'] ?? 0)) ?>
        <?php endif; ?>
        <?php if (($p['house_allowance'] ?? 0) > 0): ?>
        <?= $row('House Allowance',                       (float)($p['house_allowance'] ?? 0)) ?>
        <?php endif; ?>
        <?php if (($p['medical_allowance'] ?? 0) > 0): ?>
        <?= $row('Medical Allowance',                     (float)($p['medical_allowance'] ?? 0)) ?>
        <?php endif; ?>
        <tr style="background:#f0fdf4">
          <td style="padding:10px 12px;font-weight:700;font-size:.875rem;color:#065f46">Gross Pay</td>
          <td style="padding:10px 12px;text-align:right;font-weight:800;font-size:.95rem;color:#10b981">ETB <?= number_format((float)($p['gross_salary'] ?? 0), 2) ?></td>
        </tr>
      </table>
    </div>

    <!-- Deductions -->
    <div>
      <div style="padding:.875rem 1.25rem;background:#fef2f2;border-bottom:1px solid #e2e8f0">
        <div style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#ef4444;display:flex;align-items:center;gap:.5rem">
          <i class="fas fa-minus-circle"></i> Deductions
        </div>
      </div>
      <table style="width:100%;border-collapse:collapse">
        <?= $row('Taxable Income',                        (float)($p['taxable_income'] ?? 0), 'color:#6366f1') ?>
        <?= $row('Income Tax',                            (float)($p['income_tax'] ?? 0), 'color:#ef4444') ?>
        <tr><td colspan="2" style="padding:4px 12px;font-size:.7rem;color:#94a3b8;background:#f8fafc">Pension Contribution</td></tr>
        <?= $row('  Employee Pension (7%)',               (float)($p['employee_pension'] ?? 0), 'color:#ef4444') ?>
        <?= $row('  Employer Pension (11%)',              (float)($p['employer_pension'] ?? 0), 'color:#64748b') ?>
        <?= $row('  Total Pension',                       (float)($p['total_pension'] ?? 0)) ?>
        <?php if (($p['insurance'] ?? 0) > 0): ?>
        <?= $row('Insurance',                             (float)($p['insurance'] ?? 0), 'color:#ef4444') ?>
        <?php endif; ?>
        <tr style="background:#fef2f2">
          <td style="padding:10px 12px;font-weight:700;font-size:.875rem;color:#991b1b">Total Deductions</td>
          <td style="padding:10px 12px;text-align:right;font-weight:800;font-size:.95rem;color:#ef4444">ETB <?= number_format((float)($p['total_deductions'] ?? 0), 2) ?></td>
        </tr>
      </table>
    </div>

  </div>

  <!-- Net Payment -->
  <div style="background:linear-gradient(135deg,#6366f1,#8b5cf6);padding:1.5rem 2.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1rem">
    <div>
      <div style="font-size:.8rem;font-weight:600;color:rgba(255,255,255,.75);text-transform:uppercase;letter-spacing:.08em">Net Payment</div>
      <div style="font-size:.75rem;color:rgba(255,255,255,.55);margin-top:2px">Gross Pay &minus; Total Deductions</div>
    </div>
    <div style="font-size:2.2rem;font-weight:900;color:#fff;letter-spacing:-.03em">
      ETB <?= number_format((float)($p['net_payment'] ?? $p['net_salary'] ?? 0), 2) ?>
    </div>
  </div>

  <!-- Summary Row -->
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:0;border-top:1px solid #e2e8f0">
    <?php
    $summaryItems = [
      ['Gross Pay',         (float)($p['gross_salary'] ?? 0),    '#10b981'],
      ['Taxable Income',    (float)($p['taxable_income'] ?? 0),  '#6366f1'],
      ['Total Deductions',  (float)($p['total_deductions'] ?? 0),'#ef4444'],
      ['Net Payment',       (float)($p['net_payment'] ?? $p['net_salary'] ?? 0), '#0f172a'],
    ];
    foreach ($summaryItems as $i => [$label, $val, $color]):
    ?>
    <div style="padding:1rem 1.25rem;text-align:center;<?= $i < 3 ? 'border-right:1px solid #e2e8f0' : '' ?>">
      <div style="font-size:.7rem;color:#94a3b8;font-weight:600;text-transform:uppercase;letter-spacing:.05em"><?= $label ?></div>
      <div style="font-size:1rem;font-weight:800;color:<?= $color ?>;margin-top:4px">ETB <?= number_format($val, 2) ?></div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Footer -->
  <div style="padding:1rem 2.5rem;background:#f8fafc;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between;align-items:center;font-size:.75rem;color:#94a3b8">
    <span>Generated: <?= date('d M Y H:i') ?></span>
    <span>PayrollPro &mdash; Ethiopian Payroll System</span>
    <span>This is a computer-generated payslip</span>
  </div>

</div><!-- /payslip card -->
</div>

<style>
@media print {
  .page-header, .btn, .sidebar, .topbar, .main-wrapper > header { display: none !important; }
  .main-wrapper { margin-left: 0 !important; }
  .page-content { padding: 0 !important; }
  body { background: white !important; }
}
</style>
