﻿<?php
$posConfig = [
    'CEO'             => ['rate' => 0.10, 'taxable' => false],
    'COO'             => ['rate' => 0.08, 'taxable' => true],
    'CTO'             => ['rate' => 0.08, 'taxable' => true],
    'CISO'            => ['rate' => 0.08, 'taxable' => true],
    'Director'        => ['rate' => 0.07, 'taxable' => true],
    'Dept Head'       => ['rate' => 0.05, 'taxable' => true],
    'Normal Employee' => ['rate' => 0,    'taxable' => true],
];
$posConfigJson = json_encode($posConfig);
?>

<div class="page-header">
  <div>
    <div class="page-header-title">Run Payroll</div>
    <div class="page-header-sub">Process monthly salaries with Ethiopian tax rules</div>
  </div>
  <a href="<?= url('payroll') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem">

  <!-- ── Left: Run Payroll ── -->
  <div>
    <div class="card" style="margin-bottom:1.25rem">
      <div class="card-header">
        <span class="card-title"><i class="fas fa-play-circle" style="color:#10b981;margin-right:8px"></i>Process Monthly Payroll</span>
      </div>
      <div class="card-body">
        <div style="background:#f0fdf4;border:1.5px solid #bbf7d0;border-radius:10px;padding:14px;margin-bottom:18px;font-size:.82rem;color:#065f46">
          <strong><i class="fas fa-info-circle"></i> Ethiopian Payroll Rules Applied:</strong>
          <ul style="padding-left:16px;margin-top:6px;line-height:2">
            <li>Earned Salary = Worked Days &times; (Basic &divide; 30)</li>
            <li>CEO: 10% position allowance (non-taxable)</li>
            <li>COO/CTO/CISO/Director/Dept Head: taxable position allowance</li>
            <li>Positioned employees: 2,220 ETB transport (non-taxable)</li>
            <li>Normal employees: 600 ETB transport (non-taxable)</li>
            <li>Full-time: Employee 7% + Employer 11% pension</li>
            <li>Ethiopian progressive income tax slabs</li>
          </ul>
        </div>

        <form id="runPayrollForm">
          <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
          <div class="form-group">
            <label class="form-label">Pay Month <span class="required">*</span></label>
            <input type="month" name="month" class="form-control" value="<?= e($month) ?>" required>
          </div>
          <button type="button" class="btn btn-success btn-lg" style="width:100%" onclick="runPayroll()" id="runBtn">
            <i class="fas fa-play-circle"></i> Run Payroll for All Employees
          </button>
        </form>

        <div id="runResults" style="display:none;margin-top:16px"></div>
      </div>
    </div>

    <!-- Active Employees List -->
    <div class="card">
      <div class="card-header">
        <span class="card-title"><i class="fas fa-users" style="color:#6366f1;margin-right:8px"></i>Active Employees (<?= count($employees) ?>)</span>
        <span style="font-size:.75rem;color:#94a3b8">Click to load in calculator</span>
      </div>
      <div style="max-height:380px;overflow-y:auto">
        <table style="width:100%;border-collapse:collapse;font-size:.82rem">
          <thead>
            <tr style="background:#f8fafc;position:sticky;top:0;z-index:1">
              <th style="padding:8px 12px;text-align:left;font-size:.7rem;font-weight:700;text-transform:uppercase;color:#94a3b8;border-bottom:1px solid #e2e8f0">Employee</th>
              <th style="padding:8px 12px;text-align:left;font-size:.7rem;font-weight:700;text-transform:uppercase;color:#94a3b8;border-bottom:1px solid #e2e8f0">Title</th>
              <th style="padding:8px 12px;text-align:right;font-size:.7rem;font-weight:700;text-transform:uppercase;color:#94a3b8;border-bottom:1px solid #e2e8f0">Basic</th>
              <th style="padding:8px 12px;text-align:center;font-size:.7rem;font-weight:700;text-transform:uppercase;color:#94a3b8;border-bottom:1px solid #e2e8f0">Type</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($employees)): ?>
            <tr><td colspan="4" style="padding:24px;text-align:center;color:#94a3b8">No active employees found</td></tr>
            <?php else: ?>
            <?php foreach ($employees as $emp): ?>
            <tr class="emp-row" data-id="<?= (int)$emp['id'] ?>"
                data-basic="<?= (float)$emp['basic_salary'] ?>"
                data-title="<?= htmlspecialchars($emp['position_title'] ?? 'Normal Employee', ENT_QUOTES) ?>"
                data-type="<?= htmlspecialchars($emp['employment_type'] ?? 'full_time', ENT_QUOTES) ?>"
                data-commission="<?= (float)($emp['other_commission'] ?? 0) ?>"
                style="border-bottom:1px solid #f1f5f9;cursor:pointer;transition:background .15s"
                onmouseover="this.style.background='#f0f4ff'" onmouseout="this.style.background=''">
              <td style="padding:9px 12px;font-weight:600;color:#0f172a"><?= e($emp['name'] ?? 'Employee') ?></td>
              <td style="padding:9px 12px;color:#64748b;font-size:.78rem"><?= e($emp['position_title'] ?? $emp['position'] ?? 'Normal Employee') ?></td>
              <td style="padding:9px 12px;text-align:right;font-weight:600;color:#0f172a">ETB <?= number_format((float)$emp['basic_salary'], 0) ?></td>
              <td style="padding:9px 12px;text-align:center">
                <?php $ft = ($emp['employment_type'] ?? 'full_time') === 'full_time'; ?>
                <span style="font-size:.68rem;font-weight:700;padding:2px 8px;border-radius:999px;background:<?= $ft ? '#d1fae5' : '#dbeafe' ?>;color:<?= $ft ? '#065f46' : '#1e40af' ?>">
                  <?= $ft ? 'Full-time' : 'Part-time' ?>
                </span>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- ── Right: Live Calculator ── -->
  <div>
    <div class="card" id="calcCard">
      <div class="card-header">
        <span class="card-title"><i class="fas fa-calculator" style="color:#6366f1;margin-right:8px"></i>Live Payroll Calculator</span>
        <span id="calcEmpName" style="font-size:.78rem;color:#6366f1;font-weight:600"></span>
      </div>
      <div class="card-body">

        <!-- Inputs -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem">Basic Salary (ETB)</label>
            <input type="number" id="calcBasic" class="form-control" placeholder="e.g. 15000" step="0.01" min="0">
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem">Worked Days</label>
            <input type="number" id="calcWorkedDays" class="form-control" value="30" min="1" max="31">
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem">Position Title</label>
            <select id="calcPosition" class="form-control">
              <?php foreach (array_keys($posConfig) as $pt): ?>
              <option value="<?= htmlspecialchars($pt, ENT_QUOTES) ?>"><?= htmlspecialchars($pt, ENT_QUOTES) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-size:.78rem">Employment Type</label>
            <select id="calcEmpType" class="form-control">
              <option value="full_time">Full-time</option>
              <option value="part_time">Part-time</option>
            </select>
          </div>
          <div class="form-group" style="margin-bottom:0;grid-column:1/-1">
            <label class="form-label" style="font-size:.78rem">Other / Commission (ETB)</label>
            <input type="number" id="calcOther" class="form-control" value="0" step="0.01" min="0">
          </div>
        </div>

        <!-- Calculate Button -->
        <button type="button" class="btn btn-primary" style="width:100%;margin-bottom:16px" onclick="recalculate()">
          <i class="fas fa-calculator"></i> Calculate
        </button>

        <!-- Results -->
        <div id="calcResults" style="background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;overflow:hidden">
          <div style="padding:.75rem 1rem;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:.82rem;font-weight:700;display:flex;align-items:center;gap:.5rem">
            <i class="fas fa-table"></i> Payroll Breakdown
          </div>
          <div id="calcTableWrap">
            <div style="padding:32px;text-align:center;color:#94a3b8">
              <i class="fas fa-calculator" style="font-size:2rem;display:block;margin-bottom:.5rem;opacity:.3"></i>
              <div style="font-size:.85rem">Enter a basic salary and click <strong>Calculate</strong></div>
              <div style="font-size:.75rem;margin-top:.25rem">or click an employee row on the left</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

</div>

<script>
(function() {
  // ── Config ──────────────────────────────────────────────────
  var posConfig = <?= $posConfigJson ?>;
  var positionedTitles = ['CEO','COO','CTO','CISO','Director','Dept Head'];

  // ── Ethiopian Tax Slabs ──────────────────────────────────────
  // [min, max (0=unlimited), rate%, deductible_fee]
  var taxSlabs = [
    [0,       600,    0,    0],
    [601,    1650,   10,   60],
    [1651,   3200,   15,   142.5],
    [3201,   5250,   20,   302.5],
    [5251,   7800,   25,   565],
    [7801,  10900,   30,   965],
    [10901,     0,   35,  1500],
  ];

  function calcTax(income) {
    if (income <= 0) return 0;
    for (var i = 0; i < taxSlabs.length; i++) {
      var s = taxSlabs[i];
      if (income >= s[0] && (s[1] === 0 || income <= s[1])) {
        if (s[2] === 0) return 0;
        return Math.max(0, Math.round((income * s[2] / 100 - s[3]) * 100) / 100);
      }
    }
    return 0;
  }

  function fmt(v) {
    return 'ETB ' + parseFloat(v).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
  }

  function round2(v) {
    return Math.round(v * 100) / 100;
  }

  // ── Main calculate function ──────────────────────────────────
  window.recalculate = function() {
    var basic      = parseFloat(document.getElementById('calcBasic').value) || 0;
    var days       = parseInt(document.getElementById('calcWorkedDays').value) || 30;
    var position   = document.getElementById('calcPosition').value;
    var empType    = document.getElementById('calcEmpType').value;
    var commission = parseFloat(document.getElementById('calcOther').value) || 0;

    if (basic <= 0) {
      document.getElementById('calcTableWrap').innerHTML =
        '<div style="padding:32px;text-align:center;color:#94a3b8">' +
        '<i class="fas fa-exclamation-circle" style="font-size:1.5rem;display:block;margin-bottom:.5rem;color:#f59e0b;opacity:.7"></i>' +
        '<div style="font-size:.85rem">Please enter a valid basic salary (greater than 0)</div></div>';
      return;
    }

    // 1. Earned salary
    var earned = round2(days * (basic / 30));

    // 2. Position allowance
    var pa = posConfig[position] || {rate: 0, taxable: true};
    var posAllow        = round2(basic * pa.rate);
    var posAllowTaxable = pa.taxable ? posAllow : 0;
    var posAllowNonTax  = pa.taxable ? 0 : posAllow;

    // 3. Transport allowance (always non-taxable)
    var isPositioned = positionedTitles.indexOf(position) !== -1;
    var transAllow   = isPositioned ? 2220 : 600;

    // 4. Gross pay
    var gross = round2(earned + posAllow + transAllow + commission);

    // 5. Taxable income
    var taxable = round2(earned + posAllowTaxable + commission);
    // Note: transport is always non-taxable

    // 6. Income tax
    var tax = calcTax(taxable);

    // 7. Pension (full-time only, on basic salary)
    var empPension  = empType === 'full_time' ? round2(basic * 0.07) : 0;
    var emplrPension = empType === 'full_time' ? round2(basic * 0.11) : 0;
    var totalPension = round2(empPension + emplrPension);

    // 8. Total deductions & net
    var totalDed = round2(tax + empPension);
    var net      = round2(gross - totalDed);

    // ── Build table ──────────────────────────────────────────
    var rows = [
      // [label, value, labelStyle, valueStyle, isSeparator]
      ['Basic Salary',                    fmt(basic),       '', '', false],
      ['Worked Days',                     days + ' / 30',   '', 'color:#64748b', false],
      ['Earned Salary',                   fmt(earned),      '', 'color:#6366f1;font-weight:700', false],
      ['', '', 'SEPARATOR', '', true],
      ['Position Allowance (' + (pa.rate * 100) + '%)', '', 'color:#94a3b8;font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em', '', false],
      ['  Taxable',                       fmt(posAllowTaxable),  'padding-left:20px', '', false],
      ['  Non-Taxable',                   fmt(posAllowNonTax),   'padding-left:20px', '', false],
      ['', '', 'SEPARATOR', '', true],
      ['Transport Allowance',             '', 'color:#94a3b8;font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em', '', false],
      ['  Non-Taxable (' + (isPositioned ? '2,220' : '600') + ' ETB)', fmt(transAllow), 'padding-left:20px', '', false],
      ['  Taxable',                       fmt(0),           'padding-left:20px', '', false],
    ];

    if (commission > 0) {
      rows.push(['', '', 'SEPARATOR', '', true]);
      rows.push(['Other / Commission',    fmt(commission),  '', 'color:#374151', false]);
    }

    rows = rows.concat([
      ['', '', 'SEPARATOR', '', true],
      ['Gross Pay',                       fmt(gross),       'font-weight:700', 'color:#10b981;font-weight:800;font-size:.9rem', false],
      ['Taxable Income',                  fmt(taxable),     '', 'color:#6366f1;font-weight:700', false],
      ['', '', 'SEPARATOR', '', true],
      ['Income Tax',                      fmt(tax),         '', 'color:#ef4444;font-weight:700', false],
      ['Employee Pension (7%)',           fmt(empPension),  '', 'color:#ef4444', false],
      ['Employer Pension (11%)',          fmt(emplrPension),'', 'color:#64748b', false],
      ['Total Pension',                   fmt(totalPension),'', '', false],
      ['', '', 'SEPARATOR', '', true],
      ['Total Deductions',                fmt(totalDed),    'font-weight:700', 'color:#ef4444;font-weight:800;font-size:.9rem', false],
    ]);

    var html = '<table style="width:100%;border-collapse:collapse;font-size:.82rem">';

    rows.forEach(function(r) {
      if (r[2] === 'SEPARATOR') {
        html += '<tr><td colspan="2" style="height:1px;background:#e2e8f0;padding:0"></td></tr>';
        return;
      }
      html += '<tr style="border-bottom:1px solid #f8fafc">'
            + '<td style="padding:6px 12px;' + r[2] + ';color:#374151">' + r[0] + '</td>'
            + '<td style="padding:6px 12px;text-align:right;' + r[3] + '">' + r[1] + '</td>'
            + '</tr>';
    });

    // NET PAYMENT row — highlighted
    html += '<tr style="background:linear-gradient(135deg,#6366f1,#8b5cf6)">'
          + '<td style="padding:12px 14px;color:#fff;font-weight:800;font-size:.95rem;letter-spacing:.01em">NET PAYMENT</td>'
          + '<td style="padding:12px 14px;text-align:right;color:#fff;font-weight:900;font-size:1.1rem">' + fmt(net) + '</td>'
          + '</tr>';

    html += '</table>';

    document.getElementById('calcTableWrap').innerHTML = html;
  };

  // ── Load employee data into calculator ───────────────────────
  window.loadFromRow = function(row) {
    var basic      = parseFloat(row.getAttribute('data-basic')) || 0;
    var title      = row.getAttribute('data-title') || 'Normal Employee';
    var type       = row.getAttribute('data-type') || 'full_time';
    var commission = parseFloat(row.getAttribute('data-commission')) || 0;
    var name       = row.cells[0] ? row.cells[0].textContent.trim() : '';

    document.getElementById('calcBasic').value      = basic;
    document.getElementById('calcWorkedDays').value = 30;
    document.getElementById('calcPosition').value   = title;
    document.getElementById('calcEmpType').value    = type;
    document.getElementById('calcOther').value      = commission;

    var nameEl = document.getElementById('calcEmpName');
    if (nameEl) nameEl.textContent = name ? '— ' + name : '';

    // Highlight selected row
    document.querySelectorAll('.emp-row').forEach(function(r) {
      r.style.background = '';
      r.style.fontWeight = '';
    });
    row.style.background = '#eef2ff';

    recalculate();
  };

  // ── Wire up employee rows ────────────────────────────────────
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.emp-row').forEach(function(row) {
      row.addEventListener('click', function() {
        loadFromRow(this);
      });
    });

    // Also wire up input changes to auto-recalculate
    ['calcBasic','calcWorkedDays','calcOther'].forEach(function(id) {
      var el = document.getElementById(id);
      if (el) {
        el.addEventListener('input', recalculate);
        el.addEventListener('change', recalculate);
      }
    });
    ['calcPosition','calcEmpType'].forEach(function(id) {
      var el = document.getElementById(id);
      if (el) el.addEventListener('change', recalculate);
    });
  });

  // ── Run Payroll ──────────────────────────────────────────────
  window.runPayroll = function() {
    var form  = document.getElementById('runPayrollForm');
    var btn   = document.getElementById('runBtn');
    var month = form.querySelector('[name="month"]').value;

    if (!month) { showToast('Please select a pay month.', 'error'); return; }
    if (!confirm('Run payroll for ' + month + '?\nThis will process all active employees using Ethiopian tax rules.')) return;

    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';

    var fd = new FormData(form);
    ajax('POST', 'payroll/run', fd, function(data) {
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-play-circle"></i> Run Payroll for All Employees';

      if (data.success) {
        showToast(data.message, 'success');
        var r = data.results;
        var resultsEl = document.getElementById('runResults');
        resultsEl.style.display = 'block';
        resultsEl.innerHTML =
          '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:12px">'
          + '<div style="background:#d1fae5;border-radius:10px;padding:14px;text-align:center">'
          +   '<div style="font-size:1.5rem;font-weight:800;color:#10b981">' + r.success.length + '</div>'
          +   '<div style="font-size:.75rem;color:#065f46;font-weight:600">Processed</div></div>'
          + '<div style="background:#fef3c7;border-radius:10px;padding:14px;text-align:center">'
          +   '<div style="font-size:1.5rem;font-weight:800;color:#f59e0b">' + r.skipped.length + '</div>'
          +   '<div style="font-size:.75rem;color:#92400e;font-weight:600">Skipped</div></div>'
          + '<div style="background:#fee2e2;border-radius:10px;padding:14px;text-align:center">'
          +   '<div style="font-size:1.5rem;font-weight:800;color:#ef4444">' + r.errors.length + '</div>'
          +   '<div style="font-size:.75rem;color:#991b1b;font-weight:600">Errors</div></div>'
          + '</div>'
          + '<a href="' + BASE_URL + '/payroll" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i> View Payroll</a>';
      } else {
        showToast(data.message || 'Failed to run payroll.', 'error');
      }
    });
  };

}()); // end IIFE
</script>
