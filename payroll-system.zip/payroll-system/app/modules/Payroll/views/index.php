﻿<!-- Hero Banner -->
<div class="page-hero hero-payroll">
  <div class="hero-orb hero-orb-1"></div>
  <div class="hero-orb hero-orb-2"></div>
  <div class="page-hero-content">
    <div class="hero-badge"><span class="hero-badge-dot"></span> Payroll Processing</div>
    <div class="page-hero-title">Monthly Payroll</div>
    <div class="page-hero-sub">Process salaries, approve payroll, and generate payslips with Ethiopian tax rules applied automatically.</div>
    <div class="page-hero-actions">
      <a href="<?= url('payroll/run') ?>" class="page-hero-btn page-hero-btn-white">
        <i class="fas fa-play-circle"></i> Run Payroll
      </a>
      <a href="<?= url('payroll/export?month=' . $month) ?>" class="page-hero-btn page-hero-btn-outline">
        <i class="fas fa-download"></i> Export CSV
      </a>
    </div>
  </div>
  <svg class="page-hero-illustration" viewBox="0 0 280 180" fill="none" xmlns="http://www.w3.org/2000/svg" style="overflow:visible">
    <style>
      .ph-p1{animation:phF1 3.8s ease-in-out infinite}
      .ph-p2{animation:phF2 4.2s ease-in-out infinite .7s}
      .ph-coin{animation:phCoin 3s ease-in-out infinite}
      .ph-slip{animation:phSlip .9s ease .2s both}
      .ph-chk{animation:phChk .5s cubic-bezier(.34,1.56,.64,1) 1.4s both}
      @keyframes phF1{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
      @keyframes phF2{0%,100%{transform:translateY(0)}50%{transform:translateY(-11px)}}
      @keyframes phCoin{0%,100%{transform:translateY(0) rotate(-5deg)}50%{transform:translateY(-12px) rotate(5deg)}}
      @keyframes phSlip{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
      @keyframes phChk{0%{transform:scale(0)}70%{transform:scale(1.2)}100%{transform:scale(1)}}
    </style>
    <ellipse cx="140" cy="174" rx="120" ry="7" fill="rgba(0,0,0,.12)"/>
    <!-- Person 1: accountant, dark skin, green shirt -->
    <g class="ph-p1" transform="translate(8,25)">
      <rect x="16" y="78" width="34" height="44" rx="8" fill="#059669"/>
      <rect x="20" y="120" width="11" height="30" rx="5" fill="#065f46"/>
      <rect x="33" y="120" width="11" height="30" rx="5" fill="#065f46"/>
      <ellipse cx="25" cy="152" rx="10" ry="4" fill="#1a0a00"/>
      <ellipse cx="39" cy="152" rx="10" ry="4" fill="#1a0a00"/>
      <rect x="29" y="66" width="8" height="14" rx="4" fill="#c68642"/>
      <circle cx="33" cy="54" r="17" fill="#c68642"/>
      <ellipse cx="33" cy="40" rx="18" ry="13" fill="#1a0a00"/>
      <circle cx="16" cy="42" r="8" fill="#1a0a00"/>
      <circle cx="50" cy="42" r="8" fill="#1a0a00"/>
      <circle cx="27" cy="54" r="2.5" fill="#1a0a00"/>
      <circle cx="39" cy="54" r="2.5" fill="#1a0a00"/>
      <path d="M27 62 Q33 67 39 62" stroke="#8b4513" stroke-width="1.2" fill="none" stroke-linecap="round"/>
      <!-- Holding calculator -->
      <rect x="-8" y="82" width="26" height="10" rx="5" fill="#059669"/>
      <rect x="50" y="82" width="26" height="10" rx="5" fill="#059669"/>
      <rect x="-18" y="88" width="28" height="36" rx="5" fill="#0f172a"/>
      <rect x="-15" y="91" width="22" height="8" rx="3" fill="#10b981"/>
      <rect x="-15" y="102" width="6" height="6" rx="2" fill="#334155"/>
      <rect x="-7" y="102" width="6" height="6" rx="2" fill="#334155"/>
      <rect x="1" y="102" width="6" height="6" rx="2" fill="#334155"/>
      <rect x="-15" y="110" width="6" height="6" rx="2" fill="#334155"/>
      <rect x="-7" y="110" width="6" height="6" rx="2" fill="#334155"/>
      <rect x="1" y="110" width="6" height="6" rx="2" fill="#6366f1"/>
    </g>
    <!-- Person 2: manager, medium skin, suit -->
    <g class="ph-p2" transform="translate(155,8)">
      <rect x="22" y="88" width="46" height="56" rx="10" fill="#1e293b"/>
      <rect x="32" y="88" width="26" height="32" rx="4" fill="white"/>
      <polygon points="45,88 38,102 45,96 52,102" fill="#6366f1"/>
      <polygon points="22,88 32,88 26,112" fill="#0f172a"/>
      <polygon points="68,88 58,88 64,112" fill="#0f172a"/>
      <rect x="22" y="142" width="16" height="36" rx="7" fill="#1e293b"/>
      <rect x="40" y="142" width="16" height="36" rx="7" fill="#1e293b"/>
      <ellipse cx="30" cy="180" rx="13" ry="5" fill="#0f172a"/>
      <ellipse cx="48" cy="180" rx="13" ry="5" fill="#0f172a"/>
      <rect x="38" y="72" width="14" height="18" rx="7" fill="#d4956a"/>
      <circle cx="45" cy="58" r="22" fill="#d4956a"/>
      <ellipse cx="45" cy="39" rx="22" ry="15" fill="#5c3317"/>
      <ellipse cx="45" cy="37" rx="18" ry="11" fill="#7b4a2d"/>
      <circle cx="37" cy="58" r="3.5" fill="white"/>
      <circle cx="53" cy="58" r="3.5" fill="white"/>
      <circle cx="38" cy="59" r="2" fill="#3d2b1f"/>
      <circle cx="54" cy="59" r="2" fill="#3d2b1f"/>
      <path d="M37 67 Q45 73 53 67" stroke="#c0845a" stroke-width="1.3" fill="none" stroke-linecap="round"/>
      <rect x="0" y="94" width="24" height="11" rx="5" fill="#1e293b"/>
      <rect x="66" y="94" width="24" height="11" rx="5" fill="#1e293b"/>
      <!-- Payslip in hand -->
      <rect x="66" y="100" width="38" height="50" rx="5" fill="white" opacity=".95"/>
      <rect x="69" y="103" width="32" height="6" rx="3" fill="#6366f1"/>
      <rect x="69" y="112" width="22" height="3" rx="1.5" fill="#94a3b8"/>
      <rect x="69" y="118" width="28" height="3" rx="1.5" fill="#94a3b8"/>
      <rect x="69" y="124" width="18" height="3" rx="1.5" fill="#94a3b8"/>
      <line x1="69" y1="130" x2="101" y2="130" stroke="#e2e8f0" stroke-width="1" stroke-dasharray="3 2"/>
      <rect x="69" y="134" width="32" height="8" rx="4" fill="#10b981"/>
      <g class="ph-chk">
        <circle cx="100" cy="103" r="8" fill="#10b981"/>
        <path d="M96 103 L99 106 L104 100" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
      </g>
    </g>
    <!-- Floating gold coin -->
    <g class="ph-coin" transform="translate(6,8)">
      <circle cx="18" cy="18" r="16" fill="#f59e0b" stroke="#fbbf24" stroke-width="2"/>
      <circle cx="18" cy="18" r="11" fill="#fbbf24"/>
      <text x="18" y="23" text-anchor="middle" font-size="12" font-weight="bold" fill="#78350f" font-family="Arial,sans-serif">$</text>
    </g>
    <!-- Salary card -->
    <g class="ph-slip" transform="translate(2,110)">
      <rect x="0" y="0" width="100" height="58" rx="10" fill="white" opacity=".95"/>
      <rect x="0" y="0" width="100" height="20" rx="10" fill="#059669"/>
      <rect x="0" y="10" width="100" height="10" fill="#059669"/>
      <text x="8" y="14" font-size="7" fill="white" font-weight="bold" font-family="Arial,sans-serif">Payroll Processed</text>
      <text x="8" y="36" font-size="14" fill="#0f172a" font-weight="bold" font-family="Arial,sans-serif">ETB 32,400</text>
      <rect x="8" y="44" width="50" height="4" rx="2" fill="#e2e8f0"/>
      <rect x="8" y="44" width="38" height="4" rx="2" fill="#10b981"/>
      <text x="8" y="56" font-size="6.5" fill="#64748b" font-family="Arial,sans-serif">Net payment approved</text>
    </g>
  </svg>
</div>

<div class="page-header">
  <div>
    <div class="page-header-title">Payroll</div>
    <div class="page-header-sub">Manage and process employee salaries</div>
  </div>
  <div class="page-header-actions">
    <a href="<?= url('payroll/run') ?>" class="btn btn-primary"><i class="fas fa-play-circle"></i> Run Payroll</a>
    <?php
    $approvedIds = array_column(array_filter($payrolls ?? [], fn($p) => $p['status'] === 'approved'), 'id');
    if (!empty($approvedIds)):
    ?>
    <button class="btn btn-success" onclick="markAllApprovedPaid()">
      <i class="fas fa-check-double"></i> Mark All Approved as Paid (<?= count($approvedIds) ?>)
    </button>
    <?php endif; ?>
    <a href="<?= url('payroll/export?month=' . $month) ?>" class="btn btn-outline"><i class="fas fa-download"></i> Export CSV</a>
  </div>
</div>

<!-- Month Filter -->
<div class="filter-bar">
  <form method="GET" action="<?= url('payroll') ?>" style="display:flex;gap:10px;align-items:center">
    <label class="form-label" style="margin:0;white-space:nowrap">Pay Month:</label>
    <input type="month" name="month" class="form-control" value="<?= e($month) ?>" style="width:auto">
    <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button>
  </form>
</div>

<!-- Summary Cards -->
<?php if (!empty($summary)): ?>
<div class="stats-grid" style="margin-bottom:20px">
  <div class="stat-card stat-card-primary">
    <div class="stat-icon stat-icon-primary"><i class="fas fa-users"></i></div>
    <div class="stat-body">
      <div class="stat-value"><?= $summary['count'] ?></div>
      <div class="stat-label">Employees Processed</div>
    </div>
  </div>
  <div class="stat-card stat-card-success">
    <div class="stat-icon stat-icon-success"><i class="fas fa-money-bill-wave"></i></div>
    <div class="stat-body">
      <div class="stat-value"><?= formatCurrency($summary['total_gross']) ?></div>
      <div class="stat-label">Total Gross</div>
    </div>
  </div>
  <div class="stat-card stat-card-info">
    <div class="stat-icon stat-icon-info"><i class="fas fa-hand-holding-usd"></i></div>
    <div class="stat-body">
      <div class="stat-value"><?= formatCurrency($summary['total_net']) ?></div>
      <div class="stat-label">Total Net Payroll</div>
    </div>
  </div>
  <div class="stat-card stat-card-warning">
    <div class="stat-icon stat-icon-warning"><i class="fas fa-receipt"></i></div>
    <div class="stat-body">
      <div class="stat-value"><?= formatCurrency($summary['total_tax']) ?></div>
      <div class="stat-label">Total Tax</div>
    </div>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th>Employee</th>
          <th>Basic</th>
          <th>Allowances</th>
          <th>Overtime</th>
          <th>Gross</th>
          <th>Deductions</th>
          <th>Tax</th>
          <th>Net Salary</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($payrolls)): ?>
        <tr>
          <td colspan="10">
            <div class="empty-state">
              <div class="empty-state-icon"><i class="fas fa-money-bill-wave"></i></div>
              <div class="empty-state-title">No payroll for <?= e($month) ?></div>
              <div class="empty-state-text"><a href="<?= url('payroll/run') ?>" class="btn btn-primary btn-sm" style="margin-top:10px"><i class="fas fa-play"></i> Run Payroll Now</a></div>
            </div>
          </td>
        </tr>
        <?php else: ?>
        <?php foreach ($payrolls as $p): ?>
        <tr>
          <td>
            <div class="emp-cell">
              <div>
                <div class="emp-info-name"><?= e($p['employee_name']) ?></div>
                <div class="emp-info-code"><?= e($p['department']) ?></div>
              </div>
            </div>
          </td>
          <td><?= formatCurrency((float)$p['basic_salary']) ?></td>
          <td><?= formatCurrency((float)$p['house_allowance'] + (float)$p['transport_allowance'] + (float)$p['medical_allowance']) ?></td>
          <td><?= formatCurrency((float)$p['overtime_pay']) ?></td>
          <td><strong><?= formatCurrency((float)$p['gross_salary']) ?></strong></td>
          <td style="color:#ef4444"><?= formatCurrency((float)$p['total_deductions']) ?></td>
          <td style="color:#f59e0b"><?= formatCurrency((float)$p['tax']) ?></td>
          <td><strong style="color:#10b981"><?= formatCurrency((float)$p['net_salary']) ?></strong></td>
          <td><?= statusBadge($p['status']) ?></td>
          <td>
            <div style="display:flex;gap:5px">
              <a href="<?= url('payroll/payslip/' . $p['id']) ?>" class="btn btn-outline btn-sm btn-icon" title="View Payslip">
                <i class="fas fa-file-invoice"></i>
              </a>
              <?php if ($p['status'] === 'pending'): ?>
              <button class="btn btn-success btn-sm btn-icon" title="Approve"
                      onclick="payrollAction('approve', <?= $p['id'] ?>)">
                <i class="fas fa-check"></i>
              </button>
              <button class="btn btn-danger btn-sm btn-icon" title="Reject"
                      onclick="payrollAction('reject', <?= $p['id'] ?>)">
                <i class="fas fa-times"></i>
              </button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
function payrollAction(action, id) {
  const label = action === 'approve' ? 'approve' : 'reject';
  if (!confirm(`Are you sure you want to ${label} this payroll?`)) return;
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', `payroll/${action}/${id}`, { csrf_token: csrf }, data => {
    if (data.success) { showToast(data.message, 'success'); setTimeout(() => location.reload(), 800); }
    else showToast(data.message || 'Failed', 'error');
  });
}

function markAllApprovedPaid() {
  const ids = <?= json_encode($approvedIds ?? []) ?>;
  if (!ids.length) return;
  if (!confirm(`Mark all ${ids.length} approved payroll(s) as paid?`)) return;
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  const fd = new FormData();
  fd.append('csrf_token', csrf);
  ids.forEach(id => fd.append('ids[]', id));
  ajax('POST', 'payroll/bulk-mark-paid', fd, data => {
    if (data.success) { showToast(data.message, 'success'); setTimeout(() => location.reload(), 1000); }
    else showToast(data.message || 'Failed', 'error');
  });
}
</script>
