<!-- Hero Banner -->
<div class="page-hero hero-payroll">
  <div class="hero-orb hero-orb-1"></div>
  <div class="hero-orb hero-orb-2"></div>
  <div class="page-hero-content">
    <div class="hero-badge"><span class="hero-badge-dot"></span> Payroll Records</div>
    <div class="page-hero-title">Payroll History</div>
    <div class="page-hero-sub">View all processed payroll records, download payslips, and track payment status.</div>
    <div class="page-hero-actions">
      <?php if (isHR()): ?>
      <a href="<?= url('payroll/run') ?>" class="page-hero-btn page-hero-btn-white">
        <i class="fas fa-play-circle"></i> Run Payroll
      </a>
      <?php endif; ?>
      <a href="<?= url('payroll') ?>" class="page-hero-btn page-hero-btn-outline">
        <i class="fas fa-arrow-left"></i> Back to Payroll
      </a>
    </div>
  </div>
</div>

<div class="page-header">
  <div>
    <div class="page-header-title">Payroll History</div>
    <div class="page-header-sub">All payroll records &mdash; <?= $pager['total'] ?? 0 ?> total</div>
  </div>
  <div class="page-header-actions">
    <?php if (isHR()): ?>
    <button class="btn btn-success btn-sm" id="markPaidBtn" onclick="bulkMarkPaid()" style="display:none">
      <i class="fas fa-check-double"></i> Mark Selected as Paid
    </button>
    <?php endif; ?>
  </div>
</div>

<!-- Month Filter -->
<div class="filter-bar">
  <form method="GET" action="<?= url('payroll/history') ?>" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
    <label class="form-label" style="margin:0;white-space:nowrap">Filter by Month:</label>
    <input type="month" name="month" class="form-control" value="<?= e($_GET['month'] ?? '') ?>" style="width:auto">
    <select name="status" class="form-control" style="width:auto">
      <option value="">All Statuses</option>
      <option value="pending"  <?= ($_GET['status']??'')==='pending'  ?'selected':'' ?>>Pending</option>
      <option value="approved" <?= ($_GET['status']??'')==='approved' ?'selected':'' ?>>Approved</option>
      <option value="paid"     <?= ($_GET['status']??'')==='paid'     ?'selected':'' ?>>Paid</option>
      <option value="rejected" <?= ($_GET['status']??'')==='rejected' ?'selected':'' ?>>Rejected</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button>
    <?php if (!empty($_GET['month']) || !empty($_GET['status'])): ?>
    <a href="<?= url('payroll/history') ?>" class="btn btn-outline btn-sm"><i class="fas fa-times"></i> Clear</a>
    <?php endif; ?>
  </form>
</div>

<div class="card">
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <?php if (isHR()): ?>
          <th style="width:40px">
            <input type="checkbox" id="selectAll" onchange="toggleSelectAll(this)" style="cursor:pointer;accent-color:#6366f1">
          </th>
          <?php endif; ?>
          <th>Employee</th>
          <th>Month</th>
          <th>Basic</th>
          <th>Gross</th>
          <th>Deductions</th>
          <th>Net Salary</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($payrolls)): ?>
        <tr><td colspan="<?= isHR() ? 9 : 8 ?>">
          <div class="empty-state">
            <div class="empty-state-icon"><i class="fas fa-history"></i></div>
            <div class="empty-state-title">No payroll history found</div>
            <div class="empty-state-text">
              <?php if (!empty($_GET['month']) || !empty($_GET['status'])): ?>
              Try adjusting your filters.
              <?php else: ?>
              Run payroll to see records here.
              <?php endif; ?>
            </div>
          </div>
        </td></tr>
        <?php else: ?>
        <?php foreach ($payrolls as $p): ?>
        <tr>
          <?php if (isHR()): ?>
          <td>
            <?php if ($p['status'] === 'approved'): ?>
            <input type="checkbox" class="payroll-check" value="<?= $p['id'] ?>"
                   onchange="updateBulkBtn()" style="cursor:pointer;accent-color:#6366f1">
            <?php endif; ?>
          </td>
          <?php endif; ?>
          <td>
            <div class="emp-info-name"><?= e($p['employee_name']) ?></div>
            <div class="emp-info-code"><?= e($p['department']) ?></div>
          </td>
          <td>
            <span style="font-weight:600;color:#374151"><?= date('M Y', strtotime($p['pay_month'] . '-01')) ?></span>
          </td>
          <td><?= formatCurrency((float)$p['basic_salary']) ?></td>
          <td><strong><?= formatCurrency((float)$p['gross_salary']) ?></strong></td>
          <td style="color:#ef4444"><?= formatCurrency((float)$p['total_deductions']) ?></td>
          <td><strong style="color:#10b981;font-size:.95rem"><?= formatCurrency((float)$p['net_salary']) ?></strong></td>
          <td><?= statusBadge($p['status']) ?></td>
          <td>
            <div style="display:flex;gap:5px">
              <a href="<?= url('payroll/payslip/' . $p['id']) ?>" class="btn btn-outline btn-sm btn-icon" title="View Payslip">
                <i class="fas fa-file-invoice"></i>
              </a>
              <?php if (isHR() && $p['status'] === 'approved'): ?>
              <button class="btn btn-success btn-sm btn-icon" title="Mark as Paid"
                      onclick="markSinglePaid(<?= $p['id'] ?>)">
                <i class="fas fa-check"></i>
              </button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if (isset($pager) && $pager['total_pages'] > 1): ?>
  <div class="pagination">
    <?php if ($pager['has_prev']): ?>
    <a href="?page=<?= $pager['current_page'] - 1 ?>&month=<?= urlencode($_GET['month']??'') ?>&status=<?= urlencode($_GET['status']??'') ?>" class="page-btn">
      <i class="fas fa-chevron-left"></i>
    </a>
    <?php endif; ?>
    <?php for ($i = max(1, $pager['current_page'] - 2); $i <= min($pager['total_pages'], $pager['current_page'] + 2); $i++): ?>
    <a href="?page=<?= $i ?>&month=<?= urlencode($_GET['month']??'') ?>&status=<?= urlencode($_GET['status']??'') ?>"
       class="page-btn <?= $i === $pager['current_page'] ? 'active' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($pager['has_next']): ?>
    <a href="?page=<?= $pager['current_page'] + 1 ?>&month=<?= urlencode($_GET['month']??'') ?>&status=<?= urlencode($_GET['status']??'') ?>" class="page-btn">
      <i class="fas fa-chevron-right"></i>
    </a>
    <?php endif; ?>
    <span style="margin-left:auto;font-size:.78rem;color:#64748b">
      Showing <?= count($payrolls) ?> of <?= $pager['total'] ?>
    </span>
  </div>
  <?php endif; ?>
</div>

<?php if (isHR()): ?>
<script>
function toggleSelectAll(cb) {
  document.querySelectorAll('.payroll-check').forEach(function(c) { c.checked = cb.checked; });
  updateBulkBtn();
}

function updateBulkBtn() {
  var checked = document.querySelectorAll('.payroll-check:checked').length;
  var btn = document.getElementById('markPaidBtn');
  if (btn) {
    btn.style.display = checked > 0 ? 'inline-flex' : 'none';
    btn.innerHTML = '<i class="fas fa-check-double"></i> Mark ' + checked + ' as Paid';
  }
}

function bulkMarkPaid() {
  var ids = Array.from(document.querySelectorAll('.payroll-check:checked')).map(function(c) { return c.value; });
  if (!ids.length) return;
  if (!confirm('Mark ' + ids.length + ' payroll record(s) as paid?')) return;
  var csrf = document.querySelector('meta[name="csrf-token"]').content;
  var done = 0;
  ids.forEach(function(id) {
    ajax('POST', 'payroll/approve/' + id, { csrf_token: csrf }, function(data) {
      done++;
      if (done === ids.length) {
        showToast(ids.length + ' payroll(s) marked as paid!', 'success');
        setTimeout(function() { location.reload(); }, 1000);
      }
    });
  });
}

function markSinglePaid(id) {
  if (!confirm('Mark this payroll as paid?')) return;
  var csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', 'payroll/approve/' + id, { csrf_token: csrf }, function(data) {
    if (data.success) {
      showToast('Payroll marked as paid!', 'success');
      setTimeout(function() { location.reload(); }, 800);
    } else {
      showToast(data.message || 'Failed', 'error');
    }
  });
}
</script>
<?php endif; ?>
