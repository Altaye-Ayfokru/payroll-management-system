<?php
/**
 * Payroll Module — Model
 */
class PayrollModel extends Model {
    protected string $table = 'payroll';

    public function getWithEmployee(int $limit = ITEMS_PER_PAGE, int $offset = 0): array {
        return $this->query(
            "SELECT p.*, u.name AS employee_name, e.position, e.department, e.employee_code
             FROM payroll p
             JOIN employees e ON e.id = p.employee_id
             JOIN users u ON u.id = e.user_id
             ORDER BY p.created_at DESC
             LIMIT :limit OFFSET :offset",
            [':limit' => $limit, ':offset' => $offset]
        );
    }

    public function getByMonth(string $month): array {
        return $this->query(
            "SELECT p.*, u.name AS employee_name, e.position, e.department, e.employee_code
             FROM payroll p
             JOIN employees e ON e.id = p.employee_id
             JOIN users u ON u.id = e.user_id
             WHERE p.pay_month = :month
             ORDER BY u.name ASC",
            [':month' => $month]
        );
    }

    public function getByEmployeeAndMonth(int $empId, string $month): ?array {
        return $this->queryOne(
            "SELECT * FROM payroll WHERE employee_id = :eid AND pay_month = :month",
            [':eid' => $empId, ':month' => $month]
        );
    }

    public function getPayslip(int $id): ?array {
        return $this->queryOne(
            "SELECT p.*,
                    u.name AS employee_name, u.email, u.avatar, u.phone,
                    e.position, e.position_title, e.department, e.employee_code,
                    e.bank_account, e.bank_name, e.hire_date, e.employment_type,
                    pu.name AS processed_by_name, au.name AS approved_by_name
             FROM payroll p
             JOIN employees e ON e.id = p.employee_id
             JOIN users u ON u.id = e.user_id
             LEFT JOIN users pu ON pu.id = p.processed_by
             LEFT JOIN users au ON au.id = p.approved_by
             WHERE p.id = :id",
            [':id' => $id]
        );
    }

    public function getByEmployee(int $empId, int $limit = 12): array {
        return $this->query(
            "SELECT * FROM payroll WHERE employee_id = :eid ORDER BY pay_month DESC LIMIT :limit",
            [':eid' => $empId, ':limit' => $limit]
        );
    }

    public function getTotalByMonth(string $month): float {
        $stmt = $this->db->prepare(
            "SELECT COALESCE(SUM(net_salary),0) FROM payroll WHERE pay_month=:m AND status='approved'"
        );
        $stmt->execute([':m' => $month]);
        return (float)$stmt->fetchColumn();
    }

    public function getPendingCount(): int {
        $stmt = $this->db->query("SELECT COUNT(*) FROM payroll WHERE status='pending'");
        return (int)$stmt->fetchColumn();
    }

    public function getMonthlyTrend(int $months = 6): array {
        return $this->query(
            "SELECT pay_month,
                    SUM(net_salary)   AS total,
                    SUM(tax)          AS total_tax,
                    COUNT(*)          AS employee_count
             FROM payroll
             WHERE status='approved'
               AND pay_month >= DATE_FORMAT(DATE_SUB(NOW(), INTERVAL :m MONTH),'%Y-%m')
             GROUP BY pay_month
             ORDER BY pay_month ASC",
            [':m' => $months]
        );
    }

    public function getDeptBreakdown(string $month): array {
        return $this->query(
            "SELECT e.department,
                    COUNT(*)          AS emp_count,
                    SUM(p.net_salary) AS total_net,
                    SUM(p.tax)        AS total_tax
             FROM payroll p
             JOIN employees e ON e.id = p.employee_id
             WHERE p.pay_month = :month
             GROUP BY e.department
             ORDER BY total_net DESC",
            [':month' => $month]
        );
    }

    public function getApprovedByMonth(string $month): array {
        return $this->query(
            "SELECT p.*, u.name AS employee_name, e.department
             FROM payroll p
             JOIN employees e ON e.id = p.employee_id
             JOIN users u ON u.id = e.user_id
             WHERE p.pay_month = :month AND p.status = 'approved'
             ORDER BY u.name ASC",
            [':month' => $month]
        );
    }

    public function bulkMarkPaid(array $ids, int $approvedBy): int {
        if (empty($ids)) return 0;
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $params = array_merge([$approvedBy, date('Y-m-d H:i:s')], $ids);
        $stmt = $this->db->prepare(
            "UPDATE payroll SET status='paid', approved_by=?, approved_at=?
             WHERE id IN ({$placeholders}) AND status='approved'"
        );
        $stmt->execute($params);
        return $stmt->rowCount();
    }
}
