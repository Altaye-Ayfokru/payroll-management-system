<?php
/**
 * PayrollPro — Ethiopian Payroll Calculation Engine
 *
 * Rules implemented:
 * - Earned Salary = Worked Days × (Basic ÷ 30)
 * - Position Allowance by title (CEO non-taxable, others taxable)
 * - Transport Allowance: positioned=2220 ETB non-taxable, others=600 ETB non-taxable
 * - Gross = Earned + Position Allowance + Transport + Other/Commission
 * - Taxable Income = Earned + Taxable Position + Taxable Transport + Other/Commission
 * - Income Tax = Ethiopian progressive slab (with deductible fee)
 * - Pension: Full-time only — Employee 7%, Employer 11% of Basic
 * - Total Deduction = Income Tax + Employee Pension
 * - Net Payment = Gross - Total Deduction
 */
class PayrollService {
    private PayrollModel  $payrollModel;
    private EmployeeModel $employeeModel;

    // ── Ethiopian Income Tax Slabs ────────────────────────────
    // [min, max (0=unlimited), rate%, deductible_fee]
    private array $taxSlabs = [
        [0,       600,    0,    0],
        [601,    1650,   10,   60],
        [1651,   3200,   15,  142.5],
        [3201,   5250,   20,  302.5],
        [5251,   7800,   25,  565],
        [7801,  10900,   30,  965],
        [10901,     0,   35, 1500],
    ];

    // ── Position Allowance rates ──────────────────────────────
    // [rate%, is_taxable]
    private array $positionAllowance = [
        'CEO'             => [0.10, false],  // 10% non-taxable
        'COO'             => [0.08, true],   // 8% taxable
        'CTO'             => [0.08, true],
        'CISO'            => [0.08, true],
        'Director'        => [0.07, true],
        'Dept Head'       => [0.05, true],
        'Normal Employee' => [0,    true],
    ];

    // ── Transport Allowance ───────────────────────────────────
    private array $transportAllowance = [
        'positioned'  => 2220.00,  // CEO/COO/CTO/CISO/Director/Dept Head
        'normal'      => 600.00,
    ];

    private array $positionedTitles = ['CEO','COO','CTO','CISO','Director','Dept Head'];

    public function __construct() {
        require_once APP_PATH . '/modules/Payroll/PayrollModel.php';
        require_once APP_PATH . '/modules/Employee/EmployeeModel.php';
        require_once APP_PATH . '/modules/Attendance/AttendanceModel.php';
        $this->payrollModel  = new PayrollModel();
        $this->employeeModel = new EmployeeModel();
    }

    // ════════════════════════════════════════════════════════
    // Run payroll for all active employees
    // ════════════════════════════════════════════════════════
    public function runMonthlyPayroll(string $month, int $processedBy): array {
        $employees = $this->employeeModel->getActiveWithUsers();
        $results   = ['success' => [], 'skipped' => [], 'errors' => []];

        foreach ($employees as $emp) {
            if ($this->payrollModel->getByEmployeeAndMonth($emp['id'], $month)) {
                $results['skipped'][] = $emp['id'];
                continue;
            }
            try {
                $id = $this->processOne($emp, $month, $processedBy);
                $results['success'][] = $id;
                $this->notifyEmployee($emp['user_id'], $month);
            } catch (Exception $e) {
                Logger::error("Payroll error emp#{$emp['id']}: " . $e->getMessage());
                $results['errors'][] = ['employee_id' => $emp['id'], 'error' => $e->getMessage()];
            }
        }
        return $results;
    }

    // ════════════════════════════════════════════════════════
    // Calculate payroll for one employee — full Ethiopian rules
    // ════════════════════════════════════════════════════════
    public function processOne(array $emp, string $month, int $processedBy): int {
        $calc = $this->calculate($emp, $month);

        return $this->payrollModel->insert([
            'employee_id'                   => $emp['id'],
            'pay_month'                     => $month,
            'basic_salary'                  => $calc['basic_salary'],
            'worked_days'                   => $calc['worked_days'],
            'working_days'                  => $calc['working_days'],
            'earned_salary'                 => $calc['earned_salary'],
            'position_allowance'            => $calc['position_allowance'],
            'position_allowance_taxable'    => $calc['position_allowance_taxable'],
            'position_allowance_nontaxable' => $calc['position_allowance_nontaxable'],
            'transport_allowance'           => $calc['transport_allowance'],
            'transport_allowance_taxable'   => $calc['transport_allowance_taxable'],
            'transport_allowance_nontaxable'=> $calc['transport_allowance_nontaxable'],
            'other_commission'              => $calc['other_commission'],
            'house_allowance'               => $calc['house_allowance'],
            'medical_allowance'             => $calc['medical_allowance'],
            'overtime_pay'                  => $calc['overtime_pay'],
            'gross_salary'                  => $calc['gross_salary'],
            'taxable_income'                => $calc['taxable_income'],
            'income_tax'                    => $calc['income_tax'],
            'employee_pension'              => $calc['employee_pension'],
            'employer_pension'              => $calc['employer_pension'],
            'total_pension'                 => $calc['total_pension'],
            'provident_fund'                => $calc['employee_pension'], // alias
            'insurance'                     => 0,
            'other_deductions'              => 0,
            'tax'                           => $calc['income_tax'],       // alias
            'total_deductions'              => $calc['total_deductions'],
            'net_salary'                    => $calc['net_payment'],       // alias
            'net_payment'                   => $calc['net_payment'],
            'total_days'                    => $calc['working_days'],
            'overtime_hours'                => $calc['overtime_hours'],
            'status'                        => 'pending',
            'processed_by'                  => $processedBy,
            'created_at'                    => date('Y-m-d H:i:s'),
        ]);
    }

    // ════════════════════════════════════════════════════════
    // Core calculation — returns full breakdown array
    // ════════════════════════════════════════════════════════
    public function calculate(array $emp, string $month): array {
        $basic          = (float)($emp['basic_salary'] ?? 0);
        $positionTitle  = $emp['position_title'] ?? 'Normal Employee';
        $employmentType = $emp['employment_type'] ?? 'full_time';
        $otherComm      = (float)($emp['other_commission'] ?? 0);
        $houseAllow     = (float)($emp['house_allowance'] ?? 0);
        $medicalAllow   = (float)($emp['medical_allowance'] ?? 0);

        // ── 1. Worked days from attendance ──────────────────
        $db   = Database::getInstance();
        $stmt = $db->prepare(
            "SELECT
                COALESCE(SUM(CASE WHEN status IN ('present','late') THEN 1 ELSE 0 END), 0) AS present_days,
                COALESCE(SUM(overtime_hours), 0) AS overtime_hours
             FROM attendance
             WHERE employee_id = :eid AND DATE_FORMAT(date,'%Y-%m') = :month"
        );
        $stmt->execute([':eid' => $emp['id'], ':month' => $month]);
        $att = $stmt->fetch() ?: ['present_days' => 0, 'overtime_hours' => 0];

        $workedDays    = max(1, (int)($att['present_days'] ?? 0));
        $overtimeHours = (float)($att['overtime_hours'] ?? 0);

        // If no attendance records, assume full month
        if ($workedDays === 1 && (int)($att['present_days'] ?? 0) === 0) {
            $workedDays = 30;
        }

        // ── 2. Earned Salary = Worked Days × (Basic ÷ 30) ──
        $earnedSalary = round($workedDays * ($basic / 30), 2);

        // ── 3. Overtime pay ─────────────────────────────────
        $hourlyRate  = $basic / (30 * 8);
        $overtimePay = round($overtimeHours * $hourlyRate * 1.5, 2);

        // ── 4. Position Allowance ────────────────────────────
        $paConfig   = $this->positionAllowance[$positionTitle] ?? [0, true];
        $paRate     = $paConfig[0];
        $paTaxable  = $paConfig[1];
        $posAllow   = round($basic * $paRate, 2);

        $posAllowTaxable    = $paTaxable ? $posAllow : 0.0;
        $posAllowNonTaxable = $paTaxable ? 0.0 : $posAllow;

        // ── 5. Transport Allowance ───────────────────────────
        $isPositioned = in_array($positionTitle, $this->positionedTitles);
        $transAllow   = $isPositioned
            ? $this->transportAllowance['positioned']
            : $this->transportAllowance['normal'];

        // Transport is always non-taxable per spec
        $transAllowTaxable    = 0.0;
        $transAllowNonTaxable = $transAllow;

        // ── 6. Gross Pay ─────────────────────────────────────
        // Gross = Earned + Position Allowance + Transport + Other/Commission + Overtime
        $grossPay = round(
            $earnedSalary + $posAllow + $transAllow + $otherComm + $overtimePay
            + $houseAllow + $medicalAllow,
            2
        );

        // ── 7. Taxable Income ────────────────────────────────
        // Taxable = Earned + Taxable Position + Taxable Transport + Other/Commission + Overtime
        $taxableIncome = round(
            $earnedSalary + $posAllowTaxable + $transAllowTaxable + $otherComm + $overtimePay,
            2
        );

        // ── 8. Income Tax (Ethiopian progressive slabs) ──────
        $incomeTax = $this->calculateEthiopianTax($taxableIncome);

        // ── 9. Pension (Full-time only) ──────────────────────
        $employeePension = 0.0;
        $employerPension = 0.0;
        if ($employmentType === 'full_time') {
            $employeePension = round($basic * 0.07, 2);  // 7%
            $employerPension = round($basic * 0.11, 2);  // 11%
        }
        $totalPension = round($employeePension + $employerPension, 2);

        // ── 10. Total Deduction & Net Payment ────────────────
        $totalDeductions = round($incomeTax + $employeePension, 2);
        $netPayment      = round($grossPay - $totalDeductions, 2);

        return [
            'basic_salary'                  => $basic,
            'worked_days'                   => $workedDays,
            'working_days'                  => 30,
            'earned_salary'                 => $earnedSalary,
            'position_title'                => $positionTitle,
            'position_allowance'            => $posAllow,
            'position_allowance_taxable'    => $posAllowTaxable,
            'position_allowance_nontaxable' => $posAllowNonTaxable,
            'transport_allowance'           => $transAllow,
            'transport_allowance_taxable'   => $transAllowTaxable,
            'transport_allowance_nontaxable'=> $transAllowNonTaxable,
            'other_commission'              => $otherComm,
            'house_allowance'               => $houseAllow,
            'medical_allowance'             => $medicalAllow,
            'overtime_pay'                  => $overtimePay,
            'overtime_hours'                => $overtimeHours,
            'gross_salary'                  => $grossPay,
            'taxable_income'                => $taxableIncome,
            'income_tax'                    => $incomeTax,
            'employee_pension'              => $employeePension,
            'employer_pension'              => $employerPension,
            'total_pension'                 => $totalPension,
            'total_deductions'              => $totalDeductions,
            'net_payment'                   => $netPayment,
        ];
    }

    // ════════════════════════════════════════════════════════
    // Ethiopian progressive income tax with deductible fee
    // ════════════════════════════════════════════════════════
    public function calculateEthiopianTax(float $taxableIncome): float {
        if ($taxableIncome <= 0) return 0.0;

        foreach ($this->taxSlabs as [$min, $max, $rate, $deductible]) {
            $inRange = $taxableIncome >= $min && ($max === 0 || $taxableIncome <= $max);
            if ($inRange) {
                if ($rate === 0) return 0.0;
                $tax = ($taxableIncome * $rate / 100) - $deductible;
                return round(max(0, $tax), 2);
            }
        }
        return 0.0;
    }

    // ════════════════════════════════════════════════════════
    // Preview calculation without saving (for UI preview)
    // ════════════════════════════════════════════════════════
    public function preview(array $empData, int $workedDays = 30): array {
        $empData['id'] = $empData['id'] ?? 0;
        // Override attendance with provided worked days
        $basic = (float)($empData['basic_salary'] ?? 0);
        $empData['other_commission'] = (float)($empData['other_commission'] ?? 0);

        $month = date('Y-m');
        $calc  = $this->calculate($empData, $month);

        // Override worked days with provided value
        $calc['worked_days']  = $workedDays;
        $calc['earned_salary'] = round($workedDays * ($basic / 30), 2);

        // Recalculate downstream
        $posAllow      = $calc['position_allowance'];
        $transAllow    = $calc['transport_allowance'];
        $otherComm     = $calc['other_commission'];
        $posAllowTax   = $calc['position_allowance_taxable'];
        $transAllowTax = $calc['transport_allowance_taxable'];

        $calc['gross_salary']   = round($calc['earned_salary'] + $posAllow + $transAllow + $otherComm, 2);
        $calc['taxable_income'] = round($calc['earned_salary'] + $posAllowTax + $transAllowTax + $otherComm, 2);
        $calc['income_tax']     = $this->calculateEthiopianTax($calc['taxable_income']);
        $calc['total_deductions'] = round($calc['income_tax'] + $calc['employee_pension'], 2);
        $calc['net_payment']    = round($calc['gross_salary'] - $calc['total_deductions'], 2);

        return $calc;
    }

    private function workingDaysInMonth(string $month): int {
        $dt   = new DateTime($month . '-01');
        $days = (int)$dt->format('t');
        $count = 0;
        for ($d = 1; $d <= $days; $d++) {
            $dow = (int)(new DateTime("{$month}-" . str_pad($d, 2, '0', STR_PAD_LEFT)))->format('N');
            if ($dow < 6) $count++;
        }
        return $count;
    }

    private function notifyEmployee(int $userId, string $month): void {
        try {
            $db = Database::getInstance();
            $db->prepare(
                "INSERT INTO notifications (user_id, message, type, is_read, created_at)
                 VALUES (:uid, :msg, 'payroll', 0, NOW())"
            )->execute([
                ':uid' => $userId,
                ':msg' => "Your payroll for {$month} has been processed and is pending approval.",
            ]);
        } catch (Exception $e) { /* silent */ }
    }
}
