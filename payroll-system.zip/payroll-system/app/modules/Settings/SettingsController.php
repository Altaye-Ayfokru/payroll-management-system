<?php
require_once CORE_PATH . '/Controller.php';

class SettingsController extends Controller {
    public function index(): void {
        $this->requireRole('admin');
        $db = Database::getInstance();

        $taxRules   = $db->query("SELECT * FROM tax_rules ORDER BY min_salary ASC")->fetchAll();
        $components = $db->query("SELECT * FROM salary_components ORDER BY type,name")->fetchAll();
        $settings   = [];
        foreach ($db->query("SELECT `key`,`value` FROM settings")->fetchAll() as $s) {
            $settings[$s['key']] = $s['value'];
        }

        $this->view('settings.index', [
            'taxRules'         => $taxRules,
            'salaryComponents' => $components,
            'settings'         => $settings,
            'pageTitle'        => 'Settings',
            'csrf'             => csrfToken(),
            'flash'            => $this->getFlash(),
        ]);
    }

    public function saveTax(): void {
        $this->requireRole('admin');
        if (!validateCsrf()) $this->json(['success' => false, 'message' => 'Invalid token'], 403);

        $db = Database::getInstance();
        $db->exec("DELETE FROM tax_rules");

        $names  = $_POST['tax_name']       ?? [];
        $pcts   = $_POST['tax_percentage'] ?? [];
        $mins   = $_POST['min_salary']     ?? [];
        $maxs   = $_POST['max_salary']     ?? [];

        $stmt = $db->prepare(
            "INSERT INTO tax_rules (name,percentage,min_salary,max_salary,is_active,created_at)
             VALUES (:name,:pct,:min,:max,1,NOW())"
        );
        foreach ($names as $i => $name) {
            if (empty(trim($name))) continue;
            $stmt->execute([':name'=>$name,':pct'=>(float)($pcts[$i]??0),
                            ':min'=>(float)($mins[$i]??0),':max'=>(float)($maxs[$i]??0)]);
        }

        logActivity(currentUserId(), 'Updated tax rules');
        $this->flash('success', 'Tax rules saved!');
        $this->redirect('settings');
    }

    public function saveSalary(): void {
        $this->requireRole('admin');
        if (!validateCsrf()) $this->json(['success' => false, 'message' => 'Invalid token'], 403);

        $db     = Database::getInstance();
        $names  = $_POST['component_name']   ?? [];
        $types  = $_POST['component_type']   ?? [];
        $amounts = $_POST['component_amount'] ?? [];

        $stmt = $db->prepare(
            "INSERT INTO salary_components (name,type,amount,is_active,created_at)
             VALUES (:name,:type,:amount,1,NOW())"
        );
        foreach ($names as $i => $name) {
            if (empty(trim($name))) continue;
            $stmt->execute([':name'=>$name,':type'=>$types[$i]??'allowance',
                            ':amount'=>(float)($amounts[$i]??0)]);
        }

        logActivity(currentUserId(), 'Updated salary components');
        $this->flash('success', 'Salary components saved!');
        $this->redirect('settings');
    }

    public function saveGeneral(): void {
        $this->requireRole('admin');
        if (!validateCsrf()) $this->json(['success' => false, 'message' => 'Invalid token'], 403);

        $db   = Database::getInstance();
        $stmt = $db->prepare(
            "INSERT INTO settings (`key`,`value`) VALUES (:k,:v)
             ON DUPLICATE KEY UPDATE `value`=:v2"
        );

        $allowed = ['company_name','company_address','company_email','company_phone',
                    'currency_symbol','work_start_time','work_end_time','payroll_day'];
        foreach ($allowed as $key) {
            if (isset($_POST[$key])) {
                $val = htmlspecialchars(trim($_POST[$key]), ENT_QUOTES, 'UTF-8');
                $stmt->execute([':k' => $key, ':v' => $val, ':v2' => $val]);
            }
        }

        logActivity(currentUserId(), 'Updated general settings');
        $this->flash('success', 'Settings saved!');
        $this->redirect('settings');
    }
}
