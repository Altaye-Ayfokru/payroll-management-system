<!-- Hero Banner -->
<div class="page-hero hero-settings">
  <div class="hero-orb hero-orb-1"></div>
  <div class="hero-orb hero-orb-2"></div>
  <div class="page-hero-content">
    <div class="hero-badge"><span class="hero-badge-dot"></span> System Configuration</div>
    <div class="page-hero-title">Settings</div>
    <div class="page-hero-sub">Configure company information, tax rules, salary components, and system preferences.</div>
  </div>
  <svg class="page-hero-illustration" viewBox="0 0 280 180" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="140" cy="90" r="60" fill="rgba(255,255,255,0.08)" stroke="rgba(255,255,255,0.15)" stroke-width="1.5"/>
    <circle cx="140" cy="90" r="40" fill="rgba(255,255,255,0.08)" stroke="rgba(255,255,255,0.15)" stroke-width="1.5"/>
    <circle cx="140" cy="90" r="20" fill="rgba(255,255,255,0.15)"/>
    <path d="M140 70 L140 110 M120 90 L160 90" stroke="rgba(255,255,255,0.6)" stroke-width="3" stroke-linecap="round"/>
    <circle cx="140" cy="30" r="8" fill="rgba(255,255,255,0.4)"/>
    <circle cx="200" cy="60" r="6" fill="rgba(255,255,255,0.3)"/>
    <circle cx="80" cy="60" r="6" fill="rgba(255,255,255,0.3)"/>
    <circle cx="200" cy="120" r="6" fill="rgba(255,255,255,0.3)"/>
    <circle cx="80" cy="120" r="6" fill="rgba(255,255,255,0.3)"/>
    <circle cx="140" cy="150" r="8" fill="rgba(255,255,255,0.4)"/>
  </svg>
</div>

<div class="page-header">
  <div>
    <div class="page-header-title">System Settings</div>
    <div class="page-header-sub">Configure tax rules, salary components, and system settings</div>
  </div>
</div>

<!-- Tabs -->
<div style="display:flex;gap:4px;margin-bottom:20px;border-bottom:2px solid #e2e8f0;padding-bottom:0">
  <button class="tab-btn active" onclick="showTab('general', this)">
    <i class="fas fa-building" style="margin-right:6px"></i>General
  </button>
  <button class="tab-btn" onclick="showTab('tax', this)">
    <i class="fas fa-receipt" style="margin-right:6px"></i>Tax Rules
  </button>
  <button class="tab-btn" onclick="showTab('salary', this)">
    <i class="fas fa-coins" style="margin-right:6px"></i>Salary Components
  </button>
</div>

<style>
.tab-btn {
  padding: 10px 18px;
  background: none;
  border: none;
  cursor: pointer;
  font-weight: 600;
  font-size: .875rem;
  color: #64748b;
  border-bottom: 2px solid transparent;
  margin-bottom: -2px;
  transition: all .2s;
  border-radius: 8px 8px 0 0;
  font-family: inherit;
}
.tab-btn:hover { color: #6366f1; background: #f0f4ff; }
.tab-btn.active { color: #6366f1; border-bottom-color: #6366f1; background: #f0f4ff; }
.tab-content { display: none; animation: fadeInUp 0.3s ease; }
.tab-content.active { display: block; }
</style>

<!-- General Settings -->
<div class="tab-content active" id="tab-general">
  <div class="card" style="max-width:760px">
    <div class="card-header">
      <span class="card-title"><i class="fas fa-building" style="color:#6366f1;margin-right:8px"></i>Company Settings</span>
    </div>
    <div class="card-body">
      <form method="POST" action="<?= url('settings/general') ?>">
        <?= csrfField() ?>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Company Name</label>
            <input type="text" name="company_name" class="form-control" value="<?= e($settings['company_name'] ?? 'PayrollPro Inc.') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Company Email</label>
            <input type="email" name="company_email" class="form-control" value="<?= e($settings['company_email'] ?? '') ?>">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Phone</label>
            <input type="text" name="company_phone" class="form-control" value="<?= e($settings['company_phone'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Currency Symbol</label>
            <input type="text" name="currency_symbol" class="form-control" value="<?= e($settings['currency_symbol'] ?? 'ETB') ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Company Address</label>
          <textarea name="company_address" class="form-control" rows="2"><?= e($settings['company_address'] ?? '') ?></textarea>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Work Start Time</label>
            <input type="time" name="work_start_time" class="form-control" value="<?= e($settings['work_start_time'] ?? '09:00') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Work End Time</label>
            <input type="time" name="work_end_time" class="form-control" value="<?= e($settings['work_end_time'] ?? '18:00') ?>">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Overtime Rate (multiplier)</label>
            <input type="number" name="overtime_rate" class="form-control" value="<?= e($settings['overtime_rate'] ?? '1.5') ?>" step="0.1" min="1">
            <div class="form-hint">e.g. 1.5 = 150% of hourly rate</div>
          </div>
          <div class="form-group">
            <label class="form-label">Working Days per Month</label>
            <input type="number" name="working_days" class="form-control" value="<?= e($settings['working_days'] ?? '30') ?>" min="20" max="31">
          </div>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Settings</button>
      </form>
    </div>
  </div>
</div>

<!-- Tax Rules -->
<div class="tab-content" id="tab-tax">
  <div class="card">
    <div class="card-header">
      <span class="card-title"><i class="fas fa-receipt" style="color:#f59e0b;margin-right:8px"></i>Tax Rules</span>
      <button class="btn btn-primary btn-sm" onclick="addTaxRow()"><i class="fas fa-plus"></i> Add Rule</button>
    </div>
    <div class="card-body">
      <div style="background:#fef3c7;border:1px solid #fde68a;border-radius:10px;padding:12px;margin-bottom:18px;font-size:.82rem;color:#92400e">
        <i class="fas fa-info-circle"></i>
        <strong>Ethiopian Income Tax Brackets:</strong> Rules are applied progressively based on taxable income.
        Set Max Salary to 0 for the highest bracket (unlimited).
      </div>
      <form method="POST" action="<?= url('settings/tax') ?>">
        <?= csrfField() ?>
        <div id="taxRules">
          <?php foreach ($taxRules as $i => $rule): ?>
          <div class="form-row" style="align-items:end;margin-bottom:10px;background:#f8fafc;padding:12px;border-radius:10px;border:1px solid #e2e8f0" id="taxRow<?= $i ?>">
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Rule Name</label>
              <input type="text" name="tax_name[]" class="form-control" value="<?= e($rule['name']) ?>" required>
            </div>
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Rate (%)</label>
              <input type="number" name="tax_percentage[]" class="form-control" value="<?= $rule['percentage'] ?>" step="0.01" min="0" max="100" required>
            </div>
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Min Salary (ETB)</label>
              <input type="number" name="min_salary[]" class="form-control" value="<?= $rule['min_salary'] ?>" step="0.01" min="0">
            </div>
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Max Salary (0=unlimited)</label>
              <input type="number" name="max_salary[]" class="form-control" value="<?= $rule['max_salary'] ?>" step="0.01" min="0">
            </div>
            <button type="button" class="btn btn-danger btn-sm btn-icon" onclick="this.closest('[id^=taxRow]').remove()" title="Remove">
              <i class="fas fa-trash"></i>
            </button>
          </div>
          <?php endforeach; ?>
        </div>
        <button type="submit" class="btn btn-primary" style="margin-top:16px"><i class="fas fa-save"></i> Save Tax Rules</button>
      </form>
    </div>
  </div>
</div>

<!-- Salary Components -->
<div class="tab-content" id="tab-salary">
  <div class="card">
    <div class="card-header">
      <span class="card-title"><i class="fas fa-coins" style="color:#10b981;margin-right:8px"></i>Salary Components</span>
      <button class="btn btn-primary btn-sm" onclick="addComponentRow()"><i class="fas fa-plus"></i> Add Component</button>
    </div>
    <div class="card-body">
      <form method="POST" action="<?= url('settings/salary') ?>">
        <?= csrfField() ?>
        <div id="components">
          <?php foreach ($salaryComponents as $i => $c): ?>
          <div class="form-row" style="align-items:end;margin-bottom:10px;background:#f8fafc;padding:12px;border-radius:10px;border:1px solid #e2e8f0">
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Component Name</label>
              <input type="text" name="component_name[]" class="form-control" value="<?= e($c['name']) ?>" required>
            </div>
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Type</label>
              <select name="component_type[]" class="form-control">
                <option value="allowance" <?= $c['type'] === 'allowance' ? 'selected' : '' ?>>Allowance</option>
                <option value="deduction" <?= $c['type'] === 'deduction' ? 'selected' : '' ?>>Deduction</option>
              </select>
            </div>
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label">Default Amount (ETB)</label>
              <input type="number" name="component_amount[]" class="form-control" value="<?= $c['amount'] ?>" step="0.01" min="0">
            </div>
            <button type="button" class="btn btn-danger btn-sm btn-icon" onclick="this.closest('.form-row').remove()" title="Remove">
              <i class="fas fa-trash"></i>
            </button>
          </div>
          <?php endforeach; ?>
        </div>
        <button type="submit" class="btn btn-primary" style="margin-top:16px"><i class="fas fa-save"></i> Save Components</button>
      </form>
    </div>
  </div>
</div>

<script>
function showTab(name, btn) {
  document.querySelectorAll('.tab-content').forEach(function(t) { t.classList.remove('active'); });
  document.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
  document.getElementById('tab-' + name).classList.add('active');
  if (btn) btn.classList.add('active');
}

var taxIdx = <?= count($taxRules) ?>;
function addTaxRow() {
  var div = document.createElement('div');
  div.className = 'form-row';
  div.style.cssText = 'align-items:end;margin-bottom:10px;background:#f8fafc;padding:12px;border-radius:10px;border:1px solid #e2e8f0';
  div.id = 'taxRow' + taxIdx++;
  div.innerHTML = `
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Rule Name</label><input type="text" name="tax_name[]" class="form-control" required></div>
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Rate (%)</label><input type="number" name="tax_percentage[]" class="form-control" step="0.01" min="0" max="100" required></div>
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Min Salary (ETB)</label><input type="number" name="min_salary[]" class="form-control" step="0.01" min="0" value="0"></div>
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Max Salary (0=unlimited)</label><input type="number" name="max_salary[]" class="form-control" step="0.01" min="0" value="0"></div>
    <button type="button" class="btn btn-danger btn-sm btn-icon" onclick="this.closest('[id^=taxRow]').remove()"><i class="fas fa-trash"></i></button>`;
  document.getElementById('taxRules').appendChild(div);
}

function addComponentRow() {
  var div = document.createElement('div');
  div.className = 'form-row';
  div.style.cssText = 'align-items:end;margin-bottom:10px;background:#f8fafc;padding:12px;border-radius:10px;border:1px solid #e2e8f0';
  div.innerHTML = `
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Name</label><input type="text" name="component_name[]" class="form-control" required></div>
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Type</label><select name="component_type[]" class="form-control"><option value="allowance">Allowance</option><option value="deduction">Deduction</option></select></div>
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Amount (ETB)</label><input type="number" name="component_amount[]" class="form-control" step="0.01" min="0" value="0"></div>
    <button type="button" class="btn btn-danger btn-sm btn-icon" onclick="this.closest('.form-row').remove()"><i class="fas fa-trash"></i></button>`;
  document.getElementById('components').appendChild(div);
}
</script>
