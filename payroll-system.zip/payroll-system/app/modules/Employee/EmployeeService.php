<?php
/**
 * Employee Module — Service
 * Business logic layer, isolated from HTTP/DB concerns
 */
class EmployeeService {
    private EmployeeModel $model;
    private User          $userModel;

    public function __construct() {
        require_once APP_PATH . '/modules/Employee/EmployeeModel.php';
        require_once APP_PATH . '/models/User.php';
        $this->model     = new EmployeeModel();
        $this->userModel = new User();
    }

    /**
     * Create user account + employee record atomically
     */
    public function createEmployee(array $data, ?array $avatarFile = null): array {
        // Validate email uniqueness
        if ($this->userModel->findByEmail($data['email'])) {
            return ['success' => false, 'error' => 'Email already in use.'];
        }

        $avatar = null;
        if ($avatarFile && !empty($avatarFile['name'])) {
            $avatar = uploadFile($avatarFile, 'avatars');
        }

        $userId = $this->userModel->createUser([
            'name'   => $data['name'],
            'email'  => strtolower(trim($data['email'])),
            'password' => $data['password'] ?? 'Employee@123',
            'role'   => 'employee',
            'phone'  => $data['phone'] ?? '',
            'avatar' => $avatar,
        ]);

        $empCode = $this->model->getNextCode();
        $empId   = $this->model->insert([
            'user_id'             => $userId,
            'employee_code'       => $empCode,
            'gender'              => $data['gender']          ?? 'male',
            'employment_type'     => $data['employment_type'] ?? 'full_time',
            'position_title'      => $data['position_title']  ?? 'Normal Employee',
            'position'            => !empty($data['position']) ? $data['position'] : ($data['position_title'] ?? 'Employee'),
            'department'          => $data['department'],
            'basic_salary'        => (float)($data['basic_salary'] ?? 0),
            'house_allowance'     => (float)($data['house_allowance'] ?? 0),
            'transport_allowance' => 0, // auto-calculated by payroll engine
            'medical_allowance'   => (float)($data['medical_allowance'] ?? 0),
            'other_commission'    => (float)($data['other_commission'] ?? 0),
            'insurance_deduction' => (float)($data['insurance_deduction'] ?? 0),
            'hire_date'           => $data['hire_date'],
            'bank_name'           => $data['bank_name']    ?? '',
            'bank_account'        => $data['bank_account'] ?? '',
            'status'              => 'active',
            'created_at'          => date('Y-m-d H:i:s'),
        ]);

        return ['success' => true, 'employee_id' => $empId, 'user_id' => $userId, 'code' => $empCode];
    }

    /**
     * Update employee + user data
     */
    public function updateEmployee(int $empId, array $data, ?array $avatarFile = null): bool {
        $emp = $this->model->getWithUser($empId);
        if (!$emp) return false;

        $userUpdate = ['name' => $data['name'], 'phone' => $data['phone'] ?? ''];
        if ($avatarFile && !empty($avatarFile['name'])) {
            $avatar = uploadFile($avatarFile, 'avatars');
            if ($avatar) $userUpdate['avatar'] = $avatar;
        }
        $this->userModel->update($emp['user_id'], $userUpdate);

        $this->model->update($empId, [
            'gender'              => $data['gender']          ?? 'male',
            'employment_type'     => $data['employment_type'] ?? 'full_time',
            'position_title'      => $data['position_title']  ?? 'Normal Employee',
            'position'            => !empty($data['position']) ? $data['position'] : ($data['position_title'] ?? 'Employee'),
            'department'          => $data['department'],
            'basic_salary'        => (float)($data['basic_salary'] ?? 0),
            'house_allowance'     => (float)($data['house_allowance'] ?? 0),
            'transport_allowance' => 0,
            'medical_allowance'   => (float)($data['medical_allowance'] ?? 0),
            'other_commission'    => (float)($data['other_commission'] ?? 0),
            'insurance_deduction' => (float)($data['insurance_deduction'] ?? 0),
            'bank_name'           => $data['bank_name']    ?? '',
            'bank_account'        => $data['bank_account'] ?? '',
            'status'              => $data['status'] ?? 'active',
        ]);

        return true;
    }

    public function getEmployee(int $id): ?array {
        return $this->model->getWithUser($id);
    }

    public function listEmployees(int $page, string $search = '', string $dept = ''): array {
        $offset = ($page - 1) * ITEMS_PER_PAGE;
        $total  = $this->model->countFiltered($dept);

        $employees = $search
            ? $this->model->search($search, ITEMS_PER_PAGE, $offset)
            : $this->model->getAllWithUsers(ITEMS_PER_PAGE, $offset, $dept);

        return [
            'employees' => $employees,
            'pager'     => paginate($total, ITEMS_PER_PAGE, $page),
        ];
    }

    public function deleteEmployee(int $id): bool {
        return $this->model->softDelete($id);
    }
}
