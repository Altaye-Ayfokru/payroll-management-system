<div class="page-header">
  <div>
    <div class="page-header-title">Edit Employee</div>
    <div class="page-header-sub"><?= e($employee['name']) ?> · <?= e($employee['employee_code']) ?></div>
  </div>
  <div class="page-header-actions">
    <a href="<?= url('employees/view/' . $employee['id']) ?>" class="btn btn-outline"><i class="fas fa-eye"></i> View Profile</a>
    <a href="<?= url('employees') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back</a>
  </div>
</div>

<div class="card" style="max-width:860px">
  <div class="card-body">
    <form method="POST" action="<?= url('employees/update/' . $employee['id']) ?>" enctype="multipart/form-data">
      <?= csrfField() ?>

      <!-- Avatar -->
      <div class="avatar-upload">
        <?php if (!empty($employee['avatar'])): ?>
        <img src="<?= e(url($employee['avatar'])) ?>" alt="Preview" class="avatar-preview" id="avatarPreview">
        <?php else: ?>
        <div id="avatarPreview" style="width:72px;height:72px;border-radius:50%;overflow:hidden;border:3px solid #e0e7ff">
          <?= renderAvatarSvg($employee['name'] ?? 'E', (int)($employee['id'] ?? 0), 72) ?>
        </div>
        <?php endif; ?>
        <div>
          <label class="avatar-upload-btn" for="avatarInput"><i class="fas fa-camera"></i> Change Photo</label>
          <input type="file" name="avatar" id="avatarInput" class="avatar-upload-input" accept="image/*"
                 onchange="document.getElementById('avatarPreview').src = URL.createObjectURL(this.files[0])">
        </div>
      </div>

      <!-- Personal Info -->
      <div class="form-section">
        <div class="form-section-title"><i class="fas fa-user"></i> Personal Information</div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Full Name <span class="required">*</span></label>
            <input type="text" name="name" class="form-control" value="<?= e($employee['name']) ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">Gender</label>
            <select name="gender" class="form-control">
              <option value="male"   <?= ($employee['gender']??'male')==='male'   ?'selected':'' ?>>Male</option>
              <option value="female" <?= ($employee['gender']??'')==='female' ?'selected':'' ?>>Female</option>
              <option value="other"  <?= ($employee['gender']??'')==='other'  ?'selected':'' ?>>Other</option>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Phone</label>
            <input type="text" name="phone" class="form-control" value="<?= e($employee['phone'] ?? '') ?>" placeholder="+251 9xx xxx xxx">
          </div>
        </div>
      </div>

      <!-- Employment Info -->
      <div class="form-section">
        <div class="form-section-title"><i class="fas fa-briefcase"></i> Employment Information</div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Employment Type</label>
            <select name="employment_type" class="form-control">
              <option value="full_time" <?= ($employee['employment_type']??'full_time')==='full_time'?'selected':'' ?>>Full-time</option>
              <option value="part_time" <?= ($employee['employment_type']??'')==='part_time'?'selected':'' ?>>Part-time</option>
            </select>
            <div class="form-hint">Affects pension calculation</div>
          </div>
          <div class="form-group">
            <label class="form-label">Position Title</label>
            <select name="position_title" class="form-control" id="positionTitle" onchange="updateAllowancePreview()">
              <?php foreach (['CEO','COO','CTO','CISO','Director','Dept Head','Normal Employee'] as $pt): ?>
              <option value="<?= $pt ?>" <?= ($employee['position_title']??'Normal Employee')===$pt?'selected':'' ?>><?= $pt ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Job Position / Role <span class="required">*</span></label>
            <input type="text" name="position" class="form-control" value="<?= e($employee['position']) ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">Department <span class="required">*</span></label>
            <input type="text" name="department" class="form-control" value="<?= e($employee['department']) ?>" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Status</label>
            <select name="status" class="form-control">
              <option value="active"     <?= $employee['status'] === 'active'     ? 'selected' : '' ?>>Active</option>
              <option value="inactive"   <?= $employee['status'] === 'inactive'   ? 'selected' : '' ?>>Inactive</option>
              <option value="terminated" <?= $employee['status'] === 'terminated' ? 'selected' : '' ?>>Terminated</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Salary Structure -->
      <div class="form-section">
        <div class="form-section-title"><i class="fas fa-coins"></i> Salary Structure</div>

        <!-- Live Preview -->
        <div id="allowancePreview" style="background:linear-gradient(135deg,#f0f4ff,#faf5ff);border:1px solid #ddd6fe;border-radius:12px;padding:16px;margin-bottom:20px">
          <div style="font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#6366f1;margin-bottom:10px">
            <i class="fas fa-calculator"></i> Allowance Preview (auto-calculated)
          </div>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;font-size:.82rem">
            <div><span style="color:#64748b">Position Allowance:</span><br><strong id="previewPosAllow">—</strong></div>
            <div><span style="color:#64748b">Transport Allowance:</span><br><strong id="previewTransAllow">—</strong></div>
            <div><span style="color:#64748b">Taxable:</span><br><strong id="previewTaxable">—</strong></div>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Basic Salary (ETB) <span class="required">*</span></label>
            <div class="input-group">
              <i class="fas fa-coins input-group-icon"></i>
              <input type="number" name="basic_salary" id="basicSalary" class="form-control"
                     value="<?= $employee['basic_salary'] ?>" step="0.01" min="0" required oninput="updateAllowancePreview()">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Other / Commission (ETB)</label>
            <input type="number" name="other_commission" class="form-control"
                   value="<?= $employee['other_commission'] ?? 0 ?>" step="0.01" min="0">
            <div class="form-hint">Fully taxable</div>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">House Allowance (ETB)</label>
            <input type="number" name="house_allowance" class="form-control" value="<?= $employee['house_allowance'] ?>" step="0.01" min="0">
          </div>
          <div class="form-group">
            <label class="form-label">Medical Allowance (ETB)</label>
            <input type="number" name="medical_allowance" class="form-control" value="<?= $employee['medical_allowance'] ?>" step="0.01" min="0">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Insurance Deduction (ETB)</label>
            <input type="number" name="insurance_deduction" class="form-control" value="<?= $employee['insurance_deduction'] ?>" step="0.01" min="0">
          </div>
        </div>
      </div>

      <!-- Bank Details -->
      <div class="form-section">
        <div class="form-section-title"><i class="fas fa-university"></i> Bank Details</div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Bank Name</label>
            <input type="text" name="bank_name" class="form-control" value="<?= e($employee['bank_name'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Account Number</label>
            <input type="text" name="bank_account" class="form-control" value="<?= e($employee['bank_account'] ?? '') ?>">
          </div>
        </div>
      </div>

      <div style="display:flex;gap:10px;justify-content:flex-end">
        <a href="<?= url('employees') ?>" class="btn btn-outline">Cancel</a>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Employee</button>
      </div>
    </form>
  </div>
</div>

<script>
var positionAllowances = {
  'CEO':             { rate: 0.10, taxable: false },
  'COO':             { rate: 0.08, taxable: true  },
  'CTO':             { rate: 0.08, taxable: true  },
  'CISO':            { rate: 0.08, taxable: true  },
  'Director':        { rate: 0.07, taxable: true  },
  'Dept Head':       { rate: 0.05, taxable: true  },
  'Normal Employee': { rate: 0,    taxable: true  }
};
var positionedTitles = ['CEO','COO','CTO','CISO','Director','Dept Head'];

function updateAllowancePreview() {
  var basic    = parseFloat(document.getElementById('basicSalary').value) || 0;
  var title    = document.getElementById('positionTitle').value;
  var pa       = positionAllowances[title] || { rate: 0, taxable: true };
  var posAllow = Math.round(basic * pa.rate * 100) / 100;
  var transAllow = positionedTitles.includes(title) ? 2220 : 600;
  var taxablePos = pa.taxable ? posAllow : 0;

  document.getElementById('previewPosAllow').textContent =
    posAllow.toLocaleString('en-US', {minimumFractionDigits:2}) + ' ETB' +
    (pa.taxable ? ' (taxable)' : ' (non-taxable)');
  document.getElementById('previewTransAllow').textContent =
    transAllow.toLocaleString('en-US', {minimumFractionDigits:2}) + ' ETB (non-taxable)';
  document.getElementById('previewTaxable').textContent =
    taxablePos.toLocaleString('en-US', {minimumFractionDigits:2}) + ' ETB taxable pos.';
}
updateAllowancePreview();
</script>
