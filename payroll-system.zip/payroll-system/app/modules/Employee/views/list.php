﻿<!-- Hero Banner -->
<div class="page-hero hero-employees">
  <div class="hero-orb hero-orb-1"></div>
  <div class="hero-orb hero-orb-2"></div>
  <div class="page-hero-content">
    <div class="hero-badge"><span class="hero-badge-dot"></span> HR Management</div>
    <div class="page-hero-title">Employee Directory</div>
    <div class="page-hero-sub">Manage your workforce — add, edit, and track all employee profiles and salary structures.</div>
    <div class="page-hero-actions">
      <a href="<?= url('employees/create') ?>" class="page-hero-btn page-hero-btn-white">
        <i class="fas fa-user-plus"></i> Add Employee
      </a>
      <a href="<?= url('employees/import') ?>" class="page-hero-btn page-hero-btn-outline">
        <i class="fas fa-upload"></i> Import CSV
      </a>
      <a href="<?= url('reports') ?>" class="page-hero-btn page-hero-btn-outline">
        <i class="fas fa-chart-bar"></i> View Reports
      </a>
    </div>
  </div>
  <svg class="page-hero-illustration" viewBox="0 0 280 180" fill="none" xmlns="http://www.w3.org/2000/svg" style="overflow:visible">
    <style>
      .eh-p1{animation:ehF1 3.5s ease-in-out infinite}
      .eh-p2{animation:ehF2 4s ease-in-out infinite .6s}
      .eh-p3{animation:ehF3 3.2s ease-in-out infinite 1.2s}
      .eh-card{animation:ehSl .8s ease .3s both}
      .eh-plus{animation:ehPp .5s cubic-bezier(.34,1.56,.64,1) 1s both}
      @keyframes ehF1{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
      @keyframes ehF2{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
      @keyframes ehF3{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
      @keyframes ehSl{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:translateX(0)}}
      @keyframes ehPp{0%{transform:scale(0)}70%{transform:scale(1.3)}100%{transform:scale(1)}}
    </style>
    <ellipse cx="140" cy="174" rx="120" ry="7" fill="rgba(0,0,0,.12)"/>
    <!-- Person 1: dark skin, purple blazer -->
    <g class="eh-p1" transform="translate(10,30)">
      <rect x="16" y="80" width="32" height="40" rx="8" fill="#7c3aed"/>
      <rect x="20" y="118" width="10" height="28" rx="5" fill="#4c1d95"/>
      <rect x="32" y="118" width="10" height="28" rx="5" fill="#4c1d95"/>
      <ellipse cx="25" cy="148" rx="9" ry="4" fill="#1a0a00"/>
      <ellipse cx="37" cy="148" rx="9" ry="4" fill="#1a0a00"/>
      <rect x="28" y="68" width="8" height="14" rx="4" fill="#c68642"/>
      <circle cx="32" cy="56" r="16" fill="#c68642"/>
      <ellipse cx="32" cy="43" rx="17" ry="12" fill="#1a0a00"/>
      <circle cx="16" cy="44" r="7" fill="#1a0a00"/>
      <circle cx="48" cy="44" r="7" fill="#1a0a00"/>
      <circle cx="27" cy="56" r="2.5" fill="#1a0a00"/>
      <circle cx="37" cy="56" r="2.5" fill="#1a0a00"/>
      <path d="M27 63 Q32 67 37 63" stroke="#8b4513" stroke-width="1.2" fill="none" stroke-linecap="round"/>
      <circle cx="16" cy="59" r="2" fill="#fbbf24"/>
      <circle cx="48" cy="59" r="2" fill="#fbbf24"/>
      <rect x="0" y="84" width="18" height="9" rx="4" fill="#7c3aed"/>
      <rect x="46" y="84" width="18" height="9" rx="4" fill="#7c3aed"/>
    </g>
    <!-- Person 2: light skin, dark suit, center -->
    <g class="eh-p2" transform="translate(95,10)">
      <rect x="20" y="90" width="40" height="50" rx="9" fill="#1e293b"/>
      <rect x="30" y="90" width="20" height="28" rx="3" fill="white"/>
      <polygon points="40,90 34,102 40,97 46,102" fill="#6366f1"/>
      <polygon points="20,90 30,90 24,110" fill="#0f172a"/>
      <polygon points="60,90 50,90 56,110" fill="#0f172a"/>
      <rect x="20" y="138" width="14" height="34" rx="6" fill="#1e293b"/>
      <rect x="36" y="138" width="14" height="34" rx="6" fill="#1e293b"/>
      <ellipse cx="27" cy="174" rx="12" ry="5" fill="#0f172a"/>
      <ellipse cx="43" cy="174" rx="12" ry="5" fill="#0f172a"/>
      <rect x="34" y="74" width="12" height="18" rx="6" fill="#f5cba7"/>
      <circle cx="40" cy="60" r="20" fill="#f5cba7"/>
      <ellipse cx="40" cy="43" rx="20" ry="13" fill="#5c3317"/>
      <ellipse cx="40" cy="41" rx="16" ry="9" fill="#7b4a2d"/>
      <circle cx="33" cy="60" r="3" fill="white"/>
      <circle cx="47" cy="60" r="3" fill="white"/>
      <circle cx="34" cy="61" r="1.8" fill="#3d2b1f"/>
      <circle cx="48" cy="61" r="1.8" fill="#3d2b1f"/>
      <path d="M33 68 Q40 73 47 68" stroke="#c0845a" stroke-width="1.2" fill="none" stroke-linecap="round"/>
      <rect x="0" y="96" width="22" height="10" rx="5" fill="#1e293b"/>
      <rect x="58" y="96" width="22" height="10" rx="5" fill="#1e293b"/>
    </g>
    <!-- Person 3: medium skin, teal blouse -->
    <g class="eh-p3" transform="translate(200,35)">
      <rect x="14" y="78" width="36" height="42" rx="8" fill="#0ea5e9"/>
      <rect x="18" y="118" width="10" height="28" rx="5" fill="#0369a1"/>
      <rect x="30" y="118" width="10" height="28" rx="5" fill="#0369a1"/>
      <ellipse cx="23" cy="148" rx="9" ry="4" fill="#1e3a5f"/>
      <ellipse cx="35" cy="148" rx="9" ry="4" fill="#1e3a5f"/>
      <rect x="27" y="66" width="10" height="14" rx="5" fill="#d4956a"/>
      <circle cx="32" cy="54" r="16" fill="#d4956a"/>
      <ellipse cx="32" cy="40" rx="16" ry="12" fill="#1a0a00"/>
      <rect x="16" y="40" width="6" height="36" rx="3" fill="#1a0a00"/>
      <rect x="42" y="40" width="6" height="36" rx="3" fill="#1a0a00"/>
      <circle cx="26" cy="54" r="2.5" fill="#1a0a00"/>
      <circle cx="38" cy="54" r="2.5" fill="#1a0a00"/>
      <path d="M26 62 Q32 67 38 62" stroke="#a0522d" stroke-width="1.2" fill="none" stroke-linecap="round"/>
      <rect x="-2" y="82" width="18" height="9" rx="4" fill="#0ea5e9"/>
      <rect x="48" y="82" width="18" height="9" rx="4" fill="#0ea5e9"/>
    </g>
    <!-- Floating employee card -->
    <g class="eh-card" transform="translate(4,100)">
      <rect x="0" y="0" width="80" height="52" rx="8" fill="white" opacity=".95"/>
      <rect x="0" y="0" width="80" height="18" rx="8" fill="#6366f1"/>
      <rect x="0" y="9" width="80" height="9" fill="#6366f1"/>
      <text x="8" y="13" font-size="6.5" fill="white" font-weight="bold" font-family="Arial,sans-serif">New Employee</text>
      <circle cx="16" cy="32" r="8" fill="#e0e7ff"/>
      <circle cx="16" cy="29" r="4" fill="#6366f1"/>
      <path d="M8 38 Q16 34 24 38" fill="#6366f1"/>
      <rect x="28" y="26" width="40" height="4" rx="2" fill="#0f172a"/>
      <rect x="28" y="33" width="28" height="3" rx="1.5" fill="#94a3b8"/>
      <rect x="28" y="40" width="34" height="3" rx="1.5" fill="#94a3b8"/>
    </g>
    <!-- Plus badge -->
    <g class="eh-plus" transform="translate(240,8)">
      <circle cx="16" cy="16" r="16" fill="#10b981"/>
      <path d="M10 16 H22 M16 10 V22" stroke="white" stroke-width="3" stroke-linecap="round"/>
    </g>
  </svg>
</div>

<div class="page-header">
  <div>
    <div class="page-header-title">Employees</div>
    <div class="page-header-sub"><?= number_format($pager['total']) ?> total employees</div>
  </div>
  <div class="page-header-actions">
    <a href="<?= url('employees/import') ?>" class="btn btn-outline">
      <i class="fas fa-upload"></i> Import
    </a>
    <a href="<?= url('employees/export') ?>" class="btn btn-outline">
      <i class="fas fa-download"></i> Export
    </a>
    <a href="<?= url('employees/create') ?>" class="btn btn-primary">
      <i class="fas fa-user-plus"></i> Add Employee
    </a>
  </div>
</div>

<!-- Filter Bar -->
<div class="filter-bar">
  <form method="GET" action="<?= url('employees') ?>" style="display:flex;gap:10px;flex-wrap:wrap;width:100%">
    <div class="search-bar" style="flex:1;min-width:200px">
      <i class="fas fa-search"></i>
      <input type="text" name="search" placeholder="Search by name, email, position..." value="<?= e($search) ?>">
    </div>
    <select name="dept" class="form-control" style="width:auto">
      <option value="">All Departments</option>
      <?php foreach ($departments as $d): ?>
      <option value="<?= e($d['department']) ?>" <?= $dept === $d['department'] ? 'selected' : '' ?>>
        <?= e($d['department']) ?>
      </option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
    <?php if ($search || $dept): ?>
    <a href="<?= url('employees') ?>" class="btn btn-outline"><i class="fas fa-times"></i> Clear</a>
    <?php endif; ?>
  </form>
</div>

<div class="card">
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th>Employee</th>
          <th>Department</th>
          <th>Position</th>
          <th>Basic Salary</th>
          <th>Hire Date</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($employees)): ?>
        <tr>
          <td colspan="7">
            <div class="empty-state">
              <div class="empty-state-icon"><i class="fas fa-users"></i></div>
              <div class="empty-state-title">No employees found</div>
              <div class="empty-state-text">Add your first employee to get started</div>
            </div>
          </td>
        </tr>
        <?php else: ?>
        <?php foreach ($employees as $emp): ?>
        <tr>
          <td>
            <div class="emp-cell">
              <?php
              $empId   = (int)($emp['id'] ?? 0);
              $empName = $emp['name'] ?? '';
              if (!empty($emp['avatar'])) {
                  echo '<img src="' . e(getAvatarUrl($emp['avatar'], $empName, $empId)) . '" alt="" class="avatar avatar-sm" style="border:2px solid #e0e7ff">';
              } else {
                  echo renderAvatarSvg($empName, $empId, 36);
              }
              ?>
              <div>
                <div class="emp-info-name"><?= e($emp['name']) ?></div>
                <div class="emp-info-code"><?= e($emp['employee_code']) ?> &middot; <?= e($emp['email']) ?></div>
              </div>
            </div>
          </td>
          <td><span class="dept-badge"><?= e($emp['department']) ?></span></td>
          <td><?= e($emp['position']) ?></td>
          <td><strong><?= formatCurrency((float)$emp['basic_salary']) ?></strong></td>
          <td><?= formatDate($emp['hire_date']) ?></td>
          <td><?= statusBadge($emp['status']) ?></td>
          <td>
            <div style="display:flex;gap:6px">
              <a href="<?= url('employees/view/' . $emp['id']) ?>" class="btn btn-outline btn-sm btn-icon" title="View">
                <i class="fas fa-eye"></i>
              </a>
              <a href="<?= url('employees/edit/' . $emp['id']) ?>" class="btn btn-outline btn-sm btn-icon" title="Edit">
                <i class="fas fa-edit"></i>
              </a>
              <?php if (isAdmin()): ?>
              <button class="btn btn-danger btn-sm btn-icon" title="Delete"
                      onclick="deleteEmployee(<?= $emp['id'] ?>, this)">
                <i class="fas fa-trash"></i>
              </button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($pager['total_pages'] > 1): ?>
  <div class="pagination">
    <?php if ($pager['has_prev']): ?>
    <a href="?page=<?= $pager['current_page'] - 1 ?>&search=<?= urlencode($search) ?>&dept=<?= urlencode($dept) ?>" class="page-btn">
      <i class="fas fa-chevron-left"></i>
    </a>
    <?php endif; ?>
    <?php for ($i = max(1, $pager['current_page'] - 2); $i <= min($pager['total_pages'], $pager['current_page'] + 2); $i++): ?>
    <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&dept=<?= urlencode($dept) ?>"
       class="page-btn <?= $i === $pager['current_page'] ? 'active' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($pager['has_next']): ?>
    <a href="?page=<?= $pager['current_page'] + 1 ?>&search=<?= urlencode($search) ?>&dept=<?= urlencode($dept) ?>" class="page-btn">
      <i class="fas fa-chevron-right"></i>
    </a>
    <?php endif; ?>
    <span style="margin-left:auto;font-size:.78rem;color:#64748b">
      Showing <?= count($employees) ?> of <?= $pager['total'] ?>
    </span>
  </div>
  <?php endif; ?>
</div>

<script>
function deleteEmployee(id, btn) {
  if (!confirm('Delete this employee? This action cannot be undone.')) return;
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  ajax('POST', `employees/delete/${id}`, { csrf_token: csrf }, data => {
    if (data.success) {
      btn.closest('tr').style.opacity = '0';
      btn.closest('tr').style.transition = 'opacity .3s';
      setTimeout(() => { btn.closest('tr').remove(); showToast('Employee deleted.', 'success'); }, 300);
    } else {
      showToast(data.message || 'Failed to delete.', 'error');
    }
  });
}
</script>
