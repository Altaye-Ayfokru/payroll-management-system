<div class="page-header">
  <div>
    <div class="page-header-title">Add Employee</div>
    <div class="page-header-sub">Create a new employee record</div>
  </div>
  <a href="<?= url('employees') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<div class="card" style="max-width:860px">
  <div class="card-body">
    <form method="POST" action="<?= url('employees/store') ?>" enctype="multipart/form-data">
      <?= csrfField() ?>

      <!-- Avatar -->
      <div class="avatar-upload">
        <?php if (!empty($old['avatar'] ?? '')): ?>
        <img src="<?= e(asset('images/default-avatar.png')) ?>" alt="Preview" class="avatar-preview" id="avatarPreview">
        <?php else: ?>
        <div id="avatarPreview" style="width:72px;height:72px;border-radius:50%;overflow:hidden;border:3px solid #e0e7ff">
          <?= renderAvatarSvg('New Employee', 0, 72) ?>
        </div>
        <?php endif; ?>
        <div>
          <label class="avatar-upload-btn" for="avatarInput"><i class="fas fa-camera"></i> Upload Photo</label>
          <input type="file" name="avatar" id="avatarInput" class="avatar-upload-input" accept="image/*"
                 onchange="document.getElementById('avatarPreview').src=URL.createObjectURL(this.files[0])">
          <div class="form-hint">JPG, PNG up to 5MB</div>
        </div>
      </div>

      <!-- Personal Info -->
      <div class="form-section">
        <div class="form-section-title"><i class="fas fa-user"></i> Personal Information</div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Full Name <span class="required">*</span></label>
            <input type="text" name="name" class="form-control <?= isset($errors['name'])?'is-invalid':'' ?>"
                   value="<?= e($old['name'] ?? '') ?>" placeholder="Full name" required>
            <?php if (isset($errors['name'])): ?><div class="form-error"><?= e($errors['name']) ?></div><?php endif; ?>
          </div>
          <div class="form-group">
            <label class="form-label">Gender <span class="required">*</span></label>
            <select name="gender" class="form-control" required>
              <option value="male"   <?= ($old['gender']??'')==='male'   ?'selected':'' ?>>Male</option>
              <option value="female" <?= ($old['gender']??'')==='female' ?'selected':'' ?>>Female</option>
              <option value="other"  <?= ($old['gender']??'')==='other'  ?'selected':'' ?>>Other</option>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Email Address <span class="required">*</span></label>
            <input type="email" name="email" class="form-control <?= isset($errors['email'])?'is-invalid':'' ?>"
                   value="<?= e($old['email'] ?? '') ?>" placeholder="email@company.com" required>
            <?php if (isset($errors['email'])): ?><div class="form-error"><?= e($errors['email']) ?></div><?php endif; ?>
          </div>
          <div class="form-group">
            <label class="form-label">Phone</label>
            <input type="text" name="phone" class="form-control" value="<?= e($old['phone'] ?? '') ?>" placeholder="+251 9xx xxx xxx">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Login Password</label>
            <input type="password" name="password" class="form-control" placeholder="Default: Employee@123">
            <div class="form-hint">Leave blank to use default</div>
          </div>
        </div>
      </div>

      <!-- Employment Info -->
      <div class="form-section">
        <div class="form-section-title"><i class="fas fa-briefcase"></i> Employment Information</div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Employment Type <span class="required">*</span></label>
            <select name="employment_type" class="form-control" required>
              <option value="full_time"  <?= ($old['employment_type']??'full_time')==='full_time' ?'selected':'' ?>>Full-time</option>
              <option value="part_time"  <?= ($old['employment_type']??'')==='part_time' ?'selected':'' ?>>Part-time</option>
            </select>
            <div class="form-hint">Affects pension calculation (full-time only)</div>
          </div>
          <div class="form-group">
            <label class="form-label">Position Title <span class="required">*</span></label>
            <select name="position_title" class="form-control" id="positionTitle" required onchange="updateAllowancePreview()">
              <?php foreach (['CEO','COO','CTO','CISO','Director','Dept Head','Normal Employee'] as $pt): ?>
              <option value="<?= $pt ?>" <?= ($old['position_title']??'')===$pt?'selected':'' ?>><?= $pt ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Job Position / Role</label>
            <input type="text" name="position" class="form-control" value="<?= e($old['position'] ?? '') ?>" placeholder="e.g. Senior Developer">
          </div>
          <div class="form-group">
            <label class="form-label">Department <span class="required">*</span></label>
            <input type="text" name="department" class="form-control <?= isset($errors['department'])?'is-invalid':'' ?>"
                   value="<?= e($old['department'] ?? '') ?>" placeholder="Engineering" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Employment Date <span class="required">*</span></label>
            <input type="date" name="hire_date" class="form-control" value="<?= e($old['hire_date'] ?? date('Y-m-d')) ?>" required>
          </div>
        </div>
      </div>

      <!-- Salary Structure -->
      <div class="form-section">
        <div class="form-section-title"><i class="fas fa-coins"></i> Salary Structure</div>

        <!-- Live Preview Box -->
        <div id="allowancePreview" style="background:linear-gradient(135deg,#f0f4ff,#faf5ff);border:1px solid #ddd6fe;border-radius:12px;padding:16px;margin-bottom:20px">
          <div style="font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#6366f1;margin-bottom:10px">
            <i class="fas fa-calculator"></i> Allowance Preview (auto-calculated)
          </div>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;font-size:.82rem">
            <div><span style="color:#64748b">Position Allowance:</span><br><strong id="previewPosAllow">—</strong></div>
            <div><span style="color:#64748b">Transport Allowance:</span><br><strong id="previewTransAllow">—</strong></div>
            <div><span style="color:#64748b">Taxable:</span><br><strong id="previewTaxable">—</strong></div>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Basic Salary (ETB) <span class="required">*</span></label>
            <div class="input-group">
              <i class="fas fa-coins input-group-icon"></i>
              <input type="number" name="basic_salary" id="basicSalary" class="form-control"
                     value="<?= e($old['basic_salary'] ?? '') ?>" placeholder="0.00" step="0.01" min="0"
                     required oninput="updateAllowancePreview()">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Other / Commission (ETB)</label>
            <div class="input-group">
              <i class="fas fa-plus-circle input-group-icon"></i>
              <input type="number" name="other_commission" class="form-control"
                     value="<?= e($old['other_commission'] ?? '0') ?>" step="0.01" min="0">
            </div>
            <div class="form-hint">Fully taxable</div>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">House Allowance (ETB)</label>
            <input type="number" name="house_allowance" class="form-control" value="<?= e($old['house_allowance'] ?? '0') ?>" step="0.01" min="0">
          </div>
          <div class="form-group">
            <label class="form-label">Medical Allowance (ETB)</label>
            <input type="number" name="medical_allowance" class="form-control" value="<?= e($old['medical_allowance'] ?? '0') ?>" step="0.01" min="0">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Insurance Deduction (ETB)</label>
            <input type="number" name="insurance_deduction" class="form-control" value="<?= e($old['insurance_deduction'] ?? '0') ?>" step="0.01" min="0">
          </div>
        </div>
      </div>

      <!-- Bank Details -->
      <div class="form-section">
        <div class="form-section-title"><i class="fas fa-university"></i> Bank Details</div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Bank Name</label>
            <input type="text" name="bank_name" class="form-control" value="<?= e($old['bank_name'] ?? '') ?>" placeholder="Commercial Bank of Ethiopia">
          </div>
          <div class="form-group">
            <label class="form-label">Bank Account Number</label>
            <input type="text" name="bank_account" class="form-control" value="<?= e($old['bank_account'] ?? '') ?>" placeholder="1000XXXXXXXXX">
          </div>
        </div>
      </div>

      <div style="display:flex;gap:10px;justify-content:flex-end">
        <a href="<?= url('employees') ?>" class="btn btn-outline">Cancel</a>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Employee</button>
      </div>
    </form>
  </div>
</div>

<script>
var positionAllowances = {
  'CEO':             { rate: 0.10, taxable: false },
  'COO':             { rate: 0.08, taxable: true  },
  'CTO':             { rate: 0.08, taxable: true  },
  'CISO':            { rate: 0.08, taxable: true  },
  'Director':        { rate: 0.07, taxable: true  },
  'Dept Head':       { rate: 0.05, taxable: true  },
  'Normal Employee': { rate: 0,    taxable: true  }
};
var transportAllowances = {
  positioned: 2220,
  normal: 600
};
var positionedTitles = ['CEO','COO','CTO','CISO','Director','Dept Head'];

function updateAllowancePreview() {
  var basic    = parseFloat(document.getElementById('basicSalary').value) || 0;
  var title    = document.getElementById('positionTitle').value;
  var pa       = positionAllowances[title] || { rate: 0, taxable: true };
  var posAllow = Math.round(basic * pa.rate * 100) / 100;
  var transAllow = positionedTitles.includes(title) ? transportAllowances.positioned : transportAllowances.normal;
  var taxablePos = pa.taxable ? posAllow : 0;

  document.getElementById('previewPosAllow').textContent =
    posAllow.toLocaleString('en-US', {minimumFractionDigits:2}) + ' ETB' +
    (pa.taxable ? ' (taxable)' : ' (non-taxable)');
  document.getElementById('previewTransAllow').textContent =
    transAllow.toLocaleString('en-US', {minimumFractionDigits:2}) + ' ETB (non-taxable)';
  document.getElementById('previewTaxable').textContent =
    taxablePos.toLocaleString('en-US', {minimumFractionDigits:2}) + ' ETB taxable pos.';
}
updateAllowancePreview();
</script>
