<!-- Hero Banner -->
<div class="page-hero hero-employees">
  <div class="hero-orb hero-orb-1"></div>
  <div class="hero-orb hero-orb-2"></div>
  <div class="page-hero-content">
    <div class="hero-badge"><span class="hero-badge-dot"></span> Bulk Import</div>
    <div class="page-hero-title">Import Employees</div>
    <div class="page-hero-sub">Upload a CSV file to add multiple employees at once. Download the template to get started.</div>
    <div class="page-hero-actions">
      <a href="<?= url('employees') ?>" class="page-hero-btn page-hero-btn-outline">
        <i class="fas fa-arrow-left"></i> Back to Employees
      </a>
    </div>
  </div>
</div>

<div class="page-header">
  <div>
    <div class="page-header-title">Bulk Employee Import</div>
    <div class="page-header-sub">Upload CSV to add multiple employees</div>
  </div>
  <div class="page-header-actions">
    <a href="<?= url('employees/export') ?>" class="btn btn-outline">
      <i class="fas fa-download"></i> Export Current Employees
    </a>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem">

  <!-- Upload Form -->
  <div class="card">
    <div class="card-header">
      <span class="card-title"><i class="fas fa-upload" style="color:#6366f1;margin-right:8px"></i>Upload CSV File</span>
    </div>
    <div class="card-body">
      <form method="POST" action="<?= url('employees/import') ?>" enctype="multipart/form-data">
        <?= csrfField() ?>

        <div style="border:2px dashed #e2e8f0;border-radius:12px;padding:2rem;text-align:center;margin-bottom:1.25rem;transition:all .2s;cursor:pointer"
             id="dropZone"
             ondragover="event.preventDefault();this.style.borderColor='#6366f1';this.style.background='#f0f4ff'"
             ondragleave="this.style.borderColor='#e2e8f0';this.style.background=''"
             ondrop="handleDrop(event)">
          <i class="fas fa-file-csv" style="font-size:2.5rem;color:#6366f1;margin-bottom:.75rem;display:block"></i>
          <div style="font-weight:700;color:#0f172a;margin-bottom:.25rem">Drop CSV file here</div>
          <div style="font-size:.82rem;color:#64748b;margin-bottom:1rem">or click to browse</div>
          <label class="btn btn-outline" for="csvFile" style="cursor:pointer">
            <i class="fas fa-folder-open"></i> Choose File
          </label>
          <input type="file" name="csv_file" id="csvFile" accept=".csv,text/csv" style="display:none"
                 onchange="updateFileName(this)">
          <div id="fileName" style="margin-top:.75rem;font-size:.82rem;color:#6366f1;font-weight:600"></div>
        </div>

        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:12px;margin-bottom:1.25rem;font-size:.82rem;color:#065f46">
          <i class="fas fa-info-circle"></i>
          <strong>Default password</strong> for all imported employees: <code style="background:#d1fae5;padding:2px 6px;border-radius:4px">Employee@123</code>
          <br>Employees can change their password after first login.
        </div>

        <button type="submit" class="btn btn-primary" style="width:100%">
          <i class="fas fa-upload"></i> Import Employees
        </button>
      </form>
    </div>
  </div>

  <!-- Template & Instructions -->
  <div style="display:flex;flex-direction:column;gap:1.25rem">

    <!-- CSV Template -->
    <div class="card">
      <div class="card-header">
        <span class="card-title"><i class="fas fa-table" style="color:#10b981;margin-right:8px"></i>CSV Template</span>
        <button class="btn btn-success btn-sm" onclick="downloadTemplate()">
          <i class="fas fa-download"></i> Download Template
        </button>
      </div>
      <div class="card-body" style="padding:0">
        <div style="overflow-x:auto">
          <table style="width:100%;border-collapse:collapse;font-size:.78rem">
            <thead>
              <tr style="background:#f8fafc">
                <th style="padding:8px 12px;text-align:left;color:#94a3b8;font-weight:700;text-transform:uppercase;font-size:.68rem;border-bottom:1px solid #e2e8f0">Column</th>
                <th style="padding:8px 12px;text-align:left;color:#94a3b8;font-weight:700;text-transform:uppercase;font-size:.68rem;border-bottom:1px solid #e2e8f0">Required</th>
                <th style="padding:8px 12px;text-align:left;color:#94a3b8;font-weight:700;text-transform:uppercase;font-size:.68rem;border-bottom:1px solid #e2e8f0">Example</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $cols = [
                ['name',         true,  'John Doe'],
                ['email',        true,  'john@company.com'],
                ['department',   true,  'Engineering'],
                ['position',     false, 'Senior Developer'],
                ['basic_salary', false, '15000'],
                ['hire_date',    false, '2024-01-15'],
              ];
              foreach ($cols as [$col, $req, $ex]):
              ?>
              <tr style="border-bottom:1px solid #f1f5f9">
                <td style="padding:8px 12px;font-weight:600;color:#0f172a"><?= $col ?></td>
                <td style="padding:8px 12px">
                  <?php if ($req): ?>
                  <span style="background:#fee2e2;color:#dc2626;padding:2px 8px;border-radius:4px;font-size:.7rem;font-weight:700">Required</span>
                  <?php else: ?>
                  <span style="background:#f1f5f9;color:#64748b;padding:2px 8px;border-radius:4px;font-size:.7rem;font-weight:600">Optional</span>
                  <?php endif; ?>
                </td>
                <td style="padding:8px 12px;color:#64748b;font-family:monospace"><?= $ex ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Instructions -->
    <div class="card">
      <div class="card-header">
        <span class="card-title"><i class="fas fa-list-ul" style="color:#f59e0b;margin-right:8px"></i>Instructions</span>
      </div>
      <div class="card-body">
        <ol style="padding-left:1.25rem;font-size:.85rem;color:#374151;line-height:2">
          <li>Download the CSV template above</li>
          <li>Fill in employee data (first row is the header)</li>
          <li>Save as CSV format (UTF-8 encoding)</li>
          <li>Upload the file using the form</li>
          <li>Duplicate emails will be skipped automatically</li>
          <li>All employees get role: <strong>employee</strong></li>
          <li>Default password: <code style="background:#f1f5f9;padding:2px 6px;border-radius:4px">Employee@123</code></li>
        </ol>
      </div>
    </div>

  </div>
</div>

<script>
function updateFileName(input) {
  var fn = document.getElementById('fileName');
  if (input.files.length > 0) {
    fn.textContent = '✓ ' + input.files[0].name;
  }
}

function handleDrop(e) {
  e.preventDefault();
  var zone = document.getElementById('dropZone');
  zone.style.borderColor = '#e2e8f0';
  zone.style.background  = '';
  var files = e.dataTransfer.files;
  if (files.length > 0) {
    document.getElementById('csvFile').files = files;
    updateFileName(document.getElementById('csvFile'));
  }
}

function downloadTemplate() {
  var csv = 'name,email,department,position,basic_salary,hire_date\n';
  csv += 'John Doe,john@company.com,Engineering,Senior Developer,15000,2024-01-15\n';
  csv += 'Jane Smith,jane@company.com,HR,HR Officer,12000,2024-02-01\n';
  csv += 'Bob Johnson,bob@company.com,Finance,Accountant,13500,2024-03-10\n';

  var blob = new Blob([csv], { type: 'text/csv' });
  var url  = URL.createObjectURL(blob);
  var a    = document.createElement('a');
  a.href     = url;
  a.download = 'employee_import_template.csv';
  a.click();
  URL.revokeObjectURL(url);
}
</script>
