<div class="page-header">
  <div>
    <div class="page-header-title">Employee Profile</div>
    <div class="page-header-sub"><?= e($employee['employee_code']) ?></div>
  </div>
  <div class="page-header-actions">
    <?php if (isHR()): ?>
    <a href="<?= url('employees/edit/' . $employee['id']) ?>" class="btn btn-primary">
      <i class="fas fa-edit"></i> Edit
    </a>
    <?php endif; ?>
    <a href="<?= url('employees') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back</a>
  </div>
</div>

<div class="grid-3-1" style="gap:24px">
  <!-- Left: Profile Card -->
  <div style="display:flex;flex-direction:column;gap:20px">

    <!-- Identity Card -->
    <div class="card">
      <div style="background:linear-gradient(135deg,#6366f1,#8b5cf6);height:80px;border-radius:12px 12px 0 0"></div>
      <div style="padding:0 24px 24px;text-align:center;margin-top:-40px">
        <?php
        $evName = $employee['name'] ?? 'E';
        $evId   = (int)($employee['id'] ?? 0);
        if (!empty($employee['avatar'])): ?>
        <img src="<?= e(url($employee['avatar'])) ?>"
             alt="" style="width:80px;height:80px;border-radius:50%;border:4px solid #fff;object-fit:cover;box-shadow:0 2px 12px rgba(0,0,0,.15)">
        <?php else: ?>
        <div style="width:80px;height:80px;border-radius:50%;overflow:hidden;border:4px solid #fff;box-shadow:0 2px 12px rgba(0,0,0,.15);margin:0 auto">
          <?= renderAvatarSvg($evName, $evId, 80) ?>
        </div>
        <?php endif; ?>
        <div style="font-size:1.15rem;font-weight:800;margin-top:10px"><?= e($employee['name']) ?></div>
        <div style="font-size:.82rem;color:#64748b"><?= e($employee['position']) ?></div>
        <div style="margin-top:8px"><?= statusBadge($employee['status']) ?></div>
        <div style="display:flex;justify-content:center;gap:20px;margin-top:16px;padding-top:16px;border-top:1px solid #f1f5f9">
          <div style="text-align:center">
            <div style="font-size:1rem;font-weight:800;color:#6366f1"><?= e($employee['employee_code']) ?></div>
            <div style="font-size:.7rem;color:#94a3b8">Employee ID</div>
          </div>
          <div style="text-align:center">
            <div style="font-size:1rem;font-weight:800;color:#10b981"><?= formatDate($employee['hire_date'], 'M Y') ?></div>
            <div style="font-size:.7rem;color:#94a3b8">Joined</div>
          </div>
          <div style="text-align:center">
            <div style="font-size:1rem;font-weight:800;color:#f59e0b"><?= e($employee['department']) ?></div>
            <div style="font-size:.7rem;color:#94a3b8">Department</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Contact Info -->
    <div class="card">
      <div class="card-header"><span class="card-title"><i class="fas fa-address-card" style="color:#6366f1;margin-right:8px"></i>Contact</span></div>
      <div class="card-body" style="padding:16px">
        <div style="display:flex;flex-direction:column;gap:12px">
          <div style="display:flex;align-items:center;gap:10px">
            <div style="width:32px;height:32px;border-radius:8px;background:#e0e7ff;color:#6366f1;display:flex;align-items:center;justify-content:center;font-size:.8rem;flex-shrink:0"><i class="fas fa-envelope"></i></div>
            <div><div style="font-size:.7rem;color:#94a3b8">Email</div><div style="font-size:.85rem;font-weight:500"><?= e($employee['email']) ?></div></div>
          </div>
          <?php if ($employee['phone']): ?>
          <div style="display:flex;align-items:center;gap:10px">
            <div style="width:32px;height:32px;border-radius:8px;background:#d1fae5;color:#10b981;display:flex;align-items:center;justify-content:center;font-size:.8rem;flex-shrink:0"><i class="fas fa-phone"></i></div>
            <div><div style="font-size:.7rem;color:#94a3b8">Phone</div><div style="font-size:.85rem;font-weight:500"><?= e($employee['phone']) ?></div></div>
          </div>
          <?php endif; ?>
          <?php if ($employee['bank_name']): ?>
          <div style="display:flex;align-items:center;gap:10px">
            <div style="width:32px;height:32px;border-radius:8px;background:#fef3c7;color:#f59e0b;display:flex;align-items:center;justify-content:center;font-size:.8rem;flex-shrink:0"><i class="fas fa-university"></i></div>
            <div><div style="font-size:.7rem;color:#94a3b8">Bank</div><div style="font-size:.85rem;font-weight:500"><?= e($employee['bank_name']) ?> · <?= e($employee['bank_account']) ?></div></div>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Right: Details -->
  <div style="display:flex;flex-direction:column;gap:20px">

    <!-- Salary Structure -->
    <div class="card">
      <div class="card-header"><span class="card-title"><i class="fas fa-dollar-sign" style="color:#10b981;margin-right:8px"></i>Salary Structure</span></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
          <div style="background:linear-gradient(135deg,#6366f1,#8b5cf6);border-radius:12px;padding:16px;color:#fff">
            <div style="font-size:.72rem;opacity:.8">Basic Salary</div>
            <div style="font-size:1.4rem;font-weight:800"><?= formatCurrency((float)$employee['basic_salary']) ?></div>
          </div>
          <div style="background:#f8fafc;border-radius:12px;padding:16px;border:1.5px solid #e2e8f0">
            <div style="font-size:.72rem;color:#64748b">Total Package</div>
            <?php $total = $employee['basic_salary'] + $employee['house_allowance'] + $employee['transport_allowance'] + $employee['medical_allowance']; ?>
            <div style="font-size:1.4rem;font-weight:800;color:#10b981"><?= formatCurrency($total) ?></div>
          </div>
        </div>
        <?php
        $components = [
          ['House Allowance', $employee['house_allowance'], '#e0e7ff', '#6366f1'],
          ['Transport Allowance', $employee['transport_allowance'], '#d1fae5', '#10b981'],
          ['Medical Allowance', $employee['medical_allowance'], '#fef3c7', '#f59e0b'],
          ['Insurance Deduction', $employee['insurance_deduction'], '#fee2e2', '#ef4444'],
        ];
        foreach ($components as [$label, $amount, $bg, $color]):
          if ($amount <= 0) continue;
        ?>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f1f5f9">
          <div style="display:flex;align-items:center;gap:8px">
            <div style="width:8px;height:8px;border-radius:50%;background:<?= $color ?>"></div>
            <span style="font-size:.82rem;color:#64748b"><?= $label ?></span>
          </div>
          <span style="font-size:.85rem;font-weight:600;color:<?= $color ?>"><?= formatCurrency((float)$amount) ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Job Details -->
    <div class="card">
      <div class="card-header"><span class="card-title"><i class="fas fa-briefcase" style="color:#8b5cf6;margin-right:8px"></i>Job Details</span></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
          <?php $details = [
            ['Position', $employee['position'], 'fa-user-tie', '#6366f1'],
            ['Department', $employee['department'], 'fa-building', '#8b5cf6'],
            ['Hire Date', formatDate($employee['hire_date']), 'fa-calendar', '#10b981'],
            ['Status', ucfirst($employee['status']), 'fa-circle', '#f59e0b'],
          ]; ?>
          <?php foreach ($details as [$label, $value, $icon, $color]): ?>
          <div style="background:#f8fafc;border-radius:10px;padding:12px">
            <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
              <i class="fas <?= $icon ?>" style="color:<?= $color ?>;font-size:.75rem"></i>
              <span style="font-size:.7rem;color:#94a3b8;text-transform:uppercase;letter-spacing:.04em"><?= $label ?></span>
            </div>
            <div style="font-size:.9rem;font-weight:700"><?= e($value) ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

  </div>
</div>
