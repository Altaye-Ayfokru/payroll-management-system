<?php
require_once CORE_PATH . '/Controller.php';
require_once APP_PATH . '/helpers/validator.php';
require_once APP_PATH . '/models/User.php';
require_once APP_PATH . '/modules/Employee/EmployeeModel.php';
require_once APP_PATH . '/modules/Employee/EmployeeService.php';

class EmployeeController extends Controller {
    private EmployeeService $service;

    public function __construct() {
        $this->service = new EmployeeService();
    }

    public function index(): void {
        $this->requireRole('admin', 'hr');
        $page   = max(1, (int)($_GET['page'] ?? 1));
        $search = trim($_GET['search'] ?? '');
        $dept   = trim($_GET['dept'] ?? '');

        $result = $this->service->listEmployees($page, $search, $dept);
        $depts  = (new EmployeeModel())->getDepartments();

        $this->view('employees.list', array_merge($result, [
            'departments' => $depts,
            'search'      => $search,
            'dept'        => $dept,
            'pageTitle'   => 'Employees',
            'flash'       => $this->getFlash(),
        ]));
    }

    public function create(): void {
        $this->requireRole('admin', 'hr');
        $this->view('employees.create', [
            'pageTitle' => 'Add Employee',
            'csrf'      => csrfToken(),
        ]);
    }

    public function store(): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) $this->json(['success' => false, 'message' => 'Invalid token'], 403);

        $v = new Validator($_POST);
        $v->required('name')->required('email')->email('email')
          ->required('position')->required('department')
          ->required('basic_salary')->positive('basic_salary')
          ->required('hire_date')->date('hire_date');

        if (!$v->passes()) {
            $this->view('employees.create', [
                'errors' => $v->errors(), 'old' => $_POST,
                'pageTitle' => 'Add Employee', 'csrf' => csrfToken(),
            ]);
            return;
        }

        $result = $this->service->createEmployee($_POST, $_FILES['avatar'] ?? null);

        if (!$result['success']) {
            $this->view('employees.create', [
                'errors' => ['email' => $result['error']], 'old' => $_POST,
                'pageTitle' => 'Add Employee', 'csrf' => csrfToken(),
            ]);
            return;
        }

        logActivity(currentUserId(), "Created employee {$result['code']}");
        $this->flash('success', 'Employee added successfully!');
        $this->redirect('employees');
    }

    public function edit(string $id): void {
        $this->requireRole('admin', 'hr');
        $employee = $this->service->getEmployee((int)$id);
        if (!$employee) { $this->redirect('employees'); return; }

        $this->view('employees.edit', [
            'employee' => $employee, 'pageTitle' => 'Edit Employee', 'csrf' => csrfToken(),
        ]);
    }

    public function update(string $id): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) $this->json(['success' => false, 'message' => 'Invalid token'], 403);

        $v = new Validator($_POST);
        $v->required('name')->required('position')->required('department')
          ->required('basic_salary')->positive('basic_salary');

        if (!$v->passes()) {
            $employee = $this->service->getEmployee((int)$id);
            $this->view('employees.edit', [
                'errors' => $v->errors(), 'employee' => $employee,
                'pageTitle' => 'Edit Employee', 'csrf' => csrfToken(),
            ]);
            return;
        }

        $this->service->updateEmployee((int)$id, $_POST, $_FILES['avatar'] ?? null);
        logActivity(currentUserId(), "Updated employee #{$id}");
        $this->flash('success', 'Employee updated!');
        $this->redirect('employees');
    }

    public function delete(string $id): void {
        $this->requireRole('admin');
        if (!validateCsrf()) $this->json(['success' => false, 'message' => 'Invalid token'], 403);

        $this->service->deleteEmployee((int)$id);
        logActivity(currentUserId(), "Deleted employee #{$id}");

        if ($this->isAjax()) $this->json(['success' => true]);
        $this->flash('success', 'Employee removed.');
        $this->redirect('employees');
    }

    public function profile(string $id): void {
        $this->requireAuth();
        $employee = $this->service->getEmployee((int)$id);
        if (!$employee) { $this->redirect('employees'); return; }

        // Employees can only view their own profile
        if (currentUserRole() === 'employee') {
            $myEmp = (new EmployeeModel())->getByUserId(currentUserId());
            if (!$myEmp || (int)$myEmp['id'] !== (int)$id) {
                $this->redirect('dashboard'); return;
            }
        }

        $this->view('employees.view', ['employee' => $employee, 'pageTitle' => 'Employee Profile']);
    }

    public function search(): void {
        $this->requireRole('admin', 'hr');
        $term = trim($_GET['q'] ?? '');
        $this->json(['data' => (new EmployeeModel())->search($term, 10, 0)]);
    }

    public function importPage(): void {
        $this->requireRole('admin', 'hr');
        $this->view('employees.import', [
            'pageTitle' => 'Import Employees',
            'csrf'      => csrfToken(),
        ]);
    }

    public function import(): void {
        $this->requireRole('admin', 'hr');
        if (!validateCsrf()) { $this->json(['success' => false, 'message' => 'Invalid token'], 403); return; }

        if (empty($_FILES['csv_file']['name'])) {
            $this->flash('error', 'Please select a CSV file.');
            $this->redirect('employees/import');
            return;
        }

        $file = $_FILES['csv_file'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $this->flash('error', 'File upload failed.');
            $this->redirect('employees/import');
            return;
        }

        $handle = fopen($file['tmp_name'], 'r');
        if (!$handle) {
            $this->flash('error', 'Could not read file.');
            $this->redirect('employees/import');
            return;
        }

        $headers = fgetcsv($handle); // skip header row
        $imported = 0;
        $skipped  = 0;
        $errors   = [];

        while (($row = fgetcsv($handle)) !== false) {
            if (count($row) < 6) { $skipped++; continue; }

            [$name, $email, $department, $position, $basicSalary, $hireDate] = $row;
            $name       = trim($name);
            $email      = strtolower(trim($email));
            $department = trim($department);
            $position   = trim($position);
            $basicSalary = (float)str_replace(',', '', $basicSalary);
            $hireDate   = trim($hireDate);

            if (empty($name) || empty($email) || empty($department)) {
                $skipped++;
                continue;
            }

            $result = $this->service->createEmployee([
                'name'             => $name,
                'email'            => $email,
                'department'       => $department,
                'position'         => $position ?: 'Employee',
                'position_title'   => 'Normal Employee',
                'employment_type'  => 'full_time',
                'gender'           => 'male',
                'basic_salary'     => $basicSalary ?: 0,
                'hire_date'        => $hireDate ?: date('Y-m-d'),
                'password'         => 'Employee@123',
            ]);

            if ($result['success']) {
                $imported++;
            } else {
                $errors[] = $email . ': ' . $result['error'];
                $skipped++;
            }
        }
        fclose($handle);

        logActivity(currentUserId(), "Imported {$imported} employees via CSV");
        $msg = "Imported {$imported} employee(s).";
        if ($skipped > 0) $msg .= " Skipped {$skipped}.";
        $this->flash('success', $msg);
        $this->redirect('employees');
    }

    public function export(): void {
        $this->requireRole('admin', 'hr');
        $employees = (new EmployeeModel())->getAllWithUsers(1000, 0);

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="employees_' . date('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Code', 'Name', 'Email', 'Department', 'Position', 'Basic Salary', 'Hire Date', 'Status', 'Employment Type']);
        foreach ($employees as $emp) {
            fputcsv($out, [
                $emp['employee_code'],
                $emp['name'],
                $emp['email'],
                $emp['department'],
                $emp['position'],
                $emp['basic_salary'],
                $emp['hire_date'],
                $emp['status'],
                $emp['employment_type'] ?? 'full_time',
            ]);
        }
        fclose($out);
        exit;
    }
}
