<?php
require_once CORE_PATH . '/Model.php';

class Tax extends Model {
    protected string $table = 'tax_rules';

    public function getActiveTaxRules(): array {
        return $this->query(
            "SELECT * FROM tax_rules WHERE is_active = 1 ORDER BY min_salary ASC"
        );
    }

    public function calculateTax(float $grossSalary): float {
        $rules = $this->getActiveTaxRules();
        $tax = 0.0;

        foreach ($rules as $rule) {
            if ($grossSalary >= $rule['min_salary'] &&
                ($rule['max_salary'] == 0 || $grossSalary <= $rule['max_salary'])) {
                $tax = $grossSalary * ($rule['percentage'] / 100);
                break;
            }
        }

        return round($tax, 2);
    }

    public function getSalaryComponents(): array {
        return $this->query(
            "SELECT * FROM salary_components WHERE is_active = 1 ORDER BY type, name"
        );
    }

    public function getComponentsByType(string $type): array {
        return $this->query(
            "SELECT * FROM salary_components WHERE type = :type AND is_active = 1",
            [':type' => $type]
        );
    }
}
