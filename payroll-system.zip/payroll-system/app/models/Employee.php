<?php
require_once CORE_PATH . '/Model.php';

class Employee extends Model {
    protected string $table = 'employees';

    public function getAllWithUsers(int $limit = ITEMS_PER_PAGE, int $offset = 0): array {
        return $this->query(
            "SELECT e.*, u.name, u.email, u.role, u.avatar
             FROM employees e
             JOIN users u ON u.id = e.user_id
             WHERE e.deleted_at IS NULL
             ORDER BY e.created_at DESC
             LIMIT :limit OFFSET :offset",
            [':limit' => $limit, ':offset' => $offset]
        );
    }

    public function getWithUser(int $id): ?array {
        return $this->queryOne(
            "SELECT e.*, u.name, u.email, u.role, u.avatar, u.phone
             FROM employees e
             JOIN users u ON u.id = e.user_id
             WHERE e.id = :id AND e.deleted_at IS NULL",
            [':id' => $id]
        );
    }

    public function getByUserId(int $userId): ?array {
        return $this->queryOne(
            "SELECT e.*, u.name, u.email, u.avatar
             FROM employees e
             JOIN users u ON u.id = e.user_id
             WHERE e.user_id = :uid AND e.deleted_at IS NULL",
            [':uid' => $userId]
        );
    }

    public function search(string $term, int $limit = ITEMS_PER_PAGE, int $offset = 0): array {
        $like = '%' . $term . '%';
        return $this->query(
            "SELECT e.*, u.name, u.email
             FROM employees e
             JOIN users u ON u.id = e.user_id
             WHERE e.deleted_at IS NULL
               AND (u.name LIKE :term OR u.email LIKE :term2
                    OR e.position LIKE :term3 OR e.department LIKE :term4
                    OR e.employee_code LIKE :term5)
             ORDER BY u.name ASC
             LIMIT :limit OFFSET :offset",
            [
                ':term' => $like, ':term2' => $like, ':term3' => $like,
                ':term4' => $like, ':term5' => $like,
                ':limit' => $limit, ':offset' => $offset
            ]
        );
    }

    public function countActive(): int {
        $stmt = $this->db->query(
            "SELECT COUNT(*) FROM employees WHERE status = 'active' AND deleted_at IS NULL"
        );
        return (int)$stmt->fetchColumn();
    }

    public function countTotal(): int {
        $stmt = $this->db->query(
            "SELECT COUNT(*) FROM employees WHERE deleted_at IS NULL"
        );
        return (int)$stmt->fetchColumn();
    }

    public function getDepartments(): array {
        return $this->query(
            "SELECT DISTINCT department FROM employees WHERE deleted_at IS NULL AND department IS NOT NULL ORDER BY department"
        );
    }

    public function softDelete(int $id): bool {
        return $this->execute(
            "UPDATE employees SET deleted_at = NOW() WHERE id = :id",
            [':id' => $id]
        );
    }

    public function getTotalSalaryBudget(): float {
        $stmt = $this->db->query(
            "SELECT COALESCE(SUM(basic_salary), 0) FROM employees WHERE status = 'active' AND deleted_at IS NULL"
        );
        return (float)$stmt->fetchColumn();
    }
}
