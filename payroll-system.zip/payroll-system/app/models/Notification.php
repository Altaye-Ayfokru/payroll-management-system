<?php
require_once CORE_PATH . '/Model.php';

class Notification extends Model {
    protected string $table = 'notifications';

    public function getForUser(int $userId, int $limit = 20): array {
        return $this->query(
            "SELECT * FROM notifications WHERE user_id = :uid ORDER BY created_at DESC LIMIT :limit",
            [':uid' => $userId, ':limit' => $limit]
        );
    }

    public function getUnreadCount(int $userId): int {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM notifications WHERE user_id = :uid AND is_read = 0"
        );
        $stmt->execute([':uid' => $userId]);
        return (int)$stmt->fetchColumn();
    }

    public function markRead(int $id, int $userId): bool {
        return $this->execute(
            "UPDATE notifications SET is_read = 1 WHERE id = :id AND user_id = :uid",
            [':id' => $id, ':uid' => $userId]
        );
    }

    public function markAllRead(int $userId): bool {
        return $this->execute(
            "UPDATE notifications SET is_read = 1 WHERE user_id = :uid",
            [':uid' => $userId]
        );
    }

    public function send(int $userId, string $message, string $type = 'info'): int {
        return $this->insert([
            'user_id'    => $userId,
            'message'    => $message,
            'type'       => $type,
            'is_read'    => 0,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public function broadcast(array $userIds, string $message, string $type = 'info'): void {
        foreach ($userIds as $uid) {
            $this->send($uid, $message, $type);
        }
    }
}
