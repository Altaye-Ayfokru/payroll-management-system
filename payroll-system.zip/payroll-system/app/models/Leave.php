<?php
require_once CORE_PATH . '/Model.php';

class Leave extends Model {
    protected string $table = 'leaves';

    public function getAllWithEmployees(int $limit = ITEMS_PER_PAGE, int $offset = 0): array {
        return $this->query(
            "SELECT l.*, u.name AS employee_name, e.position, e.department
             FROM leaves l
             JOIN employees e ON e.id = l.employee_id
             JOIN users u ON u.id = e.user_id
             ORDER BY l.created_at DESC
             LIMIT :limit OFFSET :offset",
            [':limit' => $limit, ':offset' => $offset]
        );
    }

    public function getPendingApprovals(): array {
        return $this->query(
            "SELECT l.*, u.name AS employee_name, e.position, e.department
             FROM leaves l
             JOIN employees e ON e.id = l.employee_id
             JOIN users u ON u.id = e.user_id
             WHERE l.status = 'pending'
             ORDER BY l.created_at ASC"
        );
    }

    public function getByEmployee(int $employeeId): array {
        return $this->query(
            "SELECT * FROM leaves WHERE employee_id = :eid ORDER BY created_at DESC",
            [':eid' => $employeeId]
        );
    }

    public function getBalance(int $employeeId, int $year): array {
        return $this->query(
            "SELECT leave_type,
                    SUM(DATEDIFF(end_date, start_date) + 1) AS days_taken
             FROM leaves
             WHERE employee_id = :eid
               AND YEAR(start_date) = :year
               AND status = 'approved'
             GROUP BY leave_type",
            [':eid' => $employeeId, ':year' => $year]
        );
    }

    public function getPendingCount(): int {
        $stmt = $this->db->query("SELECT COUNT(*) FROM leaves WHERE status = 'pending'");
        return (int)$stmt->fetchColumn();
    }

    public function getUpcoming(): array {
        return $this->query(
            "SELECT l.*, u.name AS employee_name
             FROM leaves l
             JOIN employees e ON e.id = l.employee_id
             JOIN users u ON u.id = e.user_id
             WHERE l.status = 'approved' AND l.start_date >= CURDATE()
             ORDER BY l.start_date ASC
             LIMIT 5"
        );
    }
}
