<?php
require_once CORE_PATH . '/Model.php';

class User extends Model {
    protected string $table = 'users';

    public function findByEmail(string $email): ?array {
        return $this->findOneBy('email', $email);
    }

    public function createUser(array $data): int {
        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]);
        $data['created_at'] = date('Y-m-d H:i:s');
        return $this->insert($data);
    }

    public function verifyPassword(string $password, string $hash): bool {
        return password_verify($password, $hash);
    }

    public function updatePassword(int $id, string $newPassword): bool {
        return $this->update($id, [
            'password' => password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12])
        ]);
    }

    public function getAllWithRoles(): array {
        return $this->query(
            "SELECT u.*, e.position, e.department FROM users u
             LEFT JOIN employees e ON e.user_id = u.id
             ORDER BY u.created_at DESC"
        );
    }

    public function generateCsrfToken(): string {
        $token = bin2hex(random_bytes(32));
        $_SESSION['csrf_token'] = $token;
        return $token;
    }
}
