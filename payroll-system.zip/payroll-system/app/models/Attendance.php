<?php
require_once CORE_PATH . '/Model.php';

class Attendance extends Model {
    protected string $table = 'attendance';

    public function getTodayRecord(int $employeeId): ?array {
        return $this->queryOne(
            "SELECT * FROM attendance WHERE employee_id = :eid AND date = CURDATE()",
            [':eid' => $employeeId]
        );
    }

    public function getMonthlyByEmployee(int $employeeId, string $month): array {
        return $this->query(
            "SELECT * FROM attendance WHERE employee_id = :eid AND DATE_FORMAT(date, '%Y-%m') = :month ORDER BY date ASC",
            [':eid' => $employeeId, ':month' => $month]
        );
    }

    public function getAllWithEmployees(string $date = null, int $limit = ITEMS_PER_PAGE, int $offset = 0): array {
        $where = $date ? "AND a.date = :date" : "";
        $params = [':limit' => $limit, ':offset' => $offset];
        if ($date) $params[':date'] = $date;

        return $this->query(
            "SELECT a.*, u.name AS employee_name, e.position, e.department, e.employee_code
             FROM attendance a
             JOIN employees e ON e.id = a.employee_id
             JOIN users u ON u.id = e.user_id
             WHERE 1=1 {$where}
             ORDER BY a.date DESC, a.check_in DESC
             LIMIT :limit OFFSET :offset",
            $params
        );
    }

    public function getMonthlySummary(int $employeeId, string $month): array {
        return $this->queryOne(
            "SELECT
                COUNT(*) AS total_days,
                SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present_days,
                SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) AS absent_days,
                SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) AS late_days,
                COALESCE(SUM(hours_worked), 0) AS total_hours,
                COALESCE(SUM(overtime_hours), 0) AS overtime_hours
             FROM attendance
             WHERE employee_id = :eid AND DATE_FORMAT(date, '%Y-%m') = :month",
            [':eid' => $employeeId, ':month' => $month]
        ) ?? [];
    }

    public function getTodayStats(): array {
        return $this->queryOne(
            "SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present,
                SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) AS absent,
                SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) AS late
             FROM attendance WHERE date = CURDATE()"
        ) ?? ['total' => 0, 'present' => 0, 'absent' => 0, 'late' => 0];
    }

    public function getCalendarData(int $employeeId, string $month): array {
        $records = $this->getMonthlyByEmployee($employeeId, $month);
        $calendar = [];
        foreach ($records as $r) {
            $calendar[$r['date']] = $r;
        }
        return $calendar;
    }
}
