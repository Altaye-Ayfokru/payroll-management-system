<?php
require_once CORE_PATH . '/Model.php';

class Payroll extends Model {
    protected string $table = 'payroll';

    public function getWithEmployee(int $limit = ITEMS_PER_PAGE, int $offset = 0): array {
        return $this->query(
            "SELECT p.*, u.name AS employee_name, e.position, e.department, e.employee_code
             FROM payroll p
             JOIN employees e ON e.id = p.employee_id
             JOIN users u ON u.id = e.user_id
             ORDER BY p.created_at DESC
             LIMIT :limit OFFSET :offset",
            [':limit' => $limit, ':offset' => $offset]
        );
    }

    public function getByEmployeeAndMonth(int $employeeId, string $month): ?array {
        return $this->queryOne(
            "SELECT * FROM payroll WHERE employee_id = :eid AND pay_month = :month",
            [':eid' => $employeeId, ':month' => $month]
        );
    }

    public function getByMonth(string $month): array {
        return $this->query(
            "SELECT p.*, u.name AS employee_name, e.position, e.department
             FROM payroll p
             JOIN employees e ON e.id = p.employee_id
             JOIN users u ON u.id = e.user_id
             WHERE p.pay_month = :month
             ORDER BY u.name ASC",
            [':month' => $month]
        );
    }

    public function getPayslip(int $id): ?array {
        return $this->queryOne(
            "SELECT p.*, u.name AS employee_name, u.email, u.avatar,
                    e.position, e.department, e.employee_code, e.bank_account, e.bank_name
             FROM payroll p
             JOIN employees e ON e.id = p.employee_id
             JOIN users u ON u.id = e.user_id
             WHERE p.id = :id",
            [':id' => $id]
        );
    }

    public function getTotalPayrollByMonth(string $month): float {
        $stmt = $this->db->prepare(
            "SELECT COALESCE(SUM(net_salary), 0) FROM payroll WHERE pay_month = :month AND status = 'approved'"
        );
        $stmt->execute([':month' => $month]);
        return (float)$stmt->fetchColumn();
    }

    public function getPendingCount(): int {
        $stmt = $this->db->query(
            "SELECT COUNT(*) FROM payroll WHERE status = 'pending'"
        );
        return (int)$stmt->fetchColumn();
    }

    public function getMonthlyTrend(int $months = 6): array {
        return $this->query(
            "SELECT pay_month, SUM(net_salary) AS total, COUNT(*) AS count
             FROM payroll
             WHERE status = 'approved'
               AND pay_month >= DATE_FORMAT(DATE_SUB(NOW(), INTERVAL :months MONTH), '%Y-%m')
             GROUP BY pay_month
             ORDER BY pay_month ASC",
            [':months' => $months]
        );
    }

    public function getByEmployee(int $employeeId): array {
        return $this->query(
            "SELECT * FROM payroll WHERE employee_id = :eid ORDER BY pay_month DESC",
            [':eid' => $employeeId]
        );
    }
}
