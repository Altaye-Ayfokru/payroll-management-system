<?php
require_once APP_PATH . '/models/Payroll.php';
require_once APP_PATH . '/models/Employee.php';
require_once APP_PATH . '/models/Attendance.php';
require_once APP_PATH . '/services/TaxService.php';
require_once APP_PATH . '/services/NotificationService.php';

class PayrollService {
    private Payroll $payrollModel;
    private Employee $employeeModel;
    private Attendance $attendanceModel;
    private TaxService $taxService;
    private NotificationService $notificationService;

    public function __construct() {
        $this->payrollModel        = new Payroll();
        $this->employeeModel       = new Employee();
        $this->attendanceModel     = new Attendance();
        $this->taxService          = new TaxService();
        $this->notificationService = new NotificationService();
    }

    /**
     * Run payroll for all active employees for a given month
     */
    public function runMonthlyPayroll(string $month, int $processedBy): array {
        $employees = $this->employeeModel->findBy('status', 'active');
        $results   = ['success' => [], 'skipped' => [], 'errors' => []];

        foreach ($employees as $emp) {
            // Skip if already processed
            if ($this->payrollModel->getByEmployeeAndMonth($emp['id'], $month)) {
                $results['skipped'][] = $emp['id'];
                continue;
            }

            try {
                $payrollId = $this->calculateAndSave($emp, $month, $processedBy);
                $results['success'][] = $payrollId;

                // Notify employee
                $this->notificationService->notifyPayrollProcessed($emp['user_id'], $month);
            } catch (Exception $e) {
                Logger::error("Payroll error for emp {$emp['id']}: " . $e->getMessage());
                $results['errors'][] = ['employee_id' => $emp['id'], 'error' => $e->getMessage()];
            }
        }

        return $results;
    }

    /**
     * Calculate payroll for a single employee
     */
    public function calculateAndSave(array $employee, string $month, int $processedBy): int {
        $basicSalary = (float)$employee['basic_salary'];

        // Get attendance summary for the month
        $attendance = $this->attendanceModel->getMonthlySummary($employee['id'], $month);
        $workedDays = (int)($attendance['present_days'] ?? 0);
        $totalDays  = $this->getWorkingDaysInMonth($month);

        // Pro-rate salary based on attendance
        $effectiveSalary = $totalDays > 0
            ? ($basicSalary / $totalDays) * $workedDays
            : $basicSalary;

        // Allowances
        $houseAllowance    = (float)($employee['house_allowance'] ?? 0);
        $transportAllowance = (float)($employee['transport_allowance'] ?? 0);
        $medicalAllowance  = (float)($employee['medical_allowance'] ?? 0);

        // Overtime
        $overtimeHours = (float)($attendance['overtime_hours'] ?? 0);
        $overtimeRate  = $basicSalary / (22 * 8); // hourly rate
        $overtimePay   = round($overtimeHours * $overtimeRate * 1.5, 2);

        // Gross salary
        $grossSalary = $effectiveSalary + $houseAllowance + $transportAllowance
                     + $medicalAllowance + $overtimePay;

        // Deductions
        $providentFund = round($basicSalary * 0.05, 2); // 5% PF
        $insurance     = (float)($employee['insurance_deduction'] ?? 0);
        $otherDeductions = (float)($employee['other_deductions'] ?? 0);

        // Tax
        $tax = $this->taxService->calculate($grossSalary);

        $totalDeductions = $providentFund + $insurance + $otherDeductions + $tax;
        $netSalary       = round($grossSalary - $totalDeductions, 2);

        return $this->payrollModel->insert([
            'employee_id'         => $employee['id'],
            'pay_month'           => $month,
            'basic_salary'        => round($basicSalary, 2),
            'house_allowance'     => $houseAllowance,
            'transport_allowance' => $transportAllowance,
            'medical_allowance'   => $medicalAllowance,
            'overtime_pay'        => $overtimePay,
            'gross_salary'        => round($grossSalary, 2),
            'provident_fund'      => $providentFund,
            'insurance'           => $insurance,
            'other_deductions'    => $otherDeductions,
            'tax'                 => $tax,
            'total_deductions'    => round($totalDeductions, 2),
            'net_salary'          => $netSalary,
            'worked_days'         => $workedDays,
            'total_days'          => $totalDays,
            'overtime_hours'      => $overtimeHours,
            'status'              => 'pending',
            'processed_by'        => $processedBy,
            'created_at'          => date('Y-m-d H:i:s'),
        ]);
    }

    private function getWorkingDaysInMonth(string $month): int {
        $date  = new DateTime($month . '-01');
        $days  = (int)$date->format('t');
        $count = 0;
        for ($d = 1; $d <= $days; $d++) {
            $day = (int)(new DateTime($month . '-' . str_pad($d, 2, '0', STR_PAD_LEFT)))->format('N');
            if ($day < 6) $count++; // Mon-Fri
        }
        return $count;
    }
}
