<?php
require_once APP_PATH . '/models/Notification.php';

class NotificationService {
    private Notification $model;

    public function __construct() {
        $this->model = new Notification();
    }

    public function notifyPayrollProcessed(int $userId, string $month): void {
        $this->model->send(
            $userId,
            "Your payroll for {$month} has been processed and is pending approval.",
            'payroll'
        );
    }

    public function notifyPayrollApproved(int $userId, string $month): void {
        $this->model->send(
            $userId,
            "Your payroll for {$month} has been approved. Salary will be credited shortly.",
            'success'
        );
    }

    public function notifyLeaveApproved(int $userId, string $leaveType, string $dates): void {
        $this->model->send(
            $userId,
            "Your {$leaveType} leave request ({$dates}) has been approved.",
            'success'
        );
    }

    public function notifyLeaveRejected(int $userId, string $leaveType, string $reason = ''): void {
        $msg = "Your {$leaveType} leave request has been rejected.";
        if ($reason) $msg .= " Reason: {$reason}";
        $this->model->send($userId, $msg, 'warning');
    }

    public function notifyAdmins(string $message, string $type = 'info'): void {
        $db   = Database::getInstance();
        $stmt = $db->query("SELECT id FROM users WHERE role IN ('admin', 'hr')");
        $ids  = array_column($stmt->fetchAll(), 'id');
        $this->model->broadcast($ids, $message, $type);
    }
}
