<?php
require_once APP_PATH . '/models/Tax.php';

class TaxService {
    private Tax $taxModel;

    public function __construct() {
        $this->taxModel = new Tax();
    }

    public function calculate(float $grossSalary): float {
        return $this->taxModel->calculateTax($grossSalary);
    }

    public function getEffectiveRate(float $grossSalary): float {
        $tax = $this->calculate($grossSalary);
        return $grossSalary > 0 ? round(($tax / $grossSalary) * 100, 2) : 0;
    }
}
