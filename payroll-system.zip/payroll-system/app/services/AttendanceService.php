<?php
require_once APP_PATH . '/models/Attendance.php';

class AttendanceService {
    private Attendance $model;

    public function __construct() {
        $this->model = new Attendance();
    }

    public function checkIn(int $employeeId): array {
        $today = $this->model->getTodayRecord($employeeId);
        if ($today) {
            return ['success' => false, 'message' => 'Already checked in today'];
        }

        $now       = date('H:i:s');
        $lateTime  = '09:15:00';
        $status    = $now > $lateTime ? 'late' : 'present';

        $id = $this->model->insert([
            'employee_id' => $employeeId,
            'date'        => date('Y-m-d'),
            'check_in'    => $now,
            'status'      => $status,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        return ['success' => true, 'id' => $id, 'status' => $status, 'check_in' => $now];
    }

    public function checkOut(int $employeeId): array {
        $today = $this->model->getTodayRecord($employeeId);
        if (!$today) {
            return ['success' => false, 'message' => 'No check-in record found'];
        }
        if ($today['check_out']) {
            return ['success' => false, 'message' => 'Already checked out'];
        }

        $now          = date('H:i:s');
        $checkIn      = new DateTime($today['check_in']);
        $checkOut     = new DateTime($now);
        $diff         = $checkIn->diff($checkOut);
        $hoursWorked  = round($diff->h + ($diff->i / 60), 2);
        $standardHours = 8.0;
        $overtime     = max(0, round($hoursWorked - $standardHours, 2));

        $this->model->update($today['id'], [
            'check_out'      => $now,
            'hours_worked'   => $hoursWorked,
            'overtime_hours' => $overtime,
        ]);

        return [
            'success'      => true,
            'check_out'    => $now,
            'hours_worked' => $hoursWorked,
            'overtime'     => $overtime,
        ];
    }
}
