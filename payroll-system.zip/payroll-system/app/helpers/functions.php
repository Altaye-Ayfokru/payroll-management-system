<?php
/**
 * PayrollPro — Global Helper Functions
 */

function url(string $path = ''): string {
    return BASE_URL . '/' . ltrim($path, '/');
}

function asset(string $path): string {
    return BASE_URL . '/assets/' . ltrim($path, '/');
}

function e(mixed $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function formatCurrency(float $amount, string $symbol = '$'): string {
    return $symbol . number_format($amount, 2);
}

function formatDate(string $date, string $format = 'M d, Y'): string {
    if (empty($date) || $date === '0000-00-00') return '—';
    return date($format, strtotime($date));
}

function timeAgo(string $datetime): string {
    if (empty($datetime)) return '—';
    $time = time() - strtotime($datetime);
    if ($time < 60)     return 'just now';
    if ($time < 3600)   return floor($time / 60) . 'm ago';
    if ($time < 86400)  return floor($time / 3600) . 'h ago';
    if ($time < 604800) return floor($time / 86400) . 'd ago';
    return date('M d', strtotime($datetime));
}

function csrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrfField(): string {
    return '<input type="hidden" name="csrf_token" value="' . csrfToken() . '">';
}

function validateCsrf(): bool {
    $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    return hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function isAdmin(): bool {
    return ($_SESSION['user_role'] ?? '') === 'admin';
}

function isHR(): bool {
    return in_array($_SESSION['user_role'] ?? '', ['admin', 'hr']);
}

function currentUserId(): int {
    return (int)($_SESSION['user_id'] ?? 0);
}

function currentUserRole(): string {
    return $_SESSION['user_role'] ?? '';
}

function paginate(int $total, int $perPage, int $currentPage): array {
    $totalPages = max(1, (int)ceil($total / $perPage));
    return [
        'total'        => $total,
        'per_page'     => $perPage,
        'current_page' => $currentPage,
        'total_pages'  => $totalPages,
        'offset'       => ($currentPage - 1) * $perPage,
        'has_prev'     => $currentPage > 1,
        'has_next'     => $currentPage < $totalPages,
    ];
}

function statusBadge(string $status): string {
    $map = [
        'active'     => ['badge-success',   'check-circle'],
        'inactive'   => ['badge-danger',    'times-circle'],
        'terminated' => ['badge-danger',    'ban'],
        'pending'    => ['badge-warning',   'clock'],
        'approved'   => ['badge-success',   'check-circle'],
        'rejected'   => ['badge-danger',    'times-circle'],
        'paid'       => ['badge-info',      'money-bill'],
        'present'    => ['badge-success',   'user-check'],
        'absent'     => ['badge-danger',    'user-times'],
        'late'       => ['badge-warning',   'clock'],
        'half_day'   => ['badge-info',      'adjust'],
        'holiday'    => ['badge-secondary', 'umbrella-beach'],
        'cancelled'  => ['badge-secondary', 'ban'],
    ];
    [$class, $icon] = $map[strtolower($status)] ?? ['badge-secondary', 'circle'];
    return '<span class="badge ' . $class . '"><i class="fas fa-' . $icon . '"></i> '
         . ucfirst(str_replace('_', ' ', $status)) . '</span>';
}

function uploadFile(array $file, string $subDir = 'avatars'): ?string {
    if ($file['error'] !== UPLOAD_ERR_OK) return null;
    if ($file['size'] > MAX_UPLOAD_SIZE)  return null;
    if (!in_array($file['type'], ALLOWED_IMAGE_TYPES)) return null;

    $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = uniqid('', true) . '.' . $ext;
    $dir      = UPLOAD_PATH . '/' . $subDir;

    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $dest = $dir . '/' . $filename;
    if (move_uploaded_file($file['tmp_name'], $dest)) {
        return 'uploads/' . $subDir . '/' . $filename;
    }
    return null;
}

function logActivity(int $userId, string $action): void {
    try {
        $db   = Database::getInstance();
        $stmt = $db->prepare(
            "INSERT INTO activity_logs (user_id, action, ip_address, created_at)
             VALUES (:uid, :action, :ip, NOW())"
        );
        $stmt->execute([
            ':uid'    => $userId,
            ':action' => $action,
            ':ip'     => $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
        ]);
    } catch (Exception $e) {
        // Silently fail — logging must never break the app
    }
}
