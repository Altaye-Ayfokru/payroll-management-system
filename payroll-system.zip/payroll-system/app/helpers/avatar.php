<?php
/**
 * PayrollPro — Avatar Helper
 * Assigns colorful SVG avatars to employees based on their name/ID
 */

/**
 * Get avatar URL for an employee.
 * Uses uploaded avatar if available, otherwise assigns a colorful SVG.
 */
function getAvatarUrl(?string $uploadedAvatar, string $name = '', int $id = 0): string {
    // Use uploaded avatar if it exists
    if (!empty($uploadedAvatar)) {
        $path = STORAGE_PATH . '/uploads/' . ltrim($uploadedAvatar, '/');
        if (file_exists($path)) {
            return url($uploadedAvatar);
        }
    }

    // Assign one of 7 colorful SVG avatars based on name hash
    $avatarCount = 7;
    $index = ($id > 0)
        ? (($id - 1) % $avatarCount) + 1
        : (abs(crc32($name)) % $avatarCount) + 1;

    return asset("images/avatar-{$index}.svg");
}

/**
 * Get initials from a name (max 2 chars)
 */
function getInitials(string $name): string {
    $parts = array_filter(explode(' ', trim($name)));
    if (count($parts) >= 2) {
        return strtoupper(substr($parts[0], 0, 1) . substr(end($parts), 0, 1));
    }
    return strtoupper(substr($name, 0, 2));
}

/**
 * Get a gradient color pair based on name/id for inline avatar backgrounds
 */
function getAvatarGradient(string $name = '', int $id = 0): array {
    $gradients = [
        ['#6366f1', '#8b5cf6'],  // indigo-purple
        ['#10b981', '#059669'],  // emerald
        ['#f59e0b', '#d97706'],  // amber
        ['#3b82f6', '#2563eb'],  // blue
        ['#ec4899', '#db2777'],  // pink
        ['#14b8a6', '#0d9488'],  // teal
        ['#ef4444', '#dc2626'],  // red
        ['#8b5cf6', '#7c3aed'],  // violet
        ['#f97316', '#ea580c'],  // orange
    ];

    $index = ($id > 0)
        ? (($id - 1) % count($gradients))
        : (abs(crc32($name)) % count($gradients));

    return $gradients[$index];
}

/**
 * Render an inline SVG avatar with initials
 */
function renderAvatarSvg(string $name, int $id = 0, int $size = 36): string {
    $initials  = getInitials($name);
    [$c1, $c2] = getAvatarGradient($name, $id);
    $gradId    = 'ag' . abs(crc32($name . $id));
    $fontSize  = (int)($size * 0.38);

    return '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 ' . $size . ' ' . $size . '">'
         . '<defs><linearGradient id="' . $gradId . '" x1="0" y1="0" x2="1" y2="1">'
         . '<stop offset="0%" stop-color="' . $c1 . '"/>'
         . '<stop offset="100%" stop-color="' . $c2 . '"/>'
         . '</linearGradient></defs>'
         . '<circle cx="' . ($size/2) . '" cy="' . ($size/2) . '" r="' . ($size/2) . '" fill="url(#' . $gradId . ')"/>'
         . '<text x="' . ($size/2) . '" y="' . ($size/2 + $fontSize*0.38) . '" text-anchor="middle" font-size="' . $fontSize . '" font-weight="700" font-family="Inter,sans-serif" fill="white">'
         . htmlspecialchars($initials, ENT_QUOTES, 'UTF-8')
         . '</text>'
         . '</svg>';
}
