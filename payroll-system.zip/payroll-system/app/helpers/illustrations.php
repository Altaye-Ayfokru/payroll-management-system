<?php
/**
 * PayrollPro — Illustration Helper
 * Animated SVG people scenes for HR & Payroll system
 */

/**
 * Returns the animated people scene SVG for the login page left panel
 */
function loginIllustration(): string {
    return <<<'SVG'
<style>
@keyframes pFloat1{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
@keyframes pFloat2{0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
@keyframes pFloat3{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
@keyframes mFloat{0%,100%{transform:translateY(0) rotate(-4deg)}50%{transform:translateY(-14px) rotate(4deg)}}
@keyframes cGrow{from{transform:scaleY(0);transform-origin:bottom}to{transform:scaleY(1);transform-origin:bottom}}
@keyframes cPop{0%{transform:scale(0)}70%{transform:scale(1.2)}100%{transform:scale(1)}}
@keyframes nPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.12)}}
@keyframes dSlide{from{opacity:0;transform:translateX(16px)}to{opacity:1;transform:translateX(0)}}
@keyframes spark{0%,100%{opacity:0;transform:scale(0) rotate(0deg)}50%{opacity:1;transform:scale(1) rotate(180deg)}}
.il-p1{animation:pFloat1 3.5s ease-in-out infinite}
.il-p2{animation:pFloat2 4s ease-in-out infinite .5s}
.il-p3{animation:pFloat3 3s ease-in-out infinite 1s}
.il-c1{animation:mFloat 3s ease-in-out infinite}
.il-c2{animation:mFloat 4s ease-in-out infinite .8s}
.il-c3{animation:mFloat 3.5s ease-in-out infinite 1.5s}
.il-chk{animation:cPop .6s cubic-bezier(.34,1.56,.64,1) 1.2s both}
.il-ntf{animation:nPulse 2s ease-in-out infinite}
.il-b1{animation:cGrow 1s ease .3s both}
.il-b2{animation:cGrow 1s ease .5s both}
.il-b3{animation:cGrow 1s ease .7s both}
.il-b4{animation:cGrow 1s ease .9s both}
.il-d1{animation:dSlide .8s ease .4s both}
.il-d2{animation:dSlide .8s ease .7s both}
.il-s1{animation:spark 2s ease-in-out infinite}
.il-s2{animation:spark 2s ease-in-out infinite .7s}
.il-s3{animation:spark 2s ease-in-out infinite 1.4s}
</style>
<svg viewBox="0 0 460 270" fill="none" xmlns="http://www.w3.org/2000/svg"
     style="width:100%;max-width:460px;filter:drop-shadow(0 16px 32px rgba(0,0,0,.25))">
  <defs>
    <filter id="il-sh"><feDropShadow dx="0" dy="3" stdDeviation="6" flood-color="rgba(0,0,0,.18)"/></filter>
  </defs>

  <!-- Ground shadow -->
  <ellipse cx="230" cy="262" rx="190" ry="10" fill="rgba(0,0,0,.12)"/>

  <!-- ── PERSON 1: HR Manager — dark skin, purple blazer ── -->
  <g class="il-p1" transform="translate(18,55)">
    <!-- Legs -->
    <rect x="26" y="126" width="15" height="40" rx="6" fill="#4c1d95"/>
    <rect x="44" y="126" width="15" height="40" rx="6" fill="#4c1d95"/>
    <!-- Shoes -->
    <ellipse cx="33" cy="168" rx="12" ry="5" fill="#1a0a00"/>
    <ellipse cx="51" cy="168" rx="12" ry="5" fill="#1a0a00"/>
    <!-- Body -->
    <rect x="18" y="70" width="50" height="60" rx="10" fill="#7c3aed"/>
    <rect x="28" y="70" width="30" height="28" rx="4" fill="#6d28d9"/>
    <!-- Collar -->
    <polygon points="43,70 36,83 43,78 50,83" fill="white" opacity=".9"/>
    <!-- ID badge -->
    <rect x="33" y="86" width="20" height="26" rx="3" fill="white" opacity=".92"/>
    <rect x="36" y="89" width="14" height="4" rx="2" fill="#6366f1"/>
    <circle cx="43" cy="99" r="4" fill="#e0e7ff"/>
    <rect x="36" y="105" width="14" height="2" rx="1" fill="#94a3b8"/>
    <line x1="43" y1="78" x2="43" y2="86" stroke="white" stroke-width="1.5" opacity=".7"/>
    <!-- Arms -->
    <rect x="-2" y="76" width="22" height="11" rx="5" fill="#7c3aed"/>
    <rect x="66" y="76" width="22" height="11" rx="5" fill="#7c3aed"/>
    <!-- Hands -->
    <ellipse cx="8" cy="87" rx="7" ry="5" fill="#c68642"/>
    <ellipse cx="78" cy="87" rx="7" ry="5" fill="#c68642"/>
    <!-- Neck -->
    <rect x="38" y="56" width="10" height="17" rx="5" fill="#c68642"/>
    <!-- Head -->
    <circle cx="43" cy="45" r="21" fill="#c68642"/>
    <!-- Afro hair -->
    <ellipse cx="43" cy="28" rx="23" ry="17" fill="#1a0a00"/>
    <ellipse cx="43" cy="25" rx="19" ry="13" fill="#2d1200"/>
    <circle cx="23" cy="36" r="9" fill="#1a0a00"/>
    <circle cx="63" cy="36" r="9" fill="#1a0a00"/>
    <!-- Eyes -->
    <circle cx="36" cy="45" r="3.5" fill="white"/>
    <circle cx="50" cy="45" r="3.5" fill="white"/>
    <circle cx="37" cy="46" r="2" fill="#1a0a00"/>
    <circle cx="51" cy="46" r="2" fill="#1a0a00"/>
    <!-- Smile -->
    <path d="M36 54 Q43 60 50 54" stroke="#8b4513" stroke-width="1.5" fill="none" stroke-linecap="round"/>
    <!-- Earrings -->
    <circle cx="22" cy="49" r="3" fill="#fbbf24"/>
    <circle cx="64" cy="49" r="3" fill="#fbbf24"/>
  </g>

  <!-- ── PERSON 2: CEO — light skin, dark suit, holding tablet ── -->
  <g class="il-p2" transform="translate(158,15)">
    <!-- Legs -->
    <rect x="42" y="148" width="19" height="50" rx="7" fill="#1e293b"/>
    <rect x="64" y="148" width="19" height="50" rx="7" fill="#1e293b"/>
    <!-- Shoes -->
    <ellipse cx="51" cy="200" rx="15" ry="6" fill="#0f172a"/>
    <ellipse cx="73" cy="200" rx="15" ry="6" fill="#0f172a"/>
    <!-- Suit body -->
    <rect x="26" y="80" width="72" height="72" rx="12" fill="#1e293b"/>
    <!-- Shirt -->
    <rect x="50" y="80" width="24" height="38" rx="4" fill="white"/>
    <!-- Tie -->
    <polygon points="62,82 57,98 62,128 67,98" fill="#6366f1"/>
    <polygon points="59,82 65,82 62,88" fill="#4f46e5"/>
    <!-- Lapels -->
    <polygon points="26,80 50,80 38,108" fill="#0f172a"/>
    <polygon points="98,80 74,80 86,108" fill="#0f172a"/>
    <!-- Pocket square -->
    <polygon points="30,88 40,88 36,80" fill="white" opacity=".8"/>
    <!-- Arms -->
    <rect x="-2" y="86" width="30" height="13" rx="6" fill="#1e293b"/>
    <rect x="96" y="86" width="30" height="13" rx="6" fill="#1e293b"/>
    <!-- Hands -->
    <ellipse cx="12" cy="99" rx="9" ry="6" fill="#f5cba7"/>
    <ellipse cx="112" cy="99" rx="9" ry="6" fill="#f5cba7"/>
    <!-- Tablet -->
    <rect x="18" y="94" width="88" height="56" rx="8" fill="#0f172a" filter="url(#il-sh)"/>
    <rect x="22" y="98" width="80" height="48" rx="6" fill="#1e293b"/>
    <!-- Tablet content -->
    <rect x="26" y="102" width="48" height="6" rx="3" fill="#6366f1"/>
    <rect x="26" y="112" width="32" height="3" rx="1.5" fill="#475569"/>
    <!-- Mini chart bars on tablet -->
    <rect x="26" y="120" width="7" height="16" rx="2" fill="#10b981" class="il-b1"/>
    <rect x="35" y="116" width="7" height="20" rx="2" fill="#6366f1" class="il-b2"/>
    <rect x="44" y="112" width="7" height="24" rx="2" fill="#8b5cf6" class="il-b3"/>
    <rect x="53" y="118" width="7" height="18" rx="2" fill="#f59e0b" class="il-b4"/>
    <!-- Salary on tablet -->
    <rect x="66" y="120" width="30" height="8" rx="4" fill="#10b981"/>
    <rect x="66" y="132" width="22" height="3" rx="1.5" fill="#475569"/>
    <!-- Home button -->
    <circle cx="62" cy="150" r="3" fill="#334155"/>
    <!-- Neck -->
    <rect x="56" y="64" width="12" height="20" rx="6" fill="#f5cba7"/>
    <!-- Head -->
    <circle cx="62" cy="50" r="25" fill="#f5cba7"/>
    <!-- Hair -->
    <ellipse cx="62" cy="29" rx="25" ry="15" fill="#5c3317"/>
    <ellipse cx="62" cy="27" rx="21" ry="11" fill="#7b4a2d"/>
    <!-- Ears -->
    <ellipse cx="37" cy="50" rx="5" ry="7" fill="#f5cba7"/>
    <ellipse cx="87" cy="50" rx="5" ry="7" fill="#f5cba7"/>
    <!-- Eyes -->
    <circle cx="54" cy="50" r="4" fill="white"/>
    <circle cx="70" cy="50" r="4" fill="white"/>
    <circle cx="55" cy="51" r="2.5" fill="#3d2b1f"/>
    <circle cx="71" cy="51" r="2.5" fill="#3d2b1f"/>
    <!-- Eyebrows -->
    <path d="M50 44 Q54 41 58 44" stroke="#5c3317" stroke-width="1.8" fill="none" stroke-linecap="round"/>
    <path d="M66 44 Q70 41 74 44" stroke="#5c3317" stroke-width="1.8" fill="none" stroke-linecap="round"/>
    <!-- Smile -->
    <path d="M54 60 Q62 67 70 60" stroke="#c0845a" stroke-width="1.5" fill="none" stroke-linecap="round"/>
  </g>

  <!-- ── PERSON 3: Employee — medium skin, blue blouse, payslip ── -->
  <g class="il-p3" transform="translate(328,65)">
    <!-- Legs -->
    <rect x="22" y="126" width="15" height="42" rx="6" fill="#0369a1"/>
    <rect x="40" y="126" width="15" height="42" rx="6" fill="#0369a1"/>
    <!-- Shoes -->
    <ellipse cx="29" cy="170" rx="12" ry="5" fill="#1e3a5f"/>
    <ellipse cx="47" cy="170" rx="12" ry="5" fill="#1e3a5f"/>
    <!-- Body -->
    <rect x="12" y="70" width="52" height="60" rx="10" fill="#0ea5e9"/>
    <path d="M38,70 L30,84 L38,78 L46,84 Z" fill="white" opacity=".8"/>
    <!-- Arms -->
    <rect x="-10" y="76" width="24" height="11" rx="5" fill="#0ea5e9"/>
    <rect x="62" y="76" width="24" height="11" rx="5" fill="#0ea5e9"/>
    <!-- Hands -->
    <ellipse cx="2" cy="87" rx="7" ry="5" fill="#d4956a"/>
    <ellipse cx="74" cy="87" rx="7" ry="5" fill="#d4956a"/>
    <!-- Payslip in left hand -->
    <rect x="-16" y="84" width="34" height="46" rx="4" fill="white" opacity=".95" filter="url(#il-sh)"/>
    <rect x="-12" y="88" width="26" height="5" rx="2.5" fill="#6366f1"/>
    <rect x="-12" y="96" width="18" height="3" rx="1.5" fill="#94a3b8"/>
    <rect x="-12" y="102" width="22" height="3" rx="1.5" fill="#94a3b8"/>
    <rect x="-12" y="108" width="14" height="3" rx="1.5" fill="#94a3b8"/>
    <line x1="-12" y1="114" x2="18" y2="114" stroke="#e2e8f0" stroke-width="1" stroke-dasharray="3 2"/>
    <rect x="-12" y="118" width="26" height="6" rx="3" fill="#10b981"/>
    <!-- Check badge on payslip -->
    <g class="il-chk">
      <circle cx="26" cy="88" r="8" fill="#10b981"/>
      <path d="M22 88 L25 91 L30 85" stroke="white" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
    </g>
    <!-- Neck -->
    <rect x="33" y="56" width="10" height="17" rx="5" fill="#d4956a"/>
    <!-- Head -->
    <circle cx="38" cy="44" r="21" fill="#d4956a"/>
    <!-- Long dark hair -->
    <ellipse cx="38" cy="27" rx="21" ry="15" fill="#1a0a00"/>
    <rect x="17" y="27" width="7" height="48" rx="3.5" fill="#1a0a00"/>
    <rect x="52" y="27" width="7" height="48" rx="3.5" fill="#1a0a00"/>
    <ellipse cx="38" cy="23" rx="17" ry="11" fill="#2d1200"/>
    <!-- Eyes -->
    <circle cx="31" cy="44" r="3.5" fill="white"/>
    <circle cx="45" cy="44" r="3.5" fill="white"/>
    <circle cx="32" cy="45" r="2" fill="#1a0a00"/>
    <circle cx="46" cy="45" r="2" fill="#1a0a00"/>
    <!-- Eyelashes -->
    <path d="M28 41 L31 39 L34 41" stroke="#1a0a00" stroke-width="1" fill="none"/>
    <path d="M42 41 L45 39 L48 41" stroke="#1a0a00" stroke-width="1" fill="none"/>
    <!-- Smile -->
    <path d="M31 53 Q38 59 45 53" stroke="#a0522d" stroke-width="1.5" fill="none" stroke-linecap="round"/>
  </g>

  <!-- ── FLOATING COINS ── -->
  <g class="il-c1" transform="translate(8,22)">
    <circle cx="18" cy="18" r="16" fill="#f59e0b" stroke="#fbbf24" stroke-width="2"/>
    <circle cx="18" cy="18" r="11" fill="#fbbf24"/>
    <text x="18" y="23" text-anchor="middle" font-size="12" font-weight="bold" fill="#78350f" font-family="Arial,sans-serif">$</text>
  </g>
  <g class="il-c2" transform="translate(408,14)">
    <circle cx="16" cy="16" r="14" fill="#10b981" stroke="#34d399" stroke-width="2"/>
    <circle cx="16" cy="16" r="9" fill="#34d399"/>
    <text x="16" y="21" text-anchor="middle" font-size="10" font-weight="bold" fill="#064e3b" font-family="Arial,sans-serif">$</text>
  </g>
  <g class="il-c3" transform="translate(428,118)">
    <circle cx="13" cy="13" r="11" fill="#8b5cf6" stroke="#a78bfa" stroke-width="2"/>
    <circle cx="13" cy="13" r="7" fill="#a78bfa"/>
    <text x="13" y="17" text-anchor="middle" font-size="8" font-weight="bold" fill="#2e1065" font-family="Arial,sans-serif">$</text>
  </g>

  <!-- ── SPARKLES ── -->
  <g class="il-s1" transform="translate(132,10)">
    <path d="M7 0L8.5 5.5L14 7L8.5 8.5L7 14L5.5 8.5L0 7L5.5 5.5Z" fill="#fbbf24"/>
  </g>
  <g class="il-s2" transform="translate(368,42)">
    <path d="M5 0L6 4L10 5L6 6L5 10L4 6L0 5L4 4Z" fill="#e879f9"/>
  </g>
  <g class="il-s3" transform="translate(52,196)">
    <path d="M5 0L6 4L10 5L6 6L5 10L4 6L0 5L4 4Z" fill="#a5b4fc"/>
  </g>

  <!-- ── NOTIFICATION TOAST (top center) ── -->
  <g class="il-ntf" transform="translate(182,2)">
    <rect x="0" y="0" width="96" height="38" rx="19" fill="white" opacity=".96" filter="url(#il-sh)"/>
    <circle cx="19" cy="19" r="11" fill="#6366f1"/>
    <text x="19" y="23" text-anchor="middle" font-size="11" fill="white" font-family="Arial,sans-serif">🔔</text>
    <rect x="34" y="11" width="50" height="5" rx="2.5" fill="#0f172a"/>
    <rect x="34" y="20" width="38" height="4" rx="2" fill="#94a3b8"/>
    <circle cx="82" cy="8" r="7" fill="#ef4444"/>
    <text x="82" y="12" text-anchor="middle" font-size="7" fill="white" font-weight="bold" font-family="Arial,sans-serif">3</text>
  </g>

  <!-- ── SALARY CARD (bottom left) ── -->
  <g class="il-d1" transform="translate(2,182)">
    <rect x="0" y="0" width="128" height="72" rx="12" fill="white" opacity=".96" filter="url(#il-sh)"/>
    <rect x="0" y="0" width="128" height="24" rx="12" fill="#6366f1"/>
    <rect x="0" y="12" width="128" height="12" fill="#6366f1"/>
    <text x="10" y="16" font-size="8" fill="white" font-weight="bold" font-family="Arial,sans-serif">Monthly Payroll</text>
    <text x="10" y="40" font-size="15" fill="#0f172a" font-weight="bold" font-family="Arial,sans-serif">ETB 48,500</text>
    <rect x="10" y="48" width="62" height="4" rx="2" fill="#e2e8f0"/>
    <rect x="10" y="48" width="46" height="4" rx="2" fill="#10b981"/>
    <text x="10" y="62" font-size="7" fill="#64748b" font-family="Arial,sans-serif">↑ 12% from last month</text>
    <circle cx="112" cy="50" r="12" fill="#ecfdf5"/>
    <text x="112" y="54" text-anchor="middle" font-size="11" fill="#10b981" font-family="Arial,sans-serif">✓</text>
  </g>

  <!-- ── ATTENDANCE CARD (bottom right) ── -->
  <g class="il-d2" transform="translate(330,192)">
    <rect x="0" y="0" width="118" height="66" rx="12" fill="white" opacity=".96" filter="url(#il-sh)"/>
    <rect x="0" y="0" width="118" height="22" rx="12" fill="#0ea5e9"/>
    <rect x="0" y="11" width="118" height="11" fill="#0ea5e9"/>
    <text x="10" y="15" font-size="7.5" fill="white" font-weight="bold" font-family="Arial,sans-serif">Today's Attendance</text>
    <rect x="10" y="28" width="13" height="28" rx="3" fill="#d1fae5"/>
    <rect x="10" y="34" width="13" height="22" rx="3" fill="#10b981"/>
    <text x="16" y="62" text-anchor="middle" font-size="6" fill="#64748b" font-family="Arial,sans-serif">P</text>
    <rect x="28" y="28" width="13" height="28" rx="3" fill="#fee2e2"/>
    <rect x="28" y="46" width="13" height="10" rx="3" fill="#ef4444"/>
    <text x="34" y="62" text-anchor="middle" font-size="6" fill="#64748b" font-family="Arial,sans-serif">A</text>
    <rect x="46" y="28" width="13" height="28" rx="3" fill="#fef3c7"/>
    <rect x="46" y="40" width="13" height="16" rx="3" fill="#f59e0b"/>
    <text x="52" y="62" text-anchor="middle" font-size="6" fill="#64748b" font-family="Arial,sans-serif">L</text>
    <text x="70" y="40" font-size="17" fill="#0f172a" font-weight="bold" font-family="Arial,sans-serif">87%</text>
    <text x="70" y="52" font-size="7" fill="#64748b" font-family="Arial,sans-serif">Present rate</text>
  </g>

</svg>
SVG;
}
