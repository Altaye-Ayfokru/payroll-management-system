<?php
/**
 * Database Configuration
 * Edit these values to match your MySQL setup
 */
return [
    'host'     => 'localhost',
    'dbname'   => 'payroll_pro',
    'username' => 'root',
    'password' => '',
];
