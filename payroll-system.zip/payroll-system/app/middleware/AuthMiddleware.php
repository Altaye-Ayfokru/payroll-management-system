<?php
class AuthMiddleware {
    public static function handle(): void {
        if (empty($_SESSION['user_id'])) {
            if (self::isAjax()) {
                http_response_code(401);
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Unauthorized', 'redirect' => BASE_URL . '/auth/login']);
                exit;
            }
            header('Location: ' . BASE_URL . '/auth/login');
            exit;
        }
    }

    public static function requireRole(string ...$roles): void {
        self::handle();
        if (!in_array($_SESSION['user_role'] ?? '', $roles)) {
            if (self::isAjax()) {
                http_response_code(403);
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Forbidden']);
                exit;
            }
            header('Location: ' . BASE_URL . '/dashboard');
            exit;
        }
    }

    private static function isAjax(): bool {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
}
