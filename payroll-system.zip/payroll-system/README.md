# PayrollPro — Ethiopian HR & Payroll Management System

A full-featured, modern HR and payroll management system built with PHP (custom MVC), MySQL, and vanilla JavaScript. Designed specifically for Ethiopian payroll rules including progressive income tax, pension contributions, and position-based allowances.

---

## Features

- **Dashboard** — Real-time KPIs, payroll trends, attendance stats, activity log
- **Employee Management** — Full CRUD, photo upload, bulk CSV import/export
- **Payroll Engine** — Ethiopian tax slabs, position allowances, transport allowances, pension (7%/11%), overtime
- **Attendance** — Check-in/out, calendar view, overtime tracking, manual entry
- **Leave Management** — Apply, approve/reject, leave balance tracking
- **Loan Management** — Apply, approve/reject, repayment tracking
- **Reports** — Salary, attendance, tax reports with CSV export and charts
- **Notifications** — Real-time bell notifications with AJAX
- **User Management** — Role-based access (Admin / HR / Employee)
- **Settings** — Tax rules, salary components, company settings
- **Dark Mode** — Full dark mode support

---

## Requirements

- PHP 8.1+
- MySQL 5.7+ / MariaDB 10.4+
- Apache with `mod_rewrite` enabled
- XAMPP / WAMP / LAMP stack

---

## Quick Setup

### 1. Clone / Copy Files

Place the project in your web server's document root:
```
C:\xampp\htdocs\payroll-system\
```

### 2. Create Database

Open phpMyAdmin and run the complete setup SQL:
```
database/setup_complete.sql
```

Or run individual migrations in order:
```
database/migrations/001_create_users_table.sql
database/migrations/002_create_employees_table.sql
...
database/migrations/008_create_loans_table.sql
```

### 3. Configure Database

Edit `app/config/database.php`:
```php
return [
    'host'     => 'localhost',
    'dbname'   => 'payroll_pro',
    'username' => 'root',
    'password' => '',  // your MySQL password
];
```

### 4. Configure Apache

The `.htaccess` file in `public/` handles URL rewriting automatically. Make sure `mod_rewrite` is enabled in Apache.

If your project is in a subdirectory (e.g., `htdocs/payroll-system/`), the `BASE_URL` is auto-detected from `$_SERVER['SCRIPT_NAME']`.

### 5. Access the Application

Open your browser:
```
http://localhost/payroll-system/public/
```

---

## Default Login Credentials

| Role  | Email                    | Password    |
|-------|--------------------------|-------------|
| Admin | admin@payrollpro.com     | password    |
| HR    | hr@payrollpro.com        | password    |

> **Note:** The setup SQL uses a bcrypt hash for `password`. To use different credentials, run `database/update_passwords.sql` or register a new account and promote it via the Users page.

---

## Ethiopian Payroll Rules

### Income Tax Brackets (Progressive)

| Taxable Income (ETB) | Rate | Deductible Fee |
|----------------------|------|----------------|
| 0 – 600              | 0%   | 0              |
| 601 – 1,650          | 10%  | 60             |
| 1,651 – 3,200        | 15%  | 142.50         |
| 3,201 – 5,250        | 20%  | 302.50         |
| 5,251 – 7,800        | 25%  | 565            |
| 7,801 – 10,900       | 30%  | 965            |
| Over 10,900          | 35%  | 1,500          |

### Position Allowances

| Position Title  | Rate | Taxable |
|-----------------|------|---------|
| CEO             | 10%  | No      |
| COO/CTO/CISO    | 8%   | Yes     |
| Director        | 7%   | Yes     |
| Dept Head       | 5%   | Yes     |
| Normal Employee | 0%   | —       |

### Transport Allowance

- Positioned employees (CEO–Dept Head): **2,220 ETB** (non-taxable)
- Normal employees: **600 ETB** (non-taxable)

### Pension

- Full-time employees only
- Employee contribution: **7%** of basic salary
- Employer contribution: **11%** of basic salary

---

## Project Structure

```
payroll-system/
├── app/
│   ├── config/          # App, database, routes config
│   ├── helpers/         # Functions, validator, avatar
│   ├── middleware/       # Auth middleware
│   ├── models/          # Base models (User)
│   ├── modules/         # Feature modules (MVC)
│   │   ├── Auth/
│   │   ├── Dashboard/
│   │   ├── Employee/
│   │   ├── Payroll/
│   │   ├── Attendance/
│   │   ├── Leave/
│   │   ├── Loan/
│   │   ├── Report/
│   │   ├── Settings/
│   │   ├── User/
│   │   └── Notification/
│   ├── services/        # Shared services
│   └── views/           # Layouts, error pages
├── core/                # Framework core (App, Router, Controller, Model, Database)
├── database/            # SQL migrations and seeds
├── public/              # Web root (index.php, assets)
│   └── assets/
│       ├── css/         # Stylesheets
│       ├── js/          # JavaScript
│       └── images/      # SVG avatars, illustrations
└── storage/             # Logs, uploaded files
    ├── logs/
    └── uploads/
        └── avatars/
```

---

## CSV Import Format

To bulk import employees, use the CSV template from **Employees → Import CSV**:

```csv
name,email,department,position,basic_salary,hire_date
John Doe,john@company.com,Engineering,Senior Developer,15000,2024-01-15
```

---

## Tech Stack

- **Backend:** PHP 8.1+ (custom MVC, no framework)
- **Database:** MySQL/MariaDB with PDO
- **Frontend:** HTML5, CSS3, Vanilla JavaScript
- **Charts:** Chart.js 4.4
- **Icons:** Font Awesome 6.5
- **Fonts:** Google Fonts (Inter)

---

## Security

- CSRF tokens on all POST requests
- Prepared statements (PDO) — SQL injection prevention
- bcrypt password hashing (cost 12)
- Session regeneration on login
- Role-based access control (Admin / HR / Employee)
- Input sanitization with `htmlspecialchars`
- File upload validation (MIME type + size)

---

## License

MIT License — Free to use and modify.
