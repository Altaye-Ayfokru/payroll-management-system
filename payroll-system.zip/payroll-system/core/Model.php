<?php
/**
 * Base Model - All models extend this
 */
abstract class Model {
    protected PDO $db;
    protected string $table = '';
    protected string $primaryKey = 'id';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function findAll(int $limit = 100, int $offset = 0): array {
        $stmt = $this->db->prepare(
            "SELECT * FROM {$this->table} LIMIT :limit OFFSET :offset"
        );
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function findById(int $id): ?array {
        $stmt = $this->db->prepare(
            "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = :id LIMIT 1"
        );
        $stmt->execute([':id' => $id]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    public function findBy(string $column, mixed $value): array {
        $stmt = $this->db->prepare(
            "SELECT * FROM {$this->table} WHERE {$column} = :value"
        );
        $stmt->execute([':value' => $value]);
        return $stmt->fetchAll();
    }

    public function findOneBy(string $column, mixed $value): ?array {
        $stmt = $this->db->prepare(
            "SELECT * FROM {$this->table} WHERE {$column} = :value LIMIT 1"
        );
        $stmt->execute([':value' => $value]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    public function insert(array $data): int {
        $columns      = implode(', ', array_keys($data));
        $placeholders = ':' . implode(', :', array_keys($data));
        $stmt = $this->db->prepare(
            "INSERT INTO {$this->table} ({$columns}) VALUES ({$placeholders})"
        );
        // Build named params with colon prefix
        $params = [];
        foreach ($data as $k => $v) {
            $params[':' . $k] = $v;
        }
        $this->bindParams($stmt, $params);
        $stmt->execute();
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool {
        $set = implode(', ', array_map(fn($k) => "{$k} = :{$k}", array_keys($data)));
        $params = $data;
        $params['id_pk'] = $id;
        $stmt = $this->db->prepare(
            "UPDATE {$this->table} SET {$set} WHERE {$this->primaryKey} = :id_pk"
        );
        $this->bindParams($stmt, $params);
        return $stmt->execute();
    }

    public function delete(int $id): bool {
        $stmt = $this->db->prepare(
            "DELETE FROM {$this->table} WHERE {$this->primaryKey} = :id"
        );
        return $stmt->execute([':id' => $id]);
    }

    public function count(): int {
        $stmt = $this->db->query("SELECT COUNT(*) FROM {$this->table}");
        return (int)$stmt->fetchColumn();
    }

    public function countBy(string $column, mixed $value): int {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM {$this->table} WHERE {$column} = :value"
        );
        $stmt->execute([':value' => $value]);
        return (int)$stmt->fetchColumn();
    }

    protected function query(string $sql, array $params = []): array {
        $stmt = $this->db->prepare($sql);
        $this->bindParams($stmt, $params);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    protected function queryOne(string $sql, array $params = []): ?array {
        $stmt = $this->db->prepare($sql);
        $this->bindParams($stmt, $params);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result ?: null;
    }

    protected function execute(string $sql, array $params = []): bool {
        $stmt = $this->db->prepare($sql);
        $this->bindParams($stmt, $params);
        return $stmt->execute();
    }

    /**
     * Bind params with correct PDO types.
     * Handles both named (:param) and positional (?) params.
     * Ensures integers are bound as PARAM_INT so LIMIT/OFFSET work in MySQL.
     */
    private function bindParams(\PDOStatement $stmt, array $params): void {
        foreach ($params as $key => $value) {
            if (is_int($key)) {
                // Positional param — 1-indexed
                $paramKey = $key + 1;
            } else {
                // Named param — ensure colon prefix
                $paramKey = str_starts_with($key, ':') ? $key : ':' . $key;
            }

            if (is_int($value)) {
                $stmt->bindValue($paramKey, $value, \PDO::PARAM_INT);
            } elseif (is_bool($value)) {
                $stmt->bindValue($paramKey, $value, \PDO::PARAM_BOOL);
            } elseif (is_null($value)) {
                $stmt->bindValue($paramKey, $value, \PDO::PARAM_NULL);
            } else {
                $stmt->bindValue($paramKey, (string)$value, \PDO::PARAM_STR);
            }
        }
    }
}
