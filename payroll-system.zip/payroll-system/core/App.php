<?php
/**
 * Core Application Bootstrap
 */
class App {
    private Router $router;

    public function __construct() {
        // Start session first — everything depends on it
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $this->router = new Router();
        $this->registerRoutes();
    }

    private function registerRoutes(): void {
        global $routes;
        foreach ($routes as $route) {
            $this->router->add(
                $route['method'],
                $route['path'],
                $route['controller'],
                $route['action']
            );
        }
    }

    public function run(): void {
        $this->router->dispatch();
    }
}
