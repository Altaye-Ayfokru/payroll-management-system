-- ============================================================
-- PayrollPro — Complete Database Setup
-- Run this file in phpMyAdmin or MySQL CLI to set up the DB
-- ============================================================

CREATE DATABASE IF NOT EXISTS `payroll_pro`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `payroll_pro`;

-- ── Users ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `users` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`       VARCHAR(120) NOT NULL,
    `email`      VARCHAR(180) NOT NULL UNIQUE,
    `password`   VARCHAR(255) NOT NULL,
    `role`       ENUM('admin','hr','employee') NOT NULL DEFAULT 'employee',
    `phone`      VARCHAR(20)  DEFAULT NULL,
    `avatar`     VARCHAR(255) DEFAULT NULL,
    `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
    `last_login` DATETIME     DEFAULT NULL,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_email`  (`email`),
    INDEX `idx_role`   (`role`),
    INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Employees ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `employees` (
    `id`                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`              INT UNSIGNED NOT NULL,
    `employee_code`        VARCHAR(20)  NOT NULL UNIQUE,
    `gender`               ENUM('male','female','other') DEFAULT 'male',
    `employment_type`      ENUM('full_time','part_time') NOT NULL DEFAULT 'full_time',
    `position_title`       ENUM('CEO','COO','CTO','CISO','Director','Dept Head','Normal Employee')
                           NOT NULL DEFAULT 'Normal Employee',
    `position`             VARCHAR(100) NOT NULL,
    `department`           VARCHAR(100) NOT NULL,
    `basic_salary`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `house_allowance`      DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `transport_allowance`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `medical_allowance`    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `other_commission`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `insurance_deduction`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `other_deductions`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `hire_date`            DATE         NOT NULL,
    `bank_name`            VARCHAR(100) DEFAULT NULL,
    `bank_account`         VARCHAR(50)  DEFAULT NULL,
    `status`               ENUM('active','inactive','terminated') NOT NULL DEFAULT 'active',
    `created_at`           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`           DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at`           DATETIME     DEFAULT NULL,
    CONSTRAINT `fk_emp_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_user_id`    (`user_id`),
    INDEX `idx_status`     (`status`),
    INDEX `idx_department` (`department`),
    INDEX `idx_deleted`    (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Attendance ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `attendance` (
    `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id`    INT UNSIGNED NOT NULL,
    `date`           DATE         NOT NULL,
    `check_in`       TIME         DEFAULT NULL,
    `check_out`      TIME         DEFAULT NULL,
    `hours_worked`   DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `overtime_hours` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `status`         ENUM('present','absent','late','half_day','holiday') NOT NULL DEFAULT 'present',
    `notes`          VARCHAR(255) DEFAULT NULL,
    `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_att_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `uq_emp_date` (`employee_id`, `date`),
    INDEX `idx_date`        (`date`),
    INDEX `idx_emp_date`    (`employee_id`, `date`),
    INDEX `idx_status`      (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Leaves ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `leaves` (
    `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id`      INT UNSIGNED NOT NULL,
    `leave_type`       ENUM('annual','sick','casual','maternity','paternity','unpaid','other') NOT NULL,
    `start_date`       DATE         NOT NULL,
    `end_date`         DATE         NOT NULL,
    `reason`           TEXT         DEFAULT NULL,
    `status`           ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
    `approved_by`      INT UNSIGNED DEFAULT NULL,
    `approved_at`      DATETIME     DEFAULT NULL,
    `rejection_reason` VARCHAR(255) DEFAULT NULL,
    `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_leave_emp`      FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_leave_approver` FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    INDEX `idx_emp_id`   (`employee_id`),
    INDEX `idx_status`   (`status`),
    INDEX `idx_dates`    (`start_date`, `end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Payroll ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `payroll` (
    `id`                          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id`                 INT UNSIGNED  NOT NULL,
    `pay_month`                   CHAR(7)       NOT NULL COMMENT 'Format: YYYY-MM',
    `basic_salary`                DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `worked_days`                 TINYINT       NOT NULL DEFAULT 0,
    `working_days`                TINYINT       NOT NULL DEFAULT 30,
    `earned_salary`               DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `position_allowance`          DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `position_allowance_taxable`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `position_allowance_nontaxable` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `transport_allowance`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `transport_allowance_taxable` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `transport_allowance_nontaxable` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `other_commission`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `house_allowance`             DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `medical_allowance`           DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `overtime_pay`                DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `overtime_hours`              DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
    `gross_salary`                DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `taxable_income`              DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `income_tax`                  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `employee_pension`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `employer_pension`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `total_pension`               DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `provident_fund`              DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `insurance`                   DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `other_deductions`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `tax`                         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `total_deductions`            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `net_salary`                  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `net_payment`                 DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `total_days`                  TINYINT       NOT NULL DEFAULT 0,
    `status`                      ENUM('pending','approved','rejected','paid') NOT NULL DEFAULT 'pending',
    `processed_by`                INT UNSIGNED  DEFAULT NULL,
    `approved_by`                 INT UNSIGNED  DEFAULT NULL,
    `approved_at`                 DATETIME      DEFAULT NULL,
    `created_at`                  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_pay_emp`       FOREIGN KEY (`employee_id`)  REFERENCES `employees`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_pay_processor` FOREIGN KEY (`processed_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_pay_approver`  FOREIGN KEY (`approved_by`)  REFERENCES `users`(`id`) ON DELETE SET NULL,
    UNIQUE KEY `uq_emp_month` (`employee_id`, `pay_month`),
    INDEX `idx_pay_month`  (`pay_month`),
    INDEX `idx_status`     (`status`),
    INDEX `idx_emp_id`     (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Tax Rules ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `tax_rules` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`        VARCHAR(100)  NOT NULL,
    `percentage`  DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
    `min_salary`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `max_salary`  DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT '0 = no upper limit',
    `is_active`   TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Salary Components ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `salary_components` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`       VARCHAR(100)  NOT NULL,
    `type`       ENUM('allowance','deduction') NOT NULL DEFAULT 'allowance',
    `amount`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `is_active`  TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_type`   (`type`),
    INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Notifications ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `notifications` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`    INT UNSIGNED NOT NULL,
    `message`    TEXT         NOT NULL,
    `type`       ENUM('info','success','warning','danger','payroll','leave') NOT NULL DEFAULT 'info',
    `is_read`    TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_user_read` (`user_id`, `is_read`),
    INDEX `idx_created`   (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Activity Logs ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `activity_logs` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`    INT UNSIGNED DEFAULT NULL,
    `action`     VARCHAR(255) NOT NULL,
    `ip_address` VARCHAR(45)  DEFAULT NULL,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user_id`  (`user_id`),
    INDEX `idx_created`  (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Settings ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `settings` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `key`         VARCHAR(100) NOT NULL UNIQUE,
    `value`       TEXT         DEFAULT NULL,
    `updated_at`  DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Loans ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `loans` (
    `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id`      INT UNSIGNED NOT NULL,
    `loan_type`        ENUM('personal','emergency','education','medical','housing','vehicle','other') NOT NULL DEFAULT 'personal',
    `amount`           DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `repayment_months` TINYINT UNSIGNED NOT NULL DEFAULT 12,
    `monthly_payment`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `reason`           TEXT DEFAULT NULL,
    `status`           ENUM('pending','approved','rejected','paid') NOT NULL DEFAULT 'pending',
    `approved_by`      INT UNSIGNED DEFAULT NULL,
    `approved_at`      DATETIME DEFAULT NULL,
    `rejection_reason` VARCHAR(255) DEFAULT NULL,
    `created_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_loan_emp`      FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_loan_approver` FOREIGN KEY (`approved_by`)  REFERENCES `users`(`id`) ON DELETE SET NULL,
    INDEX `idx_emp_id`  (`employee_id`),
    INDEX `idx_status`  (`status`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ════════════════════════════════════════════════════════════
-- SEED DATA
-- ════════════════════════════════════════════════════════════

-- Ethiopian Tax Rules
INSERT IGNORE INTO `tax_rules` (`name`, `percentage`, `min_salary`, `max_salary`, `is_active`) VALUES
('Exempt (0–600)',       0,   0.00,      600.00,   1),
('10% (601–1,650)',     10, 601.00,    1650.00,   1),
('15% (1,651–3,200)',   15, 1651.00,   3200.00,   1),
('20% (3,201–5,250)',   20, 3201.00,   5250.00,   1),
('25% (5,251–7,800)',   25, 5251.00,   7800.00,   1),
('30% (7,801–10,900)',  30, 7801.00,  10900.00,   1),
('35% (Over 10,900)',   35, 10901.00,     0.00,   1);

-- Default Settings
INSERT IGNORE INTO `settings` (`key`, `value`) VALUES
('company_name',    'PayrollPro Inc.'),
('company_email',   'hr@payrollpro.com'),
('company_phone',   '+251 11 123 4567'),
('company_address', 'Addis Ababa, Ethiopia'),
('currency_symbol', 'ETB'),
('work_start_time', '09:00'),
('work_end_time',   '18:00'),
('working_days',    '30'),
('overtime_rate',   '1.5');

-- ════════════════════════════════════════════════════════════
-- DEFAULT ADMIN ACCOUNT
-- Email: admin@payrollpro.com
-- Password: Admin@123
-- ════════════════════════════════════════════════════════════
INSERT IGNORE INTO `users` (`name`, `email`, `password`, `role`, `is_active`, `created_at`) VALUES
('System Admin', 'admin@payrollpro.com',
 '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'admin', 1, NOW());

-- HR Account: hr@payrollpro.com / HR@123456
INSERT IGNORE INTO `users` (`name`, `email`, `password`, `role`, `is_active`, `created_at`) VALUES
('HR Manager', 'hr@payrollpro.com',
 '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'hr', 1, NOW());
