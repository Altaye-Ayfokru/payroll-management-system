-- ============================================================
-- Sample Data Seed
-- Run AFTER all migrations
-- ============================================================

-- Default admin user  (password: Admin@123)
INSERT INTO `users` (`name`, `email`, `password`, `role`) VALUES
('System Admin',   'admin@payrollpro.com',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('HR Manager',     'hr@payrollpro.com',     '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'hr'),
('John Smith',     'john@payrollpro.com',   '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employee'),
('Sarah Johnson',  'sarah@payrollpro.com',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employee'),
('Mike Davis',     'mike@payrollpro.com',   '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employee'),
('Emily Chen',     'emily@payrollpro.com',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employee'),
('Robert Brown',   'robert@payrollpro.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employee');

-- Employees
INSERT INTO `employees` (`user_id`,`employee_code`,`position`,`department`,`basic_salary`,`house_allowance`,`transport_allowance`,`medical_allowance`,`insurance_deduction`,`hire_date`,`bank_name`,`bank_account`,`status`) VALUES
(3,  'EMP0001', 'Software Engineer',    'Engineering',  75000.00, 15000.00, 5000.00, 3000.00, 2000.00, '2022-03-15', 'City Bank',    '1234567890', 'active'),
(4,  'EMP0002', 'UI/UX Designer',       'Design',       65000.00, 12000.00, 4000.00, 2500.00, 1500.00, '2022-06-01', 'Trust Bank',   '2345678901', 'active'),
(5,  'EMP0003', 'Project Manager',      'Management',   90000.00, 18000.00, 6000.00, 4000.00, 2500.00, '2021-11-20', 'Dutch Bangla', '3456789012', 'active'),
(6,  'EMP0004', 'Data Analyst',         'Analytics',    70000.00, 14000.00, 4500.00, 3000.00, 2000.00, '2023-01-10', 'BRAC Bank',    '4567890123', 'active'),
(7,  'EMP0005', 'DevOps Engineer',      'Engineering',  80000.00, 16000.00, 5500.00, 3500.00, 2200.00, '2022-09-05', 'City Bank',    '5678901234', 'active');

-- Tax Rules
INSERT INTO `tax_rules` (`name`, `percentage`, `min_salary`, `max_salary`, `is_active`) VALUES
('Tax Free',       0.00,  0.00,      25000.00, 1),
('Basic Tax',      5.00,  25001.00,  50000.00, 1),
('Standard Tax',  10.00,  50001.00,  80000.00, 1),
('Higher Tax',    15.00,  80001.00, 120000.00, 1),
('Top Rate Tax',  20.00, 120001.00,      0.00, 1);

-- Salary Components
INSERT INTO `salary_components` (`name`, `type`, `amount`, `is_active`) VALUES
('House Allowance',      'allowance',  15000.00, 1),
('Transport Allowance',  'allowance',   5000.00, 1),
('Medical Allowance',    'allowance',   3000.00, 1),
('Performance Bonus',    'allowance',  10000.00, 1),
('Provident Fund',       'deduction',   3750.00, 1),
('Health Insurance',     'deduction',   2000.00, 1),
('Income Tax',           'deduction',   5000.00, 1);

-- Default Settings
INSERT INTO `settings` (`key`, `value`) VALUES
('company_name',      'PayrollPro Inc.'),
('company_address',   '123 Business Ave, Tech City'),
('company_email',     'hr@payrollpro.com'),
('company_phone',     '+1-555-0100'),
('currency_symbol',   '$'),
('work_start_time',   '09:00'),
('work_end_time',     '18:00'),
('late_threshold',    '09:15'),
('overtime_rate',     '1.5'),
('payroll_day',       '25'),
('fiscal_year_start', '01');
