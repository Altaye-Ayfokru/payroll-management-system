-- ============================================================
-- Migration 002: Employees Table
-- ============================================================
CREATE TABLE IF NOT EXISTS `employees` (
    `id`                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`              INT UNSIGNED NOT NULL,
    `employee_code`        VARCHAR(20)  NOT NULL UNIQUE,
    `position`             VARCHAR(100) NOT NULL,
    `department`           VARCHAR(100) NOT NULL,
    `basic_salary`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `house_allowance`      DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `transport_allowance`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `medical_allowance`    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `insurance_deduction`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `other_deductions`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `hire_date`            DATE         NOT NULL,
    `bank_name`            VARCHAR(100) DEFAULT NULL,
    `bank_account`         VARCHAR(50)  DEFAULT NULL,
    `status`               ENUM('active','inactive','terminated') NOT NULL DEFAULT 'active',
    `created_at`           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`           DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at`           DATETIME     DEFAULT NULL,
    CONSTRAINT `fk_emp_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_user_id`    (`user_id`),
    INDEX `idx_status`     (`status`),
    INDEX `idx_department` (`department`),
    INDEX `idx_deleted`    (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
