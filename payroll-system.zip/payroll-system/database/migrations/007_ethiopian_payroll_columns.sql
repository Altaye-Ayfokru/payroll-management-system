-- ============================================================
-- Migration 007: Ethiopian Payroll — extend employees & payroll tables
-- Run this in phpMyAdmin AFTER the existing migrations
-- ============================================================

USE `payroll_pro`;

-- ── Extend employees table ──────────────────────────────────
ALTER TABLE `employees`
  ADD COLUMN IF NOT EXISTS `gender`           ENUM('male','female','other') DEFAULT 'male'          AFTER `user_id`,
  ADD COLUMN IF NOT EXISTS `employment_type`  ENUM('full_time','part_time') NOT NULL DEFAULT 'full_time' AFTER `gender`,
  ADD COLUMN IF NOT EXISTS `position_title`   ENUM('CEO','COO','CTO','CISO','Director','Dept Head','Normal Employee')
                                              NOT NULL DEFAULT 'Normal Employee'                     AFTER `employment_type`,
  ADD COLUMN IF NOT EXISTS `other_commission` DECIMAL(12,2) NOT NULL DEFAULT 0.00                   AFTER `medical_allowance`;

-- ── Extend payroll table with Ethiopian-specific columns ────
ALTER TABLE `payroll`
  ADD COLUMN IF NOT EXISTS `working_days`                  TINYINT       NOT NULL DEFAULT 30         AFTER `worked_days`,
  ADD COLUMN IF NOT EXISTS `earned_salary`                 DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `working_days`,
  ADD COLUMN IF NOT EXISTS `position_allowance`            DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `earned_salary`,
  ADD COLUMN IF NOT EXISTS `position_allowance_taxable`    DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `position_allowance`,
  ADD COLUMN IF NOT EXISTS `position_allowance_nontaxable` DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `position_allowance_taxable`,
  ADD COLUMN IF NOT EXISTS `transport_allowance_taxable`   DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `position_allowance_nontaxable`,
  ADD COLUMN IF NOT EXISTS `transport_allowance_nontaxable`DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `transport_allowance_taxable`,
  ADD COLUMN IF NOT EXISTS `other_commission`              DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `transport_allowance_nontaxable`,
  ADD COLUMN IF NOT EXISTS `taxable_income`                DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `other_commission`,
  ADD COLUMN IF NOT EXISTS `income_tax`                    DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `taxable_income`,
  ADD COLUMN IF NOT EXISTS `employee_pension`              DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `income_tax`,
  ADD COLUMN IF NOT EXISTS `employer_pension`              DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `employee_pension`,
  ADD COLUMN IF NOT EXISTS `total_pension`                 DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `employer_pension`,
  ADD COLUMN IF NOT EXISTS `net_payment`                   DECIMAL(12,2) NOT NULL DEFAULT 0.00       AFTER `total_pension`;

-- ── Update Ethiopian tax rules ──────────────────────────────
DELETE FROM `tax_rules`;

INSERT INTO `tax_rules` (`name`, `percentage`, `min_salary`, `max_salary`, `is_active`) VALUES
('Exempt (0–600)',          0,   0.00,      600.00,   1),
('10% (601–1,650)',        10, 601.00,    1650.00,   1),
('15% (1,651–3,200)',      15, 1651.00,   3200.00,   1),
('20% (3,201–5,250)',      20, 3201.00,   5250.00,   1),
('25% (5,251–7,800)',      25, 5251.00,   7800.00,   1),
('30% (7,801–10,900)',     30, 7801.00,  10900.00,   1),
('35% (Over 10,900)',      35, 10901.00,     0.00,   1);
