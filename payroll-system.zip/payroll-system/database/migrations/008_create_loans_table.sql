-- ============================================================
-- Migration 008: Create loans table
-- ============================================================

CREATE TABLE IF NOT EXISTS `loans` (
    `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id`      INT UNSIGNED NOT NULL,
    `loan_type`        ENUM('personal','emergency','education','medical','housing','vehicle','other') NOT NULL DEFAULT 'personal',
    `amount`           DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `repayment_months` TINYINT UNSIGNED NOT NULL DEFAULT 12,
    `monthly_payment`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `reason`           TEXT DEFAULT NULL,
    `status`           ENUM('pending','approved','rejected','paid') NOT NULL DEFAULT 'pending',
    `approved_by`      INT UNSIGNED DEFAULT NULL,
    `approved_at`      DATETIME DEFAULT NULL,
    `rejection_reason` VARCHAR(255) DEFAULT NULL,
    `created_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_loan_emp`      FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_loan_approver` FOREIGN KEY (`approved_by`)  REFERENCES `users`(`id`) ON DELETE SET NULL,
    INDEX `idx_emp_id`  (`employee_id`),
    INDEX `idx_status`  (`status`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
