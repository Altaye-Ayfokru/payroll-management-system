-- ============================================================
-- Migration 004: Leaves Table
-- ============================================================
CREATE TABLE IF NOT EXISTS `leaves` (
    `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id`      INT UNSIGNED NOT NULL,
    `leave_type`       ENUM('annual','sick','casual','maternity','paternity','unpaid','other') NOT NULL,
    `start_date`       DATE         NOT NULL,
    `end_date`         DATE         NOT NULL,
    `reason`           TEXT         DEFAULT NULL,
    `status`           ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
    `approved_by`      INT UNSIGNED DEFAULT NULL,
    `approved_at`      DATETIME     DEFAULT NULL,
    `rejection_reason` VARCHAR(255) DEFAULT NULL,
    `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_leave_emp`      FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_leave_approver` FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    INDEX `idx_emp_id`   (`employee_id`),
    INDEX `idx_status`   (`status`),
    INDEX `idx_dates`    (`start_date`, `end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
