-- ============================================================
-- Migration 003: Attendance Table
-- ============================================================
CREATE TABLE IF NOT EXISTS `attendance` (
    `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id`    INT UNSIGNED NOT NULL,
    `date`           DATE         NOT NULL,
    `check_in`       TIME         DEFAULT NULL,
    `check_out`      TIME         DEFAULT NULL,
    `hours_worked`   DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `overtime_hours` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `status`         ENUM('present','absent','late','half_day','holiday') NOT NULL DEFAULT 'present',
    `notes`          VARCHAR(255) DEFAULT NULL,
    `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_att_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `uq_emp_date` (`employee_id`, `date`),
    INDEX `idx_date`        (`date`),
    INDEX `idx_emp_date`    (`employee_id`, `date`),
    INDEX `idx_status`      (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
