-- ============================================================
-- PayrollPro — Fix user passwords
-- Run this in phpMyAdmin if you already imported setup.sql
-- OR just re-import setup.sql from scratch (recommended)
-- ============================================================

USE `payroll_pro`;

-- Admin@123
UPDATE `users` SET `password` = '$2y$10$t6bLyTbbyl6u.0B54d2w0e.DfUZdBAVjqR2294XoEzElpECjaFY5K'
WHERE `email` = 'admin@payrollpro.com';

-- Hr@123
UPDATE `users` SET `password` = '$2y$10$UGKpVuNoB4SVNAPIu8fROOa9kTgaKvFxm6ID4Jq/NpG4RcAAQOLxu'
WHERE `email` = 'hr@payrollpro.com';

-- Emp@123 (all employees)
UPDATE `users` SET `password` = '$2y$10$NnCs3DLHLuM1bfW6k4wJZu0bzuXa5NkAX3fQlSChzUX1JMOf/IhoC'
WHERE `email` IN (
    'john@payrollpro.com',
    'sarah@payrollpro.com',
    'mike@payrollpro.com',
    'emily@payrollpro.com',
    'robert@payrollpro.com'
);

SELECT email, role, SUBSTRING(password,1,20) AS hash_preview FROM users;
