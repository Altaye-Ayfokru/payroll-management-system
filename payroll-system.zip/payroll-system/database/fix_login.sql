-- ============================================================
-- PayrollPro — Fix Login Passwords
-- Run this in phpMyAdmin → Import tab
-- This updates passwords in your EXISTING database
-- ============================================================

USE `payroll_pro`;

-- Update admin password to: Admin123
UPDATE `users` SET `password` = '$2y$10$tRr6Os7FtuToElKJG2muwe9msgalP/EVC15D7qwmvBUQbcdo4/tei',
                   `is_active` = 1
WHERE `email` = 'admin@payrollpro.com';

-- Update HR password to: Hr1234
UPDATE `users` SET `password` = '$2y$10$QRabCthO4sQ60PZUIUsFHuz/kvyJONyLzr7Z/C7pEMNGQqyjIx0uu',
                   `is_active` = 1
WHERE `email` = 'hr@payrollpro.com';

-- Update employee passwords to: John123 / Sarah123 / Mike123 / Emily123 / Robert123
UPDATE `users` SET `password` = '$2y$10$vopgRmiEKNb0wpzlvHf6Wu.ysEUQBdXpYlCktKlfYX6lamkb35YPC',
                   `is_active` = 1
WHERE `email` = 'john@payrollpro.com';

UPDATE `users` SET `password` = '$2y$10$TjvJ4FYdw47EUQNBQJiJPeSJMUN.iSoWrFOTidyfMkKJjIpXcKnGy',
                   `is_active` = 1
WHERE `email` = 'sarah@payrollpro.com';

UPDATE `users` SET `password` = '$2y$10$ZdQ5rRoBXach8jM4RbqZxOV3SSoF8qitEXe/lOBo0MqQ/Xpu.bjh.',
                   `is_active` = 1
WHERE `email` = 'mike@payrollpro.com';

UPDATE `users` SET `password` = '$2y$10$v3bFuBwKtuXq13wJ5dpoFOIjE7FtHmDcztl04ZBDSuEsgosLQjmqm',
                   `is_active` = 1
WHERE `email` = 'emily@payrollpro.com';

UPDATE `users` SET `password` = '$2y$10$9qtNC2ZaZQTohoDog6pnWOXozaAS8Xj0V/gNJC2ArYpnmDfW6uJUO',
                   `is_active` = 1
WHERE `email` = 'robert@payrollpro.com';

-- If users don't exist yet, insert them
INSERT IGNORE INTO `users` (`name`, `email`, `password`, `role`, `is_active`) VALUES
('System Admin',  'admin@payrollpro.com',  '$2y$10$tRr6Os7FtuToElKJG2muwe9msgalP/EVC15D7qwmvBUQbcdo4/tei', 'admin',    1),
('HR Manager',    'hr@payrollpro.com',     '$2y$10$QRabCthO4sQ60PZUIUsFHuz/kvyJONyLzr7Z/C7pEMNGQqyjIx0uu', 'hr',       1),
('John Smith',    'john@payrollpro.com',   '$2y$10$vopgRmiEKNb0wpzlvHf6Wu.ysEUQBdXpYlCktKlfYX6lamkb35YPC', 'employee', 1),
('Sarah Johnson', 'sarah@payrollpro.com',  '$2y$10$TjvJ4FYdw47EUQNBQJiJPeSJMUN.iSoWrFOTidyfMkKJjIpXcKnGy', 'employee', 1),
('Mike Davis',    'mike@payrollpro.com',   '$2y$10$ZdQ5rRoBXach8jM4RbqZxOV3SSoF8qitEXe/lOBo0MqQ/Xpu.bjh.', 'employee', 1),
('Emily Chen',    'emily@payrollpro.com',  '$2y$10$v3bFuBwKtuXq13wJ5dpoFOIjE7FtHmDcztl04ZBDSuEsgosLQjmqm', 'employee', 1),
('Robert Brown',  'robert@payrollpro.com', '$2y$10$9qtNC2ZaZQTohoDog6pnWOXozaAS8Xj0V/gNJC2ArYpnmDfW6uJUO', 'employee', 1);

-- Verify the fix worked
SELECT email, role, is_active,
       CASE WHEN password LIKE '$2y$10$tRr6%' THEN 'Admin123 ✓'
            WHEN password LIKE '$2y$10$QRab%' THEN 'Hr1234 ✓'
            WHEN password LIKE '$2y$10$vopg%' THEN 'John123 ✓'
            ELSE 'Other hash'
       END AS password_status
FROM users
ORDER BY role, email;
