-- ============================================================
-- PayrollPro — Complete Database Setup (phpMyAdmin compatible)
-- Import this single file in phpMyAdmin to set everything up
-- ============================================================

CREATE DATABASE IF NOT EXISTS `payroll_pro`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `payroll_pro`;

-- ============================================================
-- TABLE: users
-- ============================================================
CREATE TABLE IF NOT EXISTS `users` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`       VARCHAR(120) NOT NULL,
    `email`      VARCHAR(180) NOT NULL UNIQUE,
    `password`   VARCHAR(255) NOT NULL,
    `role`       ENUM('admin','hr','employee') NOT NULL DEFAULT 'employee',
    `phone`      VARCHAR(20)  DEFAULT NULL,
    `avatar`     VARCHAR(255) DEFAULT NULL,
    `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
    `last_login` DATETIME     DEFAULT NULL,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_email`  (`email`),
    INDEX `idx_role`   (`role`),
    INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: employees
-- ============================================================
CREATE TABLE IF NOT EXISTS `employees` (
    `id`                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`              INT UNSIGNED NOT NULL,
    `gender`               ENUM('male','female','other') DEFAULT 'male',
    `employment_type`      ENUM('full_time','part_time') NOT NULL DEFAULT 'full_time',
    `position_title`       ENUM('CEO','COO','CTO','CISO','Director','Dept Head','Normal Employee') NOT NULL DEFAULT 'Normal Employee',
    `employee_code`        VARCHAR(20)  NOT NULL UNIQUE,
    `position`             VARCHAR(100) NOT NULL,
    `department`           VARCHAR(100) NOT NULL,
    `basic_salary`         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `house_allowance`      DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `transport_allowance`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `medical_allowance`    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `other_commission`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `insurance_deduction`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `other_deductions`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `hire_date`            DATE         NOT NULL,
    `bank_name`            VARCHAR(100) DEFAULT NULL,
    `bank_account`         VARCHAR(50)  DEFAULT NULL,
    `status`               ENUM('active','inactive','terminated') NOT NULL DEFAULT 'active',
    `created_at`           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`           DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at`           DATETIME     DEFAULT NULL,
    CONSTRAINT `fk_emp_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_user_id`    (`user_id`),
    INDEX `idx_status`     (`status`),
    INDEX `idx_department` (`department`),
    INDEX `idx_deleted`    (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: attendance
-- ============================================================
CREATE TABLE IF NOT EXISTS `attendance` (
    `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id`    INT UNSIGNED NOT NULL,
    `date`           DATE         NOT NULL,
    `check_in`       TIME         DEFAULT NULL,
    `check_out`      TIME         DEFAULT NULL,
    `hours_worked`   DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `overtime_hours` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `status`         ENUM('present','absent','late','half_day','holiday') NOT NULL DEFAULT 'present',
    `notes`          VARCHAR(255) DEFAULT NULL,
    `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_att_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `uq_emp_date` (`employee_id`, `date`),
    INDEX `idx_date`     (`date`),
    INDEX `idx_emp_date` (`employee_id`, `date`),
    INDEX `idx_status`   (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: leaves
-- ============================================================
CREATE TABLE IF NOT EXISTS `leaves` (
    `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id`      INT UNSIGNED NOT NULL,
    `leave_type`       ENUM('annual','sick','casual','maternity','paternity','unpaid','other') NOT NULL,
    `start_date`       DATE         NOT NULL,
    `end_date`         DATE         NOT NULL,
    `reason`           TEXT         DEFAULT NULL,
    `status`           ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
    `approved_by`      INT UNSIGNED DEFAULT NULL,
    `approved_at`      DATETIME     DEFAULT NULL,
    `rejection_reason` VARCHAR(255) DEFAULT NULL,
    `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_leave_emp`      FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_leave_approver` FOREIGN KEY (`approved_by`)  REFERENCES `users`(`id`) ON DELETE SET NULL,
    INDEX `idx_emp_id` (`employee_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_dates`  (`start_date`, `end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: payroll
-- ============================================================
CREATE TABLE IF NOT EXISTS `payroll` (
    `id`                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id`         INT UNSIGNED  NOT NULL,
    `pay_month`           CHAR(7)       NOT NULL COMMENT 'Format: YYYY-MM',
    `basic_salary`        DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `house_allowance`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `transport_allowance` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `medical_allowance`   DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `overtime_pay`        DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `gross_salary`        DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `provident_fund`      DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `insurance`           DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `other_deductions`    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `tax`                 DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `total_deductions`    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `net_salary`          DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `worked_days`         TINYINT       NOT NULL DEFAULT 0,
    `total_days`          TINYINT       NOT NULL DEFAULT 0,
    `overtime_hours`      DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
    `status`              ENUM('pending','approved','rejected','paid') NOT NULL DEFAULT 'pending',
    `processed_by`        INT UNSIGNED  DEFAULT NULL,
    `approved_by`         INT UNSIGNED  DEFAULT NULL,
    `approved_at`         DATETIME      DEFAULT NULL,
    `created_at`          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_pay_emp`       FOREIGN KEY (`employee_id`)  REFERENCES `employees`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_pay_processor` FOREIGN KEY (`processed_by`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_pay_approver`  FOREIGN KEY (`approved_by`)  REFERENCES `users`(`id`) ON DELETE SET NULL,
    UNIQUE KEY `uq_emp_month` (`employee_id`, `pay_month`),
    INDEX `idx_pay_month` (`pay_month`),
    INDEX `idx_status`    (`status`),
    INDEX `idx_emp_id`    (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: tax_rules
-- ============================================================
CREATE TABLE IF NOT EXISTS `tax_rules` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`       VARCHAR(100)  NOT NULL,
    `percentage` DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
    `min_salary` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `max_salary` DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT '0 = no upper limit',
    `is_active`  TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: salary_components
-- ============================================================
CREATE TABLE IF NOT EXISTS `salary_components` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`       VARCHAR(100)  NOT NULL,
    `type`       ENUM('allowance','deduction') NOT NULL DEFAULT 'allowance',
    `amount`     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    `is_active`  TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_type`   (`type`),
    INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: notifications
-- ============================================================
CREATE TABLE IF NOT EXISTS `notifications` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`    INT UNSIGNED NOT NULL,
    `message`    TEXT         NOT NULL,
    `type`       ENUM('info','success','warning','danger','payroll','leave') NOT NULL DEFAULT 'info',
    `is_read`    TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_user_read` (`user_id`, `is_read`),
    INDEX `idx_created`   (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: activity_logs
-- ============================================================
CREATE TABLE IF NOT EXISTS `activity_logs` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`    INT UNSIGNED DEFAULT NULL,
    `action`     VARCHAR(255) NOT NULL,
    `ip_address` VARCHAR(45)  DEFAULT NULL,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: settings
-- ============================================================
CREATE TABLE IF NOT EXISTS `settings` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `key`        VARCHAR(100) NOT NULL UNIQUE,
    `value`      TEXT         DEFAULT NULL,
    `updated_at` DATETIME     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SEED: Default users
-- Passwords (letters + numbers):
--   Admin    => Admin123
--   HR       => Hr1234
--   Employee => John123 / Sarah123 / Mike123 / Emily123 / Robert123
-- ============================================================
INSERT INTO `users` (`name`, `email`, `password`, `role`, `is_active`) VALUES
('System Admin',  'admin@payrollpro.com',  '$2y$10$raEEz1jD9HrgpzQe.WXpWuSoWcINd6OCayOC1b81xDWaKQCAHGFCm', 'admin',    1),
('HR Manager',    'hr@payrollpro.com',     '$2y$10$m2aSSnJszz3.TkNTuvcpP.XqEAGqEHDK7DAVDpFo/Hp1S7y3qdJWG', 'hr',       1),
('John Smith',    'john@payrollpro.com',   '$2y$10$.R65k.i0yVGN2f4fHJtl7OaOJcQRqP7/MfEBzDjpUqi.ntKALMu/G', 'employee', 1),
('Sarah Johnson', 'sarah@payrollpro.com',  '$2y$10$4clBl6Q.r97/T2O/av0tRuZIOUUyfIz08ehatLB7dKeChqSTcVUby', 'employee', 1),
('Mike Davis',    'mike@payrollpro.com',   '$2y$10$joTMUE1ZFSUZvAqeD9hUwe11dRhFjNQb9siReP064GxDWaXlj.w9q', 'employee', 1),
('Emily Chen',    'emily@payrollpro.com',  '$2y$10$qX77SSP/2q/1ObBGqxhmJ.nhy9a7dkqn7rQ.YyPdqKT13LY3vZQwq', 'employee', 1),
('Robert Brown',  'robert@payrollpro.com', '$2y$10$n055AB6Zk/GDuvMLX9HCQukxyOXL.3PkbSK7nJxBXJMnUps3W2OuK', 'employee', 1);

-- ============================================================
-- SEED: Employees
-- ============================================================
INSERT INTO `employees`
  (`user_id`, `employee_code`, `position`, `department`,
   `basic_salary`, `house_allowance`, `transport_allowance`,
   `medical_allowance`, `insurance_deduction`, `hire_date`,
   `bank_name`, `bank_account`, `status`)
VALUES
(3, 'EMP0001', 'Software Engineer',  'Engineering', 75000.00, 15000.00, 5000.00, 3000.00, 2000.00, '2022-03-15', 'City Bank',    '1234567890', 'active'),
(4, 'EMP0002', 'UI/UX Designer',     'Design',      65000.00, 12000.00, 4000.00, 2500.00, 1500.00, '2022-06-01', 'Trust Bank',   '2345678901', 'active'),
(5, 'EMP0003', 'Project Manager',    'Management',  90000.00, 18000.00, 6000.00, 4000.00, 2500.00, '2021-11-20', 'Dutch Bangla', '3456789012', 'active'),
(6, 'EMP0004', 'Data Analyst',       'Analytics',   70000.00, 14000.00, 4500.00, 3000.00, 2000.00, '2023-01-10', 'BRAC Bank',    '4567890123', 'active'),
(7, 'EMP0005', 'DevOps Engineer',    'Engineering', 80000.00, 16000.00, 5500.00, 3500.00, 2200.00, '2022-09-05', 'City Bank',    '5678901234', 'active');

-- ============================================================
-- SEED: Tax Rules (Ethiopian Income Tax Law)
-- ============================================================
INSERT INTO `tax_rules` (`name`, `percentage`, `min_salary`, `max_salary`, `is_active`) VALUES
('Exempt (0–600 ETB)',       0,      0.00,     600.00, 1),
('10% (601–1,650 ETB)',     10,    601.00,    1650.00, 1),
('15% (1,651–3,200 ETB)',   15,   1651.00,    3200.00, 1),
('20% (3,201–5,250 ETB)',   20,   3201.00,    5250.00, 1),
('25% (5,251–7,800 ETB)',   25,   5251.00,    7800.00, 1),
('30% (7,801–10,900 ETB)',  30,   7801.00,   10900.00, 1),
('35% (Over 10,900 ETB)',   35,  10901.00,       0.00, 1);

-- ============================================================
-- SEED: Salary Components
-- ============================================================
INSERT INTO `salary_components` (`name`, `type`, `amount`, `is_active`) VALUES
('House Allowance',     'allowance', 15000.00, 1),
('Transport Allowance', 'allowance',  5000.00, 1),
('Medical Allowance',   'allowance',  3000.00, 1),
('Performance Bonus',   'allowance', 10000.00, 1),
('Provident Fund',      'deduction',  3750.00, 1),
('Health Insurance',    'deduction',  2000.00, 1),
('Income Tax',          'deduction',  5000.00, 1);

-- ============================================================
-- SEED: Settings
-- ============================================================
INSERT INTO `settings` (`key`, `value`) VALUES
('company_name',      'PayrollPro Inc.'),
('company_address',   '123 Business Ave, Tech City'),
('company_email',     'hr@payrollpro.com'),
('company_phone',     '+1-555-0100'),
('currency_symbol',   '$'),
('work_start_time',   '09:00'),
('work_end_time',     '18:00'),
('late_threshold',    '09:15'),
('overtime_rate',     '1.5'),
('payroll_day',       '25'),
('fiscal_year_start', '01');

-- ============================================================
-- SEED: Sample attendance for current month
-- ============================================================
INSERT INTO `attendance` (`employee_id`, `date`, `check_in`, `check_out`, `hours_worked`, `overtime_hours`, `status`) VALUES
(1, CURDATE(),                    '08:55:00', NULL,       0.00, 0.00, 'present'),
(2, CURDATE(),                    '09:05:00', NULL,       0.00, 0.00, 'present'),
(3, CURDATE(),                    '09:20:00', NULL,       0.00, 0.00, 'late'),
(1, DATE_SUB(CURDATE(), INTERVAL 1 DAY), '08:50:00', '17:55:00', 9.08, 1.08, 'present'),
(2, DATE_SUB(CURDATE(), INTERVAL 1 DAY), '09:00:00', '18:00:00', 9.00, 1.00, 'present'),
(3, DATE_SUB(CURDATE(), INTERVAL 1 DAY), '09:15:00', '18:10:00', 8.92, 0.92, 'present'),
(4, DATE_SUB(CURDATE(), INTERVAL 1 DAY), '08:45:00', '17:45:00', 9.00, 1.00, 'present'),
(5, DATE_SUB(CURDATE(), INTERVAL 1 DAY), NULL,       NULL,       0.00, 0.00, 'absent'),
(1, DATE_SUB(CURDATE(), INTERVAL 2 DAY), '09:00:00', '18:30:00', 9.50, 1.50, 'present'),
(2, DATE_SUB(CURDATE(), INTERVAL 2 DAY), '09:10:00', '18:00:00', 8.83, 0.83, 'late'),
(3, DATE_SUB(CURDATE(), INTERVAL 2 DAY), '08:55:00', '18:00:00', 9.08, 1.08, 'present'),
(4, DATE_SUB(CURDATE(), INTERVAL 2 DAY), '09:00:00', '17:00:00', 8.00, 0.00, 'present'),
(5, DATE_SUB(CURDATE(), INTERVAL 2 DAY), '09:05:00', '18:05:00', 9.00, 1.00, 'present');

-- ============================================================
-- SEED: Sample leave requests
-- ============================================================
INSERT INTO `leaves` (`employee_id`, `leave_type`, `start_date`, `end_date`, `reason`, `status`) VALUES
(1, 'annual',  DATE_ADD(CURDATE(), INTERVAL 7  DAY), DATE_ADD(CURDATE(), INTERVAL 9  DAY), 'Family vacation',    'approved'),
(2, 'sick',    DATE_SUB(CURDATE(), INTERVAL 3  DAY), DATE_SUB(CURDATE(), INTERVAL 2  DAY), 'Fever and cold',     'approved'),
(3, 'casual',  DATE_ADD(CURDATE(), INTERVAL 14 DAY), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'Personal errand',    'pending'),
(4, 'annual',  DATE_ADD(CURDATE(), INTERVAL 21 DAY), DATE_ADD(CURDATE(), INTERVAL 25 DAY), 'Holiday trip',       'pending'),
(5, 'sick',    DATE_SUB(CURDATE(), INTERVAL 10 DAY), DATE_SUB(CURDATE(), INTERVAL 8  DAY), 'Medical appointment','approved');

-- ============================================================
-- SEED: Sample notifications
-- ============================================================
INSERT INTO `notifications` (`user_id`, `message`, `type`, `is_read`) VALUES
(1, 'Welcome to PayrollPro! System is ready.',                          'success', 0),
(1, 'John Smith applied for annual leave.',                             'info',    0),
(1, 'Emily Chen applied for annual leave.',                             'info',    0),
(2, 'Welcome to PayrollPro! You have HR access.',                       'success', 0),
(2, 'Robert Brown applied for sick leave.',                             'info',    0),
(3, 'Your annual leave (7 days) has been approved.',                    'success', 0),
(4, 'Your sick leave has been approved.',                               'success', 1),
(5, 'Your leave request is pending approval.',                          'info',    0);

-- ============================================================
-- SEED: Sample activity log
-- ============================================================
INSERT INTO `activity_logs` (`user_id`, `action`, `ip_address`) VALUES
(1, 'System Admin logged in',          '127.0.0.1'),
(2, 'HR Manager logged in',            '127.0.0.1'),
(2, 'Created employee EMP0001',        '127.0.0.1'),
(2, 'Created employee EMP0002',        '127.0.0.1'),
(2, 'Created employee EMP0003',        '127.0.0.1'),
(1, 'Updated tax rules',               '127.0.0.1'),
(2, 'Approved leave #2',               '127.0.0.1');
